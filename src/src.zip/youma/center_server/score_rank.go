package main

import (
	"libs/log"
	"libs/server_conn"
	"libs/timer"
	"public_message/gen_go/server_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	SMALL_RANK_CACHE_SEC       = 1  // 排行榜请求接过缓存时间
	SMALL_RANK_CACHE_ITEM_LEN  = 50 // 排行榜缓存一个组的长度
	SMALL_RANK_CACHE_GROUP_NUM = 4  // 排行榜缓存4个组

	DEFAULT_SMALL_RANK_LEN = 200

	SCORE_RANK_MGR_SWITCH_CHK_FRAME = 1200 // 每一分钟检查一次
)

type PosSmallRankInfo struct {
	small_rank      *SmallRankService
	last_cache_unix int32
	rank_msgs       []*msg_server_message.RetRankItems
}

type ScoreRankMgr struct {
	player_n_score_rank *SmallRankService
	last_pr_cache_unix  int32
	p_n_score_ranks     []*msg_server_message.RetRankItems

	tong_score_rank    *SmallRankService
	tong_score_ranks   []*msg_server_message.RetRankItems
	last_tr_cache_unix int32
	pos2tonglocalranks map[int32]*PosSmallRankInfo

	last_switch_chk_frame      int32
	last_switch_day            int32
	last_n_score_ranks         []*msg_server_message.RetRankItems
	last_n_score_rank_msg_top3 *msg_server_message.RetRankItems
}

var score_rank_mgr ScoreRankMgr

func (this *ScoreRankMgr) Init() bool {

	this.player_n_score_rank = NewSmallRankService(DEFAULT_SMALL_RANK_LEN, SMALL_RANK_TYPE_PLAYER_N_SCORE, SMALL_RANK_SORT_TYPE_B)
	this.tong_score_rank = NewSmallRankService(DEFAULT_SMALL_RANK_LEN, SMALL_RANK_TYPE_TONG_SCORE, SMALL_RANK_SORT_TYPE_B)
	this.p_n_score_ranks = make([]*msg_server_message.RetRankItems, SMALL_RANK_CACHE_GROUP_NUM)
	this.tong_score_ranks = make([]*msg_server_message.RetRankItems, SMALL_RANK_CACHE_GROUP_NUM)
	this.pos2tonglocalranks = make(map[int32]*PosSmallRankInfo)
	var tmp_local *PosSmallRankInfo
	for pos, _ := range cfg_position.Pos2Item {
		if pos <= 0 {
			continue
		}

		tmp_local = &PosSmallRankInfo{}
		tmp_local.rank_msgs = make([]*msg_server_message.RetRankItems, SMALL_RANK_CACHE_GROUP_NUM)
		tmp_local.small_rank = NewSmallRankService(DEFAULT_SMALL_RANK_LEN, SMALL_RANK_TYPE_TONG_SCORE, SMALL_RANK_SORT_TYPE_B)
		this.pos2tonglocalranks[pos] = tmp_local
	}

	this.LoadLastRank()

	this.RegScoreRankMsg()

	return true
}

func (this *ScoreRankMgr) LoadLastRank() bool {
	small_rank := dbc.LastSmallRank.GetRow()
	if nil == small_rank {
		log.Error("ScoreRankMgr LoadLastRank failed to get row !")
		return false
	}

	this.last_switch_day = timer.GetDayFrom1970WithCfgAndSec(0, small_rank.RankInfo.GetPNScoreRankStartTime())
	this.last_n_score_ranks = make([]*msg_server_message.RetRankItems, SMALL_RANK_CACHE_GROUP_NUM)
	for idx := int32(0); idx < SMALL_RANK_CACHE_GROUP_NUM; idx++ {
		this.last_n_score_ranks[idx] = &msg_server_message.RetRankItems{}
		this.last_n_score_ranks[idx].IfGetLast = proto.Int32(1)
		this.last_n_score_ranks[idx].RankType = proto.Int32(SMALL_RANK_TYPE_PLAYER_N_SCORE)
		this.last_n_score_ranks[idx].ItemList = make([]*msg_server_message.SmallRankItem, 0, SMALL_RANK_CACHE_ITEM_LEN)
	}

	this.last_n_score_rank_msg_top3 = &msg_server_message.RetRankItems{}
	this.last_n_score_rank_msg_top3.RankType = proto.Int32(SMALL_RANK_TYPE_PLAYER_N_SCORE)
	this.last_n_score_rank_msg_top3.ItemList = make([]*msg_server_message.SmallRankItem, 0, 3)

	all_records := small_rank.PlayerNScoreRank.GetRecords()
	tmp_len := int32(len(all_records))
	if tmp_len > 0 {
		var tmp_item *msg_server_message.SmallRankItem

		for _, val := range all_records {
			if val.Id <= 0 {
				continue
			}

			tmp_item = &msg_server_message.SmallRankItem{}
			tmp_item.Rank = proto.Int32(val.Rank)
			tmp_item.Id = proto.Int32(val.Id)
			tmp_item.Name = proto.String(val.Name)
			tmp_item.TongIcon = proto.Int32(val.TongIcon)
			tmp_item.TongName = proto.String(val.TongName)

			ranks_idx := val.Rank / SMALL_RANK_CACHE_ITEM_LEN
			if ranks_idx < 0 || ranks_idx >= SMALL_RANK_CACHE_GROUP_NUM {
				log.Error("ScoreRankMgr LoadLastRank wrong rank[%d]", val.Rank)
				continue
			}

			if val.Rank < 3 {
				this.last_n_score_rank_msg_top3.ItemList = append(this.last_n_score_rank_msg_top3.ItemList, tmp_item)
			}
			this.last_n_score_ranks[ranks_idx].ItemList = append(this.last_n_score_ranks[ranks_idx].ItemList, tmp_item)
		}
	}

	return true
}

func (this *ScoreRankMgr) PrintCurPlayerNRank() {
	log.Info("ScoreRankMgr 打印玩家积分排行榜 ============ start !")
	for _, val := range this.player_n_score_rank.GetTopN(200) {
		if nil != val && val.id > 0 {
			log.Info("	rank_item: 名次[%d] Id[%d] 积分[%d] 名称[%s] 帮会Icon[%d] 帮会名称[%s]",
				val.rank, val.id, val.val, val.name, val.tongicon, val.tongname)
		}
	}
	log.Info("ScoreRankMgr 打印玩家积分排行榜 ============ end !")
}

func (this *ScoreRankMgr) PrintCurTongRank() {
	log.Info("ScoreRankMgr 打印帮会积分排行榜 ============ start !")
	for _, val := range this.tong_score_rank.GetTopN(200) {
		if nil != val && val.id > 0 {
			log.Info("	rank_item: 名次[%d] Id[%d] 积分[%d] 名称[%s] 帮会Icon[%d] 帮会名称[%s]",
				val.rank, val.id, val.val, val.name, val.tongicon, val.tongname)
		}
	}
	log.Info("ScoreRankMgr 打印帮会积分排行榜 ============ end !")
}

// ====================================================================

func (this *ScoreRankMgr) CheckRaceSwitch() {
	this.last_switch_chk_frame++
	if this.last_switch_chk_frame < SCORE_RANK_MGR_SWITCH_CHK_FRAME {
		return
	}

	this.last_switch_chk_frame = 0

	cur_day := timer.GetDayFrom1970WithCfg(0)
	if cur_day == this.last_switch_day {
		return
	}

	log.Info("切换到下一个赛季！")
	tmp_row := dbc.LastSmallRank.GetRow()
	if nil == tmp_row {
		log.Error("ScoreRankMgr CheckRaceSwitch GetRow nil !")
		return
	}

	this.last_switch_day = cur_day
	tmp_row.RankInfo.SetPNScoreRankStartTime(int32(time.Now().Unix()))

	cur_all_rds := this.player_n_score_rank.GetTopN(DEFAULT_SMALL_RANK_LEN)
	if nil == cur_all_rds || len(cur_all_rds) < 1 {
		log.Error("ScoreRankMgr CheckRaceSwitch cur_all_rds nil or enmpty", cur_all_rds)
		return
	}

	tmp_last_msgs := make([]*msg_server_message.RetRankItems, SMALL_RANK_CACHE_GROUP_NUM)
	for idx := int32(0); idx < SMALL_RANK_CACHE_GROUP_NUM; idx++ {
		tmp_last_msgs[idx] = &msg_server_message.RetRankItems{}
		tmp_last_msgs[idx].IfGetLast = proto.Int32(1)
		tmp_last_msgs[idx].ItemList = make([]*msg_server_message.SmallRankItem, 0, SMALL_RANK_CACHE_ITEM_LEN)
	}

	var tmp_item *msg_server_message.SmallRankItem
	tmp_db_records := make([]dbSmallRankRecordData, int32(len(cur_all_rds)))
	for idx, val := range cur_all_rds {
		if nil == val || val.id < 0 {
			continue
		}

		group_idx := val.rank / SMALL_RANK_CACHE_ITEM_LEN
		if group_idx < 0 || group_idx >= SMALL_RANK_CACHE_GROUP_NUM {
			log.Error("ScoreRankMgr CheckRaceSwitch rank[%d] error !", val.rank)
			continue
		}

		tmp_item = &msg_server_message.SmallRankItem{}
		tmp_item.Rank = proto.Int32(int32(val.rank))
		tmp_item.Id = proto.Int32(val.id)
		tmp_item.Name = proto.String(val.name)
		tmp_item.Score = proto.Int32(val.val)
		tmp_item.TongIcon = proto.Int32(val.tongicon)
		tmp_item.TongName = proto.String(val.tongname)
		tmp_last_msgs[group_idx].ItemList = append(tmp_last_msgs[group_idx].ItemList, tmp_item)

		tmp_db_records[idx].Rank = val.rank
		tmp_db_records[idx].Id = val.id
		tmp_db_records[idx].Val = val.val
		tmp_db_records[idx].Name = val.name
		tmp_db_records[idx].TongIcon = val.tongicon
		tmp_db_records[idx].TongName = val.tongname
	}

	for idx := int32(0); idx < SMALL_RANK_CACHE_GROUP_NUM; idx++ {
		this.last_n_score_ranks[idx] = tmp_last_msgs[idx]
	}

	tmp_row.PlayerNScoreRank.SetRecords(tmp_db_records)
	tmp_row.Save(false)

	res2h := &msg_server_message.LegendArenaSwitch{}
	res2h.IfNeedSwitch = proto.Int32(1)
	res2h.SwitchUnix = proto.Int32(this.last_switch_day)
	hall_agent_mgr.Broadcast(res2h)

	return
}

func (this *ScoreRankMgr) OnHallAgentConnect(hall_agent *HallAgent) {
	if nil == hall_agent {
		log.Error("ScoreRankMgr OnHallAgentConnect param error !")
		return
	}

	res2h := &msg_server_message.LegendArenaSwitch{}
	res2h.IfNeedSwitch = proto.Int32(0)
	res2h.SwitchUnix = proto.Int32(this.last_switch_day)
	hall_agent.Send(res2h)
}

// ====================================================================

func (this *ScoreRankMgr) RegScoreRankMsg() {
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_PlayerNScoreChg, this.H2CPlayerNScoreChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_MultiPlayerNScoreChg, this.H2CMultiPlayerNScoreChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongScoreChg, this.H2CTongScoreChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_MultiTongScoreChg, this.H2CMultiTongScoreChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_GetRankInfo, this.H2CGetRankInfoHandler)
}

func (this *ScoreRankMgr) H2CPlayerNScoreChgHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.PlayerNScoreChg)
	if nil == c || nil == req {
		log.Error("H2CPlayerNScoreChgHandler param error !")
		return
	}

	this.player_n_score_rank.SetUpdateRank(req.GetPlayerId(), req.GetScore(), req.GetTongIcon(), req.GetPlayerName(), req.GetTongName())

	this.PrintCurPlayerNRank()
	return
}

func (this *ScoreRankMgr) H2CMultiPlayerNScoreChgHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.MultiPlayerNScoreChg)
	if nil == c || nil == req {
		log.Error("H2CMultiPlayerNScoreChgHandler param error !")
		return
	}

	for _, val := range req.GetChgList() {
		if nil == val {
			continue
		}

		score_rank_mgr.player_n_score_rank.SetUpdateRank(val.GetPlayerId(), val.GetScore(), val.GetTongIcon(), val.GetPlayerName(), val.GetTongName())
	}

	log.Info("ScoreRankMgr H2CMultiPlayerNScoreChgHandler %v", *req)
	this.PrintCurPlayerNRank()

	return
}

func (this *ScoreRankMgr) H2CTongScoreChgHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongScoreChg)
	if nil == c || nil == req {
		log.Error("ScoreRankMgr H2CTongScoreChgHandler c or req nil [%v]", nil == req)
		return
	}

	tong_name := req.GetTongName()
	this.tong_score_rank.SetUpdateRank(req.GetTongId(), req.GetScore(), req.GetTongIcon(), tong_name, tong_name)
	pos := req.GetPos()
	cur_local := this.pos2tonglocalranks[pos]
	if nil != cur_local {
		cur_local.small_rank.SetUpdateRank(req.GetTongId(), req.GetScore(), req.GetTongIcon(), tong_name, tong_name)
	}

}

func (this *ScoreRankMgr) H2CMultiTongScoreChgHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.MultiTongScoreChg)
	if nil == c || nil == req {
		log.Error("ScoreRankMgr H2CMultiTongScoreChgHandler")
		return
	}

	var tmp_local *PosSmallRankInfo
	var tong_name string
	for _, val := range req.GetChgList() {
		if nil == val {
			continue
		}

		tong_name = val.GetTongName()
		this.tong_score_rank.SetUpdateRank(val.GetTongId(), val.GetScore(), val.GetTongIcon(), tong_name, tong_name)
		tmp_local = this.pos2tonglocalranks[val.GetPos()]
		if nil != tmp_local {
			tmp_local.small_rank.SetUpdateRank(val.GetTongId(), val.GetScore(), val.GetTongIcon(), tong_name, tong_name)
		}
	}

	this.PrintCurTongRank()
}

func (this *ScoreRankMgr) H2CGetRankInfoHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.GetRankInfo)
	if nil == c || nil == req {
		log.Error("H2CGetRankInfoHandler param error !")
		return
	}

	log.Info("H2CGetRankInfoHandler", req.GetRankType())

	rank_type := req.GetRankType()
	switch rank_type {
	case SMALL_RANK_TYPE_PLAYER_N_SCORE:
		{
			this.PrintCurPlayerNRank()
			playerid := req.GetPlayerId()
			if 1 == req.GetIfLastRank() {
				for idx := int32(0); idx < 4; idx++ {
					if len(this.last_n_score_ranks[idx].GetItemList()) > 0 {
						this.last_n_score_ranks[idx].PlayerId = proto.Int32(playerid)
						c.Send(this.last_n_score_ranks[idx], true)
					}
				}
				log.Trace("H2CGetRankInfoHandler Send last Cache !")
				return
			}

			if int32(time.Now().Unix())-score_rank_mgr.last_pr_cache_unix <= SMALL_RANK_CACHE_SEC {
				for idx := int32(0); idx < 4; idx++ {
					if nil != this.p_n_score_ranks[idx] &&
						len(this.p_n_score_ranks[idx].GetItemList()) > 0 {
						this.p_n_score_ranks[idx].PlayerId = proto.Int32(playerid)
						c.Send(this.p_n_score_ranks[idx], true)
					}
				}

				log.Trace("H2CGetRankInfoHandler Send Cache !")
				return
			}

			for idx := int32(0); idx < SMALL_RANK_CACHE_GROUP_NUM; idx++ {
				this.p_n_score_ranks[idx] = &msg_server_message.RetRankItems{}
				this.p_n_score_ranks[idx].RankType = proto.Int32(SMALL_RANK_TYPE_PLAYER_N_SCORE)
				this.p_n_score_ranks[idx].ItemList = make([]*msg_server_message.SmallRankItem, 0, 50)
			}

			top200 := this.player_n_score_rank.GetTopN(200)
			var tmp_item *msg_server_message.SmallRankItem
			for rank, val := range top200 {
				if nil == val {
					continue
				}

				tmp_item = &msg_server_message.SmallRankItem{}
				tmp_item.Rank = proto.Int32(int32(rank))
				tmp_item.Id = proto.Int32(val.id)
				tmp_item.Name = proto.String(val.name)
				tmp_item.Score = proto.Int32(val.val)
				tmp_item.TongIcon = proto.Int32(val.tongicon)
				tmp_item.TongName = proto.String(val.tongname)

				idx := val.rank / SMALL_RANK_CACHE_ITEM_LEN
				if idx < 0 || idx >= SMALL_RANK_CACHE_GROUP_NUM {
					log.Error("H2CGetRankInfoHandler rank[%d] not in range !", val.rank)
					continue
				}
				this.p_n_score_ranks[idx].ItemList = append(this.p_n_score_ranks[idx].ItemList, tmp_item)
			}

			for idx := int32(0); idx < SMALL_RANK_CACHE_GROUP_NUM; idx++ {
				if nil != this.p_n_score_ranks[idx] &&
					len(this.p_n_score_ranks[idx].GetItemList()) > 0 {
					this.p_n_score_ranks[idx].PlayerId = proto.Int32(playerid)
					c.Send(this.p_n_score_ranks[idx], true)
				}
			}

			return
		}
	case SMALL_RANK_TYPE_TONG_SCORE:
		{
			playerid := req.GetPlayerId()
			pos := req.GetPos()
			this.PrintCurTongRank()
			tmp_local := this.pos2tonglocalranks[pos]
			if POSITION_GLOBAL == pos || nil == tmp_local {
				if int32(time.Now().Unix())-score_rank_mgr.last_tr_cache_unix <= SMALL_RANK_CACHE_SEC {
					for idx := int32(0); idx < 4; idx++ {
						if nil != this.tong_score_ranks[idx] &&
							len(this.tong_score_ranks[idx].GetItemList()) > 0 {
							this.tong_score_ranks[idx].PlayerId = proto.Int32(playerid)
							c.Send(this.tong_score_ranks[idx], true)
						}
					}

					log.Trace("H2CGetRankInfoHandler Send Cache !")
					return
				}

				for idx := int32(0); idx < SMALL_RANK_CACHE_GROUP_NUM; idx++ {
					this.tong_score_ranks[idx] = &msg_server_message.RetRankItems{}
					this.tong_score_ranks[idx].RankType = proto.Int32(SMALL_RANK_TYPE_TONG_SCORE)
					this.tong_score_ranks[idx].ItemList = make([]*msg_server_message.SmallRankItem, 0, 50)
				}

				top200 := this.tong_score_rank.GetTopN(200)
				var tmp_item *msg_server_message.SmallRankItem
				for rank, val := range top200 {
					if nil == val {
						continue
					}

					tmp_item = &msg_server_message.SmallRankItem{}
					tmp_item.Rank = proto.Int32(int32(rank))
					tmp_item.Id = proto.Int32(val.id)
					tmp_item.Name = proto.String(val.name)
					tmp_item.Score = proto.Int32(val.val)
					tmp_item.TongIcon = proto.Int32(val.tongicon)
					tmp_item.TongName = proto.String(val.tongname)

					idx := val.rank / SMALL_RANK_CACHE_ITEM_LEN
					if idx < 0 || idx >= SMALL_RANK_CACHE_GROUP_NUM {
						log.Error("H2CGetRankInfoHandler rank[%d] not in range !", val.rank)
						continue
					}
					this.tong_score_ranks[idx].ItemList = append(this.tong_score_ranks[idx].ItemList, tmp_item)
				}

				for idx := int32(0); idx < SMALL_RANK_CACHE_GROUP_NUM; idx++ {
					if nil != this.tong_score_ranks[idx] &&
						len(this.tong_score_ranks[idx].GetItemList()) > 0 {
						this.tong_score_ranks[idx].PlayerId = proto.Int32(playerid)
						c.Send(this.tong_score_ranks[idx], true)
					}
				}
			} else {

				if int32(time.Now().Unix())-tmp_local.last_cache_unix <= SMALL_RANK_CACHE_SEC {
					for idx := int32(0); idx < 4; idx++ {
						if nil != tmp_local.rank_msgs[idx] &&
							len(tmp_local.rank_msgs[idx].GetItemList()) > 0 {
							tmp_local.rank_msgs[idx].PlayerId = proto.Int32(playerid)
							c.Send(tmp_local.rank_msgs[idx], true)
						}
					}

					log.Trace("H2CGetRankInfoHandler Send Cache !")
					return
				}

				for idx := int32(0); idx < SMALL_RANK_CACHE_GROUP_NUM; idx++ {
					tmp_local.rank_msgs[idx] = &msg_server_message.RetRankItems{}
					tmp_local.rank_msgs[idx].RankType = proto.Int32(SMALL_RANK_TYPE_TONG_SCORE)
					tmp_local.rank_msgs[idx].ItemList = make([]*msg_server_message.SmallRankItem, 0, 50)
				}

				top200 := this.player_n_score_rank.GetTopN(200)
				var tmp_item *msg_server_message.SmallRankItem
				for rank, val := range top200 {
					if nil == val {
						continue
					}

					tmp_item = &msg_server_message.SmallRankItem{}
					tmp_item.Rank = proto.Int32(int32(rank))
					tmp_item.Id = proto.Int32(val.id)
					tmp_item.Name = proto.String(val.name)
					tmp_item.Score = proto.Int32(val.val)
					tmp_item.TongIcon = proto.Int32(val.tongicon)
					tmp_item.TongName = proto.String(val.tongname)

					idx := val.rank / SMALL_RANK_CACHE_ITEM_LEN
					if idx < 0 || idx >= SMALL_RANK_CACHE_GROUP_NUM {
						log.Error("H2CGetRankInfoHandler rank[%d] not in range !", val.rank)
						continue
					}
					tmp_local.rank_msgs[idx].ItemList = append(tmp_local.rank_msgs[idx].ItemList, tmp_item)
				}

				for idx := int32(0); idx < SMALL_RANK_CACHE_GROUP_NUM; idx++ {
					if nil != tmp_local.rank_msgs[idx] &&
						len(tmp_local.rank_msgs[idx].GetItemList()) > 0 {
						tmp_local.rank_msgs[idx].PlayerId = proto.Int32(playerid)
						c.Send(tmp_local.rank_msgs[idx], true)
					}
				}
			}
		}
	}
}
