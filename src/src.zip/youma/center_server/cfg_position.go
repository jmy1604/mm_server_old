package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
)

const (
	POSITION_GLOBAL = 0 // 全球位置
)

type XmlPositionItem struct {
	Pos  int32  `xml:"Position,attr"`
	Name string `xml:"Name,attr"`
}

type XmlPositionConfig struct {
	Items []XmlPositionItem `xml:"item"`
}

type CfgPosition struct {
	Pos2Item  map[int32]*XmlPositionItem
	Name2Item map[string]*XmlPositionItem
}

var cfg_position CfgPosition

func (this *CfgPosition) Init() bool {
	data, err := ioutil.ReadFile("../game_data/position.xml")
	if nil != err {
		log.Error("CfgPosition Init failed to read file(%s)", err.Error())
		return false
	}

	tmp_cfg := &XmlPositionConfig{}
	err = xml.Unmarshal(data, tmp_cfg)
	if nil != err {
		log.Error("CfgPosition init unmarshal failed [%s]", err.Error())
		return false
	}

	this.Pos2Item = make(map[int32]*XmlPositionItem)
	this.Name2Item = make(map[string]*XmlPositionItem)

	tmp_len := int32(len(tmp_cfg.Items))
	var tmp_item *XmlPositionItem
	for idx := int32(0); idx < tmp_len; idx++ {
		tmp_item = &tmp_cfg.Items[idx]
		this.Pos2Item[tmp_item.Pos] = tmp_item
		this.Name2Item[tmp_item.Name] = tmp_item
	}

	return true
}
