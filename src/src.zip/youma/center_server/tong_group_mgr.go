package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"libs/log"
)

type SingleTongCfg struct {
	ServerIdx int32  // 内部编号
	ServerId  int32  // 服务器ID
	ServerIP  string // 服务器IP
}

type TongGroupCfg struct {
	GroupId   int32            // 组Id
	MinTid    int32            // 最小Tid
	MaxTid    int32            // 最大Tid
	ServerNum int32            // 服务器数目
	Servers   []*SingleTongCfg // 服务器IP信息
}

type TongGroups struct {
	TongServerGroups []*TongGroupCfg
}

type TongGroupMgr struct {
	max_tong_id int32
	Tong_groups *TongGroups
}

var tong_group_mgr TongGroupMgr

func (this *TongGroupMgr) Init() bool {

	if !this.load_Tong_group_config() {
		log.Error("TongGroupMgr init db_group_mgr failed !")
		return false
	}

	return true
}

func (this *TongGroupMgr) load_Tong_group_config() bool {
	this.Tong_groups = &TongGroups{}

	data, err := ioutil.ReadFile("../conf/tong_server_group.json")
	if err != nil {
		fmt.Printf("TongGroupMgr读取配置文件失败 %s", err)
		return false
	}
	err = json.Unmarshal(data, this.Tong_groups)
	if err != nil {
		fmt.Printf("TongGroupMgr解析配置文件失败 %s", err.Error())
		return false
	}

	for _, groupinfo := range this.Tong_groups.TongServerGroups {
		if nil == groupinfo {
			fmt.Printf("TongGroupMgr解析结果TongGroups包含空值")
			return false
		}

		if groupinfo.MaxTid > this.max_tong_id {
			this.max_tong_id = groupinfo.MaxTid
		}

		for ival := int32(1); ival <= groupinfo.ServerNum; ival++ {
			bfind := false
			for _, svrinfo := range groupinfo.Servers {
				if nil == svrinfo {
					fmt.Printf("TongGroupMgr解析结果TongGroups包含空值")
					return false
				}

				log.Info("svr info %d", svrinfo.ServerIdx)
				if svrinfo.ServerIdx == ival {
					bfind = true
					break
				}
			}

			if !bfind {
				fmt.Printf("数据库集群里面缺少服务器%d", ival)
				return false
			}
		}
	}

	log.Info("Tong Group Info %v", *this.Tong_groups)

	return true
}

func (this *TongGroupMgr) GetTongCfgByTongId(tongid int32) *SingleTongCfg {
	svr_idx := int32(-1)
	for _, groupinfo := range this.Tong_groups.TongServerGroups {
		if tongid < groupinfo.MinTid || tongid > groupinfo.MaxTid {
			log.Info("GetTongCfgByTongId 1 continue groupinfo.MinPId(%d) groupinfo.MaxPId(%d), tongid(%d)", groupinfo.MinTid, groupinfo.MaxTid, tongid)
			continue
		}

		svr_idx = tongid%groupinfo.ServerNum + 1
		for _, svr_info := range groupinfo.Servers {
			if svr_info.ServerIdx == svr_idx {
				return svr_info
			}
		}
	}

	return nil
}
