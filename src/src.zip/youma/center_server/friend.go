package main

import (
	"libs/log"
	"libs/server_conn"
	"public_message/gen_go/server_message"

	"3p/code.google.com.protobuf/proto"
)

type PlayerFriendManager struct {
}

var player_friend_mgr PlayerFriendManager

func (this *PlayerFriendManager) Init() bool {
	this.RegPlayerFriendMsg()
	return true
}

// ----------------------------------------------------------------------------

func (this *PlayerFriendManager) RegPlayerFriendMsg() {
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_AddFriendByPId, this.H2CAddFriendByPIdHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_AddFriendByAcc, this.H2CAddFriendByAccHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_AgreeAddFriend, this.H2CAgreeAddFriendHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_AddFocusByPId, this.H2CAddFocusByPIdHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_AddFocusByAcc, this.H2CAddFocusByAccHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_RetFocusedPlayerInfo, this.H2CRetFocusedPlayerInfoHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_FriendChat, this.H2CFriendChatHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_RemoveFriendById, this.H2CRemoveFriendByIdHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_FriendSearch, this.H2CFriendSearchHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_FriendSearchResult, this.H2CFriendSearchResultHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_GetOnlineFriendIds, this.H2CGetOnlineFriendsHandler)
}

func (this *PlayerFriendManager) H2CAddFriendByPIdHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.AddFriendByPId)

	tgt_pid := req.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(tgt_pid)
	if nil == hall_svrinfo {
		log.Error("H2CAddFriendByPIdHandler failed to get hall_svrinfo[%d]", tgt_pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("H2CAddFriendByPIdHandler failed to get hall_svr [%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(req)
}

func (this *PlayerFriendManager) H2CAddFriendByAccHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.AddFriendByAcc)

	tmp_row := dbc.Accounts.GetRow(req.GetAccount())
	if nil == tmp_row {
		log.Error("H2CAddFriendByAccHandler failed to get acc[%s]", req.GetAccount())
		return
	}

	tgt_pid := tmp_row.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(tgt_pid)
	if nil == hall_svrinfo {
		log.Error("H2CAddFriendByAccHandler failed to get hall_svrinfo[%d]", tgt_pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("H2CAddFriendByAccHandler failed to get hall_svr [%d]", hall_svrinfo.ServerId)
		return
	}

	req2h := &msg_server_message.AddFriendByPId{}
	req2h.PlayerId = proto.Int32(tgt_pid)
	req2h.ReqPlayerId = proto.Int32(req.GetReqPlayerId())
	req2h.ReqPlayerName = proto.String(req.GetReqPlayerName())
	req2h.ReqPlayerScore = proto.Int32(req.GetReqPlayerScore())
	req2h.ReqPlayerTongIcon = proto.Int32(req.GetReqPlayerTongIcon())
	req2h.ReqPlayerTongName = proto.String(req.GetReqPlayerTongName())

	hall_svr.Send(req2h)
}

func (this *PlayerFriendManager) H2CAgreeAddFriendHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.AgreeAddFriend)

	tgt_pid := req.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(tgt_pid)
	if nil == hall_svrinfo {
		log.Error("H2CAgreeAddFriendHandler failed to get hall_svrinfo[%d]", tgt_pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("H2CAgreeAddFriendHandler failed to get hall_svr [%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(req)
}

func (this *PlayerFriendManager) H2CAddFocusByPIdHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.AddFocusByPId)

	tgt_pid := req.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(tgt_pid)
	if nil == hall_svrinfo {
		log.Error("H2CAddFocusByPIdHandler failed to get hall_svrinfo[%d]", tgt_pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("H2CAddFocusByPIdHandler failed to get hall_svr [%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(req)
}

func (this *PlayerFriendManager) H2CAddFocusByAccHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.AddFocusByAcc)

	tmp_row := dbc.Accounts.GetRow(req.GetAccount())
	if nil == tmp_row {
		log.Error("H2CAddFocusByAccHandler failed to get acc[%s]", req.GetAccount())
		return
	}

	tgt_pid := tmp_row.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(tgt_pid)
	if nil == hall_svrinfo {
		log.Error("H2CAddFocusByAccHandler failed to get hall_svrinfo[%d]", tgt_pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("H2CAddFocusByAccHandler failed to get hall_svr [%d]", hall_svrinfo.ServerId)
		return
	}

	req2h := &msg_server_message.AddFocusByPId{}
	req2h.PlayerId = proto.Int32(tgt_pid)
	req2h.ReqPlayerId = proto.Int32(req.GetReqPlayerId())
	req2h.ReqPlayerName = proto.String(req.GetReqPlayerName())
	req2h.ReqPlayerScore = proto.Int32(req.GetReqPlayerScore())
	req2h.ReqPlayerTongIcon = proto.Int32(req.GetReqPlayerTongIcon())
	req2h.ReqPlayerTongName = proto.String(req.GetReqPlayerTongName())

	hall_svr.Send(req2h)
}

func (this *PlayerFriendManager) H2CRetFocusedPlayerInfoHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.RetFocusedPlayerInfo)

	tgt_pid := req.GetReqPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(tgt_pid)
	if nil == hall_svrinfo {
		log.Error("H2CRetFocusedPlayerInfoHandler failed to get hall_svrinfo[%d]", tgt_pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("H2CRetFocusedPlayerInfoHandler failed to get hall_svr [%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(req)
}

func (this *PlayerFriendManager) H2CFriendChatHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.FriendChat)

	tgt_pid := req.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(tgt_pid)
	if nil == hall_svrinfo {
		log.Error("H2CFriendChatHandler failed to get hall_svrinfo[%d]", tgt_pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("H2CFriendChatHandler failed to get hall_svr [%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(req)
}

func (this *PlayerFriendManager) H2CRemoveFriendByIdHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.RemoveFriendById)

	tgt_pid := req.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(tgt_pid)
	if nil == hall_svrinfo {
		log.Error("H2CRemoveFriendByIdHandler failed to get hall_svrinfo[%d]", tgt_pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("H2CRemoveFriendByIdHandler failed to get hall_svr [%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(req)
}

func (this *PlayerFriendManager) H2CRemoveFocusByIdHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.RemoveFocusById)

	tgt_pid := req.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(tgt_pid)
	if nil == hall_svrinfo {
		log.Error("H2CRemoveFocusByIdHandler failed to get hall_svrinfo[%d]", tgt_pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("H2CRemoveFocusByIdHandler failed to get hall_svr [%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(req)

	return
}

func (this *PlayerFriendManager) H2CFriendSearchHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.FriendSearch)

	hall_agent_mgr.Broadcast(req)

	return
}

func (this *PlayerFriendManager) H2CFriendSearchResultHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.FriendSearchResult)

	tgt_pid := req.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(tgt_pid)
	if nil == hall_svrinfo {
		log.Error("H2CRemoveFocusByIdHandler failed to get hall_svrinfo[%d]", tgt_pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("H2CRemoveFocusByIdHandler failed to get hall_svr [%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(req)
}

func (this *PlayerFriendManager) H2CGetOnlineFriendsHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.GetOnlineFriendIds)
	if nil == req {
		log.Error("PlayerFriendManager H2CGetOnlineFriendsHandler req nil")
		return
	}

	log.Info("PlayerFriendManager H2CGetOnlineFriendsHandler send %v", req)

	res2h := &msg_server_message.RetOnlineFriendIds{}
	res2h.PlayerIds = player_mgr.GetOnlines(req.GetPlayerIds())
	res2h.ReqPlayerId = proto.Int32(req.GetReqPlayerId())

	log.Info("PlayerFriendManager H2CGetOnlineFriendsHandler send %v", res2h)
	c.Send(res2h, true)

	return
}
