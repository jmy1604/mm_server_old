package main

import (
	"libs/log"
	"libs/server_conn"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	CREATE_TONG_FAILED_MAX_ID = 1  // 帮会数目已经到达上限，不能再创建了
	TONG_SEARCH_NUM           = 50 // 帮会搜索结果的数目
	TONG_SEARCH_OVER_SEC      = 3  // 帮会搜索有效时间为5秒

	DEFAULT_TONG_SEARCH_MAX_P = 100 // 默认开始有100人同时搜索帮会
)

type TongSearchItem struct {
	item_lock        *sync.Mutex                       // 数据锁                               // 搜索编号
	player_id        int32                             // 玩家Id
	cur_result_count int32                             // 当前结果数目
	result           *msg_server_message.RetTongSearch // 结果列表
	start_unix       int32                             // 开始时间
	bover            bool
}

func NewTongSearchItem(player_id int32) *TongSearchItem {
	ret_search := &TongSearchItem{}
	ret_search.player_id = player_id
	ret_search.item_lock = &sync.Mutex{}
	ret_search.cur_result_count = 0
	ret_search.result = &msg_server_message.RetTongSearch{}
	ret_search.result.PlayerId = proto.Int32(player_id)
	ret_search.result.TongList = make([]*msg_server_message.TongSummaryInfo, 0, TONG_SEARCH_NUM)
	ret_search.start_unix = int32(time.Now().Unix())

	return ret_search
}

func (this *TongSearchItem) ChkAddSearchResult(msg *msg_server_message.RetTongSearch) bool {
	if nil == msg {
		log.Error("TongSearchItem ChkAddSearchResult msg nil !")
		return false
	}

	tong_list := msg.GetTongList()
	tong_len := int32(len(tong_list))
	if tong_len < 1 {
		log.Error("TongSearchItem ChkAddSearchResult msg nil !")
		return false
	}

	this.item_lock.Lock()
	defer this.item_lock.Unlock()

	if this.bover {
		log.Info("TongSearchItem ChkAddSearchResult already over")
		return false
	}

	if this.cur_result_count >= TONG_SEARCH_NUM {
		log.Info("TongSearchItem ChkAddSearchResult already enough")
		return false
	}

	left := TONG_SEARCH_NUM - this.cur_result_count
	if left > tong_len {
		left = tong_len
	}
	for i := int32(0); i < left; i++ {
		this.result.TongList = append(this.result.TongList, tong_list[i])
		this.cur_result_count++
	}

	if this.cur_result_count >= TONG_SEARCH_NUM {
		this.bover = true
		return true
	}

	return false
}

func (this *TongSearchItem) ForceOver() bool {
	this.item_lock.Lock()
	defer this.item_lock.Unlock()
	if !this.bover {
		this.bover = true
		return true
	}

	return false
}

func (this *TongSearchItem) DoSearchOver() {
	if !this.ForceOver() {
		log.Info("TongSearchItem DoSearchOver already over !")
		return
	}
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(this.player_id)
	if nil == hall_svrinfo {
		log.Error("TongSearchItem DoSearchOver failed to find svrinfo by pid[%d]", this.player_id)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("TongSearchItem DoSearchOver Failed to get hall_svr by svr_id[%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(this.result)
}

// ===============================================================

type TongMgr struct {
	id2search      map[int32]*TongSearchItem
	id2search_lock *sync.RWMutex

	// 超时的搜索列表
	over_searchs []*TongSearchItem
	cur_os_max   int32 // 超时列表当前长度
	cur_os_count int32 // 当前超时数目
}

var tong_mgr TongMgr

func (this *TongMgr) Init() bool {

	this.id2search = make(map[int32]*TongSearchItem)
	this.id2search_lock = &sync.RWMutex{}
	this.RegTongMsg()
	return true
}

func (this *TongMgr) chkGetNextTongId() int32 {
	tmp_row := dbc.TongIdMax.GetRow()
	if nil == tmp_row {
		log.Error("TongMgr chkGetNextTongId tmp_row nil !")
		return -1
	}

	cur_tong_idmax := tmp_row.GetTongIdMax()
	if tmp_row.GetTongIdMax() >= tong_group_mgr.max_tong_id {
		log.Error("TongMgr chkGetNextTongId over max tong_id[%d] !", tong_group_mgr.max_tong_id)
		return -1
	}

	cur_tong_idmax++
	tmp_row.SetTongIdMax(cur_tong_idmax)

	return cur_tong_idmax
}

func (this *TongMgr) AddTongSearch(search *TongSearchItem) {
	if nil == search {
		log.Error("TongMgr AddTongSearch param error !")
		return
	}
	this.id2search_lock.Lock()
	defer this.id2search_lock.Unlock()
	this.id2search[search.player_id] = search
	return
}

func (this *TongMgr) GetTongSearch(pid int32) *TongSearchItem {
	this.id2search_lock.RLock()
	defer this.id2search_lock.RUnlock()
	return this.id2search[pid]
}

func (this *TongMgr) RemoveTongSearch(pid int32) {
	this.id2search_lock.Lock()
	defer this.id2search_lock.Unlock()

	delete(this.id2search, pid)
}

// ========================================================

func (this *TongMgr) PopOverSearchs() map[int32]*TongSearchItem {
	cur_unix := int32(time.Now().Unix())
	this.id2search_lock.Lock()
	defer this.id2search_lock.Unlock()

	over_searchs := make(map[int32]*TongSearchItem)
	for pid, search_item := range this.id2search {
		if nil == search_item {
			log.Error("TongMgr PopOverSearchs case search nil !")
			continue
		}

		if cur_unix-search_item.start_unix > TONG_SEARCH_OVER_SEC {
			over_searchs[pid] = search_item
		}
	}

	for pid, _ := range over_searchs {
		delete(this.id2search, pid)
	}

	return over_searchs
}

func (this *TongMgr) OnTick() {
	over_searchs := this.PopOverSearchs()
	if nil == over_searchs || len(over_searchs) < 1 {
		return
	}

	for _, search := range over_searchs {
		if nil == search {
			continue
		}

		search.DoSearchOver()
	}
}

// ========================================================

func (this *TongMgr) RegTongMsg() {
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_CreateTong, this.H2CCreateTongHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_GetTongInfo, this.H2CGetTongInfoHanlder)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_GetRecommendTong, this.H2CGetRecommendTongHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongSearch, this.H2CTongSearchHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_EnterTong, this.H2CEnterTongHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_EnterTongAgree, this.H2CEnterTongAgreeHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_SetPlayerTongInfoOk, this.H2CSetPlayerTongInfoOkHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongLeave, this.H2CTongLeaveHandler)
	//hall_agent_mgr.SetMessageHandler(msg_server_message.ID_SetTongMemberOnOffline, this.H2CSetTongMemberOnOfflineHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongSetChg, this.H2CTongSetChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongPubChg, this.H2CTongPubChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongChatSend, this.H2CTongChatSendHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongCardReq, this.H2CTongCardReqHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongDonateCard, this.H2CTongDonateCardHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongMemberFightEnd, this.H2CTongMemberFightEndHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongChestOpen, this.H2CTongChestOpenHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongFriendMatch, this.H2CTongFriendMatchHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongFriendCancel, this.H2CTongFriendCancelHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_TongFriendEnter, this.H2CTongFriendEnterHandler)

	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_CreateTongOk, this.T2CCreateTongOkHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_RetTongInfo, this.T2CRetTongInfoHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_RetRecommendTong, this.T2CRetRecommonTongHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_RetTongSearch, this.T2CRetTongSearchHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_EnterTongRequest, this.T2CEnterTongRequestHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_SetPlayerTongInfo, this.T2CSetPlayerTongInfoHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_ClearPlayerTongInfo, this.T2CClearPlayerTongInfoHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyPlayerEnter, this.T2CNotifyPlayerEnterHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyPlayerRefuse, this.T2CNotifyPlayerRefuseHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyTongMemberOnOffline, this.T2CNotifyTongMemberOnOffline)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyTongSetChg, this.T2CNotifyTongSetChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyTongPubChg, this.T2CNotifyTongPubChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyTongChatSend, this.T2CNotifyTongChatHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyTongCardReq, this.T2CNotifyTongCardReqHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyTongChestScoreChg, this.T2CNotifyTongChestScoreChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyTongMemberScoreChg, this.T2CNotifyTongMemberScoreChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_RetTongChestOpen, this.T2CRetTongChestOpenHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyTongFriendMatch, this.T2CNotifyTongFriendMatchHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_NotifyTongFriendCancel, this.T2CNotifyTongFriendCancelHandler)
}

func (this *TongMgr) H2CCreateTongHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.CreateTong)
	if nil == req || nil == c {
		log.Error("TongMgr H2CCreateTongHandler req or c nil [%v]", nil == req)
		return
	}

	new_tong_id := this.chkGetNextTongId()
	if -1 == new_tong_id {
		log.Error("TongMgr H2CCreateTongHandler get new_tong_id[%d] failed !", new_tong_id)
		res2h := &msg_server_message.CreateTongFailed{}
		res2h.Reason = proto.Int32(CREATE_TONG_FAILED_MAX_ID)
		res2h.CreatorId = proto.Int32(req.GetCreatorId())
		c.Send(res2h, true)
		return
	}

	tong_svr_cfg := tong_group_mgr.GetTongCfgByTongId(new_tong_id)
	if nil == tong_svr_cfg {
		log.Error("TongMgr H2CCreateTongHandler[%d] can not get svrcfg by tongid[%d]", req.GetCreatorId(), new_tong_id)
		return
	}
	tong_svr := hall_agent_mgr.GetAgentById(tong_svr_cfg.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CCreateTongHandler[%d tong_svr not connected ![%d]", req.GetCreatorId(), tong_svr_cfg.ServerId)
		return
	}

	req.TongId = proto.Int32(new_tong_id)

	tong_svr.Send(req)

	return
}

func (this *TongMgr) H2CGetTongInfoHanlder(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.GetTongInfo)
	if nil == c || nil == req {
		log.Error("TongMgr H2CGetTongInfoHanlder req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svr_info := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svr_info {
		log.Error("TongMgr H2CGetTongInfoHanlder failed to get tongsvninfo by id[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svr_info.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CGetTongInfoHanlder failed to get tong svr[%d] !", tong_svr_info.ServerId)
		return
	}

	tong_svr.Send(req)

	return
}

func (this *TongMgr) H2CGetRecommendTongHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.GetRecommendTong)
	if nil == c || nil == req {
		log.Error("H2CGetRecommendTongHandler c or req nil")
		return
	}

	hall_svr := hall_agent_mgr.RandOneAgent()
	if nil == hall_svr {
		log.Error("H2CGetRecommendTongHandler rand hall_svr nil")
		return
	}

	hall_svr.Send(req)
	return
}

func (this *TongMgr) H2CTongSearchHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongSearch)
	if nil == c || nil == req {
		log.Error("H2CTongSearchHandler c or req nil [%d] !", nil == req)
		return
	}

	pid := req.GetPlayerId()
	cur_search := this.GetTongSearch(pid)
	if nil != cur_search && int32(time.Now().Unix())-cur_search.start_unix <= TONG_SEARCH_OVER_SEC {
		log.Error("H2CTongSearchHandler already Searching")
		return
	}

	new_search := NewTongSearchItem(pid)

	this.AddTongSearch(new_search)

	hall_agent_mgr.Broadcast(req)

	return
}

func (this *TongMgr) H2CEnterTongHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.EnterTong)
	if nil == req || nil == c {
		log.Error("TongMgr H2CEnterTongHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CEnterTongHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CEnterTongHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

func (this *TongMgr) H2CEnterTongAgreeHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.EnterTongAgree)
	if nil == c || nil == req {
		log.Error("EnterTongAgreeHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("EnterTongAgreeHandler failed to get tong svrinfo by tong_id[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("EnterTongAgreeHandler failed to get tong svr by id[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)

	return
}

func (this *TongMgr) H2CTongEnterRefuseHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.EnterTongRefuse)
	if nil == c || nil == req {
		log.Error("TongMgr H2CTongEnterRefuseHandler c or req nil [%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongEnterRefuseHandler failed to get tong_svrinfo !")
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongEnterRefuseHandler failde to get tong_svr !")
		return
	}

	tong_svr.Send(req)

	return
}

func (this *TongMgr) H2CSetPlayerTongInfoOkHandler(c *server_conn.ServerConn, msg proto.Message) {
	res := msg.(*msg_server_message.SetPlayerTongInfoOk)
	if nil == c || nil == res {
		log.Error("TongMgr H2CSetPlayerInfoOkHandler c or req nil [%v]", nil == res)
		return
	}

	tong_id := res.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CSetPlayerInfoOkHandler failed get tongsvrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CSetPlayerInfoOkHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(res)

	return
}

func (this *TongMgr) H2CTongLeaveHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongLeave)
	if nil == c || nil == req {
		log.Error("TongMgrH2CTongLeaveHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgrH2CTongLeaveHandler failed to find tongsvninfo[%d]", tong_id)
		return
	}
	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgrH2CTongLeaveHandler failed to find tong_svr[%d]!", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)

	return
}

func (this *TongMgr) H2CTongSetChgHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongSetChg)
	if nil == req || nil == c {
		log.Error("TongMgr H2CTongSetChgHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongSetChgHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongSetChgHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

func (this *TongMgr) H2CTongPubChgHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongPubChg)
	if nil == req || nil == c {
		log.Error("TongMgr H2CTongPubChgHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongPubChgHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongPubChgHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

func (this *TongMgr) H2CTongChatSendHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongChatSend)
	if nil == req || nil == c {
		log.Error("TongMgr H2CTongChatSendHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongChatSendHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongChatSendHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

func (this *TongMgr) H2CTongCardReqHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongCardReq)
	if nil == req || nil == c {
		log.Error("TongMgr H2CTongCardReqHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongCardReqHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongCardReqHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

func (this *TongMgr) H2CTongDonateCardHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongDonateCard)
	if nil == req || nil == c {
		log.Error("TongMgr H2CTongDonateCardHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongDonateCardHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongDonateCardHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

func (this *TongMgr) H2CTongMemberFightEndHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongMemberFightEnd)
	if nil == req || nil == c {
		log.Error("TongMgr H2CTongMemberFightEndHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongMemberFightEndHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongMemberFightEndHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

func (this *TongMgr) H2CTongChestOpenHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongChestOpen)
	if nil == req || nil == c {
		log.Error("TongMgr H2CTongChestOpenHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongChestOpenHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongChestOpenHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

func (this *TongMgr) H2CTongFriendMatchHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongFriendMatch)
	if nil == req || nil == c {
		log.Error("TongMgr H2CTongFriendMatchHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongFriendMatchHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongFriendMatchHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

func (this *TongMgr) H2CTongFriendCancelHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongFriendCancel)
	if nil == req || nil == c {
		log.Error("TongMgr H2CTongFriendCancelHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongFriendCancelHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongFriendCancelHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

func (this *TongMgr) H2CTongFriendEnterHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongFriendEnter)
	if nil == req || nil == c {
		log.Error("TongMgr H2CTongFriendEnterHandler req or c nil[%v]", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong_svrinfo := tong_group_mgr.GetTongCfgByTongId(tong_id)
	if nil == tong_svrinfo {
		log.Error("TongMgr H2CTongFriendEnterHandler failed to get tong_svrinfo[%d]", tong_id)
		return
	}

	tong_svr := hall_agent_mgr.GetAgentById(tong_svrinfo.ServerId)
	if nil == tong_svr {
		log.Error("TongMgr H2CTongFriendEnterHandler failed to get tong_svr[%d]", tong_svrinfo.ServerId)
		return
	}

	tong_svr.Send(req)
	return
}

//----------------------------------------------------------------------------------------

func (this *TongMgr) T2CCreateTongOkHandler(c *server_conn.ServerConn, msg proto.Message) {
	res := msg.(*msg_server_message.CreateTongOk)
	if nil == c || nil == res {
		log.Error("TongMgr T2CCreateTongOkHandler c or req nil [%v]!", nil == c)
		return
	}

	creatorid := res.GetCreatorId()
	hall_cfg := hall_group_mgr.GetHallCfgByPlayerId(creatorid)
	if nil == hall_cfg {
		log.Error("TongMgr T2CCreateTongOkHandler can not find hall_cfg by pid[%d]", creatorid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_cfg.ServerId)
	if nil == hall_svr {
		log.Error("TongMgr T2CCreateTongOkHandler Get Hall_svr by serverid[%d] failed !", hall_cfg.ServerId)
		return
	}

	hall_svr.Send(res)

	return
}

func (this *TongMgr) T2CRetTongInfoHandler(c *server_conn.ServerConn, msg proto.Message) {
	res := msg.(*msg_server_message.RetTongInfo)
	if nil == res || nil == c {
		log.Error("TongMgr T2CRetTongInfoHandler res or c nil [%v]", nil == res)
		return
	}

	pid := res.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(pid)
	if nil == hall_svrinfo {
		log.Error("TongMgr T2CRetTongInfoHandler hall_svrinfo nil pid")
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("TongMgr T2CRetTongInfoHandler failed to get hall svr by id[%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(res)
	return
}

func (this *TongMgr) T2CRetRecommonTongHandler(c *server_conn.ServerConn, msg proto.Message) {
	res := msg.(*msg_server_message.RetRecommendTong)
	if nil == res || nil == c {
		log.Error("TongMgr T2CRetRecommonTongHandler res or c nil[%v] !", nil == res)
		return
	}

	pid := res.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(pid)
	if nil == hall_svrinfo {
		log.Error("TongMgr T2CRetRecommonTongHandler failed to get hall_svrinfo by id[%d]", pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("TongMgr T2CRetRecommonTongHandler failed to get hall_svr by id[%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(res)

	return
}

func (this *TongMgr) T2CRetTongSearchHandler(c *server_conn.ServerConn, msg proto.Message) {
	res := msg.(*msg_server_message.RetTongSearch)
	if nil == c || nil == res {
		log.Error("T2CRetTongSearchHandler c or res nil !")
		return
	}

	pid := res.GetPlayerId()
	cur_search := this.GetTongSearch(pid)
	if nil == cur_search {
		log.Error("TongMgr T2CRetTongSearchHandler GetTongSearch[%d] nil ", pid)
		return
	}

	if cur_search.ChkAddSearchResult(res) {
		log.Info("T2CRetTongSearchHandler already enough %d", len(cur_search.result.GetTongList()))
		hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(cur_search.player_id)
		if nil == hall_svrinfo {
			log.Error("TongMgr T2CRetTongSearchHandler failed to find svrinfo by pid[%d]", cur_search.player_id)
			return
		}

		hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
		if nil == hall_svr {
			log.Error("TongMgr T2CRetTongSearchHandler Failed to get hall_svr by svr_id[%d]", hall_svrinfo.ServerId)
			return
		}

		hall_svr.Send(cur_search.result)

		this.RemoveTongSearch(pid)
	}
	return
}

func (this *TongMgr) T2CEnterTongRequestHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.EnterTongRequest)
	if nil == c || nil == req {
		log.Error("TongMgr T2CEnterTongRequestHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CEnterTongRequestHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CEnterTongRequestHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}

	return
}

func (this *TongMgr) T2CSetPlayerTongInfoHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.SetPlayerTongInfo)
	if nil == req || nil == c {
		log.Error("T2CSetPlayerTongInfoHandler c or req nil [%v]", nil == req)
		return
	}

	pid := req.GetPlayerId()
	hall_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(pid)
	if nil == hall_svrinfo {
		log.Error("T2CSetPlayerTongInfoHandler failed to get hall_svr info[%d]", pid)
		return
	}

	hall_svr := hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
	if nil == hall_svr {
		log.Error("T2CSetPlayerTongInfoHandler failed to get hall_svr info[%d]", hall_svrinfo.ServerId)
		return
	}

	hall_svr.Send(req)

	return
}

func (this *TongMgr) T2CClearPlayerTongInfoHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.ClearPlayerTongInfo)
	if nil == c || nil == req {
		log.Error("T2CClearPlayerTongInfoHandler c or req nil")
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CEnterTongRequestHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CEnterTongRequestHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyPlayerEnterHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyPlayerEnter)
	if nil == c || nil == req {
		log.Error("TongMgr NotifyPlayerEnterHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CEnterTongRequestHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CEnterTongRequestHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyPlayerRefuseHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyPlayerRefuse)
	if nil == c || nil == req {
		log.Error("TongMgr NotifyPlayerEnterHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CEnterTongRequestHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CEnterTongRequestHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongMemberOnOffline GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyTongMemberOnOffline(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyTongMemberOnOffline)
	if nil == c || nil == req {
		log.Error("TongMgr T2CNotifyTongMemberOnOffline c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CNotifyTongMemberOnOffline get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CNotifyTongMemberOnOffline already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongMemberOnOffline GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyTongSetChgHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyTongSetChg)
	if nil == c || nil == req {
		log.Error("TongMgr T2CNotifyTongSetChgHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CNotifyTongSetChgHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CNotifyTongSetChgHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongSetChgHandler GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyTongPubChgHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyTongPubChg)
	if nil == c || nil == req {
		log.Error("TongMgr T2CNotifyTongPubChgHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CNotifyTongPubChgHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CNotifyTongPubChgHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongPubChgHandler GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyTongChatHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyTongChatSend)
	if nil == c || nil == req {
		log.Error("TongMgr T2CNotifyTongChatHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CNotifyTongChatHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CNotifyTongChatHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongChatHandler GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyTongCardReqHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyTongCardReq)
	if nil == c || nil == req {
		log.Error("TongMgr T2CNotifyTongCardReqHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CNotifyTongCardReqHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CNotifyTongCardReqHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongCardReqHandler GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyTongDonateCardHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyTongDonateCard)
	if nil == c || nil == req {
		log.Error("TongMgr T2CNotifyTongDonateCardHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CNotifyTongDonateCardHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CNotifyTongDonateCardHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongDonateCardHandler GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyTongChestScoreChgHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyTongChestScoreChg)
	if nil == c || nil == req {
		log.Error("TongMgr T2CNotifyTongChestScoreChgHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CNotifyTongChestScoreChgHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CNotifyTongChestScoreChgHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongChestScoreChgHandler GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyTongMemberScoreChgHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyTongMemberScoreChg)
	if nil == c || nil == req {
		log.Error("TongMgr T2CNotifyTongMemberScoreChgHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CNotifyTongMemberScoreChgHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CNotifyTongMemberScoreChgHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongMemberScoreChgHandler GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CRetTongChestOpenHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.TongChestOpen)
	if nil == c || nil == req {
		log.Error("TongMgr T2CRetTongChestOpenHandler c or req nil[%v]", nil == req)
		return
	}

	pid := req.GetPlayerId()

	tmp_svrinfo := hall_group_mgr.GetHallCfgByPlayerId(pid)
	if nil == tmp_svrinfo {
		log.Error("TongMgr T2CRetTongChestOpenHandler get tmp_svrinfo nil [%d]", pid)
		return
	}

	tmp_svr := hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
	if nil == tmp_svr {
		log.Error("TongMgr T2CRetTongChestOpenHandler GetAgentById[%d] nil", tmp_svrinfo.ServerId)
		return
	}

	tmp_svr.Send(req)
}

func (this *TongMgr) T2CNotifyTongFriendMatchHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyTongFriendMatch)
	if nil == c || nil == req {
		log.Error("TongMgr T2CNotifyTongFriendMatchHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CNotifyTongFriendMatchHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CNotifyTongFriendMatchHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongFriendMatchHandler GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}

func (this *TongMgr) T2CNotifyTongFriendCancelHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.NotifyTongFriendCancel)
	if nil == c || nil == req {
		log.Error("TongMgr T2CNotifyTongFriendCancelHandler c or req nil[%v]", nil == req)
		return
	}

	sendhallids := make(map[int32]int32)
	online_pids := req.GetOnlinePlayers()
	var tmp_svrinfo *SingleHallCfg
	var tmp_svr *HallAgent
	for _, pid := range online_pids {
		tmp_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
		if nil == tmp_svrinfo {
			log.Error("TongMgr T2CNotifyTongFriendCancelHandler get tmp_svrinfo nil [%d]", pid)
			continue
		}

		if 1 == sendhallids[tmp_svrinfo.ServerId] {
			log.Info("TongMgr T2CNotifyTongFriendCancelHandler already send[%d]", tmp_svrinfo.ServerId)
			continue
		}
		sendhallids[tmp_svrinfo.ServerId] = 1

		tmp_svr = hall_agent_mgr.GetAgentById(tmp_svrinfo.ServerId)
		if nil == tmp_svr {
			log.Error("TongMgr T2CNotifyTongFriendCancelHandler GetAgentById[%d] nil", tmp_svrinfo.ServerId)
			continue
		}

		tmp_svr.Send(req)
	}
}
