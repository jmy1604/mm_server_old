package main

import (
	"3p/code.google.com.protobuf/proto"
	_ "3p/mysql"
	"database/sql"
	"errors"
	"fmt"
	"libs/log"
	"math/rand"
	"os"
	"public_message/gen_go/db_center"
	"strings"
	"sync/atomic"
	"time"
)

type dbArgs struct {
	args  []interface{}
	count int32
}

func new_db_args(count int32) (this *dbArgs) {
	this = &dbArgs{}
	this.args = make([]interface{}, count)
	this.count = 0
	return this
}
func (this *dbArgs) Push(arg interface{}) {
	this.args[this.count] = arg
	this.count++
}
func (this *dbArgs) GetArgs() (args []interface{}) {
	return this.args[0:this.count]
}
func (this *DBC) StmtPrepare(s string) (r *sql.Stmt, e error) {
	this.m_db_lock.Lock("DBC.StmtPrepare")
	defer this.m_db_lock.Unlock()
	return this.m_db.Prepare(s)
}
func (this *DBC) StmtExec(stmt *sql.Stmt, args ...interface{}) (r sql.Result, err error) {
	this.m_db_lock.Lock("DBC.StmtExec")
	defer this.m_db_lock.Unlock()
	return stmt.Exec(args...)
}
func (this *DBC) StmtQuery(stmt *sql.Stmt, args ...interface{}) (r *sql.Rows, err error) {
	this.m_db_lock.Lock("DBC.StmtQuery")
	defer this.m_db_lock.Unlock()
	return stmt.Query(args...)
}
func (this *DBC) StmtQueryRow(stmt *sql.Stmt, args ...interface{}) (r *sql.Row) {
	this.m_db_lock.Lock("DBC.StmtQueryRow")
	defer this.m_db_lock.Unlock()
	return stmt.QueryRow(args...)
}
func (this *DBC) Query(s string, args ...interface{}) (r *sql.Rows, e error) {
	this.m_db_lock.Lock("DBC.Query")
	defer this.m_db_lock.Unlock()
	return this.m_db.Query(s, args...)
}
func (this *DBC) QueryRow(s string, args ...interface{}) (r *sql.Row) {
	this.m_db_lock.Lock("DBC.QueryRow")
	defer this.m_db_lock.Unlock()
	return this.m_db.QueryRow(s, args...)
}
func (this *DBC) Exec(s string, args ...interface{}) (r sql.Result, e error) {
	this.m_db_lock.Lock("DBC.Exec")
	defer this.m_db_lock.Unlock()
	return this.m_db.Exec(s, args...)
}
func (this *DBC) Conn(name string, addr string, acc string, pwd string, db_copy_path string) (err error) {
	log.Trace("%v %v %v %v", name, addr, acc, pwd)
	this.m_db_name = name
	source := acc + ":" + pwd + "@tcp(" + addr + ")/" + name + "?charset=utf8"
	this.m_db, err = sql.Open("mysql", source)
	if err != nil {
		log.Error("open db failed %v", err)
		return
	}

	this.m_db_lock = NewMutex()
	this.m_shutdown_lock = NewMutex()

	if config.DBCST_MAX-config.DBCST_MIN <= 1 {
		return errors.New("DBCST_MAX sub DBCST_MIN should greater than 1s")
	}

	err = this.init_tables()
	if err != nil {
		log.Error("init tables failed")
		return
	}

	if os.MkdirAll(db_copy_path, os.ModePerm) == nil {
		os.Chmod(db_copy_path, os.ModePerm)
	}
	
	this.m_db_last_copy_time = int32(time.Now().Hour())
	this.m_db_copy_path = db_copy_path
	addr_list := strings.Split(addr, ":")
	this.m_db_addr = addr_list[0]
	this.m_db_account = acc
	this.m_db_password = pwd
	this.m_initialized = true

	return
}
func (this *DBC) check_files_exist() (file_name string) {
	f_name := fmt.Sprintf("%v/%v_%v", this.m_db_copy_path, this.m_db_name, time.Now().Format("20060102-15"))
	num := int32(0)
	for {
		if num == 0 {
			file_name = f_name
		} else {
			file_name = f_name + fmt.Sprintf("_%v", num)
		}
		_, err := os.Lstat(file_name)
		if err != nil {
			break
		}
		num++
	}
	return file_name
}
func (this *DBC) Loop() {
	defer func() {
		if err := recover(); err != nil {
			log.Stack(err)
		}

		log.Trace("数据库主循环退出")
		this.m_shutdown_completed = true
	}()

	for {
		t := config.DBCST_MIN + rand.Intn(config.DBCST_MAX-config.DBCST_MIN)
		if t <= 0 {
			t = 600
		}

		for i := 0; i < t; i++ {
			time.Sleep(time.Second)
			if this.m_quit {
				break
			}
		}

		if this.m_quit {
			break
		}

		begin := time.Now()
		err := this.Save(false)
		if err != nil {
			log.Error("save db failed %v", err)
		}
		log.Trace("db存数据花费时长: %v", time.Now().Sub(begin).Nanoseconds())
		/*
			now_time_hour := int32(time.Now().Hour())
			if now_time_hour != this.m_db_last_copy_time {
				args := []string {
					fmt.Sprintf("-h%v", this.m_db_addr),
					fmt.Sprintf("-u%v", this.m_db_account),
					fmt.Sprintf("-p%v", this.m_db_password),
					this.m_db_name,
				}
				cmd := exec.Command("mysqldump", args...)
				var out bytes.Buffer
				cmd.Stdout = &out
				cmd_err := cmd.Run()
				if cmd_err == nil {
					file_name := this.check_files_exist()
					file, file_err := os.OpenFile(file_name, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0660)
					defer file.Close()
					if file_err == nil {
						_, write_err := file.Write(out.Bytes())
						if write_err == nil {
							log.Trace("数据库备份成功！备份文件名:%v", file_name)
						} else {
							log.Error("数据库备份文件写入失败！备份文件名%v", file_name)
						}
					} else {
						log.Error("数据库备份文件打开失败！备份文件名%v", file_name)
					}
					file.Close()
				} else {
					log.Error("数据库备份失败！")
				}
				this.m_db_last_copy_time = now_time_hour
			}
		*/
		
		if this.m_quit {
			break
		}
	}

	log.Trace("数据库缓存主循环退出，保存所有数据")

	err := this.Save(true)
	if err != nil {
		log.Error("shutdwon save db failed %v", err)
		return
	}

	err = this.m_db.Close()
	if err != nil {
		log.Error("close db failed %v", err)
		return
	}
}
func (this *DBC) Shutdown() {
	if !this.m_initialized {
		return
	}

	this.m_shutdown_lock.UnSafeLock("DBC.Shutdown")
	defer this.m_shutdown_lock.UnSafeUnlock()

	if this.m_quit {
		return
	}
	this.m_quit = true

	log.Trace("关闭数据库缓存")

	begin := time.Now()

	for {
		if this.m_shutdown_completed {
			break
		}

		time.Sleep(time.Millisecond * 100)
	}

	log.Trace("关闭数据库缓存耗时 %v 秒", time.Now().Sub(begin).Seconds())
}


const DBC_VERSION = 1
const DBC_SUB_VERSION = 0

type dbHeroDesireParamData struct{
	TargetValue int32
	Value1 int32
	Value2 int32
}
func (this* dbHeroDesireParamData)from_pb(pb *db.HeroDesireParam){
	if pb == nil {
		return
	}
	this.TargetValue = pb.GetTargetValue()
	this.Value1 = pb.GetValue1()
	this.Value2 = pb.GetValue2()
	return
}
func (this* dbHeroDesireParamData)to_pb()(pb *db.HeroDesireParam){
	pb = &db.HeroDesireParam{}
	pb.TargetValue = proto.Int32(this.TargetValue)
	pb.Value1 = proto.Int32(this.Value1)
	pb.Value2 = proto.Int32(this.Value2)
	return
}
func (this* dbHeroDesireParamData)clone_to(d *dbHeroDesireParamData){
	d.TargetValue = this.TargetValue
	d.Value1 = this.Value1
	d.Value2 = this.Value2
	return
}
type dbSmallRankRecordData struct{
	Rank int32
	Id int32
	Val int32
	Name string
	TongName string
	TongIcon int32
}
func (this* dbSmallRankRecordData)from_pb(pb *db.SmallRankRecord){
	if pb == nil {
		return
	}
	this.Rank = pb.GetRank()
	this.Id = pb.GetId()
	this.Val = pb.GetVal()
	this.Name = pb.GetName()
	this.TongName = pb.GetTongName()
	this.TongIcon = pb.GetTongIcon()
	return
}
func (this* dbSmallRankRecordData)to_pb()(pb *db.SmallRankRecord){
	pb = &db.SmallRankRecord{}
	pb.Rank = proto.Int32(this.Rank)
	pb.Id = proto.Int32(this.Id)
	pb.Val = proto.Int32(this.Val)
	pb.Name = proto.String(this.Name)
	pb.TongName = proto.String(this.TongName)
	pb.TongIcon = proto.Int32(this.TongIcon)
	return
}
func (this* dbSmallRankRecordData)clone_to(d *dbSmallRankRecordData){
	d.Rank = this.Rank
	d.Id = this.Id
	d.Val = this.Val
	d.Name = this.Name
	d.TongName = this.TongName
	d.TongIcon = this.TongIcon
	return
}
type dbCampFightRecordData struct{
	FightIdx int32
	XScore int32
	TScore int32
}
func (this* dbCampFightRecordData)from_pb(pb *db.CampFightRecord){
	if pb == nil {
		return
	}
	this.FightIdx = pb.GetFightIdx()
	this.XScore = pb.GetXScore()
	this.TScore = pb.GetTScore()
	return
}
func (this* dbCampFightRecordData)to_pb()(pb *db.CampFightRecord){
	pb = &db.CampFightRecord{}
	pb.FightIdx = proto.Int32(this.FightIdx)
	pb.XScore = proto.Int32(this.XScore)
	pb.TScore = proto.Int32(this.TScore)
	return
}
func (this* dbCampFightRecordData)clone_to(d *dbCampFightRecordData){
	d.FightIdx = this.FightIdx
	d.XScore = this.XScore
	d.TScore = this.TScore
	return
}
type dbLastSmallRankRankInfoData struct{
	PNScoreRankStartTime int32
}
func (this* dbLastSmallRankRankInfoData)from_pb(pb *db.LastSmallRankRankInfo){
	if pb == nil {
		return
	}
	this.PNScoreRankStartTime = pb.GetPNScoreRankStartTime()
	return
}
func (this* dbLastSmallRankRankInfoData)to_pb()(pb *db.LastSmallRankRankInfo){
	pb = &db.LastSmallRankRankInfo{}
	pb.PNScoreRankStartTime = proto.Int32(this.PNScoreRankStartTime)
	return
}
func (this* dbLastSmallRankRankInfoData)clone_to(d *dbLastSmallRankRankInfoData){
	d.PNScoreRankStartTime = this.PNScoreRankStartTime
	return
}
type dbLastSmallRankPlayerNScoreRankData struct{
	Records []dbSmallRankRecordData
}
func (this* dbLastSmallRankPlayerNScoreRankData)from_pb(pb *db.LastSmallRankPlayerNScoreRank){
	if pb == nil {
		this.Records = make([]dbSmallRankRecordData,0)
		return
	}
	this.Records = make([]dbSmallRankRecordData,len(pb.GetRecords()))
	for i, v := range pb.GetRecords() {
		this.Records[i].from_pb(v)
	}
	return
}
func (this* dbLastSmallRankPlayerNScoreRankData)to_pb()(pb *db.LastSmallRankPlayerNScoreRank){
	pb = &db.LastSmallRankPlayerNScoreRank{}
	pb.Records = make([]*db.SmallRankRecord, len(this.Records))
	for i, v := range this.Records {
		pb.Records[i]=v.to_pb()
	}
	return
}
func (this* dbLastSmallRankPlayerNScoreRankData)clone_to(d *dbLastSmallRankPlayerNScoreRankData){
	d.Records = make([]dbSmallRankRecordData, len(this.Records))
	for _ii, _vv := range this.Records {
		_vv.clone_to(&d.Records[_ii])
	}
	return
}
type dbCampFightBaseInfoData struct{
	CurFightArea int32
	CurFightIdx int32
	CurActISOWeek int32
	LastRewardISOWeek int32
	CurCamp1Score int32
	CurCamp2Score int32
	CurRestIdx int32
}
func (this* dbCampFightBaseInfoData)from_pb(pb *db.CampFightBaseInfo){
	if pb == nil {
		return
	}
	this.CurFightArea = pb.GetCurFightArea()
	this.CurFightIdx = pb.GetCurFightIdx()
	this.CurActISOWeek = pb.GetCurActISOWeek()
	this.LastRewardISOWeek = pb.GetLastRewardISOWeek()
	this.CurCamp1Score = pb.GetCurCamp1Score()
	this.CurCamp2Score = pb.GetCurCamp2Score()
	this.CurRestIdx = pb.GetCurRestIdx()
	return
}
func (this* dbCampFightBaseInfoData)to_pb()(pb *db.CampFightBaseInfo){
	pb = &db.CampFightBaseInfo{}
	pb.CurFightArea = proto.Int32(this.CurFightArea)
	pb.CurFightIdx = proto.Int32(this.CurFightIdx)
	pb.CurActISOWeek = proto.Int32(this.CurActISOWeek)
	pb.LastRewardISOWeek = proto.Int32(this.LastRewardISOWeek)
	pb.CurCamp1Score = proto.Int32(this.CurCamp1Score)
	pb.CurCamp2Score = proto.Int32(this.CurCamp2Score)
	pb.CurRestIdx = proto.Int32(this.CurRestIdx)
	return
}
func (this* dbCampFightBaseInfoData)clone_to(d *dbCampFightBaseInfoData){
	d.CurFightArea = this.CurFightArea
	d.CurFightIdx = this.CurFightIdx
	d.CurActISOWeek = this.CurActISOWeek
	d.LastRewardISOWeek = this.LastRewardISOWeek
	d.CurCamp1Score = this.CurCamp1Score
	d.CurCamp2Score = this.CurCamp2Score
	d.CurRestIdx = this.CurRestIdx
	return
}
type dbCampFightCurTotalRankData struct{
	Records []dbSmallRankRecordData
}
func (this* dbCampFightCurTotalRankData)from_pb(pb *db.CampFightCurTotalRank){
	if pb == nil {
		this.Records = make([]dbSmallRankRecordData,0)
		return
	}
	this.Records = make([]dbSmallRankRecordData,len(pb.GetRecords()))
	for i, v := range pb.GetRecords() {
		this.Records[i].from_pb(v)
	}
	return
}
func (this* dbCampFightCurTotalRankData)to_pb()(pb *db.CampFightCurTotalRank){
	pb = &db.CampFightCurTotalRank{}
	pb.Records = make([]*db.SmallRankRecord, len(this.Records))
	for i, v := range this.Records {
		pb.Records[i]=v.to_pb()
	}
	return
}
func (this* dbCampFightCurTotalRankData)clone_to(d *dbCampFightCurTotalRankData){
	d.Records = make([]dbSmallRankRecordData, len(this.Records))
	for _ii, _vv := range this.Records {
		_vv.clone_to(&d.Records[_ii])
	}
	return
}
type dbCampFightCurCamp1RankData struct{
	Records []dbSmallRankRecordData
}
func (this* dbCampFightCurCamp1RankData)from_pb(pb *db.CampFightCurCamp1Rank){
	if pb == nil {
		this.Records = make([]dbSmallRankRecordData,0)
		return
	}
	this.Records = make([]dbSmallRankRecordData,len(pb.GetRecords()))
	for i, v := range pb.GetRecords() {
		this.Records[i].from_pb(v)
	}
	return
}
func (this* dbCampFightCurCamp1RankData)to_pb()(pb *db.CampFightCurCamp1Rank){
	pb = &db.CampFightCurCamp1Rank{}
	pb.Records = make([]*db.SmallRankRecord, len(this.Records))
	for i, v := range this.Records {
		pb.Records[i]=v.to_pb()
	}
	return
}
func (this* dbCampFightCurCamp1RankData)clone_to(d *dbCampFightCurCamp1RankData){
	d.Records = make([]dbSmallRankRecordData, len(this.Records))
	for _ii, _vv := range this.Records {
		_vv.clone_to(&d.Records[_ii])
	}
	return
}
type dbCampFightCurCamp2RankData struct{
	Records []dbSmallRankRecordData
}
func (this* dbCampFightCurCamp2RankData)from_pb(pb *db.CampFightCurCamp2Rank){
	if pb == nil {
		this.Records = make([]dbSmallRankRecordData,0)
		return
	}
	this.Records = make([]dbSmallRankRecordData,len(pb.GetRecords()))
	for i, v := range pb.GetRecords() {
		this.Records[i].from_pb(v)
	}
	return
}
func (this* dbCampFightCurCamp2RankData)to_pb()(pb *db.CampFightCurCamp2Rank){
	pb = &db.CampFightCurCamp2Rank{}
	pb.Records = make([]*db.SmallRankRecord, len(this.Records))
	for i, v := range this.Records {
		pb.Records[i]=v.to_pb()
	}
	return
}
func (this* dbCampFightCurCamp2RankData)clone_to(d *dbCampFightCurCamp2RankData){
	d.Records = make([]dbSmallRankRecordData, len(this.Records))
	for _ii, _vv := range this.Records {
		_vv.clone_to(&d.Records[_ii])
	}
	return
}
type dbCampFightLastTotalRankData struct{
	Records []dbSmallRankRecordData
}
func (this* dbCampFightLastTotalRankData)from_pb(pb *db.CampFightLastTotalRank){
	if pb == nil {
		this.Records = make([]dbSmallRankRecordData,0)
		return
	}
	this.Records = make([]dbSmallRankRecordData,len(pb.GetRecords()))
	for i, v := range pb.GetRecords() {
		this.Records[i].from_pb(v)
	}
	return
}
func (this* dbCampFightLastTotalRankData)to_pb()(pb *db.CampFightLastTotalRank){
	pb = &db.CampFightLastTotalRank{}
	pb.Records = make([]*db.SmallRankRecord, len(this.Records))
	for i, v := range this.Records {
		pb.Records[i]=v.to_pb()
	}
	return
}
func (this* dbCampFightLastTotalRankData)clone_to(d *dbCampFightLastTotalRankData){
	d.Records = make([]dbSmallRankRecordData, len(this.Records))
	for _ii, _vv := range this.Records {
		_vv.clone_to(&d.Records[_ii])
	}
	return
}
type dbCampFightLastCamp1RankData struct{
	Records []dbSmallRankRecordData
}
func (this* dbCampFightLastCamp1RankData)from_pb(pb *db.CampFightLastCamp1Rank){
	if pb == nil {
		this.Records = make([]dbSmallRankRecordData,0)
		return
	}
	this.Records = make([]dbSmallRankRecordData,len(pb.GetRecords()))
	for i, v := range pb.GetRecords() {
		this.Records[i].from_pb(v)
	}
	return
}
func (this* dbCampFightLastCamp1RankData)to_pb()(pb *db.CampFightLastCamp1Rank){
	pb = &db.CampFightLastCamp1Rank{}
	pb.Records = make([]*db.SmallRankRecord, len(this.Records))
	for i, v := range this.Records {
		pb.Records[i]=v.to_pb()
	}
	return
}
func (this* dbCampFightLastCamp1RankData)clone_to(d *dbCampFightLastCamp1RankData){
	d.Records = make([]dbSmallRankRecordData, len(this.Records))
	for _ii, _vv := range this.Records {
		_vv.clone_to(&d.Records[_ii])
	}
	return
}
type dbCampFightLastCamp2RankData struct{
	Records []dbSmallRankRecordData
}
func (this* dbCampFightLastCamp2RankData)from_pb(pb *db.CampFightLastCamp2Rank){
	if pb == nil {
		this.Records = make([]dbSmallRankRecordData,0)
		return
	}
	this.Records = make([]dbSmallRankRecordData,len(pb.GetRecords()))
	for i, v := range pb.GetRecords() {
		this.Records[i].from_pb(v)
	}
	return
}
func (this* dbCampFightLastCamp2RankData)to_pb()(pb *db.CampFightLastCamp2Rank){
	pb = &db.CampFightLastCamp2Rank{}
	pb.Records = make([]*db.SmallRankRecord, len(this.Records))
	for i, v := range this.Records {
		pb.Records[i]=v.to_pb()
	}
	return
}
func (this* dbCampFightLastCamp2RankData)clone_to(d *dbCampFightLastCamp2RankData){
	d.Records = make([]dbSmallRankRecordData, len(this.Records))
	for _ii, _vv := range this.Records {
		_vv.clone_to(&d.Records[_ii])
	}
	return
}
type dbCampFightCurCampFighgtRecordData struct{
	Records []dbCampFightRecordData
}
func (this* dbCampFightCurCampFighgtRecordData)from_pb(pb *db.CampFightCurCampFighgtRecord){
	if pb == nil {
		this.Records = make([]dbCampFightRecordData,0)
		return
	}
	this.Records = make([]dbCampFightRecordData,len(pb.GetRecords()))
	for i, v := range pb.GetRecords() {
		this.Records[i].from_pb(v)
	}
	return
}
func (this* dbCampFightCurCampFighgtRecordData)to_pb()(pb *db.CampFightCurCampFighgtRecord){
	pb = &db.CampFightCurCampFighgtRecord{}
	pb.Records = make([]*db.CampFightRecord, len(this.Records))
	for i, v := range this.Records {
		pb.Records[i]=v.to_pb()
	}
	return
}
func (this* dbCampFightCurCampFighgtRecordData)clone_to(d *dbCampFightCurCampFighgtRecordData){
	d.Records = make([]dbCampFightRecordData, len(this.Records))
	for _ii, _vv := range this.Records {
		_vv.clone_to(&d.Records[_ii])
	}
	return
}

func (this *dbAccountRow)GetPlayerId( )(r int32 ){
	this.m_lock.UnSafeRLock("dbAccountRow.GetdbAccountPlayerIdColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_PlayerId)
}
func (this *dbAccountRow)SetPlayerId(v int32){
	this.m_lock.UnSafeLock("dbAccountRow.SetdbAccountPlayerIdColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_PlayerId=int32(v)
	this.m_PlayerId_changed=true
	return
}
func (this *dbAccountRow)GetCreateTime( )(r int32 ){
	this.m_lock.UnSafeRLock("dbAccountRow.GetdbAccountCreateTimeColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_CreateTime)
}
func (this *dbAccountRow)SetCreateTime(v int32){
	this.m_lock.UnSafeLock("dbAccountRow.SetdbAccountCreateTimeColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_CreateTime=int32(v)
	this.m_CreateTime_changed=true
	return
}
type dbAccountRow struct {
	m_table *dbAccountTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_Account        string
	m_PlayerId_changed bool
	m_PlayerId int32
	m_CreateTime_changed bool
	m_CreateTime int32
}
func new_dbAccountRow(table *dbAccountTable, Account string) (r *dbAccountRow) {
	this := &dbAccountRow{}
	this.m_table = table
	this.m_Account = Account
	this.m_lock = NewRWMutex()
	this.m_PlayerId_changed=true
	this.m_CreateTime_changed=true
	return this
}
func (this *dbAccountRow) GetAccount() (r string) {
	return this.m_Account
}
func (this *dbAccountRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbAccountRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(3)
		db_args.Push(this.m_Account)
		db_args.Push(this.m_PlayerId)
		db_args.Push(this.m_CreateTime)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.m_PlayerId_changed||this.m_CreateTime_changed{
			update_string = "UPDATE Accounts SET "
			db_args:=new_db_args(3)
			if this.m_PlayerId_changed{
				update_string+="PlayerId=?,"
				db_args.Push(this.m_PlayerId)
			}
			if this.m_CreateTime_changed{
				update_string+="CreateTime=?,"
				db_args.Push(this.m_CreateTime)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE Account=?"
			db_args.Push(this.m_Account)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.m_PlayerId_changed = false
	this.m_CreateTime_changed = false
	if release && this.m_loaded {
		atomic.AddInt32(&this.m_table.m_gc_n, -1)
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbAccountRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT Accounts exec failed %v ", this.m_Account)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE Accounts exec failed %v", this.m_Account)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
func (this *dbAccountRow) Touch(releasable bool) {
	this.m_touch = int32(time.Now().Unix())
	this.m_releasable = releasable
}
type dbAccountRowSort struct {
	rows []*dbAccountRow
}
func (this *dbAccountRowSort) Len() (length int) {
	return len(this.rows)
}
func (this *dbAccountRowSort) Less(i int, j int) (less bool) {
	return this.rows[i].m_touch < this.rows[j].m_touch
}
func (this *dbAccountRowSort) Swap(i int, j int) {
	temp := this.rows[i]
	this.rows[i] = this.rows[j]
	this.rows[j] = temp
}
type dbAccountTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_rows map[string]*dbAccountRow
	m_new_rows map[string]*dbAccountRow
	m_removed_rows map[string]*dbAccountRow
	m_gc_n int32
	m_gcing int32
	m_pool_size int32
	m_preload_select_stmt *sql.Stmt
	m_preload_max_id int32
	m_save_insert_stmt *sql.Stmt
	m_delete_stmt *sql.Stmt
}
func new_dbAccountTable(dbc *DBC) (this *dbAccountTable) {
	this = &dbAccountTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	this.m_rows = make(map[string]*dbAccountRow)
	this.m_new_rows = make(map[string]*dbAccountRow)
	this.m_removed_rows = make(map[string]*dbAccountRow)
	return this
}
func (this *dbAccountTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS Accounts(Account varchar(45),PRIMARY KEY (Account))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS Accounts failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='Accounts'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasPlayerId := columns["PlayerId"]
	if !hasPlayerId {
		_, err = this.m_dbc.Exec("ALTER TABLE Accounts ADD COLUMN PlayerId int(11)")
		if err != nil {
			log.Error("ADD COLUMN PlayerId failed")
			return
		}
	}
	_, hasCreateTime := columns["CreateTime"]
	if !hasCreateTime {
		_, err = this.m_dbc.Exec("ALTER TABLE Accounts ADD COLUMN CreateTime int(11)")
		if err != nil {
			log.Error("ADD COLUMN CreateTime failed")
			return
		}
	}
	return
}
func (this *dbAccountTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT Account,PlayerId,CreateTime FROM Accounts")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbAccountTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO Accounts (Account,PlayerId,CreateTime) VALUES (?,?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbAccountTable) prepare_delete_stmt() (err error) {
	this.m_delete_stmt,err=this.m_dbc.StmtPrepare("DELETE FROM Accounts WHERE Account=?")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbAccountTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	err=this.prepare_delete_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbAccountTable) Preload() (err error) {
	r, err := this.m_dbc.StmtQuery(this.m_preload_select_stmt)
	if err != nil {
		log.Error("SELECT")
		return
	}
	var Account string
	var dPlayerId int32
	var dCreateTime int32
	for r.Next() {
		err = r.Scan(&Account,&dPlayerId,&dCreateTime)
		if err != nil {
			log.Error("Scan")
			return
		}
		row := new_dbAccountRow(this,Account)
		row.m_PlayerId=dPlayerId
		row.m_CreateTime=dCreateTime
		row.m_PlayerId_changed=false
		row.m_CreateTime_changed=false
		row.m_valid = true
		this.m_rows[Account]=row
	}
	return
}
func (this *dbAccountTable) GetPreloadedMaxId() (max_id int32) {
	return this.m_preload_max_id
}
func (this *dbAccountTable) fetch_rows(rows map[string]*dbAccountRow) (r map[string]*dbAccountRow) {
	this.m_lock.UnSafeLock("dbAccountTable.fetch_rows")
	defer this.m_lock.UnSafeUnlock()
	r = make(map[string]*dbAccountRow)
	for i, v := range rows {
		r[i] = v
	}
	return r
}
func (this *dbAccountTable) fetch_new_rows() (new_rows map[string]*dbAccountRow) {
	this.m_lock.UnSafeLock("dbAccountTable.fetch_new_rows")
	defer this.m_lock.UnSafeUnlock()
	new_rows = make(map[string]*dbAccountRow)
	for i, v := range this.m_new_rows {
		_, has := this.m_rows[i]
		if has {
			log.Error("rows already has new rows %v", i)
			continue
		}
		this.m_rows[i] = v
		new_rows[i] = v
	}
	for i, _ := range new_rows {
		delete(this.m_new_rows, i)
	}
	return
}
func (this *dbAccountTable) save_rows(rows map[string]*dbAccountRow, quick bool) {
	for _, v := range rows {
		if this.m_dbc.m_quit && !quick {
			return
		}
		err, delay, _ := v.Save(false)
		if err != nil {
			log.Error("save failed %v", err)
		}
		if this.m_dbc.m_quit && !quick {
			return
		}
		if delay&&!quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
}
func (this *dbAccountTable) Save(quick bool) (err error){
	removed_rows := this.fetch_rows(this.m_removed_rows)
	for _, v := range removed_rows {
		_, err := this.m_dbc.StmtExec(this.m_delete_stmt, v.GetAccount())
		if err != nil {
			log.Error("exec delete stmt failed %v", err)
		}
		v.m_valid = false
		if !quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
	this.m_removed_rows = make(map[string]*dbAccountRow)
	rows := this.fetch_rows(this.m_rows)
	this.save_rows(rows, quick)
	new_rows := this.fetch_new_rows()
	this.save_rows(new_rows, quick)
	return
}
func (this *dbAccountTable) AddRow(Account string) (row *dbAccountRow) {
	this.m_lock.UnSafeLock("dbAccountTable.AddRow")
	defer this.m_lock.UnSafeUnlock()
	row = new_dbAccountRow(this,Account)
	row.m_new = true
	row.m_loaded = true
	row.m_valid = true
	_, has := this.m_new_rows[Account]
	if has{
		log.Error("已经存在 %v", Account)
		return nil
	}
	this.m_new_rows[Account] = row
	atomic.AddInt32(&this.m_gc_n,1)
	return row
}
func (this *dbAccountTable) RemoveRow(Account string) {
	this.m_lock.UnSafeLock("dbAccountTable.RemoveRow")
	defer this.m_lock.UnSafeUnlock()
	row := this.m_rows[Account]
	if row != nil {
		row.m_remove = true
		row = this.m_removed_rows[Account]
		if row != nil {
			log.Error("rows and removed rows both has %v", Account)
			row.m_remove = true
			delete(this.m_rows,Account)
			this.m_removed_rows[Account] = row
		} else {
			delete(this.m_rows, Account)
		}
		_, has_new := this.m_new_rows[Account]
		if has_new {
			delete(this.m_new_rows, Account)
			log.Error("rows and new_rows both has %v", Account)
		}
	} else {
		row = this.m_removed_rows[Account]
		if row == nil {
			_, has_new := this.m_new_rows[Account]
			if has_new {
				delete(this.m_new_rows, Account)
			} else {
				log.Error("row not exist %v", Account)
			}
		} else {
			log.Error("already removed %v", Account)
			_, has_new := this.m_new_rows[Account]
			if has_new {
				delete(this.m_new_rows, Account)
				log.Error("removed rows and new_rows both has %v", Account)
			}
		}
	}
}
func (this *dbAccountTable) GetRow(Account string) (row *dbAccountRow) {
	this.m_lock.UnSafeRLock("dbAccountTable.GetRow")
	defer this.m_lock.UnSafeRUnlock()
	row = this.m_rows[Account]
	if row == nil {
		row = this.m_new_rows[Account]
	}
	return row
}
func (this *dbPlayerIdMaxRow)GetPlayerIdMax( )(r int32 ){
	this.m_lock.UnSafeRLock("dbPlayerIdMaxRow.GetdbPlayerIdMaxPlayerIdMaxColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_PlayerIdMax)
}
func (this *dbPlayerIdMaxRow)SetPlayerIdMax(v int32){
	this.m_lock.UnSafeLock("dbPlayerIdMaxRow.SetdbPlayerIdMaxPlayerIdMaxColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_PlayerIdMax=int32(v)
	this.m_PlayerIdMax_changed=true
	return
}
type dbPlayerIdMaxRow struct {
	m_table *dbPlayerIdMaxTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_PlaceHolder        int32
	m_PlayerIdMax_changed bool
	m_PlayerIdMax int32
}
func new_dbPlayerIdMaxRow(table *dbPlayerIdMaxTable, PlaceHolder int32) (r *dbPlayerIdMaxRow) {
	this := &dbPlayerIdMaxRow{}
	this.m_table = table
	this.m_PlaceHolder = PlaceHolder
	this.m_lock = NewRWMutex()
	this.m_PlayerIdMax_changed=true
	return this
}
func (this *dbPlayerIdMaxRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbPlayerIdMaxRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(2)
		db_args.Push(this.m_PlaceHolder)
		db_args.Push(this.m_PlayerIdMax)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.m_PlayerIdMax_changed{
			update_string = "UPDATE PlayerIdMax SET "
			db_args:=new_db_args(2)
			if this.m_PlayerIdMax_changed{
				update_string+="PlayerIdMax=?,"
				db_args.Push(this.m_PlayerIdMax)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE PlaceHolder=?"
			db_args.Push(this.m_PlaceHolder)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.m_PlayerIdMax_changed = false
	if release && this.m_loaded {
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbPlayerIdMaxRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT PlayerIdMax exec failed %v ", this.m_PlaceHolder)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE PlayerIdMax exec failed %v", this.m_PlaceHolder)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
type dbPlayerIdMaxTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_row *dbPlayerIdMaxRow
	m_preload_select_stmt *sql.Stmt
	m_save_insert_stmt *sql.Stmt
}
func new_dbPlayerIdMaxTable(dbc *DBC) (this *dbPlayerIdMaxTable) {
	this = &dbPlayerIdMaxTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	return this
}
func (this *dbPlayerIdMaxTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS PlayerIdMax(PlaceHolder int(11),PRIMARY KEY (PlaceHolder))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS PlayerIdMax failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='PlayerIdMax'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasPlayerIdMax := columns["PlayerIdMax"]
	if !hasPlayerIdMax {
		_, err = this.m_dbc.Exec("ALTER TABLE PlayerIdMax ADD COLUMN PlayerIdMax int(11) DEFAULT 0")
		if err != nil {
			log.Error("ADD COLUMN PlayerIdMax failed")
			return
		}
	}
	return
}
func (this *dbPlayerIdMaxTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT PlayerIdMax FROM PlayerIdMax WHERE PlaceHolder=0")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbPlayerIdMaxTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO PlayerIdMax (PlaceHolder,PlayerIdMax) VALUES (?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbPlayerIdMaxTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbPlayerIdMaxTable) Preload() (err error) {
	r := this.m_dbc.StmtQueryRow(this.m_preload_select_stmt)
	var dPlayerIdMax int32
	err = r.Scan(&dPlayerIdMax)
	if err!=nil{
		if err!=sql.ErrNoRows{
			log.Error("Scan failed")
			return
		}
	}else{
		row := new_dbPlayerIdMaxRow(this,0)
		row.m_PlayerIdMax=dPlayerIdMax
		row.m_PlayerIdMax_changed=false
		row.m_valid = true
		row.m_loaded=true
		this.m_row=row
	}
	if this.m_row == nil {
		this.m_row = new_dbPlayerIdMaxRow(this, 0)
		this.m_row.m_new = true
		this.m_row.m_valid = true
		err = this.Save(false)
		if err != nil {
			log.Error("save failed")
			return
		}
		this.m_row.m_loaded = true
	}
	return
}
func (this *dbPlayerIdMaxTable) Save(quick bool) (err error) {
	if this.m_row==nil{
		return errors.New("row nil")
	}
	err, _, _ = this.m_row.Save(false)
	return err
}
func (this *dbPlayerIdMaxTable) GetRow( ) (row *dbPlayerIdMaxRow) {
	return this.m_row
}
type dbLastSmallRankRankInfoColumn struct{
	m_row *dbLastSmallRankRow
	m_data *dbLastSmallRankRankInfoData
	m_changed bool
}
func (this *dbLastSmallRankRankInfoColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbLastSmallRankRankInfoData{}
		this.m_changed = false
		return nil
	}
	pb := &db.LastSmallRankRankInfo{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_data = &dbLastSmallRankRankInfoData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbLastSmallRankRankInfoColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_changed = false
	return
}
func (this *dbLastSmallRankRankInfoColumn)Get( )(v *dbLastSmallRankRankInfoData ){
	this.m_row.m_lock.UnSafeRLock("dbLastSmallRankRankInfoColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbLastSmallRankRankInfoData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbLastSmallRankRankInfoColumn)Set(v dbLastSmallRankRankInfoData ){
	this.m_row.m_lock.UnSafeLock("dbLastSmallRankRankInfoColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbLastSmallRankRankInfoData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbLastSmallRankRankInfoColumn)GetPNScoreRankStartTime( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbLastSmallRankRankInfoColumn.GetPNScoreRankStartTime")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.PNScoreRankStartTime
	return
}
func (this *dbLastSmallRankRankInfoColumn)SetPNScoreRankStartTime(v int32){
	this.m_row.m_lock.UnSafeLock("dbLastSmallRankRankInfoColumn.SetPNScoreRankStartTime")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.PNScoreRankStartTime = v
	this.m_changed = true
	return
}
type dbLastSmallRankPlayerNScoreRankColumn struct{
	m_row *dbLastSmallRankRow
	m_data *dbLastSmallRankPlayerNScoreRankData
	m_changed bool
}
func (this *dbLastSmallRankPlayerNScoreRankColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbLastSmallRankPlayerNScoreRankData{}
		this.m_changed = false
		return nil
	}
	pb := &db.LastSmallRankPlayerNScoreRank{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_data = &dbLastSmallRankPlayerNScoreRankData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbLastSmallRankPlayerNScoreRankColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_changed = false
	return
}
func (this *dbLastSmallRankPlayerNScoreRankColumn)Get( )(v *dbLastSmallRankPlayerNScoreRankData ){
	this.m_row.m_lock.UnSafeRLock("dbLastSmallRankPlayerNScoreRankColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbLastSmallRankPlayerNScoreRankData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbLastSmallRankPlayerNScoreRankColumn)Set(v dbLastSmallRankPlayerNScoreRankData ){
	this.m_row.m_lock.UnSafeLock("dbLastSmallRankPlayerNScoreRankColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbLastSmallRankPlayerNScoreRankData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbLastSmallRankPlayerNScoreRankColumn)GetRecords( )(v []dbSmallRankRecordData ){
	this.m_row.m_lock.UnSafeRLock("dbLastSmallRankPlayerNScoreRankColumn.GetRecords")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]dbSmallRankRecordData, len(this.m_data.Records))
	for _ii, _vv := range this.m_data.Records {
		_vv.clone_to(&v[_ii])
	}
	return
}
func (this *dbLastSmallRankPlayerNScoreRankColumn)SetRecords(v []dbSmallRankRecordData){
	this.m_row.m_lock.UnSafeLock("dbLastSmallRankPlayerNScoreRankColumn.SetRecords")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Records = make([]dbSmallRankRecordData, len(v))
	for _ii, _vv := range v {
		_vv.clone_to(&this.m_data.Records[_ii])
	}
	this.m_changed = true
	return
}
type dbLastSmallRankRow struct {
	m_table *dbLastSmallRankTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_PlaceHolder        int32
	RankInfo dbLastSmallRankRankInfoColumn
	PlayerNScoreRank dbLastSmallRankPlayerNScoreRankColumn
}
func new_dbLastSmallRankRow(table *dbLastSmallRankTable, PlaceHolder int32) (r *dbLastSmallRankRow) {
	this := &dbLastSmallRankRow{}
	this.m_table = table
	this.m_PlaceHolder = PlaceHolder
	this.m_lock = NewRWMutex()
	this.RankInfo.m_row=this
	this.RankInfo.m_data=&dbLastSmallRankRankInfoData{}
	this.PlayerNScoreRank.m_row=this
	this.PlayerNScoreRank.m_data=&dbLastSmallRankPlayerNScoreRankData{}
	return this
}
func (this *dbLastSmallRankRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbLastSmallRankRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(3)
		db_args.Push(this.m_PlaceHolder)
		dRankInfo,db_err:=this.RankInfo.save()
		if db_err!=nil{
			log.Error("insert save RankInfo failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dRankInfo)
		dPlayerNScoreRank,db_err:=this.PlayerNScoreRank.save()
		if db_err!=nil{
			log.Error("insert save PlayerNScoreRank failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dPlayerNScoreRank)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.RankInfo.m_changed||this.PlayerNScoreRank.m_changed{
			update_string = "UPDATE LastSmallRank SET "
			db_args:=new_db_args(3)
			if this.RankInfo.m_changed{
				update_string+="RankInfo=?,"
				dRankInfo,err:=this.RankInfo.save()
				if err!=nil{
					log.Error("update save RankInfo failed")
					return err,false,0,"",nil
				}
				db_args.Push(dRankInfo)
			}
			if this.PlayerNScoreRank.m_changed{
				update_string+="PlayerNScoreRank=?,"
				dPlayerNScoreRank,err:=this.PlayerNScoreRank.save()
				if err!=nil{
					log.Error("update save PlayerNScoreRank failed")
					return err,false,0,"",nil
				}
				db_args.Push(dPlayerNScoreRank)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE PlaceHolder=?"
			db_args.Push(this.m_PlaceHolder)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.RankInfo.m_changed = false
	this.PlayerNScoreRank.m_changed = false
	if release && this.m_loaded {
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbLastSmallRankRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT LastSmallRank exec failed %v ", this.m_PlaceHolder)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE LastSmallRank exec failed %v", this.m_PlaceHolder)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
type dbLastSmallRankTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_row *dbLastSmallRankRow
	m_preload_select_stmt *sql.Stmt
	m_save_insert_stmt *sql.Stmt
}
func new_dbLastSmallRankTable(dbc *DBC) (this *dbLastSmallRankTable) {
	this = &dbLastSmallRankTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	return this
}
func (this *dbLastSmallRankTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS LastSmallRank(PlaceHolder int(11),PRIMARY KEY (PlaceHolder))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS LastSmallRank failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='LastSmallRank'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasRankInfo := columns["RankInfo"]
	if !hasRankInfo {
		_, err = this.m_dbc.Exec("ALTER TABLE LastSmallRank ADD COLUMN RankInfo LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN RankInfo failed")
			return
		}
	}
	_, hasPlayerNScoreRank := columns["PlayerNScoreRank"]
	if !hasPlayerNScoreRank {
		_, err = this.m_dbc.Exec("ALTER TABLE LastSmallRank ADD COLUMN PlayerNScoreRank LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN PlayerNScoreRank failed")
			return
		}
	}
	return
}
func (this *dbLastSmallRankTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT RankInfo,PlayerNScoreRank FROM LastSmallRank WHERE PlaceHolder=0")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbLastSmallRankTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO LastSmallRank (PlaceHolder,RankInfo,PlayerNScoreRank) VALUES (?,?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbLastSmallRankTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbLastSmallRankTable) Preload() (err error) {
	r := this.m_dbc.StmtQueryRow(this.m_preload_select_stmt)
	var dRankInfo []byte
	var dPlayerNScoreRank []byte
	err = r.Scan(&dRankInfo,&dPlayerNScoreRank)
	if err!=nil{
		if err!=sql.ErrNoRows{
			log.Error("Scan failed")
			return
		}
	}else{
		row := new_dbLastSmallRankRow(this,0)
		err = row.RankInfo.load(dRankInfo)
		if err != nil {
			log.Error("RankInfo ")
			return
		}
		err = row.PlayerNScoreRank.load(dPlayerNScoreRank)
		if err != nil {
			log.Error("PlayerNScoreRank ")
			return
		}
		row.m_valid = true
		row.m_loaded=true
		this.m_row=row
	}
	if this.m_row == nil {
		this.m_row = new_dbLastSmallRankRow(this, 0)
		this.m_row.m_new = true
		this.m_row.m_valid = true
		err = this.Save(false)
		if err != nil {
			log.Error("save failed")
			return
		}
		this.m_row.m_loaded = true
	}
	return
}
func (this *dbLastSmallRankTable) Save(quick bool) (err error) {
	if this.m_row==nil{
		return errors.New("row nil")
	}
	err, _, _ = this.m_row.Save(false)
	return err
}
func (this *dbLastSmallRankTable) GetRow( ) (row *dbLastSmallRankRow) {
	return this.m_row
}
func (this *dbTongRow)GetTongName( )(r string ){
	this.m_lock.UnSafeRLock("dbTongRow.GetdbTongTongNameColumn")
	defer this.m_lock.UnSafeRUnlock()
	return string(this.m_TongName)
}
func (this *dbTongRow)SetTongName(v string){
	this.m_lock.UnSafeLock("dbTongRow.SetdbTongTongNameColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_TongName=string(v)
	this.m_TongName_changed=true
	return
}
func (this *dbTongRow)GetCreateTime( )(r int32 ){
	this.m_lock.UnSafeRLock("dbTongRow.GetdbTongCreateTimeColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_CreateTime)
}
func (this *dbTongRow)SetCreateTime(v int32){
	this.m_lock.UnSafeLock("dbTongRow.SetdbTongCreateTimeColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_CreateTime=int32(v)
	this.m_CreateTime_changed=true
	return
}
type dbTongRow struct {
	m_table *dbTongTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_TongId        int32
	m_TongName_changed bool
	m_TongName string
	m_CreateTime_changed bool
	m_CreateTime int32
}
func new_dbTongRow(table *dbTongTable, TongId int32) (r *dbTongRow) {
	this := &dbTongRow{}
	this.m_table = table
	this.m_TongId = TongId
	this.m_lock = NewRWMutex()
	this.m_TongName_changed=true
	this.m_CreateTime_changed=true
	return this
}
func (this *dbTongRow) GetTongId() (r int32) {
	return this.m_TongId
}
func (this *dbTongRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbTongRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(3)
		db_args.Push(this.m_TongId)
		db_args.Push(this.m_TongName)
		db_args.Push(this.m_CreateTime)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.m_TongName_changed||this.m_CreateTime_changed{
			update_string = "UPDATE Tongs SET "
			db_args:=new_db_args(3)
			if this.m_TongName_changed{
				update_string+="TongName=?,"
				db_args.Push(this.m_TongName)
			}
			if this.m_CreateTime_changed{
				update_string+="CreateTime=?,"
				db_args.Push(this.m_CreateTime)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE TongId=?"
			db_args.Push(this.m_TongId)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.m_TongName_changed = false
	this.m_CreateTime_changed = false
	if release && this.m_loaded {
		atomic.AddInt32(&this.m_table.m_gc_n, -1)
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbTongRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT Tongs exec failed %v ", this.m_TongId)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE Tongs exec failed %v", this.m_TongId)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
func (this *dbTongRow) Touch(releasable bool) {
	this.m_touch = int32(time.Now().Unix())
	this.m_releasable = releasable
}
type dbTongRowSort struct {
	rows []*dbTongRow
}
func (this *dbTongRowSort) Len() (length int) {
	return len(this.rows)
}
func (this *dbTongRowSort) Less(i int, j int) (less bool) {
	return this.rows[i].m_touch < this.rows[j].m_touch
}
func (this *dbTongRowSort) Swap(i int, j int) {
	temp := this.rows[i]
	this.rows[i] = this.rows[j]
	this.rows[j] = temp
}
type dbTongTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_rows map[int32]*dbTongRow
	m_new_rows map[int32]*dbTongRow
	m_removed_rows map[int32]*dbTongRow
	m_gc_n int32
	m_gcing int32
	m_pool_size int32
	m_preload_select_stmt *sql.Stmt
	m_preload_max_id int32
	m_save_insert_stmt *sql.Stmt
	m_delete_stmt *sql.Stmt
}
func new_dbTongTable(dbc *DBC) (this *dbTongTable) {
	this = &dbTongTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	this.m_rows = make(map[int32]*dbTongRow)
	this.m_new_rows = make(map[int32]*dbTongRow)
	this.m_removed_rows = make(map[int32]*dbTongRow)
	return this
}
func (this *dbTongTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS Tongs(TongId int(11),PRIMARY KEY (TongId))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS Tongs failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='Tongs'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasTongName := columns["TongName"]
	if !hasTongName {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN TongName varchar(45)")
		if err != nil {
			log.Error("ADD COLUMN TongName failed")
			return
		}
	}
	_, hasCreateTime := columns["CreateTime"]
	if !hasCreateTime {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN CreateTime int(11)")
		if err != nil {
			log.Error("ADD COLUMN CreateTime failed")
			return
		}
	}
	return
}
func (this *dbTongTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT TongId,TongName,CreateTime FROM Tongs")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbTongTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO Tongs (TongId,TongName,CreateTime) VALUES (?,?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbTongTable) prepare_delete_stmt() (err error) {
	this.m_delete_stmt,err=this.m_dbc.StmtPrepare("DELETE FROM Tongs WHERE TongId=?")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbTongTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	err=this.prepare_delete_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbTongTable) Preload() (err error) {
	r, err := this.m_dbc.StmtQuery(this.m_preload_select_stmt)
	if err != nil {
		log.Error("SELECT")
		return
	}
	var TongId int32
	var dTongName string
	var dCreateTime int32
		this.m_preload_max_id = 0
	for r.Next() {
		err = r.Scan(&TongId,&dTongName,&dCreateTime)
		if err != nil {
			log.Error("Scan")
			return
		}
		if TongId>this.m_preload_max_id{
			this.m_preload_max_id =TongId
		}
		row := new_dbTongRow(this,TongId)
		row.m_TongName=dTongName
		row.m_CreateTime=dCreateTime
		row.m_TongName_changed=false
		row.m_CreateTime_changed=false
		row.m_valid = true
		this.m_rows[TongId]=row
	}
	return
}
func (this *dbTongTable) GetPreloadedMaxId() (max_id int32) {
	return this.m_preload_max_id
}
func (this *dbTongTable) fetch_rows(rows map[int32]*dbTongRow) (r map[int32]*dbTongRow) {
	this.m_lock.UnSafeLock("dbTongTable.fetch_rows")
	defer this.m_lock.UnSafeUnlock()
	r = make(map[int32]*dbTongRow)
	for i, v := range rows {
		r[i] = v
	}
	return r
}
func (this *dbTongTable) fetch_new_rows() (new_rows map[int32]*dbTongRow) {
	this.m_lock.UnSafeLock("dbTongTable.fetch_new_rows")
	defer this.m_lock.UnSafeUnlock()
	new_rows = make(map[int32]*dbTongRow)
	for i, v := range this.m_new_rows {
		_, has := this.m_rows[i]
		if has {
			log.Error("rows already has new rows %v", i)
			continue
		}
		this.m_rows[i] = v
		new_rows[i] = v
	}
	for i, _ := range new_rows {
		delete(this.m_new_rows, i)
	}
	return
}
func (this *dbTongTable) save_rows(rows map[int32]*dbTongRow, quick bool) {
	for _, v := range rows {
		if this.m_dbc.m_quit && !quick {
			return
		}
		err, delay, _ := v.Save(false)
		if err != nil {
			log.Error("save failed %v", err)
		}
		if this.m_dbc.m_quit && !quick {
			return
		}
		if delay&&!quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
}
func (this *dbTongTable) Save(quick bool) (err error){
	removed_rows := this.fetch_rows(this.m_removed_rows)
	for _, v := range removed_rows {
		_, err := this.m_dbc.StmtExec(this.m_delete_stmt, v.GetTongId())
		if err != nil {
			log.Error("exec delete stmt failed %v", err)
		}
		v.m_valid = false
		if !quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
	this.m_removed_rows = make(map[int32]*dbTongRow)
	rows := this.fetch_rows(this.m_rows)
	this.save_rows(rows, quick)
	new_rows := this.fetch_new_rows()
	this.save_rows(new_rows, quick)
	return
}
func (this *dbTongTable) AddRow(TongId int32) (row *dbTongRow) {
	this.m_lock.UnSafeLock("dbTongTable.AddRow")
	defer this.m_lock.UnSafeUnlock()
	row = new_dbTongRow(this,TongId)
	row.m_new = true
	row.m_loaded = true
	row.m_valid = true
	_, has := this.m_new_rows[TongId]
	if has{
		log.Error("已经存在 %v", TongId)
		return nil
	}
	this.m_new_rows[TongId] = row
	atomic.AddInt32(&this.m_gc_n,1)
	return row
}
func (this *dbTongTable) RemoveRow(TongId int32) {
	this.m_lock.UnSafeLock("dbTongTable.RemoveRow")
	defer this.m_lock.UnSafeUnlock()
	row := this.m_rows[TongId]
	if row != nil {
		row.m_remove = true
		row = this.m_removed_rows[TongId]
		if row != nil {
			log.Error("rows and removed rows both has %v", TongId)
			row.m_remove = true
			delete(this.m_rows,TongId)
			this.m_removed_rows[TongId] = row
		} else {
			delete(this.m_rows, TongId)
		}
		_, has_new := this.m_new_rows[TongId]
		if has_new {
			delete(this.m_new_rows, TongId)
			log.Error("rows and new_rows both has %v", TongId)
		}
	} else {
		row = this.m_removed_rows[TongId]
		if row == nil {
			_, has_new := this.m_new_rows[TongId]
			if has_new {
				delete(this.m_new_rows, TongId)
			} else {
				log.Error("row not exist %v", TongId)
			}
		} else {
			log.Error("already removed %v", TongId)
			_, has_new := this.m_new_rows[TongId]
			if has_new {
				delete(this.m_new_rows, TongId)
				log.Error("removed rows and new_rows both has %v", TongId)
			}
		}
	}
}
func (this *dbTongTable) GetRow(TongId int32) (row *dbTongRow) {
	this.m_lock.UnSafeRLock("dbTongTable.GetRow")
	defer this.m_lock.UnSafeRUnlock()
	row = this.m_rows[TongId]
	if row == nil {
		row = this.m_new_rows[TongId]
	}
	return row
}
func (this *dbTongIdMaxRow)GetTongIdMax( )(r int32 ){
	this.m_lock.UnSafeRLock("dbTongIdMaxRow.GetdbTongIdMaxTongIdMaxColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_TongIdMax)
}
func (this *dbTongIdMaxRow)SetTongIdMax(v int32){
	this.m_lock.UnSafeLock("dbTongIdMaxRow.SetdbTongIdMaxTongIdMaxColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_TongIdMax=int32(v)
	this.m_TongIdMax_changed=true
	return
}
type dbTongIdMaxRow struct {
	m_table *dbTongIdMaxTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_PlaceHolder        int32
	m_TongIdMax_changed bool
	m_TongIdMax int32
}
func new_dbTongIdMaxRow(table *dbTongIdMaxTable, PlaceHolder int32) (r *dbTongIdMaxRow) {
	this := &dbTongIdMaxRow{}
	this.m_table = table
	this.m_PlaceHolder = PlaceHolder
	this.m_lock = NewRWMutex()
	this.m_TongIdMax_changed=true
	return this
}
func (this *dbTongIdMaxRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbTongIdMaxRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(2)
		db_args.Push(this.m_PlaceHolder)
		db_args.Push(this.m_TongIdMax)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.m_TongIdMax_changed{
			update_string = "UPDATE TongIdMax SET "
			db_args:=new_db_args(2)
			if this.m_TongIdMax_changed{
				update_string+="TongIdMax=?,"
				db_args.Push(this.m_TongIdMax)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE PlaceHolder=?"
			db_args.Push(this.m_PlaceHolder)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.m_TongIdMax_changed = false
	if release && this.m_loaded {
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbTongIdMaxRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT TongIdMax exec failed %v ", this.m_PlaceHolder)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE TongIdMax exec failed %v", this.m_PlaceHolder)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
type dbTongIdMaxTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_row *dbTongIdMaxRow
	m_preload_select_stmt *sql.Stmt
	m_save_insert_stmt *sql.Stmt
}
func new_dbTongIdMaxTable(dbc *DBC) (this *dbTongIdMaxTable) {
	this = &dbTongIdMaxTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	return this
}
func (this *dbTongIdMaxTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS TongIdMax(PlaceHolder int(11),PRIMARY KEY (PlaceHolder))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS TongIdMax failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='TongIdMax'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasTongIdMax := columns["TongIdMax"]
	if !hasTongIdMax {
		_, err = this.m_dbc.Exec("ALTER TABLE TongIdMax ADD COLUMN TongIdMax int(11) DEFAULT 0")
		if err != nil {
			log.Error("ADD COLUMN TongIdMax failed")
			return
		}
	}
	return
}
func (this *dbTongIdMaxTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT TongIdMax FROM TongIdMax WHERE PlaceHolder=0")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbTongIdMaxTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO TongIdMax (PlaceHolder,TongIdMax) VALUES (?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbTongIdMaxTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbTongIdMaxTable) Preload() (err error) {
	r := this.m_dbc.StmtQueryRow(this.m_preload_select_stmt)
	var dTongIdMax int32
	err = r.Scan(&dTongIdMax)
	if err!=nil{
		if err!=sql.ErrNoRows{
			log.Error("Scan failed")
			return
		}
	}else{
		row := new_dbTongIdMaxRow(this,0)
		row.m_TongIdMax=dTongIdMax
		row.m_TongIdMax_changed=false
		row.m_valid = true
		row.m_loaded=true
		this.m_row=row
	}
	if this.m_row == nil {
		this.m_row = new_dbTongIdMaxRow(this, 0)
		this.m_row.m_new = true
		this.m_row.m_valid = true
		err = this.Save(false)
		if err != nil {
			log.Error("save failed")
			return
		}
		this.m_row.m_loaded = true
	}
	return
}
func (this *dbTongIdMaxTable) Save(quick bool) (err error) {
	if this.m_row==nil{
		return errors.New("row nil")
	}
	err, _, _ = this.m_row.Save(false)
	return err
}
func (this *dbTongIdMaxTable) GetRow( ) (row *dbTongIdMaxRow) {
	return this.m_row
}
type dbCampFightBaseInfoColumn struct{
	m_row *dbCampFightRow
	m_data *dbCampFightBaseInfoData
	m_changed bool
}
func (this *dbCampFightBaseInfoColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbCampFightBaseInfoData{}
		this.m_changed = false
		return nil
	}
	pb := &db.CampFightBaseInfo{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_data = &dbCampFightBaseInfoData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbCampFightBaseInfoColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_changed = false
	return
}
func (this *dbCampFightBaseInfoColumn)Get( )(v *dbCampFightBaseInfoData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightBaseInfoColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbCampFightBaseInfoData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbCampFightBaseInfoColumn)Set(v dbCampFightBaseInfoData ){
	this.m_row.m_lock.UnSafeLock("dbCampFightBaseInfoColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbCampFightBaseInfoData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbCampFightBaseInfoColumn)GetCurFightArea( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightBaseInfoColumn.GetCurFightArea")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurFightArea
	return
}
func (this *dbCampFightBaseInfoColumn)SetCurFightArea(v int32){
	this.m_row.m_lock.UnSafeLock("dbCampFightBaseInfoColumn.SetCurFightArea")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurFightArea = v
	this.m_changed = true
	return
}
func (this *dbCampFightBaseInfoColumn)GetCurFightIdx( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightBaseInfoColumn.GetCurFightIdx")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurFightIdx
	return
}
func (this *dbCampFightBaseInfoColumn)SetCurFightIdx(v int32){
	this.m_row.m_lock.UnSafeLock("dbCampFightBaseInfoColumn.SetCurFightIdx")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurFightIdx = v
	this.m_changed = true
	return
}
func (this *dbCampFightBaseInfoColumn)GetCurActISOWeek( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightBaseInfoColumn.GetCurActISOWeek")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurActISOWeek
	return
}
func (this *dbCampFightBaseInfoColumn)SetCurActISOWeek(v int32){
	this.m_row.m_lock.UnSafeLock("dbCampFightBaseInfoColumn.SetCurActISOWeek")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurActISOWeek = v
	this.m_changed = true
	return
}
func (this *dbCampFightBaseInfoColumn)GetLastRewardISOWeek( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightBaseInfoColumn.GetLastRewardISOWeek")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastRewardISOWeek
	return
}
func (this *dbCampFightBaseInfoColumn)SetLastRewardISOWeek(v int32){
	this.m_row.m_lock.UnSafeLock("dbCampFightBaseInfoColumn.SetLastRewardISOWeek")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastRewardISOWeek = v
	this.m_changed = true
	return
}
func (this *dbCampFightBaseInfoColumn)GetCurCamp1Score( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightBaseInfoColumn.GetCurCamp1Score")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurCamp1Score
	return
}
func (this *dbCampFightBaseInfoColumn)SetCurCamp1Score(v int32){
	this.m_row.m_lock.UnSafeLock("dbCampFightBaseInfoColumn.SetCurCamp1Score")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurCamp1Score = v
	this.m_changed = true
	return
}
func (this *dbCampFightBaseInfoColumn)GetCurCamp2Score( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightBaseInfoColumn.GetCurCamp2Score")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurCamp2Score
	return
}
func (this *dbCampFightBaseInfoColumn)SetCurCamp2Score(v int32){
	this.m_row.m_lock.UnSafeLock("dbCampFightBaseInfoColumn.SetCurCamp2Score")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurCamp2Score = v
	this.m_changed = true
	return
}
func (this *dbCampFightBaseInfoColumn)GetCurRestIdx( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightBaseInfoColumn.GetCurRestIdx")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurRestIdx
	return
}
func (this *dbCampFightBaseInfoColumn)SetCurRestIdx(v int32){
	this.m_row.m_lock.UnSafeLock("dbCampFightBaseInfoColumn.SetCurRestIdx")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurRestIdx = v
	this.m_changed = true
	return
}
type dbCampFightCurTotalRankColumn struct{
	m_row *dbCampFightRow
	m_data *dbCampFightCurTotalRankData
	m_changed bool
}
func (this *dbCampFightCurTotalRankColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbCampFightCurTotalRankData{}
		this.m_changed = false
		return nil
	}
	pb := &db.CampFightCurTotalRank{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_data = &dbCampFightCurTotalRankData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbCampFightCurTotalRankColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_changed = false
	return
}
func (this *dbCampFightCurTotalRankColumn)Get( )(v *dbCampFightCurTotalRankData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightCurTotalRankColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbCampFightCurTotalRankData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbCampFightCurTotalRankColumn)Set(v dbCampFightCurTotalRankData ){
	this.m_row.m_lock.UnSafeLock("dbCampFightCurTotalRankColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbCampFightCurTotalRankData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbCampFightCurTotalRankColumn)GetRecords( )(v []dbSmallRankRecordData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightCurTotalRankColumn.GetRecords")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]dbSmallRankRecordData, len(this.m_data.Records))
	for _ii, _vv := range this.m_data.Records {
		_vv.clone_to(&v[_ii])
	}
	return
}
func (this *dbCampFightCurTotalRankColumn)SetRecords(v []dbSmallRankRecordData){
	this.m_row.m_lock.UnSafeLock("dbCampFightCurTotalRankColumn.SetRecords")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Records = make([]dbSmallRankRecordData, len(v))
	for _ii, _vv := range v {
		_vv.clone_to(&this.m_data.Records[_ii])
	}
	this.m_changed = true
	return
}
type dbCampFightCurCamp1RankColumn struct{
	m_row *dbCampFightRow
	m_data *dbCampFightCurCamp1RankData
	m_changed bool
}
func (this *dbCampFightCurCamp1RankColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbCampFightCurCamp1RankData{}
		this.m_changed = false
		return nil
	}
	pb := &db.CampFightCurCamp1Rank{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_data = &dbCampFightCurCamp1RankData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbCampFightCurCamp1RankColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_changed = false
	return
}
func (this *dbCampFightCurCamp1RankColumn)Get( )(v *dbCampFightCurCamp1RankData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightCurCamp1RankColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbCampFightCurCamp1RankData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbCampFightCurCamp1RankColumn)Set(v dbCampFightCurCamp1RankData ){
	this.m_row.m_lock.UnSafeLock("dbCampFightCurCamp1RankColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbCampFightCurCamp1RankData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbCampFightCurCamp1RankColumn)GetRecords( )(v []dbSmallRankRecordData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightCurCamp1RankColumn.GetRecords")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]dbSmallRankRecordData, len(this.m_data.Records))
	for _ii, _vv := range this.m_data.Records {
		_vv.clone_to(&v[_ii])
	}
	return
}
func (this *dbCampFightCurCamp1RankColumn)SetRecords(v []dbSmallRankRecordData){
	this.m_row.m_lock.UnSafeLock("dbCampFightCurCamp1RankColumn.SetRecords")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Records = make([]dbSmallRankRecordData, len(v))
	for _ii, _vv := range v {
		_vv.clone_to(&this.m_data.Records[_ii])
	}
	this.m_changed = true
	return
}
type dbCampFightCurCamp2RankColumn struct{
	m_row *dbCampFightRow
	m_data *dbCampFightCurCamp2RankData
	m_changed bool
}
func (this *dbCampFightCurCamp2RankColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbCampFightCurCamp2RankData{}
		this.m_changed = false
		return nil
	}
	pb := &db.CampFightCurCamp2Rank{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_data = &dbCampFightCurCamp2RankData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbCampFightCurCamp2RankColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_changed = false
	return
}
func (this *dbCampFightCurCamp2RankColumn)Get( )(v *dbCampFightCurCamp2RankData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightCurCamp2RankColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbCampFightCurCamp2RankData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbCampFightCurCamp2RankColumn)Set(v dbCampFightCurCamp2RankData ){
	this.m_row.m_lock.UnSafeLock("dbCampFightCurCamp2RankColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbCampFightCurCamp2RankData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbCampFightCurCamp2RankColumn)GetRecords( )(v []dbSmallRankRecordData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightCurCamp2RankColumn.GetRecords")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]dbSmallRankRecordData, len(this.m_data.Records))
	for _ii, _vv := range this.m_data.Records {
		_vv.clone_to(&v[_ii])
	}
	return
}
func (this *dbCampFightCurCamp2RankColumn)SetRecords(v []dbSmallRankRecordData){
	this.m_row.m_lock.UnSafeLock("dbCampFightCurCamp2RankColumn.SetRecords")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Records = make([]dbSmallRankRecordData, len(v))
	for _ii, _vv := range v {
		_vv.clone_to(&this.m_data.Records[_ii])
	}
	this.m_changed = true
	return
}
type dbCampFightLastTotalRankColumn struct{
	m_row *dbCampFightRow
	m_data *dbCampFightLastTotalRankData
	m_changed bool
}
func (this *dbCampFightLastTotalRankColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbCampFightLastTotalRankData{}
		this.m_changed = false
		return nil
	}
	pb := &db.CampFightLastTotalRank{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_data = &dbCampFightLastTotalRankData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbCampFightLastTotalRankColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_changed = false
	return
}
func (this *dbCampFightLastTotalRankColumn)Get( )(v *dbCampFightLastTotalRankData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightLastTotalRankColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbCampFightLastTotalRankData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbCampFightLastTotalRankColumn)Set(v dbCampFightLastTotalRankData ){
	this.m_row.m_lock.UnSafeLock("dbCampFightLastTotalRankColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbCampFightLastTotalRankData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbCampFightLastTotalRankColumn)GetRecords( )(v []dbSmallRankRecordData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightLastTotalRankColumn.GetRecords")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]dbSmallRankRecordData, len(this.m_data.Records))
	for _ii, _vv := range this.m_data.Records {
		_vv.clone_to(&v[_ii])
	}
	return
}
func (this *dbCampFightLastTotalRankColumn)SetRecords(v []dbSmallRankRecordData){
	this.m_row.m_lock.UnSafeLock("dbCampFightLastTotalRankColumn.SetRecords")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Records = make([]dbSmallRankRecordData, len(v))
	for _ii, _vv := range v {
		_vv.clone_to(&this.m_data.Records[_ii])
	}
	this.m_changed = true
	return
}
type dbCampFightLastCamp1RankColumn struct{
	m_row *dbCampFightRow
	m_data *dbCampFightLastCamp1RankData
	m_changed bool
}
func (this *dbCampFightLastCamp1RankColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbCampFightLastCamp1RankData{}
		this.m_changed = false
		return nil
	}
	pb := &db.CampFightLastCamp1Rank{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_data = &dbCampFightLastCamp1RankData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbCampFightLastCamp1RankColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_changed = false
	return
}
func (this *dbCampFightLastCamp1RankColumn)Get( )(v *dbCampFightLastCamp1RankData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightLastCamp1RankColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbCampFightLastCamp1RankData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbCampFightLastCamp1RankColumn)Set(v dbCampFightLastCamp1RankData ){
	this.m_row.m_lock.UnSafeLock("dbCampFightLastCamp1RankColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbCampFightLastCamp1RankData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbCampFightLastCamp1RankColumn)GetRecords( )(v []dbSmallRankRecordData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightLastCamp1RankColumn.GetRecords")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]dbSmallRankRecordData, len(this.m_data.Records))
	for _ii, _vv := range this.m_data.Records {
		_vv.clone_to(&v[_ii])
	}
	return
}
func (this *dbCampFightLastCamp1RankColumn)SetRecords(v []dbSmallRankRecordData){
	this.m_row.m_lock.UnSafeLock("dbCampFightLastCamp1RankColumn.SetRecords")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Records = make([]dbSmallRankRecordData, len(v))
	for _ii, _vv := range v {
		_vv.clone_to(&this.m_data.Records[_ii])
	}
	this.m_changed = true
	return
}
type dbCampFightLastCamp2RankColumn struct{
	m_row *dbCampFightRow
	m_data *dbCampFightLastCamp2RankData
	m_changed bool
}
func (this *dbCampFightLastCamp2RankColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbCampFightLastCamp2RankData{}
		this.m_changed = false
		return nil
	}
	pb := &db.CampFightLastCamp2Rank{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_data = &dbCampFightLastCamp2RankData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbCampFightLastCamp2RankColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_changed = false
	return
}
func (this *dbCampFightLastCamp2RankColumn)Get( )(v *dbCampFightLastCamp2RankData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightLastCamp2RankColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbCampFightLastCamp2RankData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbCampFightLastCamp2RankColumn)Set(v dbCampFightLastCamp2RankData ){
	this.m_row.m_lock.UnSafeLock("dbCampFightLastCamp2RankColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbCampFightLastCamp2RankData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbCampFightLastCamp2RankColumn)GetRecords( )(v []dbSmallRankRecordData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightLastCamp2RankColumn.GetRecords")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]dbSmallRankRecordData, len(this.m_data.Records))
	for _ii, _vv := range this.m_data.Records {
		_vv.clone_to(&v[_ii])
	}
	return
}
func (this *dbCampFightLastCamp2RankColumn)SetRecords(v []dbSmallRankRecordData){
	this.m_row.m_lock.UnSafeLock("dbCampFightLastCamp2RankColumn.SetRecords")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Records = make([]dbSmallRankRecordData, len(v))
	for _ii, _vv := range v {
		_vv.clone_to(&this.m_data.Records[_ii])
	}
	this.m_changed = true
	return
}
type dbCampFightCurCampFighgtRecordColumn struct{
	m_row *dbCampFightRow
	m_data *dbCampFightCurCampFighgtRecordData
	m_changed bool
}
func (this *dbCampFightCurCampFighgtRecordColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbCampFightCurCampFighgtRecordData{}
		this.m_changed = false
		return nil
	}
	pb := &db.CampFightCurCampFighgtRecord{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_data = &dbCampFightCurCampFighgtRecordData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbCampFightCurCampFighgtRecordColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Unmarshal ")
		return
	}
	this.m_changed = false
	return
}
func (this *dbCampFightCurCampFighgtRecordColumn)Get( )(v *dbCampFightCurCampFighgtRecordData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightCurCampFighgtRecordColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbCampFightCurCampFighgtRecordData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbCampFightCurCampFighgtRecordColumn)Set(v dbCampFightCurCampFighgtRecordData ){
	this.m_row.m_lock.UnSafeLock("dbCampFightCurCampFighgtRecordColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbCampFightCurCampFighgtRecordData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbCampFightCurCampFighgtRecordColumn)GetRecords( )(v []dbCampFightRecordData ){
	this.m_row.m_lock.UnSafeRLock("dbCampFightCurCampFighgtRecordColumn.GetRecords")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]dbCampFightRecordData, len(this.m_data.Records))
	for _ii, _vv := range this.m_data.Records {
		_vv.clone_to(&v[_ii])
	}
	return
}
func (this *dbCampFightCurCampFighgtRecordColumn)SetRecords(v []dbCampFightRecordData){
	this.m_row.m_lock.UnSafeLock("dbCampFightCurCampFighgtRecordColumn.SetRecords")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Records = make([]dbCampFightRecordData, len(v))
	for _ii, _vv := range v {
		_vv.clone_to(&this.m_data.Records[_ii])
	}
	this.m_changed = true
	return
}
type dbCampFightRow struct {
	m_table *dbCampFightTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_PlaceHolder        int32
	BaseInfo dbCampFightBaseInfoColumn
	CurTotalRank dbCampFightCurTotalRankColumn
	CurCamp1Rank dbCampFightCurCamp1RankColumn
	CurCamp2Rank dbCampFightCurCamp2RankColumn
	LastTotalRank dbCampFightLastTotalRankColumn
	LastCamp1Rank dbCampFightLastCamp1RankColumn
	LastCamp2Rank dbCampFightLastCamp2RankColumn
	CurCampFighgtRecord dbCampFightCurCampFighgtRecordColumn
}
func new_dbCampFightRow(table *dbCampFightTable, PlaceHolder int32) (r *dbCampFightRow) {
	this := &dbCampFightRow{}
	this.m_table = table
	this.m_PlaceHolder = PlaceHolder
	this.m_lock = NewRWMutex()
	this.BaseInfo.m_row=this
	this.BaseInfo.m_data=&dbCampFightBaseInfoData{}
	this.CurTotalRank.m_row=this
	this.CurTotalRank.m_data=&dbCampFightCurTotalRankData{}
	this.CurCamp1Rank.m_row=this
	this.CurCamp1Rank.m_data=&dbCampFightCurCamp1RankData{}
	this.CurCamp2Rank.m_row=this
	this.CurCamp2Rank.m_data=&dbCampFightCurCamp2RankData{}
	this.LastTotalRank.m_row=this
	this.LastTotalRank.m_data=&dbCampFightLastTotalRankData{}
	this.LastCamp1Rank.m_row=this
	this.LastCamp1Rank.m_data=&dbCampFightLastCamp1RankData{}
	this.LastCamp2Rank.m_row=this
	this.LastCamp2Rank.m_data=&dbCampFightLastCamp2RankData{}
	this.CurCampFighgtRecord.m_row=this
	this.CurCampFighgtRecord.m_data=&dbCampFightCurCampFighgtRecordData{}
	return this
}
func (this *dbCampFightRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbCampFightRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(9)
		db_args.Push(this.m_PlaceHolder)
		dBaseInfo,db_err:=this.BaseInfo.save()
		if db_err!=nil{
			log.Error("insert save BaseInfo failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dBaseInfo)
		dCurTotalRank,db_err:=this.CurTotalRank.save()
		if db_err!=nil{
			log.Error("insert save CurTotalRank failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dCurTotalRank)
		dCurCamp1Rank,db_err:=this.CurCamp1Rank.save()
		if db_err!=nil{
			log.Error("insert save CurCamp1Rank failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dCurCamp1Rank)
		dCurCamp2Rank,db_err:=this.CurCamp2Rank.save()
		if db_err!=nil{
			log.Error("insert save CurCamp2Rank failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dCurCamp2Rank)
		dLastTotalRank,db_err:=this.LastTotalRank.save()
		if db_err!=nil{
			log.Error("insert save LastTotalRank failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dLastTotalRank)
		dLastCamp1Rank,db_err:=this.LastCamp1Rank.save()
		if db_err!=nil{
			log.Error("insert save LastCamp1Rank failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dLastCamp1Rank)
		dLastCamp2Rank,db_err:=this.LastCamp2Rank.save()
		if db_err!=nil{
			log.Error("insert save LastCamp2Rank failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dLastCamp2Rank)
		dCurCampFighgtRecord,db_err:=this.CurCampFighgtRecord.save()
		if db_err!=nil{
			log.Error("insert save CurCampFighgtRecord failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dCurCampFighgtRecord)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.BaseInfo.m_changed||this.CurTotalRank.m_changed||this.CurCamp1Rank.m_changed||this.CurCamp2Rank.m_changed||this.LastTotalRank.m_changed||this.LastCamp1Rank.m_changed||this.LastCamp2Rank.m_changed||this.CurCampFighgtRecord.m_changed{
			update_string = "UPDATE CampFight SET "
			db_args:=new_db_args(9)
			if this.BaseInfo.m_changed{
				update_string+="BaseInfo=?,"
				dBaseInfo,err:=this.BaseInfo.save()
				if err!=nil{
					log.Error("update save BaseInfo failed")
					return err,false,0,"",nil
				}
				db_args.Push(dBaseInfo)
			}
			if this.CurTotalRank.m_changed{
				update_string+="CurTotalRank=?,"
				dCurTotalRank,err:=this.CurTotalRank.save()
				if err!=nil{
					log.Error("update save CurTotalRank failed")
					return err,false,0,"",nil
				}
				db_args.Push(dCurTotalRank)
			}
			if this.CurCamp1Rank.m_changed{
				update_string+="CurCamp1Rank=?,"
				dCurCamp1Rank,err:=this.CurCamp1Rank.save()
				if err!=nil{
					log.Error("update save CurCamp1Rank failed")
					return err,false,0,"",nil
				}
				db_args.Push(dCurCamp1Rank)
			}
			if this.CurCamp2Rank.m_changed{
				update_string+="CurCamp2Rank=?,"
				dCurCamp2Rank,err:=this.CurCamp2Rank.save()
				if err!=nil{
					log.Error("update save CurCamp2Rank failed")
					return err,false,0,"",nil
				}
				db_args.Push(dCurCamp2Rank)
			}
			if this.LastTotalRank.m_changed{
				update_string+="LastTotalRank=?,"
				dLastTotalRank,err:=this.LastTotalRank.save()
				if err!=nil{
					log.Error("update save LastTotalRank failed")
					return err,false,0,"",nil
				}
				db_args.Push(dLastTotalRank)
			}
			if this.LastCamp1Rank.m_changed{
				update_string+="LastCamp1Rank=?,"
				dLastCamp1Rank,err:=this.LastCamp1Rank.save()
				if err!=nil{
					log.Error("update save LastCamp1Rank failed")
					return err,false,0,"",nil
				}
				db_args.Push(dLastCamp1Rank)
			}
			if this.LastCamp2Rank.m_changed{
				update_string+="LastCamp2Rank=?,"
				dLastCamp2Rank,err:=this.LastCamp2Rank.save()
				if err!=nil{
					log.Error("update save LastCamp2Rank failed")
					return err,false,0,"",nil
				}
				db_args.Push(dLastCamp2Rank)
			}
			if this.CurCampFighgtRecord.m_changed{
				update_string+="CurCampFighgtRecord=?,"
				dCurCampFighgtRecord,err:=this.CurCampFighgtRecord.save()
				if err!=nil{
					log.Error("update save CurCampFighgtRecord failed")
					return err,false,0,"",nil
				}
				db_args.Push(dCurCampFighgtRecord)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE PlaceHolder=?"
			db_args.Push(this.m_PlaceHolder)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.BaseInfo.m_changed = false
	this.CurTotalRank.m_changed = false
	this.CurCamp1Rank.m_changed = false
	this.CurCamp2Rank.m_changed = false
	this.LastTotalRank.m_changed = false
	this.LastCamp1Rank.m_changed = false
	this.LastCamp2Rank.m_changed = false
	this.CurCampFighgtRecord.m_changed = false
	if release && this.m_loaded {
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbCampFightRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT CampFight exec failed %v ", this.m_PlaceHolder)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE CampFight exec failed %v", this.m_PlaceHolder)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
type dbCampFightTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_row *dbCampFightRow
	m_preload_select_stmt *sql.Stmt
	m_save_insert_stmt *sql.Stmt
}
func new_dbCampFightTable(dbc *DBC) (this *dbCampFightTable) {
	this = &dbCampFightTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	return this
}
func (this *dbCampFightTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS CampFight(PlaceHolder int(11),PRIMARY KEY (PlaceHolder))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS CampFight failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='CampFight'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasBaseInfo := columns["BaseInfo"]
	if !hasBaseInfo {
		_, err = this.m_dbc.Exec("ALTER TABLE CampFight ADD COLUMN BaseInfo LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN BaseInfo failed")
			return
		}
	}
	_, hasCurTotalRank := columns["CurTotalRank"]
	if !hasCurTotalRank {
		_, err = this.m_dbc.Exec("ALTER TABLE CampFight ADD COLUMN CurTotalRank LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN CurTotalRank failed")
			return
		}
	}
	_, hasCurCamp1Rank := columns["CurCamp1Rank"]
	if !hasCurCamp1Rank {
		_, err = this.m_dbc.Exec("ALTER TABLE CampFight ADD COLUMN CurCamp1Rank LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN CurCamp1Rank failed")
			return
		}
	}
	_, hasCurCamp2Rank := columns["CurCamp2Rank"]
	if !hasCurCamp2Rank {
		_, err = this.m_dbc.Exec("ALTER TABLE CampFight ADD COLUMN CurCamp2Rank LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN CurCamp2Rank failed")
			return
		}
	}
	_, hasLastTotalRank := columns["LastTotalRank"]
	if !hasLastTotalRank {
		_, err = this.m_dbc.Exec("ALTER TABLE CampFight ADD COLUMN LastTotalRank LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN LastTotalRank failed")
			return
		}
	}
	_, hasLastCamp1Rank := columns["LastCamp1Rank"]
	if !hasLastCamp1Rank {
		_, err = this.m_dbc.Exec("ALTER TABLE CampFight ADD COLUMN LastCamp1Rank LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN LastCamp1Rank failed")
			return
		}
	}
	_, hasLastCamp2Rank := columns["LastCamp2Rank"]
	if !hasLastCamp2Rank {
		_, err = this.m_dbc.Exec("ALTER TABLE CampFight ADD COLUMN LastCamp2Rank LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN LastCamp2Rank failed")
			return
		}
	}
	_, hasCurCampFighgtRecord := columns["CurCampFighgtRecord"]
	if !hasCurCampFighgtRecord {
		_, err = this.m_dbc.Exec("ALTER TABLE CampFight ADD COLUMN CurCampFighgtRecord LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN CurCampFighgtRecord failed")
			return
		}
	}
	return
}
func (this *dbCampFightTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT BaseInfo,CurTotalRank,CurCamp1Rank,CurCamp2Rank,LastTotalRank,LastCamp1Rank,LastCamp2Rank,CurCampFighgtRecord FROM CampFight WHERE PlaceHolder=0")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbCampFightTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO CampFight (PlaceHolder,BaseInfo,CurTotalRank,CurCamp1Rank,CurCamp2Rank,LastTotalRank,LastCamp1Rank,LastCamp2Rank,CurCampFighgtRecord) VALUES (?,?,?,?,?,?,?,?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbCampFightTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbCampFightTable) Preload() (err error) {
	r := this.m_dbc.StmtQueryRow(this.m_preload_select_stmt)
	var dBaseInfo []byte
	var dCurTotalRank []byte
	var dCurCamp1Rank []byte
	var dCurCamp2Rank []byte
	var dLastTotalRank []byte
	var dLastCamp1Rank []byte
	var dLastCamp2Rank []byte
	var dCurCampFighgtRecord []byte
	err = r.Scan(&dBaseInfo,&dCurTotalRank,&dCurCamp1Rank,&dCurCamp2Rank,&dLastTotalRank,&dLastCamp1Rank,&dLastCamp2Rank,&dCurCampFighgtRecord)
	if err!=nil{
		if err!=sql.ErrNoRows{
			log.Error("Scan failed")
			return
		}
	}else{
		row := new_dbCampFightRow(this,0)
		err = row.BaseInfo.load(dBaseInfo)
		if err != nil {
			log.Error("BaseInfo ")
			return
		}
		err = row.CurTotalRank.load(dCurTotalRank)
		if err != nil {
			log.Error("CurTotalRank ")
			return
		}
		err = row.CurCamp1Rank.load(dCurCamp1Rank)
		if err != nil {
			log.Error("CurCamp1Rank ")
			return
		}
		err = row.CurCamp2Rank.load(dCurCamp2Rank)
		if err != nil {
			log.Error("CurCamp2Rank ")
			return
		}
		err = row.LastTotalRank.load(dLastTotalRank)
		if err != nil {
			log.Error("LastTotalRank ")
			return
		}
		err = row.LastCamp1Rank.load(dLastCamp1Rank)
		if err != nil {
			log.Error("LastCamp1Rank ")
			return
		}
		err = row.LastCamp2Rank.load(dLastCamp2Rank)
		if err != nil {
			log.Error("LastCamp2Rank ")
			return
		}
		err = row.CurCampFighgtRecord.load(dCurCampFighgtRecord)
		if err != nil {
			log.Error("CurCampFighgtRecord ")
			return
		}
		row.m_valid = true
		row.m_loaded=true
		this.m_row=row
	}
	if this.m_row == nil {
		this.m_row = new_dbCampFightRow(this, 0)
		this.m_row.m_new = true
		this.m_row.m_valid = true
		err = this.Save(false)
		if err != nil {
			log.Error("save failed")
			return
		}
		this.m_row.m_loaded = true
	}
	return
}
func (this *dbCampFightTable) Save(quick bool) (err error) {
	if this.m_row==nil{
		return errors.New("row nil")
	}
	err, _, _ = this.m_row.Save(false)
	return err
}
func (this *dbCampFightTable) GetRow( ) (row *dbCampFightRow) {
	return this.m_row
}

type DBC struct {
	m_db_name            string
	m_db                 *sql.DB
	m_db_lock            *Mutex
	m_initialized        bool
	m_quit               bool
	m_shutdown_completed bool
	m_shutdown_lock      *Mutex
	m_db_last_copy_time	int32
	m_db_copy_path		string
	m_db_addr			string
	m_db_account			string
	m_db_password		string
	Accounts *dbAccountTable
	PlayerIdMax *dbPlayerIdMaxTable
	LastSmallRank *dbLastSmallRankTable
	Tongs *dbTongTable
	TongIdMax *dbTongIdMaxTable
	CampFight *dbCampFightTable
}
func (this *DBC)init_tables()(err error){
	this.Accounts = new_dbAccountTable(this)
	err = this.Accounts.Init()
	if err != nil {
		log.Error("init Accounts table failed")
		return
	}
	this.PlayerIdMax = new_dbPlayerIdMaxTable(this)
	err = this.PlayerIdMax.Init()
	if err != nil {
		log.Error("init PlayerIdMax table failed")
		return
	}
	this.LastSmallRank = new_dbLastSmallRankTable(this)
	err = this.LastSmallRank.Init()
	if err != nil {
		log.Error("init LastSmallRank table failed")
		return
	}
	this.Tongs = new_dbTongTable(this)
	err = this.Tongs.Init()
	if err != nil {
		log.Error("init Tongs table failed")
		return
	}
	this.TongIdMax = new_dbTongIdMaxTable(this)
	err = this.TongIdMax.Init()
	if err != nil {
		log.Error("init TongIdMax table failed")
		return
	}
	this.CampFight = new_dbCampFightTable(this)
	err = this.CampFight.Init()
	if err != nil {
		log.Error("init CampFight table failed")
		return
	}
	return
}
func (this *DBC)Preload()(err error){
	err = this.Accounts.Preload()
	if err != nil {
		log.Error("preload Accounts table failed")
		return
	}
	err = this.PlayerIdMax.Preload()
	if err != nil {
		log.Error("preload PlayerIdMax table failed")
		return
	}
	err = this.LastSmallRank.Preload()
	if err != nil {
		log.Error("preload LastSmallRank table failed")
		return
	}
	err = this.Tongs.Preload()
	if err != nil {
		log.Error("preload Tongs table failed")
		return
	}
	err = this.TongIdMax.Preload()
	if err != nil {
		log.Error("preload TongIdMax table failed")
		return
	}
	err = this.CampFight.Preload()
	if err != nil {
		log.Error("preload CampFight table failed")
		return
	}
	err = this.on_preload()
	if err != nil {
		log.Error("on_preload failed")
		return
	}
	err = this.Save(true)
	if err != nil {
		log.Error("save on preload failed")
		return
	}
	return
}
func (this *DBC)Save(quick bool)(err error){
	err = this.Accounts.Save(quick)
	if err != nil {
		log.Error("save Accounts table failed")
		return
	}
	err = this.PlayerIdMax.Save(quick)
	if err != nil {
		log.Error("save PlayerIdMax table failed")
		return
	}
	err = this.LastSmallRank.Save(quick)
	if err != nil {
		log.Error("save LastSmallRank table failed")
		return
	}
	err = this.Tongs.Save(quick)
	if err != nil {
		log.Error("save Tongs table failed")
		return
	}
	err = this.TongIdMax.Save(quick)
	if err != nil {
		log.Error("save TongIdMax table failed")
		return
	}
	err = this.CampFight.Save(quick)
	if err != nil {
		log.Error("save CampFight table failed")
		return
	}
	return
}
