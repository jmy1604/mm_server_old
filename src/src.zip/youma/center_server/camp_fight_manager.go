package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"libs/server_conn"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	CAMP_FIGHT_STATE_CLOSED = 1 // 关闭状态
	CAMP_FIGHT_STATE_OPEN   = 2 // 开战状态
	CAMP_FIGHT_STATE_REST   = 3 // 休战状态
	CAMP_FIGHT_STATE_REWARD = 4 // 发奖状态

	CAMP_STATE_CHK_FRAME_COUNT    = 60
	CAMP_UP_TO_DB_CHK_FRAME_COUNT = 10
	CAMP_UPDATE_SCORE_FRAME_COUNT = 5

	CAMP_FIGHT_RANK_GROUP_NUM        = 4
	CAMP_FIGHT_RANK_SINGLE_GROUP_LEN = 50

	PLAYER_CAMP_1 = 1 // 玩家阵营1
	PLAYER_CAMP_2 = 2 // 玩家阵营2
)

type CfgIdNum struct {
	CfgId int32
	Num   int32
}

type CampRewardInfo struct {
	Camp    int32       // 阵营
	Rewards []*CfgIdNum // 奖励内容
}

type XmlCampAreaItem struct {
	CampID       int32 `xml:"CampID,attr"`
	Xcampwin     int32 `xml:"Xcampwin,attr"`
	Tcampwin     int32 `xml:"Tcampwin,attr"`
	XReward      int32 `xml:"XReward,attr"`
	TReward      int32 `xml:"TReward,attr"`
	Camp2Rewards map[int32]int32
}

type XmlCampAreaConfig struct {
	Items []XmlCampAreaItem `xml:"item"`
}

type CampAreaReward struct {
	AreaLvl int32
	Items   []CampRewardInfo
}

type XmlCampSingRewardItem struct {
	Camp           int32 `xml:"Camp,attr"`
	IntegralMin    int32 `xml:"IntegralMin,attr"`
	IntegralMax    int32 `xml:"IntegralMax,attr"`
	Arena_reward_1 int32 `xml:"Arena_reward_1,attr"`
	Arena_reward_2 int32 `xml:"Arena_reward_2,attr"`
	Arena_reward_3 int32 `xml:"Arena_reward_3,attr"`
	Arena_reward_4 int32 `xml:"Arena_reward_4,attr"`
	Arena_reward_5 int32 `xml:"Arena_reward_5,attr"`
	Arena_reward_6 int32 `xml:"Arena_reward_6,attr"`
	Arena_reward_7 int32 `xml:"Arena_reward_7,attr"`
	Arena_reward_8 int32 `xml:"Arena_reward_8,attr"`
	Arena_reward_9 int32 `xml:"Arena_reward_9,attr"`
	Arena2Reward   map[int32]int32
}

type XmlCampSingRewardConfig struct {
	Items []XmlCampSingRewardItem `xml:"item"`
}

type CampRankRecordsCache struct {
	records_lock *sync.RWMutex
	records      []*msg_server_message.SmallRankItem
}

type CampRankRecordsCacheGroup struct {
	Caches []*CampRankRecordsCache
}

type CampFightManager struct {
	state_chk_frame int32
	cur_state       int32
	cur_fight_area  int32
	cur_fight_idx   int32
	next_time_point int32 // 下一个时间节点的Unix

	binit bool

	area2cfg         map[int32]*XmlCampAreaItem
	first_fight_area int32

	up_to_db_chk_frame int32
	is_up_to_db        bool
	is_up_to_db_lock   *sync.RWMutex

	total_score_rank *SmallRankService
	camp1_score_rank *SmallRankService
	camp2_score_rank *SmallRankService
	total_rank_cache *CampRankRecordsCacheGroup
	camp1_rank_cache *CampRankRecordsCacheGroup
	camp2_rank_cache *CampRankRecordsCacheGroup

	last_total_score_rank *SmallRankService
	last_camp1_score_rank *SmallRankService
	last_camp2_score_rank *SmallRankService

	last_total_rank_cache *CampRankRecordsCacheGroup
	last_camp1_rank_cache *CampRankRecordsCacheGroup
	last_camp2_rank_cache *CampRankRecordsCacheGroup

	update_score_frame int32
	last_up_x_score    int32
	last_up_t_score    int32

	tmp_row *dbCampFightRow
}

var camp_fight_mgr CampFightManager

func (this *CampFightManager) Init() bool {
	tmp_row := dbc.CampFight.GetRow()
	if nil == tmp_row {
		log.Error("CampFightManager Init get row nil !")
		return false
	}

	this.tmp_row = tmp_row

	this.total_score_rank = NewSmallRankService(DEFAULT_SMALL_RANK_LENTH, SMALL_RANK_TYPE_CAMP_FIGHT_TOTAL, SMALL_RANK_SORT_TYPE_B)
	this.camp1_score_rank = NewSmallRankService(DEFAULT_SMALL_RANK_LENTH, SMALL_RANK_TYPE_CAMP_FIGHT_1_SCORE, SMALL_RANK_SORT_TYPE_B)
	this.camp2_score_rank = NewSmallRankService(DEFAULT_SMALL_RANK_LENTH, SMALL_RANK_TYPE_CAMP_FIGHT_2_SCORE, SMALL_RANK_SORT_TYPE_B)

	this.last_total_score_rank = NewSmallRankService(DEFAULT_SMALL_RANK_LENTH, SMALL_RANK_TYPE_CAMP_FIGHT_TOTAL, SMALL_RANK_SORT_TYPE_B)
	this.last_camp1_score_rank = NewSmallRankService(DEFAULT_SMALL_RANK_LENTH, SMALL_RANK_TYPE_CAMP_FIGHT_1_SCORE, SMALL_RANK_SORT_TYPE_B)
	this.last_camp2_score_rank = NewSmallRankService(DEFAULT_SMALL_RANK_LENTH, SMALL_RANK_TYPE_CAMP_FIGHT_2_SCORE, SMALL_RANK_SORT_TYPE_B)

	this.is_up_to_db_lock = &sync.RWMutex{}

	this.LoadDbRank()
	this.LoadCampArea()

	this.cur_fight_area = tmp_row.BaseInfo.GetCurFightArea()
	this.cur_fight_idx = tmp_row.BaseInfo.GetCurFightIdx()
	this.state_chk_frame = CAMP_STATE_CHK_FRAME_COUNT + 1
	this.CheckActState()

	this.total_rank_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}
	this.camp1_rank_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}
	this.camp2_rank_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}

	this.last_total_rank_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}
	this.last_camp1_rank_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}
	this.last_camp2_rank_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}

	for idx := int32(0); idx < CAMP_FIGHT_RANK_GROUP_NUM; idx++ {
		this.total_rank_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		this.camp1_rank_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		this.camp2_rank_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		this.last_total_rank_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		this.last_camp1_rank_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		this.last_camp2_rank_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
	}

	signal_mgr.RegCloseFunc("CampFightManager", this.Close_Func)

	this.RegMsgHandler()

	this.binit = true
	return true
}

func (this *CampFightManager) LoadCampArea() bool {
	content, err := ioutil.ReadFile("../game_data/CampConfig.xml")
	if nil != err {
		log.Error("CampFightManager LoadCampArea read file error err[%s]!", err.Error())
		return false
	}

	tmp_camp_cfg := &XmlCampAreaConfig{}
	err = xml.Unmarshal(content, tmp_camp_cfg)
	if nil != err {
		log.Error("CampFightManager LoadCampArea xml unmarshal err[%s] !", err.Error())
		return false
	}

	this.area2cfg = make(map[int32]*XmlCampAreaItem)
	for idx := int32(0); idx < int32(len(tmp_camp_cfg.Items)); idx++ {
		tmp_val := &tmp_camp_cfg.Items[idx]
		if 0 == this.first_fight_area {
			this.first_fight_area = tmp_val.CampID
		}
		tmp_val.Camp2Rewards = make(map[int32]int32)
		tmp_val.Camp2Rewards[PLAYER_CAMP_1] = tmp_val.XReward
		tmp_val.Camp2Rewards[PLAYER_CAMP_2] = tmp_val.TReward
		this.area2cfg[tmp_val.CampID] = tmp_val
	}

	return true
}

func (this *CampFightManager) LoadDbRank() {
	tmp_row := dbc.CampFight.GetRow()
	if nil == tmp_row {
		log.Error("CampFightManager LoadDbRank tmp_row nil !")
		return
	}

	log.Info("数据库全榜玩家数目 %v", len(tmp_row.LastTotalRank.GetRecords()))
	for _, val := range tmp_row.CurTotalRank.GetRecords() {
		log.Info("加载上期阵营战全榜 %v", val)
		this.total_score_rank.SetUpdateRank(val.Id, val.Val, val.TongIcon, val.Name, val.TongName)
	}

	for _, val := range tmp_row.CurCamp1Rank.GetRecords() {
		log.Info("加载上期阵营战阵营1榜 %v", val)
		this.camp1_score_rank.SetUpdateRank(val.Id, val.Val, val.TongIcon, val.Name, val.TongName)
	}

	for _, val := range tmp_row.CurCamp2Rank.GetRecords() {
		log.Info("加载上期阵营战阵营2榜 %v", val)
		this.camp2_score_rank.SetUpdateRank(val.Id, val.Val, val.TongIcon, val.Name, val.TongName)
	}

	for _, val := range tmp_row.LastTotalRank.GetRecords() {
		log.Info("加载阵营战全榜 %v", val)
		this.last_total_score_rank.SetUpdateRank(val.Id, val.Val, val.TongIcon, val.Name, val.TongName)
	}

	for _, val := range tmp_row.LastCamp1Rank.GetRecords() {
		log.Info("加载阵营战阵营1榜 %v", val)
		this.last_camp1_score_rank.SetUpdateRank(val.Id, val.Val, val.TongIcon, val.Name, val.TongName)
	}

	for _, val := range tmp_row.LastCamp2Rank.GetRecords() {
		log.Info("加载阵营战阵营2榜 %v", val)
		this.last_camp2_score_rank.SetUpdateRank(val.Id, val.Val, val.TongIcon, val.Name, val.TongName)
	}
}

func (this *CampFightManager) UpdateLastRankCache() {
	var cur_count, group_idx, array_idx int32
	var tmp_cache *CampRankRecordsCacheGroup
	var tmp_rds []*msg_server_message.SmallRankItem
	var tmp_item *msg_server_message.SmallRankItem
	bchg, allrds := this.last_total_score_rank.FillAllIfChanged()
	if bchg {
		tmp_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}
		for idx := int32(0); idx < CAMP_FIGHT_RANK_GROUP_NUM; idx++ {
			tmp_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		}

		for idx, val := range allrds {
			if idx >= DEFAULT_SMALL_RANK_LENTH {
				break
			}

			group_idx = int32(idx) / CAMP_FIGHT_RANK_SINGLE_GROUP_LEN
			array_idx = int32(idx) - CAMP_FIGHT_RANK_SINGLE_GROUP_LEN*group_idx
			if 0 == array_idx {
				if group_idx > 0 {
					tmp_cache.Caches[group_idx].records = tmp_rds
				}
				tmp_rds = make([]*msg_server_message.SmallRankItem, 0, CAMP_FIGHT_RANK_SINGLE_GROUP_LEN)
				cur_count = 0
			}

			tmp_item = &msg_server_message.SmallRankItem{}
			tmp_item.Rank = proto.Int32(val.Rank)
			tmp_item.Id = proto.Int32(val.Id)
			tmp_item.Name = proto.String(val.Name)
			tmp_item.Score = proto.Int32(val.Val)
			tmp_item.TongIcon = proto.Int32(val.TongIcon)
			tmp_item.TongName = proto.String(val.TongName)
			tmp_rds = append(tmp_rds, tmp_item)
			cur_count++
		}

		if cur_count > 0 && group_idx < CAMP_FIGHT_RANK_GROUP_NUM {
			//log.Info("======== %d %d", cur_count, group_idx, CAMP_FIGHT_RANK_GROUP_NUM)
			tmp_cache.Caches[group_idx].records = tmp_rds
		}

		this.last_total_rank_cache = tmp_cache
	}

	bchg, allrds = this.last_camp1_score_rank.FillAllIfChanged()
	if bchg {
		tmp_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}
		for idx := int32(0); idx < CAMP_FIGHT_RANK_GROUP_NUM; idx++ {
			tmp_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		}

		for idx, val := range allrds {
			if idx >= DEFAULT_SMALL_RANK_LENTH {
				break
			}

			group_idx = int32(idx) / CAMP_FIGHT_RANK_SINGLE_GROUP_LEN
			array_idx = int32(idx) - CAMP_FIGHT_RANK_SINGLE_GROUP_LEN*group_idx
			if 0 == array_idx {
				if group_idx > 0 {
					tmp_cache.Caches[group_idx].records = tmp_rds
				}
				tmp_rds = make([]*msg_server_message.SmallRankItem, 0, CAMP_FIGHT_RANK_SINGLE_GROUP_LEN)
				cur_count = 0
			}

			tmp_item = &msg_server_message.SmallRankItem{}
			tmp_item.Rank = proto.Int32(val.Rank)
			tmp_item.Id = proto.Int32(val.Id)
			tmp_item.Name = proto.String(val.Name)
			tmp_item.Score = proto.Int32(val.Val)
			tmp_item.TongIcon = proto.Int32(val.TongIcon)
			tmp_item.TongName = proto.String(val.TongName)
			tmp_rds = append(tmp_rds, tmp_item)
			cur_count++
		}

		if cur_count > 0 && group_idx <= CAMP_FIGHT_RANK_GROUP_NUM {
			tmp_cache.Caches[group_idx].records = tmp_rds
		}

		this.last_camp1_rank_cache = tmp_cache
	}

	bchg, allrds = this.last_camp2_score_rank.FillAllIfChanged()
	if bchg {
		tmp_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}
		for idx := int32(0); idx < CAMP_FIGHT_RANK_GROUP_NUM; idx++ {
			tmp_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		}

		for idx, val := range allrds {
			if idx >= DEFAULT_SMALL_RANK_LENTH {
				break
			}

			group_idx = int32(idx) / CAMP_FIGHT_RANK_SINGLE_GROUP_LEN
			array_idx = int32(idx) - CAMP_FIGHT_RANK_SINGLE_GROUP_LEN*group_idx
			if 0 == array_idx {
				if group_idx > 0 {
					tmp_cache.Caches[group_idx].records = tmp_rds
				}
				tmp_rds = make([]*msg_server_message.SmallRankItem, 0, CAMP_FIGHT_RANK_SINGLE_GROUP_LEN)
				cur_count = 0
			}

			tmp_item = &msg_server_message.SmallRankItem{}
			tmp_item.Rank = proto.Int32(val.Rank)
			tmp_item.Id = proto.Int32(val.Id)
			tmp_item.Name = proto.String(val.Name)
			tmp_item.Score = proto.Int32(val.Val)
			tmp_item.TongIcon = proto.Int32(val.TongIcon)
			tmp_item.TongName = proto.String(val.TongName)
			tmp_rds = append(tmp_rds, tmp_item)
			cur_count++
		}

		if cur_count > 0 && group_idx <= CAMP_FIGHT_RANK_GROUP_NUM {
			tmp_cache.Caches[group_idx].records = tmp_rds
		}

		this.last_camp2_rank_cache = tmp_cache
	}

	return
}

// 时间函数 =====================================================================

func (this *CampFightManager) UpdateRankCache() {

	var cur_count, group_idx, array_idx int32
	var tmp_cache *CampRankRecordsCacheGroup
	var tmp_rds []*msg_server_message.SmallRankItem
	var tmp_item *msg_server_message.SmallRankItem
	bchg, allrds := this.total_score_rank.FillAllIfChanged()
	if bchg {
		tmp_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}
		for idx := int32(0); idx < CAMP_FIGHT_RANK_GROUP_NUM; idx++ {
			tmp_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		}

		for idx, val := range allrds {
			if idx >= DEFAULT_SMALL_RANK_LENTH {
				break
			}

			group_idx = int32(idx) / CAMP_FIGHT_RANK_SINGLE_GROUP_LEN
			array_idx = int32(idx) - CAMP_FIGHT_RANK_SINGLE_GROUP_LEN*group_idx
			if 0 == array_idx {
				if group_idx > 0 {
					tmp_cache.Caches[group_idx].records = tmp_rds
				}
				tmp_rds = make([]*msg_server_message.SmallRankItem, 0, CAMP_FIGHT_RANK_SINGLE_GROUP_LEN)
				cur_count = 0
			}

			tmp_item = &msg_server_message.SmallRankItem{}
			tmp_item.Rank = proto.Int32(val.Rank)
			tmp_item.Id = proto.Int32(val.Id)
			tmp_item.Name = proto.String(val.Name)
			tmp_item.Score = proto.Int32(val.Val)
			tmp_item.TongIcon = proto.Int32(val.TongIcon)
			tmp_item.TongName = proto.String(val.TongName)
			tmp_rds = append(tmp_rds, tmp_item)
			cur_count++
		}

		if cur_count > 0 && group_idx < CAMP_FIGHT_RANK_GROUP_NUM {
			//log.Info("======== %d %d", cur_count, group_idx, CAMP_FIGHT_RANK_GROUP_NUM)
			tmp_cache.Caches[group_idx].records = tmp_rds
		}

		this.total_rank_cache = tmp_cache
	}

	bchg, allrds = this.camp1_score_rank.FillAllIfChanged()
	if bchg {
		tmp_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}
		for idx := int32(0); idx < CAMP_FIGHT_RANK_GROUP_NUM; idx++ {
			tmp_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		}

		for idx, val := range allrds {
			if idx >= DEFAULT_SMALL_RANK_LENTH {
				break
			}

			group_idx = int32(idx) / CAMP_FIGHT_RANK_SINGLE_GROUP_LEN
			array_idx = int32(idx) - CAMP_FIGHT_RANK_SINGLE_GROUP_LEN*group_idx
			if 0 == array_idx {
				if group_idx > 0 {
					tmp_cache.Caches[group_idx].records = tmp_rds
				}
				tmp_rds = make([]*msg_server_message.SmallRankItem, 0, CAMP_FIGHT_RANK_SINGLE_GROUP_LEN)
				cur_count = 0
			}

			tmp_item = &msg_server_message.SmallRankItem{}
			tmp_item.Rank = proto.Int32(val.Rank)
			tmp_item.Id = proto.Int32(val.Id)
			tmp_item.Name = proto.String(val.Name)
			tmp_item.Score = proto.Int32(val.Val)
			tmp_item.TongIcon = proto.Int32(val.TongIcon)
			tmp_item.TongName = proto.String(val.TongName)
			tmp_rds = append(tmp_rds, tmp_item)
			cur_count++
		}

		if cur_count > 0 && group_idx <= CAMP_FIGHT_RANK_GROUP_NUM {
			tmp_cache.Caches[group_idx].records = tmp_rds
		}

		this.camp1_rank_cache = tmp_cache
	}

	bchg, allrds = this.camp2_score_rank.FillAllIfChanged()
	if bchg {
		tmp_cache = &CampRankRecordsCacheGroup{Caches: make([]*CampRankRecordsCache, CAMP_FIGHT_RANK_GROUP_NUM)}
		for idx := int32(0); idx < CAMP_FIGHT_RANK_GROUP_NUM; idx++ {
			tmp_cache.Caches[idx] = &CampRankRecordsCache{records_lock: &sync.RWMutex{}}
		}

		for idx, val := range allrds {
			if idx >= DEFAULT_SMALL_RANK_LENTH {
				break
			}

			group_idx = int32(idx) / CAMP_FIGHT_RANK_SINGLE_GROUP_LEN
			array_idx = int32(idx) - CAMP_FIGHT_RANK_SINGLE_GROUP_LEN*group_idx
			if 0 == array_idx {
				if group_idx > 0 {
					tmp_cache.Caches[group_idx].records = tmp_rds
				}
				tmp_rds = make([]*msg_server_message.SmallRankItem, 0, CAMP_FIGHT_RANK_SINGLE_GROUP_LEN)
				cur_count = 0
			}

			tmp_item = &msg_server_message.SmallRankItem{}
			tmp_item.Rank = proto.Int32(val.Rank)
			tmp_item.Id = proto.Int32(val.Id)
			tmp_item.Name = proto.String(val.Name)
			tmp_item.Score = proto.Int32(val.Val)
			tmp_item.TongIcon = proto.Int32(val.TongIcon)
			tmp_item.TongName = proto.String(val.TongName)
			tmp_rds = append(tmp_rds, tmp_item)
			cur_count++
		}

		if cur_count > 0 && group_idx <= CAMP_FIGHT_RANK_GROUP_NUM {
			tmp_cache.Caches[group_idx].records = tmp_rds
		}

		this.camp2_rank_cache = tmp_cache
	}

	return
}

func (this *CampFightManager) IsUpToDb() bool {
	this.is_up_to_db_lock.RLock()
	defer this.is_up_to_db_lock.RUnlock()

	return this.is_up_to_db
}

func (this *CampFightManager) SetUpToDb(bval bool) {
	this.is_up_to_db_lock.Lock()
	defer this.is_up_to_db_lock.Unlock()

	this.is_up_to_db = bval
}

func (this *CampFightManager) SetUpToDbIfNot() bool {
	this.is_up_to_db_lock.Lock()
	defer this.is_up_to_db_lock.Unlock()

	if this.is_up_to_db {
		return false
	}

	this.is_up_to_db = true

	return true
}

func (this *CampFightManager) WaitUpToDb() bool {
	for this.IsUpToDb() {
		time.Sleep(time.Second)
	}
	return true
}

func (this *CampFightManager) DoUpToDb() bool {
	log.Info("阵营战更新数据到数据库")
	if !this.SetUpToDbIfNot() {
		log.Info("CampFightManager DoUpToDb is in updating !")
		return false
	}

	defer this.SetUpToDb(false)

	tmp_row := dbc.CampFight.GetRow()
	if nil == tmp_row {
		log.Error("CampFightManager DoUpToDb tmp_row nil !")
		return true
	}

	bchg, allrds := this.total_score_rank.FillAllIfChanged()
	if bchg {
		log.Info("阵营战更新数据到数据库 全榜更新  %v", allrds)
		tmp_row.LastTotalRank.SetRecords(allrds)
	}

	bchg, allrds = this.camp1_score_rank.FillAllIfChanged()
	if bchg {
		log.Info("阵营战更新数据到数据库 Camp1榜更新  %v", allrds)
		tmp_row.LastCamp1Rank.SetRecords(allrds)
	}

	bchg, allrds = this.camp2_score_rank.FillAllIfChanged()
	if bchg {
		log.Info("阵营战更新数据到数据库 Camp2榜更新  %v", allrds)
		tmp_row.LastCamp2Rank.SetRecords(allrds)
	}

	log.Info("阵营战更新数据到数据库 结束")
	tmp_row.Save(false)
	return true
}

func (this *CampFightManager) ChkUpToDb() {
	this.up_to_db_chk_frame++
	if this.up_to_db_chk_frame < CAMP_UP_TO_DB_CHK_FRAME_COUNT {
		return
	}

	this.up_to_db_chk_frame = 0

	this.DoUpToDb()

	return
}

func (this *CampFightManager) CheckActState() {

	this.state_chk_frame++
	if this.state_chk_frame < CAMP_STATE_CHK_FRAME_COUNT {
		return
	}
	this.state_chk_frame = 0

	cur_unix := int32(time.Now().Unix())
	old_state := this.cur_state

	cur_week_day := int32(time.Now().Weekday())
	if 0 == cur_week_day {
		cur_week_day = 7
	}

	cur_week_sec := cur_week_day*24*3600 + int32(time.Now().Hour())*3600 + int32(time.Now().Minute())*60 + int32(time.Now().Second())

	bfind := false

	log.Info("整个活动区间 %d %d  cur_week_sec:%d", global_config.CampFightAllStartWeekSec, global_config.CampFightAllEndWeekSec, cur_week_sec)
	if cur_week_sec < global_config.CampFightAllStartWeekSec || cur_week_sec > global_config.CampFightAllEndWeekSec {
		for _, val := range global_config.CampFightRewardTimes {
			log.Info("比较奖励区间 %d  %d  cur_week_sec", val.StartWeekSec, val.ActEndWeekSec, cur_week_sec)
			if cur_week_sec >= val.StartWeekSec && cur_week_sec <= val.ActEndWeekSec {
				this.cur_state = CAMP_FIGHT_STATE_REWARD
				bfind = true
				break
			}
		}

		if !bfind {
			this.cur_state = CAMP_FIGHT_STATE_CLOSED
		}
	} else {
		var tmp_next_start int32
		for _, val := range global_config.CampFightOpenTimes {
			if cur_week_sec < val.StartWeekSec && tmp_next_start < val.StartWeekSec {
				tmp_next_start = val.StartWeekSec
			}

			if cur_week_sec >= val.StartWeekSec && cur_week_sec <= val.ActEndWeekSec {
				this.cur_state = CAMP_FIGHT_STATE_OPEN
				this.cur_fight_idx = val.FightIdx
				this.next_time_point = cur_unix + val.ActEndWeekSec - cur_week_sec
				bfind = true
				break
			}
		}

		if !bfind {
			this.next_time_point = cur_unix + tmp_next_start - cur_week_sec
			this.cur_state = CAMP_FIGHT_STATE_REST
		}
	}

	tmp_row := dbc.CampFight.GetRow()
	if nil == tmp_row {
		return
	}

	switch this.cur_state {
	case CAMP_FIGHT_STATE_OPEN:
		{
			if 0 == this.cur_fight_area {
				log.Info("开始在第一个快领[%d]地上作战", this.first_fight_area)
				this.cur_fight_area = this.first_fight_area
				tmp_row.BaseInfo.SetCurFightArea(this.first_fight_area)
				tmp_row.BaseInfo.SetCurFightIdx(this.cur_fight_idx)
				tmp_row.BaseInfo.SetCurCamp1Score(0)
				tmp_row.BaseInfo.SetCurCamp2Score(0)
			} else {
				if this.cur_fight_idx != tmp_row.BaseInfo.GetCurFightIdx() {
					if tmp_row.BaseInfo.GetCurCamp1Score() > tmp_row.BaseInfo.GetCurCamp2Score() {
						area_cfg := this.area2cfg[this.cur_fight_area]
						if nil != area_cfg {
							this.cur_fight_area = area_cfg.Xcampwin
							tmp_row.BaseInfo.SetCurFightArea(area_cfg.Xcampwin)
						}
					} else if tmp_row.BaseInfo.GetCurCamp1Score() < tmp_row.BaseInfo.GetCurCamp2Score() {
						area_cfg := this.area2cfg[this.cur_fight_area]
						if nil != area_cfg {
							this.cur_fight_area = area_cfg.Tcampwin
							tmp_row.BaseInfo.SetCurFightArea(area_cfg.Tcampwin)
						}
					}
					tmp_row.BaseInfo.SetCurFightIdx(this.cur_fight_idx)
					tmp_row.BaseInfo.SetCurCamp1Score(0)
					tmp_row.BaseInfo.SetCurCamp2Score(0)
				}
			}

		}
	case CAMP_FIGHT_STATE_CLOSED:
		{
			if global_config.CampFightAllStartWeekSec > cur_week_sec {
				this.next_time_point = cur_unix + global_config.CampFightAllStartWeekSec - cur_week_sec
			} else {
				this.next_time_point = cur_unix + global_config.CampFightAllStartWeekSec + 7*24*3600 - cur_week_sec
			}
		}
	case CAMP_FIGHT_STATE_REWARD:
		{
			if global_config.CampFightAllStartWeekSec > cur_week_sec {
				this.next_time_point = cur_unix + global_config.CampFightAllStartWeekSec - cur_week_sec
			} else {
				this.next_time_point = cur_unix + global_config.CampFightAllStartWeekSec + 7*24*3600 - cur_week_sec
			}

			_, iso_week := time.Now().ISOWeek()

			if tmp_row.BaseInfo.GetLastRewardISOWeek() != int32(iso_week) {
				if tmp_row.BaseInfo.GetCurCamp1Score() > tmp_row.BaseInfo.GetCurCamp2Score() {
					area_cfg := this.area2cfg[this.cur_fight_area]
					if nil != area_cfg {
						this.cur_fight_area = area_cfg.Xcampwin
						tmp_row.BaseInfo.SetCurFightArea(area_cfg.Xcampwin)
						tmp_row.BaseInfo.SetLastRewardISOWeek(int32(iso_week))
					}
				} else if tmp_row.BaseInfo.GetCurCamp1Score() < tmp_row.BaseInfo.GetCurCamp2Score() {
					area_cfg := this.area2cfg[this.cur_fight_area]
					if nil != area_cfg {
						this.cur_fight_area = area_cfg.Tcampwin
						tmp_row.BaseInfo.SetCurFightArea(area_cfg.Tcampwin)
						tmp_row.BaseInfo.SetLastRewardISOWeek(int32(iso_week))
					}
				}
			}
		}
	}

	_, iso_week := time.Now().ISOWeek()
	if this.binit && old_state != this.cur_state {
		res2h := &msg_server_message.NotifyCampFightState{}
		res2h.State = proto.Int32(this.cur_state)
		res2h.CurFightArena = proto.Int32(this.cur_fight_area)
		res2h.LeftSec = proto.Int32(this.next_time_point - cur_unix)

		res2h.CurYearWeek = proto.Int32(int32(iso_week))
		res2h.CurRewardISOWeek = proto.Int32(tmp_row.BaseInfo.GetLastRewardISOWeek())
		hall_agent_mgr.Broadcast(res2h)
	}

	if 1 == time.Now().Weekday() && int32(iso_week) != tmp_row.BaseInfo.GetCurActISOWeek() {
		this.last_total_score_rank.Reset()
		all_rds := this.total_score_rank.GetAllAndReset()
		for _, val := range all_rds {
			if nil == val {
				continue
			}

			this.last_total_score_rank.SetUpdateRank(val.id, val.val, val.tongicon, val.name, val.tongname)
		}

		this.last_camp1_score_rank.Reset()
		all_rds = this.camp1_score_rank.GetAllAndReset()
		for _, val := range all_rds {
			if nil == val {
				continue
			}

			this.last_camp1_score_rank.SetUpdateRank(val.id, val.val, val.tongicon, val.name, val.tongname)
		}

		this.last_camp2_score_rank.Reset()
		all_rds = this.camp2_score_rank.GetAllAndReset()
		for _, val := range all_rds {
			if nil == val {
				continue
			}

			this.last_camp2_score_rank.SetUpdateRank(val.id, val.val, val.tongicon, val.name, val.tongname)
		}

		tmp_row.CurCampFighgtRecord.SetRecords(nil)
	}

	if CAMP_FIGHT_STATE_REST == this.cur_state && tmp_row.BaseInfo.GetCurRestIdx() != this.cur_fight_idx {
		cur_rds := tmp_row.CurCampFighgtRecord.GetRecords()
		tmp_len := int32(len(cur_rds))
		new_rds := make([]dbCampFightRecordData, tmp_len+1)
		for idx := int32(0); idx < tmp_len; idx++ {
			cur_rds[idx].clone_to(&new_rds[idx])
		}

		new_rds[tmp_len].FightIdx = this.cur_fight_idx
		new_rds[tmp_len].XScore = tmp_row.BaseInfo.GetCurCamp1Score()
		new_rds[tmp_len].TScore = tmp_row.BaseInfo.GetCurCamp2Score()

		tmp_row.CurCampFighgtRecord.SetRecords(new_rds)
	}

	log.Info("CampFightManager 当前状态 fight_area:%v cur_state:%v left_min:%v", this.cur_fight_area, this.cur_state, (this.next_time_point-cur_unix)/60)

	return
}

func (this *CampFightManager) UpdateCampScoreChg() {
	this.update_score_frame++
	if this.update_score_frame < CAMP_UPDATE_SCORE_FRAME_COUNT {
		return
	}
	this.update_score_frame = 0

	tmp_x_score := this.tmp_row.BaseInfo.GetCurCamp1Score()
	tmp_t_score := this.tmp_row.BaseInfo.GetCurCamp2Score()
	log.Info("尝试更新积分", this.last_up_x_score, tmp_x_score, this.last_up_t_score, tmp_t_score)
	if this.last_up_x_score != tmp_x_score || this.last_up_t_score != tmp_t_score {
		notify := &msg_server_message.CampFightScoreUpdate{}
		notify.XCampScore = proto.Int32(tmp_x_score)
		notify.TCampScore = proto.Int32(tmp_t_score)
		hall_agent_mgr.Broadcast(notify)
		this.last_up_x_score = tmp_x_score
		this.last_up_t_score = tmp_t_score
	}

	return
}

func (this *CampFightManager) OnTick() {
	this.CheckActState()
	this.ChkUpToDb()
	this.UpdateRankCache()
	this.UpdateCampScoreChg()
}

// 停止处理 =====================================================================

func (this *CampFightManager) Close_Func(info *SignalRegRecod) {

	if !this.DoUpToDb() {
		this.WaitUpToDb()
	}

	info.close_flag = true
}

// 消息相关 =====================================================================

func (this *CampFightManager) RegMsgHandler() {
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_GetCampFightState, this.H2CGetCampFightStateHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_GetCampFightRank, this.H2CGetCampFightRankHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_CampFigthScoreChg, this.H2CCampFigthScoreChgHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_GetCampFightRecord, this.H2CGetCampFightRecordHandler)
}

func (this *CampFightManager) H2CGetCampFightStateHandler(conn *server_conn.ServerConn, msg proto.Message) {
	if nil == conn {
		log.Error("CampFightManager OnHallConnect conn nil !")
		return
	}

	res2h := &msg_server_message.NotifyCampFightState{}
	res2h.State = proto.Int32(this.cur_state)
	res2h.CurFightArena = proto.Int32(this.cur_fight_area)
	res2h.LeftSec = proto.Int32(this.next_time_point - int32(time.Now().Unix()))
	_, iso_week := time.Now().ISOWeek()
	res2h.CurYearWeek = proto.Int32(int32(iso_week))
	conn.Send(res2h, true)

	return
}

func (this *CampFightManager) H2CCampFigthScoreChgHandler(conn *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.CampFigthScoreChg)
	if nil == conn || nil == req {
		log.Error("CampFightManager H2CCampFigthScoreChgHandler conn or req nil [%v]", nil == req)
		return
	}

	pid := req.GetPlayerId()
	pname := req.GetPlayerName()
	pscore := req.GetCurScore()
	tong_icon := req.GetTongIcon()
	tong_name := req.GetTongName()
	this.total_score_rank.SetUpdateRank(pid, pscore, tong_icon, pname, tong_name)
	if PLAYER_CAMP_1 == req.GetPlayerCamp() {
		this.camp1_score_rank.SetUpdateRank(pid, pscore, tong_icon, pname, tong_name)
		this.tmp_row.BaseInfo.Camp1ScoreChg(req.GetPlayerScoreChg())
		log.Info("阵营1积分变化 %d  %d", req.GetPlayerScoreChg(), this.tmp_row.BaseInfo.GetCurCamp1Score())
	} else {
		this.camp2_score_rank.SetUpdateRank(pid, pscore, tong_icon, pname, tong_name)
		this.tmp_row.BaseInfo.Camp2ScoreChg(req.GetPlayerScoreChg())
		log.Info("阵营2积分变化 %d", this.tmp_row.BaseInfo.GetCurCamp2Score())
	}

	return
}

func (this *CampFightManager) H2CGetCampFightRankHandler(conn *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.GetCampFightRank)
	if nil == conn || nil == req {
		log.Error("CampFightManager H2CGetCampFightRankHandler conn or  req nil [%v]", nil == req)
		return
	}

	rank_type := req.GetRankType()
	res2h := &msg_server_message.RetCampFightRank{}
	res2h.RankType = proto.Int32(rank_type)
	res2h.PlayerId = proto.Int32(req.GetPlayerId())

	var tmp_cache_group *CampRankRecordsCacheGroup

	if 0 == req.GetIfLastRank() {
		switch rank_type {
		case SMALL_RANK_TYPE_CAMP_FIGHT_TOTAL:
			{
				tmp_cache_group = this.total_rank_cache
			}
		case SMALL_RANK_TYPE_CAMP_FIGHT_1_SCORE:
			{
				tmp_cache_group = this.camp1_rank_cache
			}
		case SMALL_RANK_TYPE_CAMP_FIGHT_2_SCORE:
			{
				tmp_cache_group = this.camp2_rank_cache
			}
		}
	} else {
		switch rank_type {
		case SMALL_RANK_TYPE_CAMP_FIGHT_TOTAL:
			{
				tmp_cache_group = this.last_total_rank_cache
			}
		case SMALL_RANK_TYPE_CAMP_FIGHT_1_SCORE:
			{
				tmp_cache_group = this.last_camp1_rank_cache
			}
		case SMALL_RANK_TYPE_CAMP_FIGHT_2_SCORE:
			{
				tmp_cache_group = this.last_camp2_rank_cache
			}
		}
	}

	for _, tmp_cache := range tmp_cache_group.Caches {
		if nil == tmp_cache || len(tmp_cache.records) < 1 {
			continue
		}

		res2h.Recoreds = tmp_cache.records
		conn.Send(res2h, true)
	}
}

func (this *CampFightManager) H2CGetCampFightRecordHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.GetCampFightRecord)
	if nil == c || nil == req {
		log.Error("CampFightManager H2CGetCampFightRecordHandler c or req nil [%v] !", nil == req)
		return
	}

	res2h := &msg_server_message.RetCampFightRecord{}
	this.tmp_row.CurCampFighgtRecord.FillRecordMsg(res2h)

	c.Send(res2h, true)

	return
}
