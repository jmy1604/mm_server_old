package main

//_ "3p/mysql"

import (
	"libs/log"
	"public_message/gen_go/server_message"

	"3p/code.google.com.protobuf/proto"
)

func (this *DBC) on_preload() (err error) {

	return
}

func (this *dbPlayerIdMaxRow) Inc() (id int32) {
	this.m_lock.Lock("dbPlayerIdMaxRow.Inc")
	defer this.m_lock.Unlock()

	this.m_PlayerIdMax++
	id = this.m_PlayerIdMax

	this.m_PlayerIdMax_changed = true

	return
}

func (this *dbCampFightCurCampFighgtRecordColumn) FillRecordMsg(msg *msg_server_message.RetCampFightRecord) {
	if nil == msg {
		log.Error("dbCampFightCurCampFighgtRecordColumn FillRecordMsg msg nil !")
		return
	}

	var tmp_rd *msg_server_message.CampFightRecord
	var tmp_db *dbCampFightRecordData
	this.m_row.m_lock.UnSafeRLock("dbCampFightCurCampFighgtRecordColumn.FillRecordMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()

	tmp_len := int32(len(this.m_data.Records))
	msg.Records = make([]*msg_server_message.CampFightRecord, 0, tmp_len)

	for idx := int32(0); idx < tmp_len; idx++ {
		tmp_db = &this.m_data.Records[idx]
		tmp_rd = &msg_server_message.CampFightRecord{}
		tmp_rd.FightIdx = proto.Int32(tmp_db.FightIdx)
		tmp_rd.XScore = proto.Int32(tmp_db.XScore)
		tmp_rd.TScore = proto.Int32(tmp_db.TScore)
		msg.Records = append(msg.Records, tmp_rd)
	}

	return
}

func (this *dbCampFightBaseInfoColumn) Camp1ScoreChg(ichg int32) (v int32) {
	this.m_row.m_lock.UnSafeLock("dbCampFightBaseInfoColumn.Camp1ScoreChg")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurCamp1Score += ichg
	if this.m_data.CurCamp1Score < 0 {
		this.m_data.CurCamp1Score = 0
	}

	this.m_changed = true
	return
}

func (this *dbCampFightBaseInfoColumn) Camp2ScoreChg(ichg int32) (v int32) {
	this.m_row.m_lock.UnSafeLock("dbCampFightBaseInfoColumn.Camp2ScoreChg")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurCamp2Score += ichg
	if this.m_data.CurCamp2Score < 0 {
		this.m_data.CurCamp2Score = 0
	}
	this.m_changed = true
	return
}
