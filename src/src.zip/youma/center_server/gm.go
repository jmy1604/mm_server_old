package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"net"
	"net/http"
	"public_message/gen_go/server_message"
	"strconv"
	"strings"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

var gm_http_mux map[string]func(http.ResponseWriter, *http.Request)

type GmHttpHandle struct{}

func (this *GmHttpHandle) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	var act_str, url_str string
	url_str = r.URL.String()
	idx := strings.Index(url_str, "?")
	if -1 == idx {
		act_str = url_str
	} else {
		act_str = string([]byte(url_str)[:idx])
	}
	log.Info("ServeHTTP actstr(%s)", act_str)
	if h, ok := gm_http_mux[act_str]; ok {
		h(w, r)
	}

	return
}

//=======================================================

type GmMgr struct {
	id2payback_lock *sync.RWMutex
	id2payback      map[int32]*msg_server_message.PayBackAdd

	id2paynotice_lock *sync.RWMutex
	id2paynotice      map[int32]*msg_server_message.NoticeAdd

	gm_http_listener net.Listener
}

var gm_mgr GmMgr

func (this *GmMgr) Init() bool {
	this.id2paynotice_lock = &sync.RWMutex{}
	this.id2paynotice = make(map[int32]*msg_server_message.NoticeAdd)

	if !this.LoadPayBack() {
		return false
	}
	return true
}

type XmlPayBackItem struct {
	Id             int32  `xml:"ID,attr"`
	Title          string `xml:"Title,attr"`
	Content        string `xml:"Content,attr"`
	ChestPosition1 int32  `xml:"ChestPosition1,attr"`
	ChestPosition2 int32  `xml:"ChestPosition2,attr"`
	ChestPosition3 int32  `xml:"ChestPosition3,attr"`
	TermOfValidity int32  `xml:"TermOfValidity,attr"`
	EndDate        string `xml:"EndDate,attr"`
}

type XmlPayBackList struct {
	Items []XmlPayBackItem `xml:"item"`
}

func (this *GmMgr) LoadPayBack() bool {
	this.id2payback_lock = &sync.RWMutex{}
	this.id2payback = make(map[int32]*msg_server_message.PayBackAdd)

	content, err := ioutil.ReadFile("../game_data/compensate.xml")
	if nil != err {
		log.Error("GmMgr LoadPayBack read file error(%s) !", err.Error())
		return false
	}

	tmp_cfg := &XmlPayBackList{}
	err = xml.Unmarshal(content, tmp_cfg)
	if nil != err {
		log.Error("GmMgr LoadPayBack unmarshl error(%s) content(%s)!", err.Error(), string(content))
		return false
	}

	cur_unix := time.Now().Unix()
	var tmp_pb *msg_server_message.PayBackAdd
	for _, val := range tmp_cfg.Items {
		tmp_t, err := time.Parse("2006 Jan 02 15:04:05", val.EndDate)
		if nil != err {
			log.Error("GmMgr LoadPayBack parse date(%s) error(%s) !", val.EndDate, err.Error())
			return false
		}

		if cur_unix > tmp_t.Unix() {
			log.Error("GmMgr LoadPayBack [%d] time over", val.Id)
			continue
		}

		tmp_pb = &msg_server_message.PayBackAdd{}
		tmp_pb.ChestsId = make([]int32, 0, 3)
		if val.ChestPosition1 > 0 {
			tmp_pb.ChestsId = append(tmp_pb.ChestsId, val.ChestPosition1)
		}
		if val.ChestPosition2 > 0 {
			tmp_pb.ChestsId = append(tmp_pb.ChestsId, val.ChestPosition2)
		}
		if val.ChestPosition3 > 0 {
			tmp_pb.ChestsId = append(tmp_pb.ChestsId, val.ChestPosition3)
		}

		tmp_pb.Coin = proto.Int32(0)
		tmp_pb.Diamond = proto.Int32(0)
		tmp_pb.MailContent = proto.String(val.Content)
		tmp_pb.MailTitle = proto.String(val.Title)
		tmp_pb.OverUnix = proto.Int32(int32(tmp_t.Unix()))
		tmp_pb.PayBackId = proto.Int32(val.Id)
		this.id2payback[val.Id] = tmp_pb
	}

	return true
}

func (this *GmMgr) AddPayBack(tmp_pb *msg_server_message.PayBackAdd) {
	if nil == tmp_pb {
		log.Error("GmMgr AddPayBack tmp_pb nil")
		return
	}

	pb_id := tmp_pb.GetPayBackId()

	this.id2payback_lock.Lock()
	defer this.id2payback_lock.Unlock()

	cur_pb := this.id2payback[pb_id]
	if nil == cur_pb {
		log.Error("GmMgr AddPayBack cur_pb[%d] already have !", pb_id)
		return
	}

	this.id2payback[pb_id] = tmp_pb
	return
}

func (this *GmMgr) RemovePayBack(pb_id int32) {
	this.id2payback_lock.Lock()
	defer this.id2payback_lock.Unlock()

	if nil != this.id2payback[pb_id] {
		delete(this.id2payback, pb_id)
	}

	return
}

func (this *GmMgr) FillPayBackSyncMsg() *msg_server_message.SyncPayBackDataList {
	this.id2payback_lock.RLock()
	defer this.id2payback_lock.RUnlock()
	tmp_len := int32(len(this.id2payback))
	if tmp_len < 1 {
		return nil
	}

	ret_msg := &msg_server_message.SyncPayBackDataList{}
	ret_msg.PayBackList = make([]*msg_server_message.PayBackAdd, 0, tmp_len)
	for _, pb := range this.id2payback {
		if nil == pb {
			continue
		}

		ret_msg.PayBackList = append(ret_msg.PayBackList, pb)
	}

	if len(ret_msg.PayBackList) > 0 {
		return ret_msg
	}

	return nil
}

func (this *GmMgr) OnHallRegist(hall_svr *HallAgent) {
	if nil == hall_svr {
		log.Error("GmMgr OnHallRegist  hall_svr nil !")
		return
	}

	res2h := this.FillPayBackSyncMsg()
	if nil == res2h {
		log.Info("GmMgr OnHallRegist[%d] payback msg nil", hall_svr.id)
		return
	}

	hall_svr.Send(res2h)

	return
}

func (this *GmMgr) StartHttp() {
	var err error
	this.reg_http_mux()

	this.gm_http_listener, err = net.Listen("tcp", config.GmIP)
	if nil != err {
		log.Error("Center StartHttp Failed %s", err.Error())
		return
	}

	signal_mgr.RegCloseFunc("gm_mgr", this.CloseFunc)

	gm_http_server := http.Server{
		Handler:     &GmHttpHandle{},
		ReadTimeout: 6 * time.Second,
	}

	log.Info("启动Gm服务 IP:%s", config.GmIP)
	err = gm_http_server.Serve(this.gm_http_listener)
	if err != nil {
		log.Error("启动Center gm Http Server %s", err.Error())
		return
	}

}

func (this *GmMgr) CloseFunc(info *SignalRegRecod) {
	if nil != this.gm_http_listener {
		this.gm_http_listener.Close()
	}

	info.close_flag = true
	return
}

//=========================================================

func (this *GmMgr) reg_http_mux() {
	gm_http_mux = make(map[string]func(http.ResponseWriter, *http.Request))
	gm_http_mux["/send_mail"] = send_mail_http_handler
	gm_http_mux["/add_payback"] = add_pay_back_http_handler
	gm_http_mux["/remove_payback"] = remove_pay_back_http_handler
	gm_http_mux["/gm_cmd"] = test_gm_command_http_handler
}

func send_mail_http_handler(w http.ResponseWriter, r *http.Request) {
	if "GET" == r.Method {
		pids_str := r.URL.Query().Get("pids")
		pid_arr := strings.Split(pids_str, "|")
		pids := make([]int32, 0, len(pids_str))
		var tmp_id int
		var err error
		for _, sub_str := range pid_arr {
			if "" == sub_str {
				continue
			}

			tmp_id, err = strconv.Atoi(sub_str)
			if nil != err {
				log.Error("send_mail_http_handler convert pid[%s] failed(%s)", sub_str, err.Error())
				continue
			}

			pids = append(pids, int32(tmp_id))
		}

		if len(pids) < 1 {
			log.Error("send_mail_http_handler pids empty !")
			return
		}

		mail_tid_str := r.URL.Query().Get("mail_id")
		mail_tid, err := strconv.Atoi(mail_tid_str)
		if nil != err {
			log.Error("send_mail_http_handler convert mail_id_str[%s] failed[%s]", mail_tid_str, err.Error())
			return
		}

		mail_cfg := cfg_mail_mgr.Map[int32(mail_tid)]
		if nil == mail_cfg {
			log.Error("send_mail_http_handler failed to find mail_cfg !")
			return
		}

		/*
			coin_str := r.URL.Query().Get("coin")
			coin, err := strconv.Atoi(coin_str)
			if nil != err {
				log.Error("send_mail_http_handler convert conin_str(%s) failed(%s)", coin_str, err.Error())
				return
			}

			diamond_str := r.URL.Query().Get("diamond")
			diamond, err := strconv.Atoi(diamond_str)
			if nil != err {
				log.Error("send_mail_http_handler convert diamond_str(%s) failed(%s)", diamond_str, err.Error())
				return
			}

			chests_str := r.URL.Query().Get("chests")
			chest_arr := strings.Split(chests_str, "|")
			chests := make([]int32, 0, len(chests_str))
			for _, sub_str := range chest_arr {
				tmp_id, err = strconv.Atoi(sub_str)
				if nil != err {
					log.Error("send_mail_http_handler convert chestid[%s] failed(%s)", sub_str, err.Error())
					return
				}
				chests = append(chests, int32(tmp_id))
			}

			title_str := r.URL.Query().Get("title")
			content_str := r.URL.Query().Get("content")
		*/

		last_sec_str := r.URL.Query().Get("last_sec")
		last_sec, err := strconv.Atoi(last_sec_str)
		if nil != err {
			log.Error("send_mail_http_handler convert last_sec_str(%s) failed(%s)", last_sec_str, err.Error())
			return
		}

		req2h := &msg_server_message.MailAdd{}
		req2h.Chests = mail_cfg.RewardIds
		req2h.ChestNums = mail_cfg.RewardNums
		/*
			req2h.Coin = proto.Int32(int32(coin))
			req2h.Content = proto.String(content_str)
			req2h.Diamond = proto.Int32(int32(diamond))
		*/
		req2h.OverUnix = proto.Int32(int32(time.Now().Unix()) + int32(last_sec))
		req2h.SenderName = proto.String("gm")
		req2h.SendUnix = proto.Int32(int32(time.Now().Unix()))
		//req2h.Title = proto.String(title_str)
		req2h.MailType = proto.Int32(int32(mail_tid))
		var hall_svrinfo *SingleHallCfg
		var hall_svr *HallAgent
		for _, pid := range pids {
			hall_svrinfo = hall_group_mgr.GetHallCfgByPlayerId(pid)
			if nil == hall_svrinfo {
				log.Error("send_mail_http_handler failed to get hallsvninfo[%d]", pid)
				continue
			}

			hall_svr = hall_agent_mgr.GetAgentById(hall_svrinfo.ServerId)
			if nil == hall_svr {
				log.Error("send_mail_http_handler failed to get hall_svr[%d]", hall_svrinfo.ServerId)
				continue
			}

			req2h.PlayerId = proto.Int32(pid)
			hall_svr.Send(req2h)
		}
	} else {
		log.Error("send_mail_http_handler not support POST Method !")
	}
}

func add_pay_back_http_handler(w http.ResponseWriter, r *http.Request) {
	if "GET" == r.Method {
		pb_id_str := r.URL.Query().Get("paybackid")
		pb_id, err := strconv.Atoi(pb_id_str)
		if nil != err {
			log.Error("add_pay_back_http_handler convert pb_id_str(%s) failed(%s)", pb_id_str, err.Error())
			return
		}

		coin_str := r.URL.Query().Get("coin")
		coin, err := strconv.Atoi(coin_str)
		if nil != err {
			log.Error("add_pay_back_http_handler convert conin_str(%s) failed(%s)", coin_str, err.Error())
			return
		}

		diamond_str := r.URL.Query().Get("diamond")
		diamond, err := strconv.Atoi(diamond_str)
		if nil != err {
			log.Error("add_pay_back_http_handler convert diamond_str(%s) failed(%s)", diamond_str, err.Error())
			return
		}

		last_sec_str := r.URL.Query().Get("last_sec")
		last_sec, err := strconv.Atoi(last_sec_str)
		if nil != err {
			log.Error("send_mail_http_handler convert last_sec_str(%s) failed(%s)", last_sec_str, err.Error())
			return
		}

		chests_str := r.URL.Query().Get("chests")
		chest_arr := strings.Split(chests_str, "|")
		chests := make([]int32, 0, len(chests_str))
		for _, sub_str := range chest_arr {
			tmp_id, err := strconv.Atoi(sub_str)
			if nil != err {
				log.Error("send_mail_http_handler convert chestid[%s] failed(%s)", sub_str, err.Error())
				return
			}
			chests = append(chests, int32(tmp_id))
		}
		title_str := r.URL.Query().Get("title")
		content_str := r.URL.Query().Get("content")
		tmp_pb := &msg_server_message.PayBackAdd{}
		tmp_pb.PayBackId = proto.Int32(int32(pb_id))
		tmp_pb.ChestsId = chests
		tmp_pb.Coin = proto.Int32(int32(coin))
		tmp_pb.Diamond = proto.Int32(int32(diamond))
		tmp_pb.MailContent = proto.String(content_str)
		tmp_pb.MailTitle = proto.String(title_str)
		tmp_pb.OverUnix = proto.Int32(int32(time.Now().Unix()) + int32(last_sec))
		gm_mgr.AddPayBack(tmp_pb)
		hall_agent_mgr.Broadcast(tmp_pb)
	} else {
		log.Error("add_pay_back_http_handler not support POST Method")
	}
}

func remove_pay_back_http_handler(w http.ResponseWriter, r *http.Request) {
	if "GET" == r.Method {
		pb_id_str := r.URL.Query().Get("paybackid")
		pb_id, err := strconv.Atoi(pb_id_str)
		if nil != err {
			log.Error("remove_pay_back_http_handler convert pb_id_str(%s) failed(%s)", pb_id_str, err.Error())
			return
		}

		tmp_pb := &msg_server_message.PayBackRemove{}
		tmp_pb.PbId = proto.Int32(int32(pb_id))

		hall_agent_mgr.Broadcast(tmp_pb)
	} else {
		log.Error("remove_pay_back_http_handler not support POST Method")
	}
}

func test_gm_command_http_handler(w http.ResponseWriter, r *http.Request) {
	if "GET" == r.Method {
		gm_str := r.URL.Query().Get("cmd_str")

		tmp_gm := &msg_server_message.C2HGmCommand{}
		tmp_gm.Command = proto.String(gm_str)
		hall_agent_mgr.Broadcast(tmp_gm)

		w.Write([]byte("MUM196-198"))
		r.Body.Close()
	} else {
		log.Error("test_gm_command_http_handler not support POST Method")
	}
}
