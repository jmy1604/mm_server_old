package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
)

type XmlExpItem struct {
	UserLvl int32 `xml:"UserLevel,attr"`
	ExpCost int32 `xml:"ExpCost,attr"`
}

type XmlExpConfig struct {
	Items []XmlExpItem `xml:"item"`
}

type CfgExp struct {
	MaxLevel    int32
	MaxLevelExp int32
	Map         map[int32]int32
	Array       []*XmlExpItem
}

var cfg_exp CfgExp

func (this *CfgExp) Init() bool {
	if !this.Load() {
		return false
	}
	return true
}

func (this *CfgExp) Load() bool {
	content, err := ioutil.ReadFile("../game_data/experience.xml")
	if nil != err {
		log.Error("CfgExp load error (%s)", err.Error())
		return false
	}

	tmp_cfg := &XmlExpConfig{}
	err = xml.Unmarshal(content, tmp_cfg)
	if nil != err {
		log.Error("CfgExp load unmarshal error(%s) !", err.Error())
		return false
	}

	this.Map = make(map[int32]int32)
	this.Array = make([]*XmlExpItem, 0, len(tmp_cfg.Items))
	for idx := int32(0); idx < int32(len(tmp_cfg.Items)); idx++ {
		val := &tmp_cfg.Items[idx]
		if val.UserLvl > this.MaxLevel {
			this.MaxLevel = val.UserLvl
			this.MaxLevelExp = val.ExpCost
		}

		this.Map[val.UserLvl] = val.UserLvl
		this.Array = append(this.Array, val)
	}

	return true
}
