package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
)

type XmlArenaItem struct {
	ArenaLvl      int32 `xml:"ArenaRating,attr"`
	StartScore    int32 `xml:"TrophyLower,attr"`
	EndScore      int32 `xml:"TrophyUpper,attr"`
	DropScore     int32 `xml:"DemoteTrophyLimit,attr"`
	WinCoin       int32 `xml:"GoldAward,attr"`
	DonationUpper int32 `xml:"DonationUpper,attr"` // 捐赠上限
	SingleCommon  int32 `xml:"SingleCommon,attr"`  // 单次捐赠白卡上限
	SingleRare    int32 `xml:"SingleRare,attr"`    // 单词捐赠稀有卡上限
	SeekCommon    int32 `xml:"SeekCommon,attr"`    // 单次请求白卡上限
	SeekRare      int32 `xml:"SeekRare,attr"`      // 单次请求稀有卡上限
}

type XmlArenaConfig struct {
	Items []XmlArenaItem `xml:"item"`
}

type CfgArena struct {
	Map    map[int32]*XmlArenaItem
	Array  []*XmlArenaItem
	LegLvl int32 // 传奇竞技场等级
}

var cfg_arena CfgArena

func (this *CfgArena) Init() bool {
	if !this.Load() {
		return false
	}
	return true
}

func (this *CfgArena) Load() bool {
	content, err := ioutil.ReadFile("../game_data/arena.xml")
	if nil != err {
		log.Error("CfgArena Load read arena error(%s) !", err.Error())
		return false
	}

	tmp_cfg := &XmlArenaConfig{}
	err = xml.Unmarshal(content, tmp_cfg)
	if nil != err {
		log.Error("CfgArena Load unmarshal arena error(%s) !", err.Error())
		return false
	}

	tmp_len := int32(len(tmp_cfg.Items))
	if tmp_len <= 0 {
		log.Error("CfgArena Load arean item zero !")
		return false
	}

	this.Map = make(map[int32]*XmlArenaItem)
	this.Array = make([]*XmlArenaItem, 0, tmp_len)
	tmp_cfg.Items[tmp_len-1].EndScore = MAX_MATCH_SCORE
	for idx := int32(0); idx < tmp_len; idx++ {
		tmp_item := &tmp_cfg.Items[idx]
		if 0 == tmp_item.ArenaLvl {
			continue
		}

		this.Map[tmp_item.ArenaLvl] = tmp_item
		this.Array = append(this.Array, tmp_item)
		if tmp_item.ArenaLvl > this.LegLvl {
			this.LegLvl = tmp_item.ArenaLvl
		}
	}

	log.Info("arena Getwincoincest lvl1:%d lvl2:%d", this.GetWinCoinByLvl(1), this.GetWinCoinByLvl(2))
	log.Info("arena GetArenaLvl by score 0_lvl:%d 200_lvl:%d", this.GetAreanLvlByScore(0), this.GetAreanLvlByScore(200))
	log.Info("print arena cfg=======================start")
	for _, val := range this.Array {
		if nil == val {
			continue
		}

		log.Info("this arena %v", *val)
	}
	log.Info("print arena cfg=======================end")

	return true
}

func (this *CfgArena) GetWinCoinByLvl(arenalvl int32) int32 {
	tmp_cfg := this.Map[arenalvl]
	if nil == tmp_cfg {
		log.Error("CfgArena GetWinCoinByLvl arenalvl not found !")
		return 0
	}

	return tmp_cfg.WinCoin
}

func (this *CfgArena) GetAreanLvlByScore(score int32) int32 {
	for _, tmp_item := range this.Array {
		if nil == tmp_item {
			continue
		}

		if score >= tmp_item.StartScore && score <= tmp_item.EndScore {
			return tmp_item.ArenaLvl
		}
	}
	return 0
}

func (this *CfgArena) GetDropScoreByArenaLvl(lvl int32) int32 {
	cur_info := this.Map[lvl]
	if nil != cur_info {
		return cur_info.DropScore
	}

	return 0
}
