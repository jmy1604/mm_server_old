package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"libs/server_conn"
	"libs/socket"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	CAMP_FIGHT_STATE_CLOSED = 1 // 关闭状态
	CAMP_FIGHT_STATE_OPEN   = 2 // 开战状态
	CAMP_FIGHT_STATE_REST   = 3 // 休战状态
	CAMP_FIGHT_STATE_REWARD = 4 // 发奖状态

)

type CfgIdNum struct {
	CfgId int32
	Num   int32
}

type CampRewardInfo struct {
	Camp    int32       // 阵营
	Rewards []*CfgIdNum // 奖励内容
}

type XmlCampAreaItem struct {
	CampID       int32 `xml:"CampID,attr"`
	Xcampwin     int32 `xml:"Xcampwin,attr"`
	Tcampwin     int32 `xml:"Tcampwin,attr"`
	XReward      int32 `xml:"XReward,attr"`
	TReward      int32 `xml:"TReward,attr"`
	Camp2Rewards map[int32]int32
}

type XmlCampAreaConfig struct {
	Items []XmlCampAreaItem `xml:"item"`
}

type CampAreaReward struct {
	AreaLvl int32
	Items   []CampRewardInfo
}

type CampSingleRewards struct {
	Camp      int32
	Min_Score int32
	Array     []*XmlCampSingRewardItem
}

type XmlCampSingRewardItem struct {
	Camp           int32 `xml:"Camp,attr"`
	IntegralMin    int32 `xml:"IntegralMin,attr"`
	IntegralMax    int32 `xml:"IntegralMax,attr"`
	Arena_reward_1 int32 `xml:"Arena_reward_1,attr"`
	Arena_reward_2 int32 `xml:"Arena_reward_2,attr"`
	Arena_reward_3 int32 `xml:"Arena_reward_3,attr"`
	Arena_reward_4 int32 `xml:"Arena_reward_4,attr"`
	Arena_reward_5 int32 `xml:"Arena_reward_5,attr"`
	Arena_reward_6 int32 `xml:"Arena_reward_6,attr"`
	Arena_reward_7 int32 `xml:"Arena_reward_7,attr"`
	Arena_reward_8 int32 `xml:"Arena_reward_8,attr"`
	Arena_reward_9 int32 `xml:"Arena_reward_9,attr"`
	Arena2Reward   map[int32]int32
}

type XmlCampSingRewardConfig struct {
	Items []XmlCampSingRewardItem `xml:"item"`
}

type CampFightManager struct {
	area2cfg          map[int32]*XmlCampAreaItem
	camp2singlereward map[int32]*CampSingleRewards

	binit               bool  // 是否已经初始化
	b_state_init        bool  // 状态是否已经初始化
	state               int32 // 当前状态
	next_time_point     int32 // 下一个时间节点
	cur_fight_idx       int32 // 当前战斗场次
	cur_fight_area      int32 // 当前战斗区域
	cur_act_iso_week    int32 // 当前活动周
	cur_reward_iso_week int32 // 当前奖励周
	cur_x_score         int32 // 当前X阵营积分
	cur_t_score         int32 // 当前T阵营积分

	in_act_players_lock *sync.RWMutex
	in_act_players      map[int32]*Player // 当前在活动中的玩家
}

var camp_fight_mgr CampFightManager

func (this *CampFightManager) Init() bool {
	if !this.LoadCampArea() {
		log.Error("CampFightManager Init Failed !")
		return false
	}
	this.in_act_players = make(map[int32]*Player)
	this.in_act_players_lock = &sync.RWMutex{}

	this.binit = true

	return true
}

func (this *CampFightManager) LoadCampArea() bool {
	content, err := ioutil.ReadFile("../game_data/CampConfig.xml")
	if nil != err {
		log.Error("CampFightManager LoadCampArea read file error err[%s]!", err.Error())
		return false
	}

	tmp_camp_cfg := &XmlCampAreaConfig{}
	err = xml.Unmarshal(content, tmp_camp_cfg)
	if nil != err {
		log.Error("CampFightManager LoadCampArea xml unmarshal err[%s] !", err.Error())
		return false
	}

	this.area2cfg = make(map[int32]*XmlCampAreaItem)
	for idx := int32(0); idx < int32(len(tmp_camp_cfg.Items)); idx++ {
		tmp_val := &tmp_camp_cfg.Items[idx]
		tmp_val.Camp2Rewards = make(map[int32]int32)
		tmp_val.Camp2Rewards[PLAYER_CAMP_1] = tmp_val.XReward
		tmp_val.Camp2Rewards[PLAYER_CAMP_2] = tmp_val.TReward
		this.area2cfg[tmp_val.CampID] = tmp_val
	}

	return true
}

func (this *CampFightManager) LoadSingleReward() bool {
	content, err := ioutil.ReadFile("../game_data/")
	if nil != err {
		log.Error("CampFightManager LoadSingleReward read file error[%s]", err.Error())
		return false
	}

	tmp_cfg := &XmlCampSingRewardConfig{}
	err = xml.Unmarshal(content, tmp_cfg)
	if nil != err {
		log.Error("CampFightManager LoadSingleReward xml unmarshal error[%s]", err.Error())
		return false
	}

	var tmp_val *XmlCampSingRewardItem
	tmp_len := int32(len(tmp_cfg.Items))
	this.camp2singlereward = make(map[int32]*CampSingleRewards)
	camp1rewards := &CampSingleRewards{Camp: PLAYER_CAMP_1, Array: make([]*XmlCampSingRewardItem, 0, tmp_len/2+1)}
	camp2rewards := &CampSingleRewards{Camp: PLAYER_CAMP_2, Array: make([]*XmlCampSingRewardItem, 0, tmp_len/2+1)}
	for idx := int32(0); idx < int32(len(tmp_cfg.Items)); idx++ {
		tmp_val = &tmp_cfg.Items[idx]
		tmp_val.Arena2Reward[1] = tmp_val.Arena_reward_1
		tmp_val.Arena2Reward[2] = tmp_val.Arena_reward_2
		tmp_val.Arena2Reward[3] = tmp_val.Arena_reward_3
		tmp_val.Arena2Reward[4] = tmp_val.Arena_reward_4
		tmp_val.Arena2Reward[5] = tmp_val.Arena_reward_5
		tmp_val.Arena2Reward[6] = tmp_val.Arena_reward_6
		tmp_val.Arena2Reward[7] = tmp_val.Arena_reward_7
		tmp_val.Arena2Reward[8] = tmp_val.Arena_reward_8
		tmp_val.Arena2Reward[9] = tmp_val.Arena_reward_9
		if PLAYER_CAMP_1 == tmp_val.Camp {
			camp1rewards.Array = append(camp1rewards.Array, tmp_val)
			if 0 == camp1rewards.Min_Score || camp1rewards.Min_Score > tmp_val.IntegralMin {
				camp1rewards.Min_Score = tmp_val.IntegralMin
			}
		} else {
			camp2rewards.Array = append(camp2rewards.Array, tmp_val)
			if 0 == camp2rewards.Min_Score || camp2rewards.Min_Score > tmp_val.IntegralMin {
				camp2rewards.Min_Score = tmp_val.IntegralMin
			}
		}
	}

	this.camp2singlereward[PLAYER_CAMP_1] = camp1rewards
	this.camp2singlereward[PLAYER_CAMP_2] = camp2rewards
	return true
}

func (this *CampFightManager) OnNotifyCampState(notify *msg_server_message.NotifyCampFightState) {
	if !this.binit {
		log.Trace("CampFightManager OnNotifyCampState not init !")
		return
	}

	this.state = notify.GetState()
	this.cur_fight_area = notify.GetCurFightArena()
	this.cur_act_iso_week = notify.GetCurYearWeek()
	this.cur_reward_iso_week = notify.GetCurRewardISOWeek()
	this.next_time_point = int32(time.Now().Unix()) + notify.GetLeftSec()

	if !this.b_state_init {
		if CAMP_FIGHT_STATE_OPEN == this.state || CAMP_FIGHT_STATE_REST == this.state {
			this.DoInitLoadEnterPlayers()
		}

		if CAMP_FIGHT_STATE_REWARD == this.state && 0 < this.cur_fight_area {
			this.DoInitChkRewardPlayers()
		}
	} else {
		if CAMP_FIGHT_STATE_REWARD == this.state && 0 < this.cur_fight_area {
			this.DoInitChkRewardPlayers()
		} else {
			log.Info("阵营战不满足发奖条件 %d %d", this.state, this.cur_fight_area)
		}
	}

	this.b_state_init = true

	return
}

// 这个函数一定是在启动的时候执行的，没有加锁
func (this *CampFightManager) DoInitLoadEnterPlayers() {
	for _, tmp_p := range player_mgr.id2players {
		if nil == tmp_p {
			continue
		}

		if tmp_p.db.CampFightInfo.GetEnterISOWeek() != this.cur_act_iso_week {
			continue
		}

		log.Info("启动添加在活动中的玩家%d %s", tmp_p.Id, tmp_p.db.GetName())
		this.in_act_players[tmp_p.Id] = tmp_p
	}

	this.b_state_init = true
	return
}

// 这个函数一定是在启动的时候执行的，没有加锁
func (this *CampFightManager) DoInitChkRewardPlayers() {

	log.Info("阵营战给玩家发奖 ！")
	area_cfg := camp_fight_mgr.area2cfg[this.cur_fight_area]
	if nil == area_cfg {
		log.Error("CampFightManager DoInitChkRewardPlayers failed to get area_cfg[%d]", this.cur_fight_area)
		return
	}

	var single_camp *CampSingleRewards
	var tmp_score, mail_id, tmp_camp int32
	for _, tmp_p := range player_mgr.id2players {
		if nil == tmp_p {
			continue
		}

		if tmp_p.db.CampFightInfo.GetEnterISOWeek() != this.cur_act_iso_week || tmp_p.db.CampFightInfo.GetLastRewardISOWeek() == this.cur_reward_iso_week {
			log.Info("玩家 %d %s 的进入活动周不是当前活动周[%d != %d] 或者已经领过奖励[%d == %d]", tmp_p.Id, tmp_p.db.GetName(), tmp_p.db.CampFightInfo.GetEnterISOWeek(), this.cur_act_iso_week)
			continue
		}

		tmp_camp = tmp_p.db.Info.GetCamp()

		if PLAYER_CAMP_1 == tmp_camp {
			tmp_p.SendMailByMailId(area_cfg.XReward, "AreaReward", "CampFight")
		} else {
			tmp_p.SendMailByMailId(area_cfg.TReward, "AreaReward", "CampFight")
		}

		single_camp = this.camp2singlereward[tmp_camp]
		log.Info("给玩家[%d %s]发奖励%v", tmp_p.Id, tmp_p.db.GetName(), single_camp)
		tmp_score = tmp_p.db.CampFightInfo.GetCurScore()
		if nil != single_camp && tmp_score >= single_camp.Min_Score {
			for _, val := range single_camp.Array {
				if nil == val {
					continue
				}

				if tmp_score >= val.IntegralMin || tmp_score <= val.IntegralMax {
					mail_id = val.Arena2Reward[tmp_p.db.CampFightInfo.GetEnterArenaLvl()]
					if mail_id > 0 {
						tmp_p.SendMailByMailId(mail_id, "singlereward", "CampFight")
						log.Info("给玩家[%d %s]发邮件奖励%v", tmp_p.Id, tmp_p.db.GetName(), mail_id)
					}
					break
				}
			}
		}
	}

	this.b_state_init = true
	return
}

func (this *CampFightManager) WaitStateInitOk() bool {

	//this.ReqCampFightState(center_conn.client_node.GetClient())

	for !this.b_state_init && !signal_mgr.IfClosing() {
		time.Sleep(time.Millisecond * 300)
	}

	this.RegMsgHandler()
	return true
}

func (this *CampFightManager) OnCampFightWin(p *Player, add_score int32) {
	this.AddToInActPlayer(p)
}

func (this *CampFightManager) OnCampFightLose(p *Player, lost_score int32) {
	this.AddToInActPlayer(p)
}

func (this *CampFightManager) AddToInActPlayer(p *Player) {
	this.in_act_players_lock.Lock()
	defer this.in_act_players_lock.Unlock()
	this.in_act_players[p.Id] = p
	return
}

func (this *CampFightManager) ResetInActPlayer() {
	this.in_act_players_lock.Lock()
	defer this.in_act_players_lock.Unlock()

	this.in_act_players = make(map[int32]*Player)
	return
}

func (this *CampFightManager) GetAllInActPlayers() []*Player {
	this.in_act_players_lock.RLock()
	defer this.in_act_players_lock.RUnlock()
	ret_ps := make([]*Player, 0, len(this.in_act_players))
	for _, tmp_p := range this.in_act_players {
		if nil == tmp_p {
			continue
		}

		ret_ps = append(ret_ps, tmp_p)
	}

	return ret_ps
}

func (this *CampFightManager) CkPlayerEnterCamp(p *Player) bool {
	if !this.binit || nil == p {
		return false
	}

	if CAMP_FIGHT_STATE_OPEN != this.state {
		return false
	}

	if p.db.CampFightInfo.GetEnterISOWeek() != this.cur_act_iso_week {
		p.db.CampFightInfo.SetNewEnterInfo(this.cur_act_iso_week, p.db.Info.GetArenaLvl())
	}

	return true
}

func (this *CampFightManager) CheckGiveReward() {
	area_cfg := camp_fight_mgr.area2cfg[this.cur_fight_area]
	if nil == area_cfg {
		log.Error("CampFightManager CheckGiveReward failed to get area_cfg [%d]", this.cur_fight_area)
		return
	}

	var single_camp *CampSingleRewards
	var tmp_score, mail_id, tmp_camp int32

	in_act_ps := this.GetAllInActPlayers()
	for _, tmp_p := range in_act_ps {
		if tmp_p.db.CampFightInfo.GetEnterISOWeek() != this.cur_act_iso_week || tmp_p.db.CampFightInfo.GetLastRewardISOWeek() == this.cur_reward_iso_week {
			continue
		}

		tmp_camp = tmp_p.db.Info.GetCamp()

		if PLAYER_CAMP_1 == tmp_camp {
			tmp_p.SendMailByMailId(area_cfg.XReward, "AreaReward", "CampFight")
		} else {
			tmp_p.SendMailByMailId(area_cfg.TReward, "AreaReward", "CampFight")
		}

		single_camp = this.camp2singlereward[tmp_camp]
		tmp_score = tmp_p.db.CampFightInfo.GetCurScore()
		if nil != single_camp && tmp_score >= single_camp.Camp {
			for _, val := range single_camp.Array {
				if nil == val {
					continue
				}

				if tmp_score >= val.IntegralMin || tmp_score <= val.IntegralMax {
					mail_id = val.Arena2Reward[tmp_p.db.CampFightInfo.GetEnterArenaLvl()]
					if mail_id > 0 {
						tmp_p.SendMailByMailId(mail_id, "singlereward", "CampFight")
					}
					break
				}
			}
		}
	}
}

// 消息相关 =====================================================================
func (this *CampFightManager) ReqCampFightState(c *server_conn.ServerConn) {
	msg := &msg_server_message.GetCampFightState{}
	c.Send(msg, true)
}

func (this *CampFightManager) RegMsgHandler() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetCampFightState, this.C2SGetCampFightStateHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetCampFightRank, this.C2SGetCampFightRankHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetCampFightRecord, this.C2SGetCampFightRecordHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetCampCurScore, this.C2SGetCampCurScoreHandler)

	center_conn.SetMessageHandler(msg_server_message.ID_RetCampFightRank, this.C2HRetCampFightRankHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_RetCampFightRecord, this.C2HRetCampFightRecordHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_CampFightScoreUpdate, this.CampFightScoreUpdateHandler)
}

func (this *CampFightManager) C2SGetCampFightStateHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetCampFightState)
	if nil == c || nil == req {
		log.Error("CampFightManager C2SGetCampFightStateHandler c or req nil[%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("CampFightManager C2SGetCampFightStateHandler not login[%d]", c.T)
		return
	}

	res2cli := &msg_client_message.S2CRetCampFightState{}
	res2cli.State = proto.Int32(this.state)
	res2cli.CurFighIdx = proto.Int32(this.cur_fight_idx)
	res2cli.AreanIdx = proto.Int32(this.cur_fight_area)
	res2cli.LeftSec = proto.Int32(this.next_time_point - int32(time.Now().Unix()))
	res2cli.MyScore = proto.Int32(p.db.CampFightInfo.GetCurScore())
	res2cli.XScore = proto.Int32(this.cur_x_score)
	res2cli.TScore = proto.Int32(this.cur_t_score)

	p.Send(res2cli)

	return
}

func (this *CampFightManager) C2SGetCampFightRankHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetCampFightRank)
	if nil == c || nil == req {
		log.Error("CampFightManager C2SGetCampFightRankHandler c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("CampFightManager C2SGetCampFightRankHandler not login ")
		return
	}

	req2co := &msg_server_message.GetCampFightRank{}
	req2co.RankType = proto.Int32(req.GetRankType())
	req2co.PlayerId = proto.Int32(p.Id)

	center_conn.Send(req2co)
}

func (this *CampFightManager) C2SGetCampFightRecordHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetCampFightRecord)
	if nil == c || nil == req {
		log.Error("CampFightManager C2SGetCampFightRecordHandler c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("CampFightManager C2SGetCampFightRecordHandler not login ")
		return
	}

	req2co := &msg_server_message.GetCampFightRecord{}
	req2co.PlayerId = proto.Int32(p.Id)

	center_conn.Send(req2co)
}

func (this *CampFightManager) C2SGetCampCurScoreHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetCampCurScore)
	if nil == c || nil == req {
		log.Error("CampFightManager C2SGetCampCurScoreHandler c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("CampFightManager C2SGetCampCurScoreHandler not login ")
		return
	}

	res2cli := &msg_client_message.S2CRetCampCurScore{}
	res2cli.CurXScore = proto.Int32(this.cur_x_score)
	res2cli.CurTScore = proto.Int32(this.cur_t_score)

	p.Send(res2cli)
	return
}

// --------------------------------------------

func (this *CampFightManager) C2HRetCampFightRankHandler(center_conn *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RetCampFightRank)
	if nil == center_conn || nil == res {
		log.Error("CampFightManager C2HRetCampFightRankHandler conn or res nil [%v]", nil == res)
		return
	}

	pid := res.GetPlayerId()
	p := player_mgr.GetPlayerById(pid)
	if nil == p {
		log.Error("CampFightManager C2HRetCampFightRankHandler failed to find player[%d] ?", pid)
		return
	}

	if 0 == p.IfOnline() {
		log.Info("CampFightManager C2HRetCampFightRankHandler no online")
		return
	}

	res2cli := &msg_client_message.S2CRetCampFightRank{}
	res2cli.RankType = proto.Int32(res.GetRankType())

	rds := res.GetRecoreds()
	tmp_len := int32(len(rds))
	if tmp_len < 1 {
		log.Info("CampFightManager C2HRetCampFightRankHandler")
		return
	}
	res2cli.RankItems = make([]*msg_client_message.SmallRankRecord, 0, tmp_len)
	var tmp_item *msg_server_message.SmallRankItem
	var tmp_rd *msg_client_message.SmallRankRecord
	for idx := int32(0); idx < tmp_len; idx++ {
		tmp_item = rds[idx]
		if nil == tmp_item {
			continue
		}

		tmp_rd = &msg_client_message.SmallRankRecord{}
		tmp_rd.Id = proto.Int32(tmp_item.GetId())
		tmp_rd.Name = proto.String(tmp_item.GetName())
		tmp_rd.Score = proto.Int32(tmp_item.GetScore())
		tmp_rd.TongIcon = proto.Int32(tmp_item.GetTongIcon())
		tmp_rd.TongName = proto.String(tmp_item.GetTongName())
		res2cli.RankItems = append(res2cli.RankItems, tmp_rd)
	}

	p.Send(res2cli)
}

func (this *CampFightManager) C2HRetCampFightRecordHandler(center_conn *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RetCampFightRecord)
	if nil == center_conn || nil == res {
		log.Error("CampFightManager C2HRetCampFightRecordHandler center_conn or res nil [%v]", nil == res)
		return
	}

	p := player_mgr.GetPlayerById(res.GetPlayerId())
	if nil == p {
		log.Error("CampFightManager C2HRetCampFightRecordHandler ")
		return
	}

	var msg_rd *msg_server_message.CampFightRecord
	var tmp_rd *msg_client_message.CampFightRecord
	rds := res.GetRecords()
	tmp_len := int32(len(rds))
	res2cli := &msg_client_message.S2CRetCampFightRecord{}
	res2cli.Records = make([]*msg_client_message.CampFightRecord, 0, tmp_len)
	for idx := int32(0); idx < tmp_len; idx++ {
		msg_rd = rds[idx]
		if nil == msg_rd {
			continue
		}

		tmp_rd = &msg_client_message.CampFightRecord{}
		tmp_rd.FightIdx = proto.Int32(msg_rd.GetFightIdx())
		tmp_rd.XScore = proto.Int32(msg_rd.GetXScore())
		tmp_rd.TScore = proto.Int32(msg_rd.GetTScore())

		res2cli.Records = append(res2cli.Records, tmp_rd)
	}

	if len(res2cli.Records) > 0 {
		p.Send(res2cli)
	}

	return
}

func (this *CampFightManager) CampFightScoreUpdateHandler(center_conn *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.CampFightScoreUpdate)
	if nil == res {
		log.Error("CampFightManager CampFightScoreUpdateHandler res nil !")
		return
	}

	this.cur_x_score = res.GetXCampScore()
	this.cur_t_score = res.GetTCampScore()

	return
}
