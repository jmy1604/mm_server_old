package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
)

const (
	CARD_TYPE_ARMY     = 1 // 军队
	CARD_TYPE_BUILDING = 2 // 建筑
	CARD_TYPE_MAGIC    = 3 // 法术

	CARD_TRAIT_COMMON = 1 // 白卡
	CARD_TRAIT_RARE   = 2 // 稀有卡
	CARD_TRAIT_EPIC   = 3 // 史诗卡
	CARD_TRAIT_LEGEND = 4 // 传奇卡
)

type XmlPlayerCard struct {
	ConfigId     int32   `xml:"ID,attr"`
	Type         int32   `xml:"Type,attr"`
	Placesize    float32 `xml:"Placesize,attr"`
	NpcCount     int32   `xml:"NpcCount,attr"`
	LoadTime     int32   `xml:"LoadTime,attr"`
	LoadNSec     int64
	SkillId1     int32 `xml:"SkillId1,attr"`
	SkillId2     int32 `xml:"SkillId2,attr"`
	SkillId3     int32 `xml:"SkillId3,attr"`
	SkillId4     int32 `xml:"SkillId4,attr"`
	LoadCost     int32 `xml:"PlaceCost,attr"`
	Trait        int32 `xml:"Trait,attr"`
	IsMirror     bool
	MirrorParams []int32
}

type XmlPlayerCards struct {
	Cards []XmlPlayerCard `xml:"item"`
}

var cfg_player_cards CfgPlayerCards

type CfgPlayerCards struct {
	Array []*XmlPlayerCard         // 数组结构
	Map   map[int32]*XmlPlayerCard // 映射结构
}

func (this *CfgPlayerCards) Load() bool {

	content, err := ioutil.ReadFile("../game_data/cardDataConfig.xml")

	if nil != err {
		log.Error("CfgPlayerCards load failed err(%s)", err.Error())
		return false
	}

	var xml_cards XmlPlayerCards
	err = xml.Unmarshal(content, &xml_cards)
	if nil != err {
		log.Error("CfgPlayerCards load Unmarshal failed err(%s)", err.Error())
		return false
	}

	this.Array = make([]*XmlPlayerCard, len(xml_cards.Cards))
	this.Map = make(map[int32]*XmlPlayerCard)

	for idx := int32(0); idx < int32(len(xml_cards.Cards)); idx++ {
		val := &xml_cards.Cards[idx]

		if val.Trait < 1 || val.Trait > 4 {
			log.Error("CfgPlayerCards load Trait[%d] error !", val.Trait)
			return false
		}

		this.Array = append(this.Array, val)
		this.Map[val.ConfigId] = val

		//log.Info("CfgPlayerCards load cfg(%d) %v", val.ConfigId, *val)
	}

	return true
}
