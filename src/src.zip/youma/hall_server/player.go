package main

import (
	"fmt"
	"libs/log"
	"libs/socket"
	"libs/timer"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

type Player struct {
	Id            int32
	Account       string
	Token         string
	ol_array_idx  int32
	all_array_idx int32

	db *dbPlayerRow

	conn      *socket.TcpConn
	conn_lock *sync.RWMutex

	pos int32

	p_cache *PlayerCache
}

type PlayerCache struct {
	last_donate_chk_unix int32 // 上一次帮会捐献超时检查时间
	last_tong_act_unix   int32 // 上一次帮会操作的时间 加入 退出，创建
}

func (this *PlayerCache) Init() {

}

func new_player(id int32, account, token string, conn *socket.TcpConn,
	db *dbPlayerRow) *Player {
	if nil == conn || id <= 0 || nil == db {
		log.Error("new_player param error !", id, account, nil == db)
		return nil
	}

	ret_p := &Player{}
	ret_p.Id = id
	ret_p.Account = account
	ret_p.Token = token
	ret_p.db = db
	ret_p.ol_array_idx = -1
	ret_p.all_array_idx = -1

	ret_p.p_cache = &PlayerCache{}
	ret_p.p_cache.Init()

	ret_p.conn = conn
	ret_p.conn_lock = &sync.RWMutex{}
	conn.T = int64(id)

	return ret_p
}

func new_player_with_db(id int32, db *dbPlayerRow) *Player {
	if id <= 0 || nil == db {
		log.Error("new_player_with_db param error !", id, nil == db)
		return nil
	}

	ret_p := &Player{}
	ret_p.Id = id
	ret_p.db = db
	ret_p.ol_array_idx = -1
	ret_p.all_array_idx = -1

	ret_p.p_cache = &PlayerCache{}
	ret_p.p_cache.Init()

	ret_p.conn_lock = &sync.RWMutex{}

	return ret_p
}

func (this *Player) CheckRelogin() {
	this.conn_lock.Lock()
	defer this.conn_lock.Unlock()

	if nil != this.conn {
		this.conn.Send(&msg_client_message.S2COtherPlaceLogin{})
		this.conn.Close(socket.E_DISCONNECT_REASON_OTHER_PLACE_LOGIN)
		this.conn = nil
	}
}

func (this *Player) IfOnline() int32 {
	this.conn_lock.RLock()
	defer this.conn_lock.RUnlock()
	if nil != this.conn {
		return 1
	}

	return 0
}

func (this *Player) SetConn(conn *socket.TcpConn, bclose bool) {
	this.conn_lock.Lock()
	defer this.conn_lock.Unlock()
	if nil != this.conn {
		if nil != conn {
			this.conn.Send(&msg_client_message.S2COtherPlaceLogin{})
		}

		if bclose {
			this.conn.T = 0
			this.conn.Close(socket.E_DISCONNECT_REASON_OTHER_PLACE_LOGIN)
		}
	}

	this.conn = conn
	if nil != conn {
		conn.T = int64(this.Id)
	}
}

func (this *Player) Send(msg proto.Message) {
	this.conn_lock.Lock()
	defer this.conn_lock.Unlock()
	if nil == this.conn {
		log.Error("Player[%d] Send conn nil", this.Id)
		return
	}

	this.conn.Send(msg)
}

func (this *Player) SendError(err_code msg_client_message.E_ERR) {
	res2cli := &msg_client_message.S2CErrCode{}
	res2cli.ErrorCode = proto.Int32(int32(err_code))

	this.conn_lock.Lock()
	defer this.conn_lock.Unlock()
	if nil == this.conn {
		log.Error("Player SendError conn nil")
		return
	}

	this.conn.Send(res2cli)
}

func (this *Player) CheckLogin() {

}

func (this *Player) OnCreate() {
	// 随机初始名称
	tmp_acc := this.Account
	if len(tmp_acc) > 6 {
		tmp_acc = string([]byte(tmp_acc)[0:6])
	}

	this.db.SetName(fmt.Sprintf("CR_%s_%d", tmp_acc, this.Id))
	this.db.Info.SetArenaLvl(1)
	this.db.Info.SetCamp(PLAYER_CAMP_1)
	this.db.Info.SetLvl(1)
	this.db.Info.SetCreateUnix(int32(time.Now().Unix()))

	// 给予初始金币
	this.db.Info.SetCoin(global_config.InitCoin)
	this.db.Info.SetDiamond(global_config.InitDiamond)
	this.db.Info.SetCardToken1(20000)
	this.db.Info.SetCardToken2(20000)
	this.db.Info.SetCardToken3(20000)
	this.db.Info.SetCardToken4(20000)
}

func (this *Player) OnLogin() {
	res_2cli := &msg_client_message.S2CLoginResponse{}
	res_2cli.PlayerId = proto.Int64(int64(this.Id))
	res_2cli.Name = proto.String(this.db.GetName())
	res_2cli.ServerUnix = proto.Int32(int32(time.Now().Unix()))

	// 基本信息
	tmp_bi := &msg_client_message.PlayerBaseInfo{}
	this.db.Info.FillBaseInfo(tmp_bi)
	tmp_bi.DayMatchRewardNum = proto.Int32(this.GetDayMatchRewardNum())

	tmp_bi.CurTongId = proto.Int32(this.db.TongInfo.GetTongId())
	if this.db.Info.GetArenaLvl() == cfg_arena.LegLvl {
		tmp_bi.CurLegScore = proto.Int32(this.db.Info.GetMatchScore())
	}
	res_2cli.BaseInfo = tmp_bi

	// 卡片信息
	res_2cli.Cards = this.db.Cards.GetAllClientCardMsg()

	//卡组信息
	res_2cli.CardTeams = this.db.CardTeams.GetAllClientTeamMsg()

	this.Send(res_2cli)

	player_match_mgr.check_send_cur_room_info(this)
	this.SyncCardShopInfo()
	this.SyncChestInfo()
	//this.DoPlayerTongLogin()
	this.SyncPlayerDialyTask()
	this.SyncPlayerAchieve()
	notice_mgr.OnPlayerLogin(this)
	payback_mgr.OnPlayerLogin(this)
	player_score_mgr.OnPlayerLogin(this)
	this.SyncCardCompound()
	this.SyncPlayerSignInfo()
	this.SyncPlayerFirstPayState()

	res2co := &msg_server_message.SetPlayerOnOffline{}
	res2co.PlayerId = proto.Int32(this.Id)
	res2co.OnOffLine = proto.Int32(1)
	res2co.TongId = proto.Int32(this.db.TongInfo.GetTongId())
	center_conn.Send(res2co)
}

func (this *Player) OnLogout() {
	this.SetConn(nil, false)
	//this.DoPlayerTongLogout()

	res2co := &msg_server_message.SetPlayerOnOffline{}
	res2co.PlayerId = proto.Int32(this.Id)
	res2co.OnOffLine = proto.Int32(1)
	res2co.TongId = proto.Int32(this.db.TongInfo.GetTongId())
	center_conn.Send(res2co)

	log.Info("玩家[%d] 登出 ！！", this.Id)
}

// 各个属性设置函数

// 玩家经验
func (this *Player) AddExp(add_val int32, reason, mod string) (int32, int32) {
	if add_val < 0 {
		log.Error("Player AddExp add_val[%d] < 0 ", add_val)
		return this.db.Info.GetLvl(), this.db.Info.GetExp()
	}

	old_exp := this.db.Info.GetExp()
	cur_exp := old_exp + add_val
	cur_lvl := this.db.Info.GetLvl()
	if cur_lvl+1 <= cfg_exp.MaxLevel {
		blvl_chg := false
		for i := cur_lvl; i < cfg_exp.MaxLevel; i++ {
			next_exp := cfg_exp.Map[i+1]
			if cur_exp > next_exp {
				cur_lvl = i + 1
				cur_exp = cur_exp - next_exp
				blvl_chg = true
			} else {
				break
			}
		}

		if blvl_chg {
			log.Info("玩家[%d] 升级了[%d]", this.Id, cur_lvl)
			this.db.Info.SetLvl(cur_lvl)
			this.db.Info.SetExp(cur_exp)
			res_2cli := &msg_client_message.S2CPlayerLvlUp{}
			res_2cli.Lvl = proto.Int32(cur_lvl)
			res_2cli.Exp = proto.Int32(cur_exp)
			this.Send(res_2cli)
		}
	} else {
		if cur_exp > cfg_exp.MaxLevelExp {
			cur_exp = cfg_exp.MaxLevelExp
		}
		if old_exp != cur_exp {
			res_2cli := &msg_client_message.S2CPlayerExpUp{}
			res_2cli.Exp = proto.Int32(cur_exp)
			this.Send(res_2cli)
		}
	}

	return cur_lvl, cur_exp
}

// 玩家积分 ====================================
func (this *Player) GetMatchScore() int32 {
	return this.db.Info.GetMatchScore()
}

func (this *Player) SubMatchScore(sub_val int32, reason, mod string) int32 {
	return this.db.Info.SubMatchScore(sub_val)
}

func (this *Player) AddMatchScore(add_val int32, reason, mod string) int32 {
	if add_val < 0 {
		log.Error("Player AddPlayerScore add_val(%d) < 0", add_val)
		return 0
	}

	return this.db.Info.IncbyMatchScore(add_val)
}

// 玩家金币 ====================================

func (this *Player) GetCoin() int32 {
	return this.db.Info.GetCoin()
}

func (this *Player) AddCoin(val int32, reason, mod string) int32 {
	if val < 0 {
		log.Error("Player AddCoin %d", val)
		return this.db.Info.GetCoin()
	}

	return this.db.Info.IncbyCoin(val)
}

func (this *Player) SubCoin(val int32, reason, mod string) int32 {
	if val < 0 {
		log.Error("Player SubCoin %d", val)
		return this.db.Info.GetCoin()
	}

	cur_coin := this.db.Info.SubCoin(val)

	this.TaskAchieveOnConditionAdd(TASK_ACHIEVE_FINISH_COIN_COST, val)

	return cur_coin
}

// 玩家钻石 ====================================

func (this *Player) GetDiamond() int32 {
	return this.db.Info.GetDiamond()
}

func (this *Player) SubDiamond(sub_val int32, reason, mod string) int32 {
	if sub_val < 0 {
		log.Error("Player SubDiamond sub_val[%d] < 0, reason[%s] mod[%s]", sub_val, reason, mod)
		return this.db.Info.GetDiamond()
	}

	cur_diamond := this.db.Info.SubDiamond(sub_val)

	this.TaskAchieveOnConditionAdd(TASK_ACHIEVE_FINISH_DIAMOND_COST, sub_val)
	return cur_diamond
}

func (this *Player) AddDiamond(add_val int32, reason, mod string) int32 {
	if add_val < 0 {
		log.Error("Player AddDiamod add_val[%d] < 0, reason[%s] mod[%s]", add_val, reason, mod)
		return this.db.Info.GetDiamond()
	}

	return this.db.Info.IncbyDiamond(add_val)
}

// 玩家卡片资源 ==========================================

func (this *Player) SubCardToken1(sub_val int32, reason, mod string) int32 {
	if sub_val < 0 {
		log.Error("Player SubCardToken1 sub_val[%d] < 0, reason[%s] mod[%s]", sub_val, reason, mod)
		return this.db.Info.GetCardToken1()
	}

	cur_cardtoken := this.db.Info.GetCardToken1()
	new_cardtoken := cur_cardtoken - sub_val
	if new_cardtoken < 0 {
		new_cardtoken = 0
	}

	this.db.Info.SetCardToken1(new_cardtoken)
	return new_cardtoken
}

func (this *Player) AddCardToken1(add_val int32, reason, mod string) int32 {
	if add_val < 0 {
		log.Error("Player AddCardToken1 add_val[%d] < 0, reason[%s] mod[%s]", add_val, reason, mod)
		return this.db.Info.GetCardToken1()
	}

	return this.db.Info.IncbyCardToken1(add_val)
}

func (this *Player) SubCardToken2(sub_val int32, reason, mod string) int32 {
	if sub_val < 0 {
		log.Error("Player SubCardToken2 sub_val[%d] < 0, reason[%s] mod[%s]", sub_val, reason, mod)
		return this.db.Info.GetCardToken2()
	}

	cur_cardtoken := this.db.Info.GetCardToken2()
	new_cardtoken := cur_cardtoken - sub_val
	if new_cardtoken < 0 {
		new_cardtoken = 0
	}

	this.db.Info.SetCardToken2(new_cardtoken)
	return new_cardtoken
}

func (this *Player) AddCardToken2(add_val int32, reason, mod string) int32 {
	if add_val < 0 {
		log.Error("Player AddCardToken2 add_val[%d] < 0, reason[%s] mod[%s]", add_val, reason, mod)
		return this.db.Info.GetCardToken2()
	}

	return this.db.Info.IncbyCardToken2(add_val)
}

func (this *Player) SubCardToken3(sub_val int32, reason, mod string) int32 {
	if sub_val < 0 {
		log.Error("Player SubCardToken3 sub_val[%d] < 0, reason[%s] mod[%s]", sub_val, reason, mod)
		return this.db.Info.GetCardToken3()
	}

	cur_cardtoken := this.db.Info.GetCardToken3()
	new_cardtoken := cur_cardtoken - sub_val
	if new_cardtoken < 0 {
		new_cardtoken = 0
	}

	this.db.Info.SetCardToken3(new_cardtoken)
	return new_cardtoken
}

func (this *Player) AddCardToken3(add_val int32, reason, mod string) int32 {
	if add_val < 0 {
		log.Error("Player AddCardToken3 add_val[%d] < 0, reason[%s] mod[%s]", add_val, reason, mod)
		return this.db.Info.GetCardToken3()
	}

	return this.db.Info.IncbyCardToken3(add_val)
}

func (this *Player) SubCardToken4(sub_val int32, reason, mod string) int32 {
	if sub_val < 0 {
		log.Error("Player SubCardToken4 sub_val[%d] < 0, reason[%s] mod[%s]", sub_val, reason, mod)
		return this.db.Info.GetCardToken4()
	}

	cur_cardtoken := this.db.Info.GetCardToken4()
	new_cardtoken := cur_cardtoken - sub_val
	if new_cardtoken < 0 {
		new_cardtoken = 0
	}

	this.db.Info.SetCardToken4(new_cardtoken)
	return new_cardtoken
}

func (this *Player) AddCardToken4(add_val int32, reason, mod string) int32 {
	if add_val < 0 {
		log.Error("Player AddCardToken4 add_val[%d] < 0, reason[%s] mod[%s]", add_val, reason, mod)
		return this.db.Info.GetCardToken4()
	}

	return this.db.Info.IncbyCardToken4(add_val)
}

// 玩家今天领取奖励次数 ===========================================================

func (this *Player) GetDayMatchRewardNum() int32 {

	last_up_day := timer.GetDayFrom1970WithCfgAndSec(0, this.db.Info.GetLayMatchRewardTime())
	cur_day := timer.GetDayFrom1970WithCfg(0)
	if last_up_day != cur_day {
		this.db.Info.SetDayMatchRewardNum(0)
		this.db.Info.SetLayMatchRewardTime(int32(time.Now().Unix()))
		return 0
	}

	return this.db.Info.GetDayMatchRewardNum()
}

func (this *Player) AddDayMatchRewardNum(add_val int32) int32 {
	if add_val <= 0 {
		log.Error("Player AddDayMatchRewardNum add_val(%d) error !", add_val)
		return 0
	}

	last_up_day := timer.GetDayFrom1970WithCfgAndSec(0, this.db.Info.GetLayMatchRewardTime())
	cur_day := timer.GetDayFrom1970WithCfg(0)
	if last_up_day != cur_day {
		this.db.Info.SetDayMatchRewardNum(add_val)
		this.db.Info.SetLayMatchRewardTime(int32(time.Now().Unix()))
		return add_val
	}

	return this.db.Info.IncbyDayMatchRewardNum(add_val)
}

// ======================================================================

func reg_player_option_msg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SSaveOptions, C2SSaveOptionsHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetOptions, C2SGetOptionsHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SChgName, C2SChgNameHandler)
}

func C2SSaveOptionsHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SSaveOptions)
	if nil == c || nil == req {
		log.Error("C2SSaveOptionsHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SSaveOptionsHandler not login [%d]", c.T)
		return
	}

	if len(req.GetValues()) > 32 {
		log.Error("C2SSaveOptionsHandler C2SSaveOptionsHandler too long !")
		return
	}

	p.db.Options.SetValues(req.GetValues())

	return
}

func C2SGetOptionsHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetOptions)
	if nil == c || nil == req {
		log.Error("C2SGetOptionsHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SGetOptionsHandler not login [%d]", c.T)
		return
	}

	res2cli := &msg_client_message.S2CRetOptions{}
	res2cli.Values = p.db.Options.GetValues()
	p.Send(res2cli)

	return
}

func C2SChgNameHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SChgName)
	if nil == c || nil == req {
		log.Error("C2SChgNameHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SChgNameHandler not login [%d]", c.T)
		return
	}

	new_name := req.GetName()
	if int32(len(new_name)) > global_config.MaxNameLen {
		log.Error("C2SChgNameHandler name len[%d] error !", len(req.GetName()))
		return
	}

	cur_chg_count := p.db.Info.GetChangeNameCount()
	if cur_chg_count >= global_config.ChgNameCostLen {
		cur_chg_count = global_config.ChgNameCostLen - 1
	}
	cost_diamond := global_config.ChgNameCost[cur_chg_count]
	if p.GetDiamond() < cost_diamond {
		log.Error("C2SChgNameHandler not enough cost[%d<%d]", p.GetDiamond(), cost_diamond)
		return
	}
	cur_chg_count = p.db.Info.IncbyChangeNameCount(1)

	p.db.SetName(new_name)

	res2cli := &msg_client_message.S2CChgName{}
	res2cli.Name = proto.String(new_name)
	res2cli.ChgNameCount = proto.Int32(cur_chg_count)
	p.Send(res2cli)

	return
}
