package main

import (
	"libs/log"
	"libs/socket"
	"public_message/gen_go/client_message"

	"3p/code.google.com.protobuf/proto"
)

func reg_player_camp_msg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SSetCamp, C2SSetCampHandler)
}

func C2SSetCampHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SSetCamp)
	if nil == c || nil == req {
		log.Error("C2SSetCampHandler c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SSetCampHandler not login [%d]", c.T)
		return
	}

	if 0 != p.db.Info.GetIfHaveChooseCamp() {
		log.Error("C2SSetCampHandler you have already choose camp !")
		return
	}

	tmp_camp := req.GetCamp()
	if PLAYER_CAMP_1 != tmp_camp && PLAYER_CAMP_2 != tmp_camp {
		log.Error("C2SSetCampHandler new_camp[%d] error !", tmp_camp)
		return
	}
	p.db.Info.SetIfHaveChooseCamp(1)
	p.db.Info.SetCamp(tmp_camp)

	res2cli := &msg_client_message.S2CCurCamp{}
	res2cli.Camp = proto.Int32(tmp_camp)

	// 给予初始卡片
	if PLAYER_CAMP_1 == tmp_camp {
		for _, cfg_id := range global_config.PlayerInitCards1 {
			if nil != cfg_player_cards.Map[cfg_id] {
				p.AddCard(cfg_id, 100, "初始化给予", "玩家初始化", true, true)
			} else {
				log.Error("玩家初始卡片ID[%d]未配置！", cfg_id)
			}
		}
	} else {
		for _, cfg_id := range global_config.PlayerInitCards2 {
			if nil != cfg_player_cards.Map[cfg_id] {
				p.AddCard(cfg_id, 100, "初始化给予", "玩家初始化", true, true)
			} else {
				log.Error("玩家初始卡片ID[%d]未配置！", cfg_id)
			}
		}
	}

	log.Trace("Player[%d] OnCreate give create cards")

	p.Send(res2cli)
	p.OnLogin()
	return
}
