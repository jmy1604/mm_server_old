package main

import (
	"libs/log"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	TONG_MEMBER_MENBER  = 0 // 帮会成员
	TONG_MEMBER_CAPTAIN = 1 // 帮会帮主

	TONG_JOIN_TYPE_EVERYONE = 0 // 任何人都可以加入
	TONG_JOIN_TYPE_NOONE    = 1 // 不允许任何人加入
	TONG_JOIN_TYPE_NEED_CHK = 2 // 需要确认

	TONG_AGREE_AVI_SEC = 5 // 同意占位有效时间
)

type EnterTongAgreeItem struct {
	pid           int32  // 玩家Id
	score         int32  // 玩家积分
	name          string // 玩家名称
	agree_unix    int32  // 同意的时间
	op_playername string // 操作者名称
}

type TongFriendMatch struct {
	pid       int32   // 玩家Id
	name      string  // 玩家名称
	score     int32   // 玩家积分
	card_ids  []int32 // 卡片Id
	card_lvls []int32 // 卡片等级
	hall_id   int32   // 大厅Id
}

type Tong struct {
	db                   *dbTongRow
	tong_id              int32
	tong_score           int32
	pos2enter_lock       *sync.RWMutex
	pos2enter            map[int32]*EnterTongAgreeItem // 预进入帮会的玩家列表
	id2onlinemember_lock *sync.RWMutex
	id2onlinemember      map[int32]bool // 在线成员
	id2friendmatch_lock  *sync.RWMutex
	Id2friendmatch       map[int32]*TongFriendMatch
}

func NewTongWithDbAndEmptyPos(tong_id int32, db *dbTongRow, empty_pos map[int32]*EnterTongAgreeItem) *Tong {
	if nil == db || nil == empty_pos {
		log.Error("NewTongWithDbAndEmptyPos param error [%v] !", nil == db)
		return nil
	}

	if TONG_CHEST_CLOSE == tong_mgr.cur_tong_chest_state {
		db.TongData.SetTongChestScore(0)
		db.TongChestOpens.Clear()
	}

	ret_tong := &Tong{}
	ret_tong.db = db
	ret_tong.tong_id = tong_id
	ret_tong.pos2enter_lock = &sync.RWMutex{}
	ret_tong.pos2enter = empty_pos
	ret_tong.tong_score = db.TongMembers.GetCurTongScore()
	ret_tong.id2onlinemember_lock = &sync.RWMutex{}
	ret_tong.id2onlinemember = make(map[int32]bool)
	ret_tong.id2friendmatch_lock = &sync.RWMutex{}
	ret_tong.Id2friendmatch = make(map[int32]*TongFriendMatch)

	return ret_tong
}

func CreateTong(msg *msg_server_message.CreateTong) *Tong {
	if nil == msg {
		log.Error("CreateTong msg nil")
		return nil
	}

	tong_id := msg.GetTongId()

	if nil != dbc.Tongs.GetRow(tong_id) {
		log.Error("CreateTong tong_id(%d) already exist !", tong_id)
		return nil
	}

	new_tong := dbc.Tongs.AddRow(tong_id)
	if nil == new_tong {
		log.Error("CreateTong failed to add tong row[%d] !", tong_id)
		return nil
	}

	new_tong.TongData.SetInitTongData(msg)

	new_member := &dbTongTongMemberData{}
	new_member.MemberId = 1
	new_member.PlayerId = msg.GetCreatorId()
	new_member.PlayerName = msg.GetCreatorName()
	new_member.Score = int16(msg.GetScore())
	new_member.MemberType = TONG_MEMBER_CAPTAIN

	new_tong.TongMembers.Add(new_member)

	ret_tong := &Tong{}
	ret_tong.db = new_tong
	ret_tong.tong_id = tong_id
	ret_tong.tong_score = msg.GetScore()
	ret_tong.pos2enter = make(map[int32]*EnterTongAgreeItem)
	for idx := int32(2); idx <= global_config.MaxTongMemberCount; idx++ {
		ret_tong.pos2enter[idx] = &EnterTongAgreeItem{}
	}
	ret_tong.pos2enter_lock = &sync.RWMutex{}
	ret_tong.id2onlinemember_lock = &sync.RWMutex{}
	ret_tong.id2onlinemember = make(map[int32]bool)
	ret_tong.id2onlinemember[msg.GetCreatorId()] = true

	ret_tong.id2friendmatch_lock = &sync.RWMutex{}
	ret_tong.Id2friendmatch = make(map[int32]*TongFriendMatch)

	return ret_tong
}

func (this *Tong) SetMemberOnline(pid_id int32) {
	this.id2onlinemember_lock.Lock()
	defer this.id2onlinemember_lock.Unlock()
	this.id2onlinemember[pid_id] = true
}

func (this *Tong) SetMemberOffline(pid_id int32) {
	this.id2onlinemember_lock.Lock()
	defer this.id2onlinemember_lock.Unlock()
	if this.id2onlinemember[pid_id] {
		delete(this.id2onlinemember, pid_id)
	}
}

func (this *Tong) GetOnlinePlayerIds(except_id int32) []int32 {
	this.id2onlinemember_lock.RLock()
	defer this.id2onlinemember_lock.RUnlock()
	ret_ids := make([]int32, 0, len(this.id2onlinemember))
	for pid, val := range this.id2onlinemember {
		if val && pid != except_id {
			ret_ids = append(ret_ids, pid)
		}
	}

	return ret_ids
}

func (this *Tong) TongSetChg(msg *msg_server_message.TongSetChg) {
	this.db.TongData.SetIcon(msg.GetIcon())
	this.db.TongData.SetJoinScore(msg.GetJoinScore())
	this.db.TongData.SetJoinType(msg.GetJoinType())
	this.db.TongData.SetName(msg.GetTongName())
	this.db.TongData.SetPos(msg.GetPos())
}

func (this *Tong) GetRetTongInfoMsg(pid int32, ifown int32) *msg_server_message.RetTongInfo {
	res2co := &msg_server_message.RetTongInfo{}
	res2co.Icon = proto.Int32(this.db.TongData.GetIcon())
	res2co.JoinScore = proto.Int32(this.db.TongData.GetJoinScore())
	res2co.JoinType = proto.Int32(this.db.TongData.GetJoinType())
	res2co.PlayerId = proto.Int32(pid)
	res2co.Pos = proto.Int32(this.db.TongData.GetPos())
	res2co.TongId = proto.Int32(this.tong_id)
	res2co.TongName = proto.String(this.db.TongData.GetName())
	res2co.TongPub = proto.String(this.db.TongData.GetPubContent())
	_, cur_week := time.Now().ISOWeek()
	last_up_week := this.db.TongData.GetLastWeekDonateUpWeek()
	if last_up_week != int32(cur_week) {
		this.db.TongMembers.ClearDonate()
	}

	this.db.TongMembers.FillAllTongMemberMsg(res2co, this.GetOnlinePlayerIds(0))
	if 1 == ifown {
		this.db.TongChatRecords.FillAllChatMsg(res2co)
		this.db.TongCardReqs.FillAllCardReqMsg(res2co)
		this.FillTongFriendMsg(res2co)
		this.db.TongJoins.FillAllTongEnterReqMsg(res2co)

		log.Info("自己帮会，填充必须要信息")
	}

	return res2co
}

func (this *Tong) AddEmptyPos(pos int32) {
	if pos <= 0 || pos > global_config.MaxTongMemberCount {
		log.Error("Tong AddEmptyPos Pos[%d] error !", pos)
		return
	}

	this.pos2enter_lock.Lock()
	defer this.pos2enter_lock.Unlock()

	this.pos2enter[pos] = &EnterTongAgreeItem{}
}

func (this *Tong) GetUseAviTongMemberId() int32 {
	cur_unix := int32(time.Now().Unix())

	this.pos2enter_lock.Lock()
	defer this.pos2enter_lock.Unlock()

	over_poss := make(map[int32]int32)
	for pos, val := range this.pos2enter {
		if nil != val && val.pid > 0 && cur_unix-val.agree_unix > TONG_AGREE_AVI_SEC {
			over_poss[pos] = 1
		}
	}

	for pos, _ := range over_poss {
		delete(this.pos2enter, pos)
	}

	for pos, val := range this.pos2enter {
		if nil != val && val.pid <= 0 {
			delete(this.pos2enter, pos)
			return int32(pos)
		}
	}

	return -1
}

func (this *Tong) UseAviTongMemberId(in_pid, score int32, name, op_playername string) int32 {
	if in_pid <= 0 {
		log.Error("Tong UseAviTongMemberId in_pid(%d<=0)", in_pid)
		return -1
	}

	cur_unix := int32(time.Now().Unix())

	this.pos2enter_lock.Lock()
	defer this.pos2enter_lock.Unlock()

	over_poss := make(map[int32]int32)
	for pos, val := range this.pos2enter {
		if nil != val && val.pid > 0 && cur_unix-val.agree_unix > TONG_AGREE_AVI_SEC {
			over_poss[pos] = 1
		}
	}

	for pos, _ := range over_poss {
		delete(this.pos2enter, pos)
	}

	for pos, val := range this.pos2enter {
		if nil != val && val.pid <= 0 {
			this.pos2enter[pos].pid = in_pid
			this.pos2enter[pos].agree_unix = cur_unix
			this.pos2enter[pos].name = name
			this.pos2enter[pos].score = score
			this.pos2enter[pos].op_playername = op_playername
			return int32(pos)
		}
	}

	return -1
}

func (this *Tong) ChkPopPreEnterInfo(pos, pid int32) *EnterTongAgreeItem {
	var ret_val *EnterTongAgreeItem
	this.pos2enter_lock.Lock()
	defer this.pos2enter_lock.Unlock()
	ret_val = this.pos2enter[pos]
	if nil != ret_val && pid == ret_val.pid {
		delete(this.pos2enter, pos)
	}
	return ret_val
}

func (this *Tong) EnterTong(c *CenterConnection, msg *msg_server_message.EnterTong) bool {
	if nil == msg {
		log.Error("Tong EnterTong msg nil !")
		return false
	}

	pid := msg.GetPlayerId()

	// 如果已经在帮会，直接加入
	old_mem := this.db.TongMembers.FindOneByPlayerId(pid)
	if nil != old_mem {
		res2t := &msg_server_message.SetPlayerTongInfo{}
		res2t.PlayerId = proto.Int32(pid)
		res2t.TongIcon = proto.Int32(this.db.TongData.GetIcon())
		res2t.TongId = proto.Int32(this.tong_id)
		res2t.TongName = proto.String(this.db.TongData.GetName())
		res2t.NotBack = proto.Int32(1)
		res2t.MemberType = proto.Int32(int32(old_mem.MemberType))
		c.Send(res2t)
		this.SetMemberOnline(pid)
		return true
	}

	// 加入积分
	if msg.GetScore() < this.db.TongData.GetJoinScore() {
		log.Error("Tong EnterTong not enough score(%d < %d)", msg.GetScore(), this.db.TongData.GetJoinScore())
		return false
	}

	join_type := this.db.TongData.GetJoinType()
	switch join_type {
	case TONG_JOIN_TYPE_EVERYONE:
		{
			member_id := this.GetUseAviTongMemberId()
			if -1 == member_id {
				log.Error("Tong EnterTong pid[%d] Failed to find member id", pid)
				return false
			}

			new_member := &dbTongTongMemberData{}
			new_member.MemberId = member_id
			new_member.PlayerId = msg.GetPlayerId()
			new_member.PlayerName = msg.GetPlayerName()
			new_member.Score = int16(msg.GetScore())
			new_member.MemberType = TONG_MEMBER_MENBER
			this.db.TongMembers.AddWithId(new_member)

			res2t := &msg_server_message.SetPlayerTongInfo{}
			res2t.PlayerId = proto.Int32(pid)
			res2t.TongIcon = proto.Int32(this.db.TongData.GetIcon())
			res2t.TongId = proto.Int32(this.tong_id)
			res2t.TongName = proto.String(this.db.TongData.GetName())
			res2t.NotBack = proto.Int32(1)
			res2t.MemberType = proto.Int32(TONG_MEMBER_MENBER)
			c.Send(res2t)

			this.SetMemberOnline(pid)
		}
	case TONG_JOIN_TYPE_NOONE:
		{
			log.Error("Tong EnterTong pid[%d] noone can join !", pid)
			return false
		}
	case TONG_JOIN_TYPE_NEED_CHK:
		{
			cur_join := this.db.TongJoins.Get(pid)
			if nil != cur_join {
				log.Trace("Tong EnterTong pid[%d] already in req list", pid)
				return false
			}

			new_req := &dbTongTongJoinData{}
			new_req.PlayerId = pid
			new_req.PlayerName = msg.GetPlayerName()
			new_req.JoinSec = int32(time.Now().Unix())
			new_req.PlayerScore = msg.GetScore()
			this.db.TongJoins.Add(new_req)

			req2co := &msg_server_message.EnterTongRequest{}
			req2co.PlayerId = proto.Int32(pid)
			req2co.PlayerName = proto.String(msg.GetPlayerName())
			req2co.PlayerScore = proto.Int32(msg.GetScore())
			req2co.JoinSec = proto.Int32(new_req.JoinSec)
			req2co.OnlinePlayers = this.GetOnlinePlayerIds(0)
			c.Send(req2co)
			return false
		}
	}

	return true
}

func (this *Tong) EnterAgree(c *CenterConnection, msg *msg_server_message.EnterTongAgree, op_mem *dbTongTongMemberData) {
	if nil == c || nil == msg || nil == op_mem {
		log.Error("Tong EnterAgree c or msg nil [%v]", nil == msg)
		return
	}

	pid := msg.GetPlayerId()
	cur_join := this.db.TongJoins.Get(pid)
	if nil == cur_join {
		log.Error("Tong EnterAgree pid[%d] not in join list", pid)
		return
	}

	pos := this.UseAviTongMemberId(pid, cur_join.PlayerScore, cur_join.PlayerName, op_mem.PlayerName)
	if -1 == pos {
		log.Error("Tong EnterAgree pid[%d] failed to find avi pos", pid)
		return
	}

	this.db.TongJoins.Remove(pid)
	req2c := &msg_server_message.SetPlayerTongInfo{}
	req2c.PlayerId = proto.Int32(pid)
	req2c.TongIcon = proto.Int32(this.db.TongData.GetIcon())
	req2c.TongId = proto.Int32(this.tong_id)
	req2c.TongName = proto.String(this.db.TongData.GetName())
	req2c.PrePos = proto.Int32(pos)
	req2c.MemberType = proto.Int32(TONG_MEMBER_MENBER)

	c.Send(req2c)

	return
}

func (this *Tong) EnterRefuse(c *CenterConnection, msg *msg_server_message.EnterTongRefuse) {
	if nil == c || nil == msg {
		log.Error("Tong EnterRefuse c or msg nil [%v]", nil == msg)
		return
	}

	op_pid := msg.GetOpPlayerId()
	cur_op_mem := this.db.TongMembers.FindOneByPlayerId(op_pid)
	if nil == cur_op_mem {
		log.Error("Tong EnterRefuse failed to find cur_op_mem[%d]", op_pid)
		return
	}

	if TONG_MEMBER_CAPTAIN != cur_op_mem.MemberType {
		log.Error("Tong EnterRefuse player[%d:%d] can not do this", op_pid, cur_op_mem.MemberType)
		return
	}

	join_pid := msg.GetPlayerId()
	cur_join := this.db.TongJoins.Get(join_pid)
	if nil == cur_join {
		log.Error("Tong EnterRefuse Player[pid] not in joinlist[%d]", op_pid, join_pid)
		return
	}

	this.db.TongJoins.Remove(join_pid)

	return
}

func (this *Tong) OnSetPlayerTongInfoOk(c *CenterConnection, msg *msg_server_message.SetPlayerTongInfoOk) bool {
	if nil == msg {
		log.Error("Tong OnSetPlayerTongInfoOk param error !")
		return false
	}

	pid := msg.GetPlayerId()
	pos := msg.GetPrePos()
	agreeitem := this.ChkPopPreEnterInfo(pos, pid)

	if nil == agreeitem {
		log.Error("Tong OnSetPlayerTongInfoOk failed to get pre pos[%d] !", pos)
		return false
	}

	cur_mem := this.db.TongMembers.Get(pos)
	if nil != cur_mem {
		log.Error("Tong OnSetPlayerTongInfoOk pos[%d] already have mem[%d:%s]", pos, cur_mem.PlayerId, cur_mem.PlayerName)
		return false
	}

	new_member := &dbTongTongMemberData{}
	new_member.MemberId = pos
	new_member.PlayerId = pid
	new_member.PlayerName = agreeitem.name
	new_member.Score = int16(agreeitem.score)
	new_member.MemberType = TONG_MEMBER_MENBER
	this.db.TongMembers.Add(new_member)

	notify := &msg_server_message.NotifyPlayerEnter{}
	notify.OnlinePlayers = this.GetOnlinePlayerIds(pid)
	if len(notify.OnlinePlayers) > 0 {
		notify.PlayerId = proto.Int32(pid)
		notify.PlayerName = proto.String(agreeitem.name)
		notify.PlayerScore = proto.Int32(agreeitem.score)
		notify.IfOnline = proto.Int32(msg.GetIfOnline())
		notify.OpPlayerName = proto.String(agreeitem.op_playername)
		c.Send(notify)
	}

	if 1 == msg.GetIfOnline() {
		res2co := this.GetRetTongInfoMsg(agreeitem.pid, 1)
		res2co.IfEnter = proto.Int32(1)
		c.Send(res2co)
	}

	return true
}

func (this *Tong) ChkMemberLeave(c *CenterConnection, msg *msg_server_message.TongLeave) {
	if nil == c || nil == msg {
		log.Error("Tong ChkMemberLeave c or msg nil")
		return
	}

	pid := msg.GetPlayerId()
	if pid == this.db.TongData.GetCaptainId() {
		log.Info("帮主退帮，自动传位")
		new_captain := this.db.TongMembers.GiveCapitain(pid)
		if new_captain > 0 {
			this.db.TongData.SetCaptainId(new_captain)
		}
	}

	cur_count, pos := this.db.TongMembers.ChkRemoveByPlayerId(msg.GetPlayerId())
	if 0 >= cur_count {
		log.Info("帮会[%d]里面没人了，帮会删除！！", this.tong_id)
		tong_mgr.remove_tong_by_id(this.tong_id)
		dbc.Tongs.RemoveRow(this.tong_id)
	} else {
		if pos > 0 {
			this.AddEmptyPos(pos)
		}
	}

	res2co := &msg_server_message.ClearPlayerTongInfo{}
	res2co.PlayerId = proto.Int32(msg.GetPlayerId())
	res2co.OnlinePlayers = this.GetOnlinePlayerIds(0)

	c.Send(res2co)
	return
}

func (this *Tong) AddFriendMatch(msg *msg_server_message.TongFriendMatch) bool {
	if nil == msg {
		log.Error("Tong AddFriendMatch msg nil !")
		return false
	}
	pid := msg.GetPlayerId()
	this.id2friendmatch_lock.Lock()
	defer this.id2friendmatch_lock.Unlock()

	if nil != this.Id2friendmatch[pid] {
		return false
	}

	this.Id2friendmatch[pid] = &TongFriendMatch{pid: pid, name: msg.GetName(), card_ids: msg.GetCardIds(), card_lvls: msg.GetCardLvls(), hall_id: msg.GetHallId()}

	return true
}

func (this *Tong) CancelFriendMatch(pid int32) bool {
	this.id2friendmatch_lock.Lock()
	defer this.id2friendmatch_lock.Unlock()

	if nil == this.Id2friendmatch[pid] {
		return false
	}

	delete(this.Id2friendmatch, pid)

	return true
}

func (this *Tong) FillTongFriendMsg(msg *msg_server_message.RetTongInfo) {
	if nil == msg {
		log.Error("Tong FillTongFriendMsg msg nil !")
		return
	}

	var tmp_match *msg_server_message.TongFriendMatchItem
	this.id2friendmatch_lock.RLock()
	defer this.id2friendmatch_lock.RUnlock()

	tmp_len := int32(len(this.Id2friendmatch))
	if tmp_len < 1 {
		return
	}

	msg.FriendMatchs = make([]*msg_server_message.TongFriendMatchItem, 0, tmp_len)
	for _, val := range this.Id2friendmatch {
		if nil == val {
			continue
		}

		tmp_match = &msg_server_message.TongFriendMatchItem{}
		tmp_match.PlayerId = proto.Int32(val.pid)
		tmp_match.Name = proto.String(val.name)
		msg.FriendMatchs = append(msg.FriendMatchs, tmp_match)
	}

	return
}

func (this *Tong) PopTongFriendMatch(pid int32) (ret_match *TongFriendMatch) {
	this.id2friendmatch_lock.Lock()
	defer this.id2friendmatch_lock.Unlock()

	ret_match = this.Id2friendmatch[pid]
	if nil != ret_match {
		delete(this.Id2friendmatch, pid)
	} else {
		log.Info("Tong PopTongFriednMatch nil")
	}

	return
}
