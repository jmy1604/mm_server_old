package main

import (
	"libs/log"
	"libs/socket"
	"libs/timer"
	"math/rand"
	"public_message/gen_go/client_message"

	"3p/code.google.com.protobuf/proto"
)

func (this *Player) SyncCardShopInfo() {
	if 0 == this.db.Info.GetIfHaveChooseCamp() {
		return
	}

	cur_day := timer.GetDayFrom1970WithCfg(0)
	last_up_day := this.db.Info.GetLastShopUpDay()
	if cur_day != last_up_day {
		camp_lib := shop_cfg_mgr.camp2ShopCardlib[this.db.Info.GetCamp()]
		if nil == camp_lib {
			log.Trace("Player SyncCardShopInfo not find camp[%d] lib !", this.db.Info.GetCamp())
			return
		}

		for pos, lib := range camp_lib.pos2cardlib {
			if nil == lib {
				continue
			}

			if nil == lib.arena2arenacardlib || len(lib.arena2arenacardlib) < 1 {
				log.Error("Player SyncCardShopInfo camp arena lvl error !")
				continue
			}

			arenacardlib := lib.arena2arenacardlib[this.db.Info.GetArenaLvl()]
			if nil == arenacardlib || arenacardlib.card_count < 1 {
				log.Error("Player SyncCardShop not find arena[%d] cardlib", this.db.Info.GetArenaLvl())
				continue
			}

			if arenacardlib.total_odds <= 0 {
				continue
			}

			rand_val := rand.Int31n(arenacardlib.total_odds)
			for _, libitem := range arenacardlib.card_lib {
				if nil == libitem {
					continue
				}

				if rand_val < libitem.Odds {
					if nil == this.db.ShopLattices.Get(pos) {
						new_shopcard := &dbPlayerShopLatticeData{}
						new_shopcard.CardCfgId = libitem.SellCardID
						new_shopcard.Lattice = pos
						new_shopcard.TodayBuyNum = 0
						this.db.ShopLattices.Add(new_shopcard)
					} else {
						this.db.ShopLattices.SetCardCfgId(pos, libitem.SellCardID)
						this.db.ShopLattices.SetTodayBuyNum(pos, 0)
					}
					break
				} else {
					rand_val = rand_val - libitem.Odds
				}
			}
		}

		this.db.Info.SetLastShopUpDay(cur_day)
	}

	cur_selling_cards := this.db.ShopLattices.GetAllClientSellingCardMsg()
	if nil != cur_selling_cards {
		this.Send(cur_selling_cards)
	}
}

func reg_player_shop_msg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SBuyChest, C2SBuyChestHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SBuyCard, C2SBuyCardHandler)
}

func C2SBuyChestHandler(c *socket.TcpConn, m proto.Message) {
	req := m.(*msg_client_message.C2SBuyChest)
	if nil == c || nil == req {
		log.Error("S2CBuyChestHanler req or c nil")
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("S2CBuyChestHandler not login p nil !")
		return
	}

	chest_id := req.GetChestId()
	shop_chest := shop_cfg_mgr.GetChestCfgById(chest_id)
	if nil == shop_chest {
		log.Error("S2CBuyChestHandler can not find[%d] in selling chests", chest_id)
		return
	}

	chest_cfg := chest_cfg_mgr.Map[chest_id]
	if nil == chest_cfg {
		log.Error("S2CBuyChestHandler can not find chest[%d]", chest_id)
		return
	}

	if chest_cfg.Camp != p.db.Info.GetCamp() {
		log.Error("S2CBuyChestHandler not same camp [%d = %d]!", chest_cfg.Camp, p.db.Info.GetCamp())
		return
	}

	if p.GetCoin() < chest_cfg.GoldCost || p.GetDiamond() < chest_cfg.GemCost {
		log.Error("S2CBuyChestHandler less cost coin[%d] diamond[%d]", chest_cfg.GoldCost, chest_cfg.GemCost)
		return
	}

	p.SubCoin(chest_cfg.GoldCost, "buy_chest", "shop")
	p.SubDiamond(chest_cfg.GemCost, "buy_chest", "shop")
	p.OpenChest(chest_cfg.ChestID, "buy_chest", "shop", 0, 0, false)

	res_2cli := &msg_client_message.S2CBuyChest{}
	res_2cli.CurDiamond = proto.Int32(p.GetDiamond())
	res_2cli.CurCoins = proto.Int32(p.GetCoin())

	p.Send(res_2cli)

	return
}

func C2SBuyCardHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SBuyCard)
	if nil == c || nil == msg {
		log.Error("C2SBuyCardHanlder c or req nil !")
		return
	}

	buy_count := req.GetBuyNum()
	if buy_count <= 0 {
		log.Error("C2SBuyCardHandler buy_count(%d) <=0", buy_count)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SBuyCardHanlder p not login !")
		return
	}

	pos := req.GetCardPos()
	db_selling := p.db.ShopLattices.Get(pos)
	if nil == db_selling {
		log.Error("C2SBuyCardHandler failed to get db_selling[%d]", pos)
		return
	}

	card_cfg := cfg_player_cards.Map[db_selling.CardCfgId]
	if nil == card_cfg {
		log.Error("C2SBuyCardHandler failed to get card_cfg[%d]", db_selling.CardCfgId)
		return
	}

	bret, total_price, real_buy_count := shop_cfg_mgr.GetBuyCost(db_selling.TodayBuyNum, card_cfg.Trait, buy_count)
	if !bret {
		log.Error("C2SBuyCardHandler failed to get buy price ! todaynum[%d] qua[%d] buy_count[%d]", db_selling.TodayBuyNum, card_cfg.Trait, buy_count)
		return
	}

	if p.GetCoin() < total_price {
		log.Error("C2SBuyCardHandler not enough coin need[%d] my[%d]", total_price, p.GetCoin())
		return
	}

	cur_coin := p.SubCoin(total_price, "buy", "card_shop")
	p.AddCard(db_selling.CardCfgId, real_buy_count, "buy", "card_shop", true, false)

	p.db.ShopLattices.IncbyTodayBuyNum(pos, real_buy_count)

	res_2cli := &msg_client_message.S2CBuyCard{}
	res_2cli.BuyNum = proto.Int32(real_buy_count)
	res_2cli.CardPos = proto.Int32(pos)
	res_2cli.CurCoin = proto.Int32(cur_coin)

	p.Send(res_2cli)
	return
}
