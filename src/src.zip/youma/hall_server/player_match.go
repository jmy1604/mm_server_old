package main

import (
	"libs/log"
	"libs/socket"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	PLAYER_MATCH_STATE_FAILED   = -1 // 匹配失败
	PLAYER_MATCH_STATE_NONE     = 0  // 未匹配
	PLAYER_MATCH_STATE_MATCHING = 1  // 匹配中
	PLAYER_MATCH_STATE_SUCCEED  = 2  // 匹配完成

	FIGHT_RESULT_2_HALL_EQUAL = 0 // 平局
	FIGHT_RESULT_2_HALL_WIN   = 1 // 赢局
	FIGHT_RESULT_2_HALL_FAIL  = 2 // 输局

	MATCH_TYPE_NORMAL      = 0 // 普通匹配赛
	MATCH_TYPE_TONG_FRIEND = 1 // 帮会友谊赛
	MATCH_TYPE_CAMP_MATCH  = 2 // 阵营战
	MATCH_TYPE_2V2_MATCH   = 3 // 2v2
)

type PlayerMatchMgr struct {
	id2matchinfo      map[int32]*msg_client_message.S2CMatchRes
	id2matchinfo_lock *sync.RWMutex

	id2match2v2room      map[int32]*msg_client_message.S2CEnter2V2MatchRoom
	id2match2v2room_lock *sync.RWMutex
}

var player_match_mgr PlayerMatchMgr

func (this *PlayerMatchMgr) Init() bool {

	this.id2matchinfo = make(map[int32]*msg_client_message.S2CMatchRes)
	this.id2matchinfo_lock = &sync.RWMutex{}

	this.id2match2v2room = make(map[int32]*msg_client_message.S2CEnter2V2MatchRoom)
	this.id2match2v2room_lock = &sync.RWMutex{}

	this.RegMatchMsg()

	return true
}

// -----------------------------------

func (this *PlayerMatchMgr) SetCurMatchInfo(pid int32, info *msg_client_message.S2CMatchRes) {
	if nil == info {
		log.Error("PlayerMatchMgr setcurmatchinfo info nil !")
		return
	}

	log.Info("SetCurMatchInfo %d  %v", pid, info)
	this.id2matchinfo_lock.Lock()
	defer this.id2matchinfo_lock.Unlock()
	this.id2matchinfo[pid] = info

	return
}

func (this *PlayerMatchMgr) RemoveMatchInfoById(id int32) {
	this.id2matchinfo_lock.Lock()
	defer this.id2matchinfo_lock.Unlock()
	if nil != this.id2matchinfo[id] {
		delete(this.id2matchinfo, id)
	}

	return
}

func (this *PlayerMatchMgr) RemoveMultiMatchInfo(req *msg_server_message.M2HClearMatchInfo) {
	if nil == req {
		log.Error("PlayerMatchMgr RemoveMultiMatchInfo req nil")
		return
	}

	this.id2matchinfo_lock.Lock()
	defer this.id2matchinfo_lock.Unlock()
	for _, tmp_id := range req.GetPlayerIds() {
		if nil != this.id2matchinfo[int32(tmp_id)] {
			delete(this.id2matchinfo, int32(tmp_id))
		}
	}

	return
}

func (this *PlayerMatchMgr) GetCurMatchInfo(playerid int32) *msg_client_message.S2CMatchRes {
	this.id2matchinfo_lock.RLock()
	defer this.id2matchinfo_lock.RUnlock()

	return this.id2matchinfo[playerid]
}

// ---------------------------------------

func (this *PlayerMatchMgr) SetCurMatch2V2(pid int32, info *msg_client_message.S2CEnter2V2MatchRoom) {
	if nil == info {
		log.Error("PlayerMatchMgr SetCurMatch2V2 info nil !")
		return
	}

	log.Info("SetCurMatch2V2 %d  %v", pid, info)
	this.id2match2v2room_lock.Lock()
	defer this.id2match2v2room_lock.Unlock()
	this.id2match2v2room[pid] = info

	return
}

func (this *PlayerMatchMgr) SetCurMatch2V2Parter(pid int32, parter *msg_client_message.S2CMatch2V2ParterEnter) {
	if nil == parter {
		log.Error("PlayerMatchMgr SetCurMatch2V2Parter parter nil !")
		return
	}

	log.Info("SetCurMatch2V2Parter %d  %v", pid, parter)
	this.id2match2v2room_lock.Lock()
	defer this.id2match2v2room_lock.Unlock()
	cur_info := this.id2match2v2room[pid]
	if nil != cur_info {
		cur_info.Parter = parter
	} else {
		log.Error("SetCurMatch2V2Parter parter cur info[%d] nil", pid)
	}

	return
}

func (this *PlayerMatchMgr) Remove2V2MatchById(id int32) {
	this.id2match2v2room_lock.Lock()
	defer this.id2match2v2room_lock.Unlock()
	if nil != this.id2match2v2room[id] {
		delete(this.id2match2v2room, id)
	}

	return
}

func (this *PlayerMatchMgr) RemoveMultiMatch2V2(req *msg_server_message.M2HClearMatchInfo) {
	if nil == req {
		log.Error("PlayerMatchMgr RemoveMultiMatchInfo req nil")
		return
	}

	this.id2match2v2room_lock.Lock()
	defer this.id2match2v2room_lock.Unlock()
	for _, tmp_id := range req.GetPlayerIds() {
		if nil != this.id2match2v2room[int32(tmp_id)] {
			delete(this.id2match2v2room, int32(tmp_id))
		}
	}

	return
}

func (this *PlayerMatchMgr) GetCurMatch2V2(playerid int32) *msg_client_message.S2CEnter2V2MatchRoom {
	this.id2match2v2room_lock.RLock()
	defer this.id2match2v2room_lock.RUnlock()

	return this.id2match2v2room[playerid]
}

// ---------------------------------------

func (this *PlayerMatchMgr) check_send_cur_room_info(p *Player) {
	if nil == p {
		log.Error("PlayerMatchMgr check_send_cur_room_info p nil !")
		return
	}

	log.Info("PlayerMatchMgr PlayerMatchMgr player[%d] ", p.Id)

	cur_match_info := this.GetCurMatchInfo(p.Id)
	if nil == cur_match_info {
		log.Error("PlayerMatchMgr check_send_cur_room_info nil[%d]", p.Id)

	} else {
		if cur_match_info.GetState() <= 0 {
			log.Info("PlayerMatchMgr check_send_cur_room_info(%v) state < = 0", cur_match_info)
		} else {
			req_2m := &msg_server_message.H2MCheckMatchInfo{}
			req_2m.Id = proto.Int64(int64(p.Id))
			match_conn.Send(req_2m)

			p.Send(cur_match_info)
		}
	}

	cur_2v2_info := this.GetCurMatch2V2(p.Id)
	if nil != cur_2v2_info {
		p.Send(cur_2v2_info)
	}

	return
}

func (this *PlayerMatchMgr) ChkPlayerLegendMatchSwitch() {

}

/// 匹配相关消息===================================================================

func (this *PlayerMatchMgr) RegMatchMsg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SMatchReq, C2SMatchReqHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SMatchCancel, C2SMatchCancelHandler)

	match_conn.SetMessageHandler(msg_server_message.ID_M2HMatchingState, M2HMatchingStateHandler)
	match_conn.SetMessageHandler(msg_server_message.ID_M2HMatchResult, M2HMatchResultHandler)
	match_conn.SetMessageHandler(msg_server_message.ID_M2HCancelMatchRes, M2HCancelMatchResHandler)
	match_conn.SetMessageHandler(msg_server_message.ID_M2HFightResult, M2HFightResultHandler)
	match_conn.SetMessageHandler(msg_server_message.ID_M2HClearMatchInfo, M2HClearMatchInfoHandler)
	match_conn.SetMessageHandler(msg_server_message.ID_Match2V2EnterRoom, M2HMatch2v2EnterRoomHandler)
	match_conn.SetMessageHandler(msg_server_message.ID_Match2V2ParterEnter, Match2V2ParterEnterHandler)
}

func C2SMatchReqHandler(conn *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SMatchReq)
	if nil == conn || nil == req {
		log.Error("C2SMatchReqHandler param error !")
		return
	}

	p := player_mgr.GetPlayerById(int32(conn.T))
	if nil == p {
		log.Error("C2SMatchReqHandler not login !")
		return
	}

	req_2m := &msg_server_message.H2MPlayerMatch{}
	cur_team := p.db.CardTeams.Get(p.db.Info.GetCurUseCardTeam())
	if nil == cur_team || len(cur_team.CardCfgIds) <= 0 {
		log.Error("cur_team cardcfgids zero !!")
		p.db.Info.SetCurUseCardTeam(DEFAULT_CARD_TEAM_0)
		cur_team = p.db.CardTeams.Get(DEFAULT_CARD_TEAM_0)
	}

	nozero_cards := make([]int32, 0, len(cur_team.CardCfgIds))
	for _, val := range cur_team.CardCfgIds {
		if val <= 0 {
			continue
		}

		nozero_cards = append(nozero_cards, val)
	}

	if len(nozero_cards) < 1 {
		log.Error("C2SMatchReqHandler card_team have not no zero cards !", p.Id, cur_team.TeamId)
		return
	}

	match_type := req.GetMatchType()
	if MATCH_TYPE_CAMP_MATCH == match_type {
		if !camp_fight_mgr.CkPlayerEnterCamp(p) {
			log.Error("C2SMatchReqHandler camp match not open !")
			return
		}
		req_2m.PlayerCamp = proto.Int32(p.db.Info.GetCamp())
	}

	req_2m.Id = proto.Int64(conn.T)
	req_2m.Name = proto.String(p.db.GetName())
	req_2m.CardCfgIds = nozero_cards
	req_2m.CardLvls = p.db.Cards.GetCardsLvls(nozero_cards)
	req_2m.Score = proto.Int32(p.db.Info.GetMatchScore())
	req_2m.TongId = proto.Int32(p.db.TongInfo.GetTongId())
	req_2m.TongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
	req_2m.TongName = proto.String(p.db.TongInfo.GetTongName())
	req_2m.MatchType = proto.Int32(match_type)

	match_conn.Send(req_2m)

	log.Info("C2SMatchReqHandler %v", *req)
}

func M2HMatchingStateHandler(a *MatchConnection, msg proto.Message) {
	res := msg.(*msg_server_message.M2HMatchingState)
	if nil == a || nil == res {
		log.Error("M2HMatchingStateHandler param error !")
		return
	}

	playerid := int32(res.GetId())

	p := player_mgr.GetPlayerById(playerid)
	if nil == p {
		log.Error("M2HMatchingStateHandler player nil")
		return
	}

	res_2c := &msg_client_message.S2CMatchRes{}
	res_2c.State = proto.Int32(res.GetState())
	res_2c.MatchType = proto.Int32(res.GetMatchType())
	p.Send(res_2c)

	player_match_mgr.SetCurMatchInfo(p.Id, res_2c)

	return

}

func M2HMatchResultHandler(a *MatchConnection, msg proto.Message) {
	res := msg.(*msg_server_message.M2HMatchResult)
	if nil == a || nil == res {
		log.Error("M2HMatchResultHandler param error !")
		return
	}

	playerid := int32(res.GetId())

	p := player_mgr.GetPlayerById(playerid)
	if nil == p {
		log.Error("M2HMatchResultHandler find player[%d] failed !", playerid)
		return
	}

	res_2cli := &msg_client_message.S2CMatchRes{}
	res_2cli.State = proto.Int32(2)
	res_2cli.RoomId = proto.Int32(res.GetRoomId())
	res_2cli.RoomIP = proto.String(res.GetRoomServerIP())
	res_2cli.Token = proto.Int32(res.GetToken())
	res_2cli.MatchType = proto.Int32(res.GetMathType())

	player_match_mgr.Remove2V2MatchById(playerid)
	player_match_mgr.SetCurMatchInfo(playerid, res_2cli)

	p.Send(res_2cli)

	return
}

func C2SMatchCancelHandler(conn *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SMatchCancel)
	if nil == conn || nil == req {
		log.Error("C2SMatchCancelHandler param error !")
		return
	}

	playerid := int32(conn.T)
	p := player_mgr.GetPlayerById(playerid)
	if nil == p {
		log.Error("C2SMatchCancelHandler GetPlayerById(%d) failed", playerid)
		return
	}

	req_2m := &msg_server_message.H2MCancelMatchReq{}
	req_2m.Id = proto.Int64(conn.T)
	match_conn.Send(req_2m)
}

func M2HCancelMatchResHandler(a *MatchConnection, msg proto.Message) {
	res := msg.(*msg_server_message.M2HCancelMatchRes)
	if nil == a || nil == res {
		log.Error("M2HCancelMatchResHandler param error !")
		return
	}

	p := player_mgr.GetPlayerById(int32(res.GetId()))
	if nil == p {
		log.Error("M2HCancelMatchResHandler p nil !")
		return
	}

	p.Send(&msg_client_message.S2CMatchCancel{})

	return
}

func M2HFightResultHandler(a *MatchConnection, msg proto.Message) {
	res := msg.(*msg_server_message.M2HFightResult)
	if nil == a || nil == res {
		log.Error("M2HFightResultHandler param error !")
		return
	}

	p := player_mgr.GetPlayerById(int32(res.GetId()))
	if nil == p {
		log.Error("M2HFightResultHandler p nil !")
		return
	}

	result := res.GetResult()
	res_f_2cli := &msg_client_message.S2CFightResult{}
	res_f_2cli.MyTowers = proto.Int32(res.GetMyTowers())
	res_f_2cli.OpTowers = proto.Int32(res.GetOpTowers())
	res_f_2cli.Result = proto.Int32(res.GetResult())

	new_fight_rd := &dbPlayerFightRecordData{}
	new_fight_rd.CreateUnix = int32(time.Now().Unix())
	new_fight_rd.MyPlayerName = p.db.GetName()
	new_fight_rd.MyTongId = p.db.TongInfo.GetTongId()
	new_fight_rd.MyTongIcon = p.db.TongInfo.GetTongIcon()
	new_fight_rd.MyTongName = p.db.TongInfo.GetTongName()
	new_fight_rd.OptPlayerName = res.GetOptName()
	new_fight_rd.OptCardLvls = res.GetOptCardLvls()
	new_fight_rd.OptCards = res.GetOptCards()
	new_fight_rd.OpTongIcon = res.GetOpTongIcon()
	new_fight_rd.OptTongId = res.GetOptTongId()
	new_fight_rd.OptTongName = res.GetOptTongName()
	new_fight_rd.MatchType = res.GetMatchType()
	new_fight_rd.MyTowers = res.GetMyTowers()
	new_fight_rd.OpTowers = res.GetOpTowers()
	new_fight_rd.MyMathScore = p.db.Info.GetMatchScore()
	new_fight_rd.OpMathScore = res.GetOpMatchScore()

	cur_team := p.db.CardTeams.Get(p.db.Info.GetCurUseCardTeam())
	if nil != cur_team {
		new_fight_rd.MyCards = cur_team.CardCfgIds
		new_fight_rd.MyCardLvls = p.db.Cards.GetCardsLvls(new_fight_rd.MyCards)
	}

	switch res.GetMatchType() {
	case MATCH_TYPE_NORMAL:
		{
			switch result {
			case FIGHT_RESULT_2_HALL_EQUAL:
				{
					new_fight_rd.WinnerId = 0
					log.Trace("M2HFightResultHandler Player[%d:%s] noraml fight equal !!", p.Id, p.db.GetName())
				}
			case FIGHT_RESULT_2_HALL_FAIL:
				{
					new_fight_rd.WinnerId = res.GetOptId()
					lost_score := player_score_mgr.GetLostScore(p.GetMatchScore(), res.GetOpScores(), res.GetOpTowers())
					new_fight_rd.MyMathScoreChg = -lost_score
					new_score := p.SubMatchScore(lost_score, "fight_lose", "normal fight")
					cur_drop_score := cfg_arena.GetDropScoreByArenaLvl(p.db.Info.GetArenaLvl())
					if new_score <= cur_drop_score {
						new_lvl := cfg_arena.GetAreanLvlByScore(new_score)
						p.db.Info.SetArenaLvl(new_lvl)
						res_2cli := &msg_client_message.S2CArenaLvl{}
						res_2cli.ArenaLvl = proto.Int32(new_lvl)
						log.Info("玩家[%d] 普通匹配竞技场掉级别了[%d]", p.Id, new_lvl)
						p.Send(res_2cli)
					}

					tong_id := p.db.TongInfo.GetTongId()
					if tong_id > 0 {
						res2co := &msg_server_message.TongMemberFightEnd{}
						res2co.Score = proto.Int32(0)
						res2co.TongId = proto.Int32(tong_id)
						res2co.CurScore = proto.Int32(new_score)
						res2co.PlayerId = proto.Int32(p.Id)
						center_conn.Send(res2co)
					}

					res2co := &msg_server_message.PlayerNScoreChg{}
					res2co.PlayerId = proto.Int32(p.Id)
					res2co.PlayerName = proto.String(p.db.GetName())
					res2co.Pos = proto.Int32(p.pos)
					res2co.Score = proto.Int32(new_score)
					res2co.TongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
					res2co.TongName = proto.String(p.db.TongInfo.GetTongName())
					center_conn.Send(res2co)
					log.Trace("M2HFightResultHandler Player[%d:%s] normal fight failed lost(%d) !!", p.Id, p.db.GetName(), lost_score)
				}
			case FIGHT_RESULT_2_HALL_WIN:
				{
					my_towers := res.GetMyTowers()
					new_fight_rd.WinnerId = p.Id
					add_score := player_score_mgr.GetWinScore(p.GetMatchScore(), res.GetOpScores(), my_towers)
					new_fight_rd.MyMathScoreChg = add_score
					new_score := p.AddMatchScore(add_score, "fight_lose", "fight")
					log.Info("M2HFightResultHandler 玩家[%d] 普通匹配获胜 新积分[%d] 增加积分[%d]", p.Id, new_score, add_score)
					if p.GetDayMatchRewardNum() < global_config.ArenaGoldAwardTimeLimit {
						add_coin := cfg_arena.GetWinCoinByLvl(p.db.Info.GetArenaLvl())
						p.AddCoin(add_coin, "fight_lose", "fight")
						p.AddDayMatchRewardNum(1)
						log.Info("M2HFightResultHandler 普通匹配赢得金币 %d", add_coin)
					} else {
						log.Error("M2HFightResultHandler Player 普通匹配金币奖励次数已经到达上限（%d >= %d）", p.GetDayMatchRewardNum(), global_config.ArenaGoldAwardTimeLimit)
					}

					arena_lvl := cfg_arena.GetAreanLvlByScore(new_score)
					if arena_lvl > p.db.Info.GetArenaLvl() {
						p.db.Info.SetArenaLvl(arena_lvl)
						res_2cli := &msg_client_message.S2CArenaLvl{}
						res_2cli.ArenaLvl = proto.Int32(arena_lvl)
						log.Info("玩家[%d]普通竞技场升级别了[%d]", p.Id, arena_lvl)
						p.Send(res_2cli)
						p.TaskAchieveOnConditionSet(TASK_ACHIEVE_FINISH_CON_ARENA_LVL, arena_lvl, false)
					}

					// 给予宝箱
					chest_cycle := p.db.Info.GetChestCycleCount() + 1
					if chest_cycle > chest_cfg_mgr.max_chest_cycle {
						chest_cycle = 1
					}

					p.db.Info.SetChestCycleCount(chest_cycle)

					chest_id := chest_cfg_mgr.GetDropChestId(p.db.Info.GetCamp(), p.db.Info.GetArenaLvl(), chest_cycle)
					if -1 == chest_id {
						log.Error("M2HFightResultHandler p[%d] normal fight win but failed to get chest", p.Id, p.db.Info.GetCamp(), p.db.Info.GetArenaLvl(), chest_cycle)
						return
					} else {
						pos := p.AddChest(chest_id, "fight_win", "normal fight", true)
						if pos != -1 {
							res_f_2cli.ChestCfgId = proto.Int32(chest_id)
						}
						res_f_2cli.Pos = proto.Int32(pos)
					}

					p.db.Info.IncbyWinCount(1)
					if arena_lvl == cfg_arena.LegLvl {
						if new_score > p.db.Info.GetCurBestLegScore() {
							p.db.Info.SetCurBestLegScore(new_score)
						}
					}

					player_score_mgr.OnPlayerScoreAdd(p, new_score)

					p.TaskAchieveOnConditionAdd(TASK_ACHIEVE_FINISH_CON_ARENA_WIN, 1)
					p.db.TowerAndFreeChest.IncbyCurChestTowerNum(my_towers)
					tong_id := p.db.TongInfo.GetTongId()
					if tong_id > 0 {
						res2co := &msg_server_message.TongMemberFightEnd{}
						res2co.Score = proto.Int32(my_towers)
						res2co.TongId = proto.Int32(tong_id)
						res2co.CurScore = proto.Int32(new_score)
						res2co.PlayerId = proto.Int32(p.Id)
						center_conn.Send(res2co)
					}

					log.Trace("M2HFightResultHandler Player[%d:%s] normal fight win(%d) !!", p.Id, p.db.GetName(), add_score)
				}
			}

			player_match_mgr.RemoveMatchInfoById(p.Id)

			res_f_2cli.CurCoins = proto.Int32(p.GetCoin())
			res_f_2cli.CurScore = proto.Int32(p.GetMatchScore())
			p.Send(res_f_2cli)
			log.Info("发送给客户端的金币数量%d", *res_f_2cli.CurCoins)
		}
	case MATCH_TYPE_TONG_FRIEND:
		{
			res_f_2cli.ChestCfgId = proto.Int32(0)
			res_f_2cli.Pos = proto.Int32(-1)
			res_f_2cli.CurCoins = proto.Int32(p.GetCoin())
			res_f_2cli.CurScore = proto.Int32(p.GetMatchScore())
			p.Send(res_f_2cli)
		}
	case MATCH_TYPE_CAMP_MATCH:
		{

			switch result {
			case FIGHT_RESULT_2_HALL_EQUAL:
				{
					new_fight_rd.WinnerId = 0
					log.Trace("M2HFightResultHandler Player[%d:%s] camp fight equal !!", p.Id, p.db.GetName())
				}
			case FIGHT_RESULT_2_HALL_FAIL:
				{
					new_fight_rd.WinnerId = res.GetOptId()
					lost_score := player_score_mgr.GetLostScore(p.GetMatchScore(), res.GetOpScores(), res.GetOpTowers())
					new_score, score_chg := p.db.CampFightInfo.SubCurScore(lost_score)

					res2co := &msg_server_message.CampFigthScoreChg{}
					res2co.PlayerId = proto.Int32(p.Id)
					res2co.PlayerName = proto.String(p.db.GetName())
					res2co.CurScore = proto.Int32(new_score)
					res2co.TongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
					res2co.TongName = proto.String(p.db.TongInfo.GetTongName())
					res2co.PlayerCamp = proto.Int32(p.db.Info.GetCamp())
					res2co.PlayerScoreChg = proto.Int32(score_chg)
					center_conn.Send(res2co)
					log.Trace("M2HFightResultHandler Player[%d:%s] camp fight failed lost(%d) chg[%d] !!", p.Id, p.db.GetName(), lost_score, score_chg)
				}
			case FIGHT_RESULT_2_HALL_WIN:
				{
					my_towers := res.GetMyTowers()
					new_fight_rd.WinnerId = p.Id
					add_score := player_score_mgr.GetWinScore(p.GetMatchScore(), res.GetOpScores(), my_towers)
					new_score := p.db.CampFightInfo.IncbyCurScore(add_score)

					res2co := &msg_server_message.CampFigthScoreChg{}
					res2co.PlayerId = proto.Int32(p.Id)
					res2co.PlayerName = proto.String(p.db.GetName())
					res2co.CurScore = proto.Int32(new_score)
					res2co.TongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
					res2co.TongName = proto.String(p.db.TongInfo.GetTongName())
					res2co.PlayerCamp = proto.Int32(p.db.Info.GetCamp())
					res2co.PlayerScoreChg = proto.Int32(add_score)
					center_conn.Send(res2co)

					log.Trace("M2HFightResultHandler Player[%d:%s] camp fight win(%d) !!", p.Id, p.db.GetName(), add_score)
				}
			}

			player_match_mgr.RemoveMatchInfoById(p.Id)

			res_f_2cli.Pos = proto.Int32(-1)
			res_f_2cli.CurCoins = proto.Int32(p.GetCoin())
			res_f_2cli.CurScore = proto.Int32(p.db.CampFightInfo.GetCurScore())
			p.Send(res_f_2cli)
			log.Info("发送给客户端的金币数量%d", *res_f_2cli.CurCoins)
		}
	default:
		{
			log.Trace("M2HFightResultHandler Player[%d:%s] wrong match type[%d] !", p.Id, p.db.GetName())
		}
	}

	new_id := p.AddFightRecord(new_fight_rd)
	tmp_rd_msg := &msg_client_message.FightRecord{}
	tmp_rd_msg.RecordId = proto.Int32(new_id)
	tmp_rd_msg.CreateUnix = proto.Int32(new_fight_rd.CreateUnix)
	tmp_rd_msg.MyCardLvls = new_fight_rd.MyCardLvls
	tmp_rd_msg.MyCards = new_fight_rd.MyCards
	tmp_rd_msg.MyTongIcon = proto.Int32(new_fight_rd.MyTongIcon)
	tmp_rd_msg.MyTongId = proto.Int32(new_fight_rd.MyTongId)
	tmp_rd_msg.MyTongName = proto.String(new_fight_rd.MyTongName)
	tmp_rd_msg.OpCardLvls = new_fight_rd.OptCardLvls
	tmp_rd_msg.OpCards = new_fight_rd.OptCards
	tmp_rd_msg.OpTongIcon = proto.Int32(new_fight_rd.OpTongIcon)
	tmp_rd_msg.OpTongId = proto.Int32(new_fight_rd.OptTongId)
	tmp_rd_msg.OpTongName = proto.String(new_fight_rd.OptTongName)
	tmp_rd_msg.OpName = proto.String(new_fight_rd.OptPlayerName)
	tmp_rd_msg.MyName = proto.String(new_fight_rd.MyPlayerName)
	tmp_rd_msg.MatchType = proto.Int32(new_fight_rd.MatchType)
	tmp_rd_msg.MyTowers = proto.Int32(new_fight_rd.MyTowers)
	tmp_rd_msg.OpTowers = proto.Int32(new_fight_rd.OpTowers)
	tmp_rd_msg.MyMatchScore = proto.Int32(new_fight_rd.MyMathScore)
	tmp_rd_msg.OpMatchScore = proto.Int32(new_fight_rd.OpMathScore)
	tmp_rd_msg.MyScoreChg = proto.Int32(new_fight_rd.MyMathScoreChg)

	res2cli := &msg_client_message.S2CRetFightRecordAdd{}
	p.Send(res2cli)

	return
}

func M2HClearMatchInfoHandler(a *MatchConnection, msg proto.Message) {
	res := msg.(*msg_server_message.M2HClearMatchInfo)
	if nil == a || nil == res {
		log.Error("M2HClearMatchInfoHandler param error !")
		return
	}

	player_match_mgr.RemoveMultiMatchInfo(res)
	return
}

func M2HMatch2v2EnterRoomHandler(a *MatchConnection, msg proto.Message) {
	res := msg.(*msg_server_message.Match2V2EnterRoom)
	if nil == a || nil == res {
		log.Error("M2HMatch2v2EnterRoomHandler param error !")
		return
	}

	pid := res.GetMyPId()
	p := player_mgr.GetPlayerById(pid)
	if nil == p {
		log.Error("M2HMatch2v2EnterRoomHandler param error !")
		return
	}

	res2cli := &msg_client_message.S2CEnter2V2MatchRoom{}
	res2cli.RoomId = proto.Int32(res.GetMatchRoomId())
	msg_parter := res.GetPater()
	if nil != msg_parter {
		tmp_parter := &msg_client_message.S2CMatch2V2ParterEnter{}
		tmp_parter.Id = proto.Int32(msg_parter.GetId())
		tmp_parter.Name = proto.String(msg_parter.GetName())
		tmp_parter.Score = proto.Int32(msg_parter.GetScore())
		tmp_parter.CardCfgIds = msg_parter.GetCardCfgIds()
		tmp_parter.CardLvls = msg_parter.GetCardLvls()
		res2cli.Parter = tmp_parter
	}

	p.Send(res2cli)

	player_match_mgr.SetCurMatch2V2(pid, res2cli)

	return
}

func Match2V2ParterEnterHandler(a *MatchConnection, msg proto.Message) {
	res := msg.(*msg_server_message.Match2V2ParterEnter)
	if nil == a || nil == res {
		log.Error("Match2V2ParterEnterHandler param error !")
		return
	}

	pid := res.GetMyId()
	p := player_mgr.GetPlayerById(pid)
	if nil == p {
		log.Error("Match2V2ParterEnterHandler param error !")
		return
	}

	res2cli := &msg_client_message.S2CMatch2V2ParterEnter{}
	res2cli.Id = proto.Int32(res.GetParterId())
	res2cli.Name = proto.String(res.GetParterName())
	res2cli.Score = proto.Int32(res.GetParterScore())
	res2cli.CardCfgIds = res.GetParterCardCfgIds()
	res2cli.CardLvls = res.GetParterCardLvls()

	p.Send(res2cli)

	player_match_mgr.SetCurMatch2V2Parter(pid, res2cli)

	return
}
