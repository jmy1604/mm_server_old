package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"libs/server_conn"
	"libs/socket"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"

	"3p/code.google.com.protobuf/proto"
)

const (
	MAX_MATCH_SCORE         = 9999999
	MAX_DESTORY_TOWER_COUNT = 3 // 当前最大摧毁塔数
)

type XmlWinScoreAdjItem struct {
	LowDiff      int32 `xml:"CorrectionLowerLimit,attr"`
	UpDiff       int32
	Higher100Per int32 `xml:"HighWinsCorrection,attr"`
	Lower100Per  int32 `xml:"LowWinsCorrection,attr"`
}

type XmlWinScoreAdjConfig struct {
	Items []XmlWinScoreAdjItem `xml:"item"`
}

type XmlWinScoreItem struct {
	StartScore  int32 `xml:"TrophyLowerLimit,attr"`
	EndScore    int32 `xml:"TrophyUpperLimit,attr"`
	WinBase     int32 `xml:"ArenaBasicTrophy,attr"`
	OneTScore   int32 `xml:"OneCrownWins,attr"`
	TwoTScore   int32 `xml:"TwoCrownWins,attr"`
	ThreeTScore int32 `xml:"ThreeCrownWins,attr"`
	FailPer     int32 `xml:"FailureProportion,attr"`
	TowerScores []int32
}

type XmlWinScoreConfig struct {
	Items []XmlWinScoreItem `xml:"item"`
}

type PlayerScoreMgr struct {
	Adjusts         []*XmlWinScoreAdjItem
	WinScores       []*XmlWinScoreItem
	PlayerScoreRank *SmallRankService

	BSyncFinished  bool  // 是否同步已经完成
	LastSwitchUnix int32 // 上一次切换时间
	binit          bool  // 是否初始化完成
}

var player_score_mgr PlayerScoreMgr

func (this *PlayerScoreMgr) Init() bool {
	if !this.LoadWinScore() {
		return false
	}

	if !this.LoadScoreAdj() {
		return false
	}

	this.RegPlayerScoreMsg()

	this.PlayerScoreRank = NewSmallRankService(200, SMALL_RANK_TYPE_PLAYER_N_SCORE, SMALL_RANK_SORT_TYPE_B)

	this.InitRankWithDb()

	this.binit = true

	return true
}

func (this *PlayerScoreMgr) InitRankWithDb() {
	all_players := player_mgr.GetAllPlayers()
	for _, p := range all_players {
		if nil == p {
			continue
		}

		log.Info("初始化积分排行榜 id[%d] score[%d]", p.Id, p.GetMatchScore())
		this.PlayerScoreRank.SetUpdateRank(p.Id, p.GetMatchScore())
	}

	this.PrintCurRank()

	all_records := this.PlayerScoreRank.GetTopN(200)
	req2c := &msg_server_message.MultiPlayerNScoreChg{}
	curcount := int32(0)
	var tmp_p *Player
	req2c.ChgList = make([]*msg_server_message.PlayerNScoreChg, 0, 50)
	for _, record := range all_records {
		if nil == record || record.id <= 0 {
			continue
		}

		tmp_p = player_mgr.GetPlayerById(record.id)
		if nil == tmp_p {
			log.Error("PlayerScoreMgr InitRankWithDb GetPlayerById[%d] failed !", record.id)
			continue
		}

		tmp_chg := &msg_server_message.PlayerNScoreChg{}
		tmp_chg.PlayerId = proto.Int32(record.id)
		tmp_chg.PlayerName = proto.String(tmp_p.db.GetName())
		tmp_chg.Score = proto.Int32(tmp_p.GetMatchScore())
		req2c.ChgList = append(req2c.ChgList, tmp_chg)

		curcount++
		if curcount >= 50 {
			center_conn.Send(req2c)
			curcount = 0
			req2c.ChgList = make([]*msg_server_message.PlayerNScoreChg, 0, 50)
		}
	}

	if curcount > 0 {
		center_conn.Send(req2c)
	}
}

func (this *PlayerScoreMgr) ChkSyncRankToCenter(c *server_conn.ServerConn) {
	if !this.binit {
		return
	}

	all_records := this.PlayerScoreRank.GetTopN(200)
	req2c := &msg_server_message.MultiPlayerNScoreChg{}
	curcount := int32(0)
	var tmp_p *Player
	req2c.ChgList = make([]*msg_server_message.PlayerNScoreChg, 0, 50)
	for _, record := range all_records {
		if nil == record || record.id <= 0 {
			continue
		}

		tmp_p = player_mgr.GetPlayerById(record.id)
		if nil == tmp_p {
			log.Error("PlayerScoreMgr InitRankWithDb GetPlayerById[%d] failed !", record.id)
			continue
		}

		tmp_chg := &msg_server_message.PlayerNScoreChg{}
		tmp_chg.PlayerId = proto.Int32(record.id)
		tmp_chg.PlayerName = proto.String(tmp_p.db.GetName())
		tmp_chg.Score = proto.Int32(tmp_p.GetMatchScore())
		req2c.ChgList = append(req2c.ChgList, tmp_chg)

		curcount++
		if curcount >= 50 {
			c.Send(req2c, true)
			curcount = 0
			req2c.ChgList = make([]*msg_server_message.PlayerNScoreChg, 0, 50)
		}
	}

	if curcount > 0 {
		c.Send(req2c, true)
	} else {
		log.Error("PlayerScoreMgr ChkSyncRankToCenter no player")
	}
}

func (this *PlayerScoreMgr) LoadWinScore() bool {
	content, err := ioutil.ReadFile("../game_data/ArenaTrophy.xml")
	if nil != err {
		log.Error("PlayerScoreMgr LoadWinScore read ArenaTrophy error(%s) !", err.Error())
		return false
	}

	tmp_ws_cfg := &XmlWinScoreConfig{}
	err = xml.Unmarshal(content, tmp_ws_cfg)
	if nil != err {
		log.Error("PlayerScoreMgr LoadWinScore unmarshal AreanTrophy error(%s) !", err.Error())
		return false
	}

	tmp_len := int32(len(tmp_ws_cfg.Items))
	if tmp_len <= 0 {
		log.Error("PlayerScoreMgr LoadWinScore AreanTrophy item zero !")
		return false
	}
	tmp_ws_cfg.Items[tmp_len-1].EndScore = MAX_MATCH_SCORE
	this.WinScores = make([]*XmlWinScoreItem, 0, tmp_len)
	for idx := int32(0); idx < tmp_len; idx++ {
		tmp_ws_cfg.Items[idx].TowerScores = make([]int32, MAX_DESTORY_TOWER_COUNT+1)
		tmp_ws_cfg.Items[idx].TowerScores[0] = tmp_ws_cfg.Items[idx].WinBase
		tmp_ws_cfg.Items[idx].TowerScores[1] = tmp_ws_cfg.Items[idx].WinBase + tmp_ws_cfg.Items[idx].OneTScore
		tmp_ws_cfg.Items[idx].TowerScores[2] = tmp_ws_cfg.Items[idx].WinBase + tmp_ws_cfg.Items[idx].TwoTScore
		tmp_ws_cfg.Items[idx].TowerScores[3] = tmp_ws_cfg.Items[idx].WinBase + tmp_ws_cfg.Items[idx].ThreeTScore
		this.WinScores = append(this.WinScores, &tmp_ws_cfg.Items[idx])
	}

	log.Info("打印积分配置=================")
	for _, val := range this.WinScores {
		log.Info("	%v", *val)
	}
	log.Info("打印积分配置*****************")

	return true
}

func (this *PlayerScoreMgr) LoadScoreAdj() bool {
	content, err := ioutil.ReadFile("../game_data/ArenaCorrection.xml")
	if nil != err {
		log.Error("PlayerScoreMgr LoadScoreAdj Read ArenaCorrection error(%s)", err.Error())
		return false
	}

	tmp_ad_cfg := &XmlWinScoreAdjConfig{}
	err = xml.Unmarshal(content, tmp_ad_cfg)
	if nil != err {
		log.Error("PlayerScoreMgr LoadScoreAdj Unmarshal error(%s) !", err.Error())
		return false
	}

	this.Adjusts = make([]*XmlWinScoreAdjItem, 0, len(tmp_ad_cfg.Items))
	for idx := int32(0); idx < int32(len(tmp_ad_cfg.Items)); idx++ {
		if idx > 0 {
			tmp_ad_cfg.Items[idx-1].UpDiff = tmp_ad_cfg.Items[idx].LowDiff - 1
		}
		this.Adjusts = append(this.Adjusts, &tmp_ad_cfg.Items[idx])
	}

	this.Adjusts[int32(len(this.Adjusts))-1].UpDiff = MAX_MATCH_SCORE

	//log.Info("win score test ", this.GetWinScore(300, 298, 3))
	//log.Info("lost score test ", this.GetLostScore(60, 60, 1))

	log.Info("打印积分调整=================")
	for _, val := range this.Adjusts {
		log.Info("	%v", *val)
	}
	log.Info("打印积分调整*****************")

	return true
}

func (this *PlayerScoreMgr) GetWinScore(my_score, op_score, towers int32) int32 {
	log.Info("PlayerScoreMgr GetWinScore ", my_score, op_score, towers)
	if towers < 0 {
		log.Error("PlayerScoreMgr GetWinScore towers < 0 !")
		return 0
	}

	if towers > MAX_DESTORY_TOWER_COUNT {
		towers = MAX_DESTORY_TOWER_COUNT
	}

	bfind := false
	base_score := int32(0)
	for _, ws := range this.WinScores {
		if nil == ws {
			continue
		}

		if my_score >= ws.StartScore && my_score <= ws.EndScore {
			base_score = ws.TowerScores[towers]
			bfind = true
		}
	}

	if !bfind {
		log.Error("PlayerScoreMgr GetWinScore not find !")
		return 0
	}

	if my_score > op_score {
		diff := my_score - op_score
		for _, aj := range this.Adjusts {
			if nil == aj {
				continue
			}

			if diff >= aj.LowDiff && diff <= aj.UpDiff {
				base_score = base_score * aj.Higher100Per / 10000
				return base_score
			}
		}
	} else {
		diff := op_score - my_score
		for _, aj := range this.Adjusts {
			if nil == aj {
				continue
			}

			if diff >= aj.LowDiff && diff <= aj.UpDiff {
				base_score = base_score * aj.Lower100Per / 10000
				return base_score
			}
		}
	}

	log.Error("PlayerScoreMgr GetWinScore not find adj !")
	return base_score
}

func (this *PlayerScoreMgr) GetLostScore(my_score, op_score, op_towers int32) int32 {
	if op_towers < 0 {
		log.Error("PlayerScoreMgr GetLostScore towers < 0 !")
		return 0
	}

	if op_towers > MAX_DESTORY_TOWER_COUNT {
		op_towers = MAX_DESTORY_TOWER_COUNT
	}

	base_score := int32(-1)
	fail_100per := int32(-1)
	for _, ws := range this.WinScores {
		if nil == ws {
			continue
		}

		if op_score >= ws.StartScore && op_score < ws.EndScore {
			base_score = ws.TowerScores[op_towers]
			if base_score >= 0 && fail_100per >= 0 {
				break
			}
		}

		if my_score >= ws.StartScore && my_score < ws.EndScore {
			fail_100per = ws.FailPer
			if base_score >= 0 && fail_100per >= 0 {
				break
			}
		}
	}

	if base_score < 0 && fail_100per < 0 {
		return 0
	}

	if op_score > my_score {
		diff := op_score - my_score
		for _, aj := range this.Adjusts {
			if nil == aj {
				continue
			}

			if diff >= aj.LowDiff && diff <= aj.UpDiff {
				base_score = base_score * aj.Higher100Per / 10000
			}
		}
	} else {
		diff := my_score - op_score
		for _, aj := range this.Adjusts {
			if nil == aj {
				continue
			}

			if diff >= aj.LowDiff && diff <= aj.UpDiff {
				log.Info("PlayerScoreMgr GetLostScore === ", base_score, aj.Lower100Per)
				base_score = base_score * aj.Lower100Per / 10000
			}
		}
	}

	log.Info("PlayerScoreMgr GetLost", my_score, op_score, op_towers, base_score, fail_100per)
	return base_score * fail_100per / 10000
}

func (this *PlayerScoreMgr) OnPlayerScoreAdd(p *Player, new_score int32) {
	if nil == p || new_score <= 0 {
		log.Error("PlayerScoreMgr OnPlayerScoreAdd param error(%v)!", nil == p)
		return
	}

	retrank, _ := this.PlayerScoreRank.SetUpdateRank(p.Id, new_score)
	if -1 == retrank {
		log.Trace("PlayerScoreMgr OnPlayer[%d] ScoreAdd newscore[%d] not enter 200 rank !", p.Id, new_score)
		return
	}

	req2c := &msg_server_message.PlayerNScoreChg{}
	req2c.PlayerId = proto.Int32(p.Id)
	req2c.PlayerName = proto.String(p.db.GetName())
	req2c.Score = proto.Int32(p.GetMatchScore())
	req2c.TongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
	req2c.TongName = proto.String(p.db.TongInfo.GetTongName())

	center_conn.Send(req2c)

	log.Info("PlayerScoreMgr OnPlayerScoreAdd Send msg to center")

	return
}

func (this *PlayerScoreMgr) PrintCurRank() {
	log.Info("PlayerScoreMgr 打印排行榜 ============ start !")
	for _, val := range this.PlayerScoreRank.GetTopN(200) {
		if nil != val && val.id > 0 {
			log.Info("	rank_item: 名次[%d] Id[%d] 积分[%d] ",
				val.rank, val.id, val.val)
		}
	}
	log.Info("PlayerScoreMgr 打印排行榜 ============ end !")
}

//==============================================================

func (this *PlayerScoreMgr) OnPlayerLogin(p *Player) {
	if nil == p {
		log.Error("PlayerScoreMgr OnPlayerLogin p nil")
		return
	}

	if !this.BSyncFinished {
		log.Error("PlayerScoreMgr OnPlayerLogin not BSyncFinished")
		return
	}

	if p.db.Info.GetLastLegendSwitchUnix() == this.LastSwitchUnix {
		return
	}

	cur_score := p.db.Info.GetMatchScore()
	if cur_score > global_config.LegendBaseScore {
		inc_score := cur_score - global_config.LegendBaseScore
		p.TaskAchieveOnConditionAdd(TASK_ACHIEVE_FINISH_LEGEND_SCORES, inc_score)
		p.db.Info.IncbyCurLegendScore(inc_score)
		p.db.Info.SetLastLegendSwitchUnix(this.LastSwitchUnix)
	}

	return
}

//==============================================================

func (this *PlayerScoreMgr) RegPlayerScoreMsg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SRankInfo, this.C2SRankInfoHandler)

	center_conn.SetMessageHandler(msg_server_message.ID_RetRankItems, this.C2HRetRankItemsHanlder)
}

func (this *PlayerScoreMgr) C2SRankInfoHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SRankInfo)
	if nil == req || nil == c {
		log.Error("PlayerScoreMgr C2SRankInfoHandler (%v)", (nil == req))
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("PlayerScoreMgr C2SRankInfoHandler not login(%d) ip", c.T, c.GetAddr())
		return
	}

	if 1 == req.GetIfLocal() && SMALL_RANK_TYPE_PLAYER_N_SCORE == req.GetRankType() {

		tongrds := this.PlayerScoreRank.GetTopN(200)
		res2cli := &msg_client_message.S2CRankItems{}
		res2cli.RankType = proto.Int32(req.GetRankType())
		res2cli.RankList = make([]*msg_client_message.SmallRankRecord, 0, 50)
		res2cli.IfLocal = proto.Int32(1)
		var tmp_item *msg_client_message.SmallRankRecord
		var tmp_p *Player
		cur_count := int32(0)
		for _, val := range tongrds {
			tmp_p = player_mgr.GetPlayerById(val.id)
			if nil == tmp_p {
				continue
			}

			tmp_item = &msg_client_message.SmallRankRecord{}
			tmp_item.Id = proto.Int32(val.id)
			tmp_item.Rank = proto.Int32(val.rank)
			tmp_item.Name = proto.String(tmp_p.db.GetName())
			tmp_item.Score = proto.Int32(val.val)
			tmp_item.TongIcon = proto.Int32(tmp_p.db.TongInfo.GetTongIcon())
			tmp_item.TongName = proto.String(tmp_p.db.TongInfo.GetTongName())

			res2cli.RankList = append(res2cli.RankList, tmp_item)
			cur_count++
			if cur_count > 50 {
				p.Send(res2cli)
				cur_count = 0
				res2cli.RankList = make([]*msg_client_message.SmallRankRecord, 0, 50)
			}
		}

		if cur_count > 0 {
			p.Send(res2cli)
		}
	} else {
		req2co := &msg_server_message.GetRankInfo{}
		req2co.PlayerId = proto.Int32(p.Id)
		req2co.RankType = proto.Int32(req.GetRankType())
		req2co.IfLastRank = proto.Int32(req.GetIfGetLast())

		center_conn.Send(req2co)
	}

	return
}

func (this *PlayerScoreMgr) C2HRetRankItemsHanlder(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RetRankItems)
	if nil == c || nil == res {
		log.Error("PlayerScoreMgr C2HRetRankItemsHanlder param error !")
		return
	}

	pid := res.GetPlayerId()
	p := player_mgr.GetPlayerById(pid)
	if nil == p {
		log.Error("PlayerScoreMgr C2HRetRankItemsHanlder p[%d] nil !", pid)
		return
	}

	item_len := int32(len(res.ItemList))
	if len(res.ItemList) < 1 {
		log.Error("C2HRetRankItemsHanlder len(ItemList)(%d) < 1", len(res.ItemList))
		return
	}

	res2cli := &msg_client_message.S2CRankItems{}
	res2cli.RankType = proto.Int32(res.GetRankType())
	res2cli.RankList = make([]*msg_client_message.SmallRankRecord, 0, item_len)
	res2cli.IfLocal = proto.Int32(0)
	res2cli.IfGetLast = proto.Int32(res.GetIfGetLast())
	var tmp_item *msg_client_message.SmallRankRecord
	for _, val := range res.ItemList {
		if nil == val {
			continue
		}

		tmp_item = &msg_client_message.SmallRankRecord{}
		tmp_item.Id = proto.Int32(val.GetId())
		tmp_item.Rank = proto.Int32(val.GetRank())
		tmp_item.Name = proto.String(val.GetName())
		tmp_item.Score = proto.Int32(val.GetScore())
		tmp_item.TongIcon = proto.Int32(val.GetTongIcon())
		tmp_item.TongName = proto.String(val.GetTongName())

		res2cli.RankList = append(res2cli.RankList, tmp_item)
	}

	p.Send(res2cli)
	return
}
