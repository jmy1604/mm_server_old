package main

import (
	"libs/log"
	"libs/timer"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

func (this *DBC) on_preload() (err error) {
	var p *Player
	for _, db := range this.Players.m_rows {
		if nil == db {
			log.Error("DBC on_preload Players have nil db !")
			continue
		}

		p = new_player_with_db(db.m_PlayerId, db)
		if nil == p {
			continue
		}

		player_mgr.Add2IdMap(p)
	}

	var tong *Tong
	for tong_id, db := range this.Tongs.m_rows {
		if nil == db {
			log.Error("DBC on_preload Tongs have ni db")
			continue
		}

		empty_pos := db.TongMembers.GetEmptyIdMap()
		tong = NewTongWithDbAndEmptyPos(tong_id, db, empty_pos)
		if nil == tong {
			log.Error("DBC on_preload Tongs NewTongWithDbAndEmptyPos nil !")
			continue
		}

		tong_mgr.AddTongNoLock(tong)
	}

	//tong_mgr.InitRankWithDb()

	return
}

func (this *dbPlayerInfoColumn) FillBaseInfo(bi *msg_client_message.PlayerBaseInfo) {
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.FillBaseInfo")
	defer this.m_row.m_lock.UnSafeRUnlock()
	tmp_data := this.m_data
	bi.MatchScore = proto.Int32(tmp_data.MatchScore)
	bi.Coins = proto.Int32(tmp_data.Coin)
	bi.Diamonds = proto.Int32(tmp_data.Diamond)
	bi.CurUseCardTeam = proto.Int32(tmp_data.CurUseCardTeam)
	bi.MyExp = proto.Int32(tmp_data.Exp)
	bi.ArenaLvl = proto.Int32(int32(tmp_data.ArenaLvl))
	bi.MyLvl = proto.Int32(tmp_data.Lvl)
	bi.WinCount = proto.Int32(int32(tmp_data.WinCount))
	bi.CurLegBestScore = proto.Int32(int32(tmp_data.CurBestLegScore))
	bi.LastLegBestScore = proto.Int32(int32(tmp_data.LastBestLegScore))
	bi.IsTongCaptain = proto.Int32(int32(tmp_data.IfCaptain))
	bi.OfenCardCfgId = proto.Int32(tmp_data.OftenCard)
	bi.DonateCount = proto.Int32(tmp_data.DonateCount)
	bi.CheModWinCount = proto.Int32(int32(tmp_data.ChellWinCount))
	bi.CheModeOfenCardCfg = proto.Int32(tmp_data.ChellOfenCard)
	bi.Camp = proto.Int32(int32(tmp_data.Camp))
	bi.CurChgNameCount = proto.Int32(int32(tmp_data.ChangeNameCount))
	bi.CardToken1 = proto.Int32(tmp_data.CardToken1)
	bi.CardToken2 = proto.Int32(tmp_data.CardToken2)
	bi.CardToken3 = proto.Int32(tmp_data.CardToken3)
	bi.CardToken4 = proto.Int32(tmp_data.CardToken4)
	bi.CreateUnix = proto.Int32(tmp_data.CreateUnix)

	return
}

func (this *dbPlayerInfoColumn) SubMatchScore(v int32) int32 {
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SubMatchScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.MatchScore = this.m_data.MatchScore - v
	if this.m_data.MatchScore < 0 {
		this.m_data.MatchScore = 0
	}

	this.m_changed = true

	return this.m_data.MatchScore
}

func (this *dbPlayerInfoColumn) SubCoin(v int32) int32 {
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SubCoin")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Coin = this.m_data.Coin - v
	if this.m_data.Coin < 0 {
		this.m_data.Coin = 0
	}

	this.m_changed = true
	return this.m_data.Coin
}

func (this *dbPlayerInfoColumn) SubDiamond(v int32) int32 {
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SubDiamond")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Diamond = this.m_data.Diamond - v
	if this.m_data.Diamond < 0 {
		this.m_data.Diamond = 0
	}
	this.m_changed = true
	return this.m_data.Diamond
}

func (this *dbPlayerCardColumn) GetAllIIndexMap() map[int32]int32 {
	ret_map := make(map[int32]int32)
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for k, _ := range this.m_data {
		ret_map[k] = 1
	}
	return ret_map
}

func (this *dbPlayerCardColumn) GetCardsLvls(cards []int32) (lvls []int32) {
	cards_len := len(cards)
	if cards_len <= 0 {
		return
	}

	lvls = make([]int32, cards_len)

	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetCardsLvls")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for idx, cfgid := range cards {
		db_card := this.m_data[cfgid]
		if nil == db_card {
			lvls[idx] = 1
			continue
		}

		lvls[idx] = db_card.CardLvl
	}

	return
}

func (this *dbPlayerCardColumn) GetAllClientCardMsg() []*msg_client_message.PlayerCard {
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetAllClientCardMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	ret_cs := make([]*msg_client_message.PlayerCard, 0, len(this.m_data))
	var tmp_card *msg_client_message.PlayerCard
	for _, c_val := range this.m_data {
		if nil == c_val {
			continue
		}

		tmp_card = &msg_client_message.PlayerCard{}
		tmp_card.CardCfgId = proto.Int32(c_val.ConfigId)
		tmp_card.CardCount = proto.Int32(c_val.CardCount)
		tmp_card.CardLvl = proto.Int32(c_val.CardLvl)
		ret_cs = append(ret_cs, tmp_card)
	}

	return ret_cs
}

func (this *dbPlayerCardTeamColumn) CheckRemoveCardInTeam(cfgid int32) {
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardTeamColumn.CheckRemoveCardInTeam")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for _, c_team := range this.m_data {
		if nil == c_team {
			continue
		}

		len_t := int32(len(c_team.CardCfgIds))
		set_idx := int32(0)
		idx := int32(0)
		for ; idx < len_t; idx++ {
			if c_team.CardCfgIds[idx] != cfgid {
				c_team.CardCfgIds[set_idx] = c_team.CardCfgIds[idx]
				set_idx++
			}
		}

		for ; set_idx < idx; set_idx++ {
			c_team.CardCfgIds[set_idx] = 0
		}
	}

	return
}

func (this *dbPlayerCardTeamColumn) GetAllClientTeamMsg() []*msg_client_message.CardTeam {
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardTeamColumn.GetAllClientTeamMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	ret_ts := make([]*msg_client_message.CardTeam, 0, len(this.m_data))
	var tmp_team *msg_client_message.CardTeam
	for _, c_team := range this.m_data {
		if nil == c_team {
			continue
		}

		tmp_team = &msg_client_message.CardTeam{}
		tmp_team.TeamId = proto.Int32(c_team.TeamId)
		tmp_team.CardIds = c_team.CardCfgIds
		ret_ts = append(ret_ts, tmp_team)
	}

	return ret_ts
}

func (this *dbPlayerShopLatticeColumn) GetAllClientSellingCardMsg() (ret_msg *msg_client_message.S2CSellingCards) {
	var tmp_s_card *msg_client_message.S2CSellCard
	this.m_row.m_lock.UnSafeLock("dbPlayerShopLatticeColumn.GetAllClientShopCardMsg")
	defer this.m_row.m_lock.UnSafeUnlock()
	if len(this.m_data) < 1 {
		return nil
	}

	ret_msg = &msg_client_message.S2CSellingCards{}
	ret_msg.SellCards = make([]*msg_client_message.S2CSellCard, 0, len(this.m_data))
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		tmp_s_card = &msg_client_message.S2CSellCard{}
		tmp_s_card.BuyNum = proto.Int32(val.TodayBuyNum)
		tmp_s_card.CardId = proto.Int32(val.CardCfgId)
		tmp_s_card.Pos = proto.Int32(val.Lattice)
		ret_msg.SellCards = append(ret_msg.SellCards, tmp_s_card)
	}

	return
}

func (this *dbPlayerChestColumn) GetEmptyPos() int32 {
	this.m_row.m_lock.UnSafeRLock("dbPlayerChestColumn.GetEmptyPos")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for slot := int32(1); slot <= global_config.ChestSlotCount; slot++ {
		if nil == this.m_data[slot] {
			this.m_data[slot] = &dbPlayerChestData{Pos: slot}
			return slot
		}
	}

	return -1
}

func (this *dbPlayerChestColumn) IfHaveOpeningChest() bool {
	this.m_row.m_lock.UnSafeRLock("dbPlayerChestColumn.IfHaveOpeningChest")
	defer this.m_row.m_lock.UnSafeRUnlock()

	cur_unix := int32(time.Now().Unix())
	var tmp_chest_cfg *XmlChestItem
	for _, chest := range this.m_data {
		if nil == chest {
			continue
		}

		tmp_chest_cfg = chest_cfg_mgr.Map[chest.ChestId]
		if nil == tmp_chest_cfg {
			continue
		}

		if chest.OpenSec > 0 {
			left_sec := tmp_chest_cfg.UnlockSec - (cur_unix - chest.OpenSec)
			if left_sec > 0 {
				log.Info("dbPlayerChestColumn IfHaveOpeningChest chest id[%d]", chest.ChestId, chest.Pos)
				return true
			}
		}
	}

	return false
}

func (this *dbPlayerChestColumn) FillAllClientChestMsg(ret_msg *msg_client_message.S2CChestsSync) {
	var tmp_chest *msg_client_message.PlayerChest
	var tmp_chest_cfg *XmlChestItem
	var left_sec int32
	cur_unix := int32(time.Now().Unix())
	this.m_row.m_lock.UnSafeRLock("dbPlayerChestColumn.GetAllClientChestMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()

	if len(this.m_data) < 1 {
		return
	}

	ret_msg.Chests = make([]*msg_client_message.PlayerChest, 0, len(this.m_data))
	for _, chest := range this.m_data {
		if nil == chest {
			continue
		}

		tmp_chest_cfg = chest_cfg_mgr.Map[chest.ChestId]
		if nil == tmp_chest_cfg {
			continue
		}

		tmp_chest = &msg_client_message.PlayerChest{}
		tmp_chest.ChestPos = proto.Int32(chest.Pos)
		tmp_chest.ChestCfgId = proto.Int32(chest.ChestId)
		left_sec = tmp_chest_cfg.UnlockSec
		if chest.OpenSec > 0 {
			left_sec = tmp_chest_cfg.UnlockSec - (cur_unix - chest.OpenSec)
			//log.Info("宝箱==[%d] 开启时间 配置[%d] 开始[%d] 当前[%d] 实际值[%d]", chest.ChestId, tmp_chest_cfg.UnlockSec, chest.OpenSec, cur_unix, left_sec)
			if left_sec < 0 {
				left_sec = 0
			}
			tmp_chest.LeftOpenTime = proto.Int32(left_sec)
		} else {
			tmp_chest.LeftOpenTime = proto.Int32(-1)
		}

		ret_msg.Chests = append(ret_msg.Chests, tmp_chest)
	}

	return
}

func (this *dbTongTongMemberColumn) GetEmptyIdMap() map[int32]*EnterTongAgreeItem {
	ret_empty_map := make(map[int32]*EnterTongAgreeItem)
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetEmptyIdMap")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for idx := int32(1); idx <= global_config.MaxTongMemberCount; idx++ {
		if nil == this.m_data[idx] {
			ret_empty_map[idx] = &EnterTongAgreeItem{}
		}
	}

	return ret_empty_map
}

func (this *dbTongTongMemberColumn) GetByPlayerId(pid int32) (v *dbTongTongMemberData) {
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetByPlayerId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		if val.PlayerId == pid {
			v = &dbTongTongMemberData{}
			val.clone_to(v)
			break
		}
	}

	return
}

func (this *dbTongTongMemberColumn) GetMemberIdByPlayerId(pid int32) int32 {
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetMemberIdByPlayerId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		if val.PlayerId == pid {
			return val.MemberId
		}
	}

	return 0
}

func (this *dbTongTongMemberColumn) AddWithId(v *dbTongTongMemberData) (id int32) {
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.AddWithId")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data[int32(v.MemberId)] = v
	this.m_changed = true
	return
}

func (this *dbTongTongDataColumn) SetInitTongData(msg *msg_server_message.CreateTong) {
	if nil == msg {
		log.Error("dbTongTongDataColumn SetInitTongData msg nil !")
		return
	}

	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetInitTongData")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Name = msg.GetTongName()
	this.m_data.Icon = int16(msg.GetIcon())
	this.m_data.JoinType = int8(msg.GetJoinType())
	this.m_data.JoinScore = int16(msg.GetJoinScore())
	this.m_data.Pos = int16(msg.GetPos())
	this.m_data.CaptainId = msg.GetCreatorId()
	this.m_data.PubContent = msg.GetTongPub()

	return
}

func (this *dbTongTongMemberColumn) GetCurTongScore() int32 {
	total_score := int32(0)
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetCurTongScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for _, d := range this.m_data {
		if nil != d && d.PlayerId > 0 {
			total_score += int32(d.Score)
		}
	}

	return total_score
}

func (this *dbTongTongMemberColumn) GetCurMemberCount() int32 {

	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetCurMemberCount")
	defer this.m_row.m_lock.UnSafeRUnlock()

	return int32(len(this.m_data))
}

func (this *dbTongTongMemberColumn) FillAllTongMemberMsg(msg *msg_server_message.RetTongInfo, online_pids []int32) {
	n := 0
	total_score := int32(0)
	var tmp_m *msg_server_message.TongMemberInfo
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.FillAllTongMemberMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for _, d := range this.m_data {
		if nil != d && d.PlayerId > 0 {
			n++
			total_score += int32(d.Score)
		}
	}

	msg.Members = make([]*msg_server_message.TongMemberInfo, 0, n)
	for _, d := range this.m_data {
		if nil != d && d.PlayerId > 0 {
			tmp_m = &msg_server_message.TongMemberInfo{}
			tmp_m.Donate = proto.Int32(int32(d.Donate))
			tmp_m.Name = proto.String(d.PlayerName)
			tmp_m.Score = proto.Int32(int32(d.Score))
			tmp_m.Title = proto.Int32(int32(d.MemberType))
			tmp_m.PlayerId = proto.Int32(int32(d.PlayerId))
			for _, pid := range online_pids {
				if pid == d.PlayerId {
					tmp_m.IfOnline = proto.Int32(1)
					break
				}
			}
			msg.Members = append(msg.Members, tmp_m)
		}
	}

	msg.TongScore = proto.Int32(total_score)
	return
}

func (this *dbTongTongChatRecordColumn) FillAllChatMsg(msg *msg_server_message.RetTongInfo) {
	var tmp_rd *msg_server_message.TongChatData
	this.m_row.m_lock.UnSafeRLock("dbTongTongChatRecordColumn.FillAllChatMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	msg.ChatRds = make([]*msg_server_message.TongChatData, 0, len(this.m_data))

	for _, v := range this.m_data {
		if nil == v {
			continue
		}

		tmp_rd = &msg_server_message.TongChatData{}
		tmp_rd.SenderId = proto.Int32(v.SenderId)
		tmp_rd.SenderName = proto.String(v.SenderName)
		tmp_rd.Content = proto.String(v.MsgContent)
		tmp_rd.SendUnix = proto.Int32(v.SendTime)
		msg.ChatRds = append(msg.ChatRds, tmp_rd)
	}
	return
}

func (this *dbTongTongCardReqColumn) FillAllCardReqMsg(msg *msg_server_message.RetTongInfo) {
	var tmp_req *msg_server_message.TongRequestCard
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.FillAllCardReqMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	msg.CardReqs = make([]*msg_server_message.TongRequestCard, 0, len(this.m_data))

	for _, v := range this.m_data {
		if nil == v {
			continue
		}

		tmp_req = &msg_server_message.TongRequestCard{}
		tmp_req.PlayerId = proto.Int32(v.PlayerId)
		tmp_req.PlayerName = proto.String(v.PlayerName)
		tmp_req.CardCfgId = proto.Int32(v.CardCfgId)
		tmp_req.SendUnix = proto.Int32(v.ReqUnix)
		tmp_req.CurGetNum = proto.Int32(v.CurGetNum)
		tmp_req.MaxGetNum = proto.Int32(v.MaxGetNum)
		msg.CardReqs = append(msg.CardReqs, tmp_req)
	}
	return
}

func (this *dbTongTongJoinColumn) FillAllTongEnterReqMsg(msg *msg_server_message.RetTongInfo) {
	var tmp_req *msg_server_message.TongRequestJoin
	this.m_row.m_lock.UnSafeRLock("dbTongTongJoinColumn.FillAllTongEnterReqMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	msg.JoinList = make([]*msg_server_message.TongRequestJoin, 0, len(this.m_data))
	for _, v := range this.m_data {
		if nil == v {
			continue
		}

		tmp_req = &msg_server_message.TongRequestJoin{}
		tmp_req.PlayerId = proto.Int32(v.PlayerId)
		tmp_req.PlayerName = proto.String(v.PlayerName)
		tmp_req.Score = proto.Int32(v.PlayerScore)
		tmp_req.JoinSec = proto.Int32(v.JoinSec)

		msg.JoinList = append(msg.JoinList, tmp_req)
	}
	return
}

func (this *dbTongTongMemberColumn) ChkRemoveByPlayerId(pid int32) (cur_count, pos int32) {
	delids := make(map[int32]bool)
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.ChkRemoveByPlayerId")
	defer this.m_row.m_lock.UnSafeUnlock()

	for _, val := range this.m_data {
		if nil == val {
			delids[val.MemberId] = true
			continue
		}

		if val.PlayerId == pid {
			pos = val.MemberId
			delids[val.MemberId] = true
		}
	}

	for pid, _ := range delids {
		delete(this.m_data, pid)
	}

	this.m_changed = true

	cur_count = int32(len(this.m_data))
	return
}

func (this *dbTongTongMemberColumn) ClearDonate() {
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.ClearDonate")
	defer this.m_row.m_lock.UnSafeUnlock()

	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		if val.Donate > 0 {
			val.Donate = 0
			this.m_changed = true
		}
	}

	return
}

func (this *dbTongTongMemberColumn) GiveCapitain(old_c_id int32) int32 {
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.GiveCapitain")
	defer this.m_row.m_lock.UnSafeUnlock()

	for _, val := range this.m_data {
		if nil != val && old_c_id != val.PlayerId {
			val.MemberType = TONG_MEMBER_CAPTAIN
			return val.PlayerId
		}
	}

	return -1
}

func (this *dbPlayerMailColumn) GetAviMailId() int32 {
	min_id := int32(0)
	min_sec := int32(time.Now().Unix())
	var cur_mail *dbPlayerMailData
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetAviMailId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for idx := int32(1); idx <= global_config.MaxMailCount; idx++ {
		cur_mail = this.m_data[idx]
		if nil == cur_mail {
			return idx
		}

		if cur_mail.SendUnix < min_sec {
			min_id = idx
			min_sec = cur_mail.SendUnix
		}
	}

	if min_id > 0 {
		delete(this.m_data, min_id)
	}

	return min_id
}

func (this *dbPlayerMailColumn) FillMsgList() *msg_client_message.S2CMailList {
	rm_mailids := make(map[int32]int32)
	cur_unix := int32(time.Now().Unix())
	var tmp_mail *msg_client_message.S2CMailAdd
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.FillMsgList")
	defer this.m_row.m_lock.UnSafeUnlock()

	tmp_len := int32(len(this.m_data))
	if tmp_len < 1 {
		return nil
	}

	ret_msg := &msg_client_message.S2CMailList{}
	ret_msg.MailList = make([]*msg_client_message.S2CMailAdd, 0, tmp_len)
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		if cur_unix >= val.OverUnix {
			rm_mailids[val.MailId] = 1
		}

		tmp_mail = &msg_client_message.S2CMailAdd{}
		tmp_mail.Chests = val.Chests
		tmp_mail.Coin = proto.Int32(val.Coin)
		tmp_mail.Content = proto.String(val.Content)
		tmp_mail.Diamond = proto.Int32(val.Diamond)
		tmp_mail.MailId = proto.Int32(val.MailId)
		tmp_mail.SenderName = proto.String(val.SenderName)
		tmp_mail.SendUnix = proto.Int32(val.SendUnix)
		tmp_mail.Title = proto.String(val.MailTitle)
		tmp_mail.OverUix = proto.Int32(val.OverUnix)
		tmp_mail.MailType = proto.Int32(int32(val.MailType))
		tmp_mail.ReadState = proto.Int32(int32(val.ReadState))
		tmp_mail.SenderId = proto.Int32(val.SenderId)
		ret_msg.MailList = append(ret_msg.MailList, tmp_mail)
	}

	if len(rm_mailids) > 0 {
		for mail_id, _ := range rm_mailids {
			delete(this.m_data, mail_id)
		}
		this.m_changed = true
	}

	if len(ret_msg.MailList) > 0 {
		return ret_msg
	}

	return nil
}

func (this *dbPlayerFightRecordColumn) ForceAdd(v *dbPlayerFightRecordData) {
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.ForceAdd")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data[int32(v.RecordId)] = v
	this.m_changed = true
	return
}

func (this *dbPlayerFightRecordColumn) GetAviRecordId() int32 {
	min_id := int32(0)
	min_sec := int32(time.Now().Unix())

	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetAviRecordId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	var cur_rd *dbPlayerFightRecordData
	for idx := int32(1); idx <= global_config.MaxFightRdCount; idx++ {
		cur_rd = this.m_data[idx]
		if nil == cur_rd {
			return idx
		}

		if cur_rd.CreateUnix < min_sec {
			min_id = idx
			min_sec = cur_rd.CreateUnix
		}
	}

	if min_id > 0 {
		delete(this.m_data, min_id)
	}

	return min_id
}

func (this *dbPlayerFightRecordColumn) FillRetClientMsg() *msg_client_message.S2CRetFightRecords {
	var tmp_rd *dbPlayerFightRecordData
	var tmp_rd_msg *msg_client_message.FightRecord
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.FillRetClientMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()

	tmp_len := int32(len(this.m_data))
	if tmp_len <= 0 {
		return nil
	}

	ret_msg := &msg_client_message.S2CRetFightRecords{}
	ret_msg.Records = make([]*msg_client_message.FightRecord, 0, tmp_len)
	for idx := int32(1); idx <= global_config.MaxFightRdCount; idx++ {
		tmp_rd = this.m_data[idx]
		if nil == tmp_rd {
			continue
		}

		tmp_rd_msg = &msg_client_message.FightRecord{}
		tmp_rd_msg.RecordId = proto.Int32(tmp_rd.RecordId)
		tmp_rd_msg.CreateUnix = proto.Int32(tmp_rd.CreateUnix)
		tmp_rd_msg.MyCardLvls = tmp_rd.MyCardLvls
		tmp_rd_msg.MyCards = tmp_rd.MyCards
		tmp_rd_msg.MyTongIcon = proto.Int32(tmp_rd.MyTongIcon)
		tmp_rd_msg.MyTongId = proto.Int32(tmp_rd.MyTongId)
		tmp_rd_msg.MyTongName = proto.String(tmp_rd.MyTongName)
		tmp_rd_msg.OpCardLvls = tmp_rd.OptCardLvls
		tmp_rd_msg.OpCards = tmp_rd.OptCards
		tmp_rd_msg.OpTongIcon = proto.Int32(tmp_rd.OpTongIcon)
		tmp_rd_msg.OpTongId = proto.Int32(tmp_rd.OptTongId)
		tmp_rd_msg.OpTongName = proto.String(tmp_rd.OptTongName)
		tmp_rd_msg.OpName = proto.String(tmp_rd.OptPlayerName)
		tmp_rd_msg.MyName = proto.String(tmp_rd.MyPlayerName)
		tmp_rd_msg.MatchType = proto.Int32(tmp_rd.MatchType)
		tmp_rd_msg.MyTowers = proto.Int32(tmp_rd.MyTowers)
		tmp_rd_msg.OpTowers = proto.Int32(tmp_rd.OpTowers)
		tmp_rd_msg.MyMatchScore = proto.Int32(tmp_rd.MyMathScore)
		tmp_rd_msg.OpMatchScore = proto.Int32(tmp_rd.OpMathScore)
		tmp_rd_msg.MyScoreChg = proto.Int32(tmp_rd.MyMathScoreChg)
		ret_msg.Records = append(ret_msg.Records, tmp_rd_msg)
	}

	if len(ret_msg.Records) < 1 {
		return nil
	}

	return ret_msg
}

func (this *dbPlayerDialyTaskColumn) ChkResetDialyTask() {
	rm_ids := make(map[int32]bool)
	this.m_row.m_lock.UnSafeLock("dbPlayerDialyTaskColumn.ChkResetDialyTask")
	defer this.m_row.m_lock.UnSafeUnlock()

	for task_id, val := range this.m_data {
		if nil == val {
			rm_ids[task_id] = true
			continue
		}

		tmp_cfg := achieve_task_mgr.DialyTaskMap[val.TaskId]
		if nil == tmp_cfg {
			rm_ids[task_id] = true
			continue
		}

		if val.Value < tmp_cfg.FinishNeedCount {
			rm_ids[task_id] = true
			continue
		}

		if val.RewardUnix > 0 {
			rm_ids[task_id] = true
			continue
		}

	}

	for task_id, _ := range rm_ids {
		delete(this.m_data, task_id)
	}

	this.m_changed = true

	return
}

func (this *dbPlayerDialyTaskColumn) FillDialyTaskMsg() *msg_client_message.S2CSyncDialyTask {
	var tmp_item *msg_client_message.DialyTaskData
	this.m_row.m_lock.UnSafeRLock("dbPlayerDialyTaskColumn.ChkResetDialyTask")
	defer this.m_row.m_lock.UnSafeRUnlock()
	ret_msg := &msg_client_message.S2CSyncDialyTask{}
	ret_msg.TaskList = make([]*msg_client_message.DialyTaskData, 0, len(this.m_data))
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		tmp_item = &msg_client_message.DialyTaskData{}
		tmp_item.TaskId = proto.Int32(val.TaskId)
		tmp_item.TaskValue = proto.Int32(val.Value)
		tmp_item.RewardUnix = proto.Int32(val.RewardUnix)
		ret_msg.TaskList = append(ret_msg.TaskList, tmp_item)
	}

	return ret_msg
}

func (this *dbPlayerAchieveColumn) FillAchieveMsg() *msg_client_message.S2CSyncAchieveData {
	ret_msg := &msg_client_message.S2CSyncAchieveData{}
	var tmp_item *msg_client_message.AchieveData
	this.m_row.m_lock.UnSafeRLock("dbPlayerAchieveColumn.FillAchieveMsg")
	defer this.m_row.m_lock.RUnlock()

	tmp_len := int32(len(this.m_data))
	if tmp_len < 1 {
		return nil
	}

	ret_msg.AchieveList = make([]*msg_client_message.AchieveData, 0, tmp_len)
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		tmp_item = &msg_client_message.AchieveData{}
		tmp_item.AchieveId = proto.Int32(val.AchieveId)
		tmp_item.AchieveValue = proto.Int32(val.Value)
		tmp_item.RewardUnix = proto.Int32(val.RewardUnix)
		ret_msg.AchieveList = append(ret_msg.AchieveList, tmp_item)
	}

	return ret_msg
}

func (this *dbPlayerSevenActivityColumn) FillSevenMsg(p *Player) *msg_client_message.S2CSyncSevenActivity {
	create_unix := p.db.Info.GetCreateUnix()
	ret_msg := &msg_client_message.S2CSyncSevenActivity{}
	var tmp_act *msg_client_message.ActivityData
	this.m_row.m_lock.UnSafeRLock("dbPlayerSevenActivityColumn.FillSevenMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	ret_msg.ActivityList = make([]*msg_client_message.ActivityData, 0, len(this.m_data))
	for _, v := range this.m_data {
		if nil == v {
			continue
		}

		tmp_act = &msg_client_message.ActivityData{}
		tmp_act.ActivityId = proto.Int32(v.ActivityId)
		tmp_act.ActivityValue = proto.Int32(v.Value)
		tmp_act.RewardUnix = proto.Int32(v.RewardUnix)
		tmp_act.LeftDays = proto.Int32(cfg_player_act_mgr.GetSevenDayLeftDays(timer.GetDayFrom1970WithCfgAndSec(0, create_unix), timer.GetDayFrom1970WithCfg(int32(time.Now().Unix())), v.ActivityId))
		ret_msg.ActivityList = append(ret_msg.ActivityList, tmp_act)
	}
	return ret_msg
}

func (this *dbTongTongChatRecordColumn) AddNewChatRdByMsg(msg *msg_server_message.TongChatSend) {
	if nil == msg {
		log.Error("dbTongTongChatRecordColumn AddNewChatRdByMsg msg nil")
		return
	}

	min_idx := int32(-1)
	min_sec := int32(time.Now().Unix())
	cur_unix := min_sec
	var tmp_rd *dbTongTongChatRecordData
	this.m_row.m_lock.UnSafeLock("dbTongTongChatRecordColumn.AddNewChatRdByMsg")
	defer this.m_row.m_lock.UnSafeUnlock()

	for idx := int32(1); idx < global_config.MaxTongChatRdNum; idx++ {
		tmp_rd = this.m_data[idx]
		if nil == tmp_rd {
			tmp_rd = &dbTongTongChatRecordData{}
			tmp_rd.Index = idx
			tmp_rd.MsgContent = msg.GetContent()
			tmp_rd.SenderId = msg.GetPlayerId()
			tmp_rd.SenderName = msg.GetPlayerName()
			tmp_rd.SendTime = cur_unix
			this.m_data[tmp_rd.Index] = tmp_rd
			this.m_changed = true
			return
		}

		if tmp_rd.SendTime < min_sec {
			min_sec = tmp_rd.SendTime
			min_idx = idx
		}
	}

	if min_idx != -1 {
		tmp_rd = &dbTongTongChatRecordData{}
		tmp_rd.Index = min_idx
		tmp_rd.MsgContent = msg.GetContent()
		tmp_rd.SenderId = msg.GetPlayerId()
		tmp_rd.SenderName = msg.GetPlayerName()
		tmp_rd.SendTime = cur_unix
		this.m_data[min_idx] = tmp_rd
	}

	this.m_changed = true

	return
}

func (this *dbTongTongCardReqColumn) AddNewCardReqBymsg(msg *msg_server_message.TongCardReq) {
	if nil == msg {
		log.Error("dbTongTongCardReqColumn AddNewCardReqBymsg msg nil !")
		return
	}
	new_req := &dbTongTongCardReqData{}
	new_req.PlayerId = msg.GetPlayerId()
	new_req.PlayerName = msg.GetPlayerName()
	new_req.CardCfgId = msg.GetCardCfgId()
	new_req.MaxGetNum = msg.GetMaxGetNum()
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.AddNewCardReqBymsg")
	defer this.m_row.m_lock.UnSafeUnlock()

	this.m_data[new_req.PlayerId] = new_req
	this.m_changed = true
	return
}

func (this *dbTongTongCardReqColumn) ChkDoDonate(msg *msg_server_message.TongDonateCard) bool {
	if nil == msg {
		log.Error("dbTongTongCardReqColumn ChkDoDonate msg nil !")
		return false
	}
	pid := msg.GetTgtPlayerId()
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.ChkDoDonate")
	defer this.m_row.m_lock.UnSafeUnlock()

	cur_req := this.m_data[pid]
	if nil == cur_req || cur_req.CurGetNum >= cur_req.MaxGetNum {
		return false
	}

	cur_req.CurGetNum++

	return true
}

func (this *dbPlayerCardColumn) GetCardKindNum() int32 {
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetCardKindNum")
	defer this.m_row.m_lock.UnSafeRUnlock()

	return int32(len(this.m_data))
}

func (this *dbPlayerCardColumn) GetTotalCount() int32 {
	total_count := int32(0)
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetTotalCount")
	defer this.m_row.m_lock.UnSafeRUnlock()

	for _, ival := range this.m_data {
		total_count += ival.CardCount
	}

	return total_count
}

func (this *dbPlayerTongDonateColumn) ChkTimeOver() {
	rm_ids := make(map[int32]bool)
	cur_unix := int32(time.Now().Unix())
	this.m_row.m_lock.UnSafeLock("dbPlayerTongDonateColumn.Reset")
	defer this.m_row.m_lock.UnSafeUnlock()
	for idx, val := range this.m_data {
		if nil == val {
			rm_ids[idx] = true
			continue
		}

		if cur_unix-val.DonateUnix > global_config.DonationRequestCD {
			rm_ids[idx] = true
		}
	}

	for idx, _ := range this.m_data {
		delete(this.m_data, idx)
	}

	return
}

func (this *dbPlayerTongDonateColumn) FillAllClientMsg(msg *msg_client_message.S2CRetTongInfo) {
	var tmp_d *msg_client_message.TongDonateInfo
	tmp_len := int32(0)
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongDonateColumn.FillAllClientMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	tmp_len = int32(len(this.m_data))
	if tmp_len <= 0 {
		return
	}

	msg.DonateInfos = make([]*msg_client_message.TongDonateInfo, 0, tmp_len)
	for _, v := range this.m_data {
		if nil == v {
			continue
		}

		tmp_d = &msg_client_message.TongDonateInfo{}
		tmp_d.PlayerId = proto.Int32(v.PlayerId)
		tmp_d.DonateNum = proto.Int32(v.DonateNum)
		msg.DonateInfos = append(msg.DonateInfos, tmp_d)
	}
	return
}

func (this *dbPlayerBeTongDonateColumn) AddByMsg(msg *msg_server_message.NotifyTongDonateCard) {
	if nil == msg {
		log.Error("dbPlayerBeTongDonateColumn AddByMsg msg nil !")
		return
	}

	this.m_row.m_lock.UnSafeLock("dbPlayerBeTongDonateColumn.AddByMsg")
	defer this.m_row.m_lock.UnSafeUnlock()
	cur_rd := this.m_data[msg.GetPlayerId()]
	if nil != cur_rd {
		cur_rd.DonateNum++
	} else {
		new_rd := &dbPlayerBeTongDonateData{}
		new_rd.DonateNum = 1
		new_rd.PlayerId = msg.GetPlayerId()
		new_rd.PlayerName = msg.GetPlayerName()
		this.m_data[new_rd.PlayerId] = new_rd
	}

	this.m_changed = true
	return
}

func (this *dbPlayerBeTongDonateColumn) FillAllMsgAndRest(msg *msg_client_message.S2CRetBeDonate) {
	if nil == msg {
		log.Error("dbPlayerBeTongDonateColumn FillAllMsgAndRest msg nil !")
		return
	}

	var tmp_bd *msg_client_message.BeDonate
	this.m_row.m_lock.UnSafeLock("dbPlayerBeTongDonateColumn.FillAllMsgAndRest")
	defer this.m_row.m_lock.UnSafeUnlock()
	tmp_len := int32(len(this.m_data))
	if tmp_len < 1 {
		return
	}

	msg.BeDonateList = make([]*msg_client_message.BeDonate, 0, tmp_len)
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		tmp_bd = &msg_client_message.BeDonate{}
		tmp_bd.PlayerName = proto.String(val.PlayerName)
		tmp_bd.DonateNum = proto.Int32(val.DonateNum)
		msg.BeDonateList = append(msg.BeDonateList, tmp_bd)
	}

	this.m_data = make(map[int32]*dbPlayerBeTongDonateData)
	this.m_changed = true
	return
}

func (this *dbTongTongChestOpenColumn) ForceAddChestOpen(pid, open_unix int32) {
	this.m_row.m_lock.UnSafeLock("dbTongTongChestOpenColumn.ForceAddChestOpen")
	defer this.m_row.m_lock.UnSafeUnlock()
	cur_rd := this.m_data[pid]
	if nil != cur_rd {
		return
	}

	new_rd := &dbTongTongChestOpenData{}
	new_rd.PlayerId = pid
	new_rd.WinScore = 0
	new_rd.ReqUnix = open_unix

	this.m_data[pid] = new_rd
	this.m_changed = true

	return
}

func (this *dbTongTongMemberColumn) GetTotalScore() int32 {
	total := int32(0)
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetTotalScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		total = total + int32(val.Score)
	}

	return total
}

func (this *dbPlayerTodayCardCompoundColumn) FillCardCompoundMsg(msg *msg_client_message.S2CSyncCardCompound) {
	var tmp_c *msg_client_message.CardCompoundInfo
	this.m_row.m_lock.UnSafeRLock("dbPlayerTodayCardCompoundColumn.FillCardCompoundMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	msg.CardCompounds = make([]*msg_client_message.CardCompoundInfo, 0, len(this.m_data))
	for card_id, val := range this.m_data {
		if nil == val {
			continue
		}

		tmp_c = &msg_client_message.CardCompoundInfo{}
		tmp_c.CardCfgId = proto.Int32(card_id)
		tmp_c.CurCompoundNum = proto.Int32(val.TodayCompoundNum)
		msg.CardCompounds = append(msg.CardCompounds, tmp_c)
	}
	return
}

func (this *dbPlayerCampFightInfoColumn) SetNewEnterInfo(iso_week, arena_lvl int32) {
	this.m_row.m_lock.UnSafeLock("dbPlayerCampFightInfoColumn.SetEnterISOWeek")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.EnterISOWeek = iso_week
	this.m_data.EnterArenaLvl = arena_lvl
	this.m_data.CurScore = 0
	this.m_changed = true
	return
}

func (this *dbPlayerCampFightInfoColumn) SubCurScore(v int32) (int32, int32) {
	this.m_row.m_lock.UnSafeLock("dbPlayerCampFightInfoColumn.SubCurScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	old_val := this.m_data.CurScore
	this.m_data.CurScore = this.m_data.CurScore - v
	if this.m_data.CurScore < 0 {
		this.m_data.CurScore = 0
	}
	this.m_changed = true
	return this.m_data.CurScore, this.m_data.CurScore - old_val
}

func (this *dbPlayerSignInfoColumn) FillSyncMsg(msg *msg_client_message.S2CSyncSignInfo) {
	this.m_row.m_lock.UnSafeRLock("dbPlayerSignInfoColumn.FillSyncMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()

	msg.CurSignSum = proto.Int32(this.m_data.CurSignSum)
	msg.CurSignDays = this.m_data.CurSignDays
	msg.CurGetSignSumRewards = this.m_data.RewardSignSum

	return
}

func (this *dbPlayerGuidesColumn) ForceAdd(guide_id int32) {
	this.m_row.m_lock.UnSafeLock("dbPlayerGuidesColumn.ForceAdd")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[guide_id]
	if has {
		return
	}
	d := &dbPlayerGuidesData{}
	d.GuideId = guide_id
	d.SetUnix = int32(time.Now().Unix())
	this.m_data[guide_id] = d
	this.m_changed = true
	return
}

func (this *dbPlayerGuidesColumn) FillSyncMsg(msg *msg_client_message.S2CSyncGuideData) {
	if nil == msg {
		log.Error("dbPlayerGuidesColumn FillSyncMsg msg nil !")
		return
	}

	this.m_row.m_lock.UnSafeRLock("dbPlayerGuidesColumn.FillSyncMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()

	msg.GuideIds = make([]int32, 0, len(this.m_data))
	for _, val := range this.m_data {
		msg.GuideIds = append(msg.GuideIds, val.GuideId)
	}

	return
}

func (this *dbPlayerFriendColumn) FillAllListMsg(msg *msg_client_message.S2CRetFriendList) {
	var tmp_info *msg_client_message.FriendInfo
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.FillAllListMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	msg.FriendList = make([]*msg_client_message.FriendInfo, 0, len(this.m_data))
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		tmp_info = &msg_client_message.FriendInfo{}
		tmp_info.PlayerId = proto.Int32(val.FriendPId)
		tmp_info.Name = proto.String(val.FriendName)
		tmp_info.Score = proto.Int32(val.MatchScore)
		tmp_info.TongIcon = proto.Int32(val.TongIcon)
		tmp_info.TongName = proto.String(val.TongName)
		log.Info("附加值到好友列表 %v", tmp_info)
		msg.FriendList = append(msg.FriendList, tmp_info)
	}

	return
}

func (this *dbPlayerFriendColumn) GetAviFriendId() int32 {
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.GetAviFriendId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for i := int32(1); i <= global_config.MaxFriendNum; i++ {
		if nil == this.m_data[i] {
			return i
		}
	}
	return 0
}

func (this dbPlayerFriendColumn) TryAddFriend(new_friend *dbPlayerFriendData) int32 {
	if nil == new_friend {
		log.Error("dbPlayerFriendColumn TryAddFriend ")
		return -1
	}

	this.m_row.m_lock.UnSafeLock("dbPlayerFriendColumn.TryAddFriend")
	defer this.m_row.m_lock.UnSafeUnlock()

	for _, val := range this.m_data {
		if nil != val && val.FriendPId == new_friend.FriendPId {
			return 1
		}
	}

	for i := int32(1); i <= global_config.MaxFriendNum; i++ {
		if nil == this.m_data[i] {
			new_friend.FriendPId = i
			this.m_data[i] = new_friend
			this.m_changed = true
			return 0
		}
	}
	return 2
}

func (this *dbPlayerFriendReqColumn) FillAllListMsg(msg *msg_client_message.S2CRetFriendList) {

	var tmp_info *msg_client_message.FriendReq
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.FillAllListMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()

	msg.Reqs = make([]*msg_client_message.FriendReq, 0, len(this.m_data))
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		tmp_info = &msg_client_message.FriendReq{}
		tmp_info.PlayerId = proto.Int32(val.FriendPId)
		tmp_info.Name = proto.String(val.FriendName)
		tmp_info.Score = proto.Int32(val.MatchScore)
		tmp_info.TongIcon = proto.Int32(val.TongIcon)
		tmp_info.TongName = proto.String(val.TongName)
		msg.Reqs = append(msg.Reqs, tmp_info)
	}

	return
}

func (this *dbPlayerFocusPlayerColumn) FillAllListMsg(msg *msg_client_message.S2CRetFriendList) {

	var tmp_info *msg_client_message.FriendInfo
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.FillAllListMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	msg.FriendList = make([]*msg_client_message.FriendInfo, 0, len(this.m_data))
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		tmp_info = &msg_client_message.FriendInfo{}
		tmp_info.PlayerId = proto.Int32(val.FriendPId)
		tmp_info.Name = proto.String(val.FriendName)
		tmp_info.Score = proto.Int32(val.MatchScore)
		tmp_info.TongIcon = proto.Int32(val.TongIcon)
		tmp_info.TongName = proto.String(val.TongName)
		msg.FriendList = append(msg.FriendList, tmp_info)
	}

	return
}

func (this *dbPlayerBeFocusPlayerColumn) FillAllListMsg(msg *msg_client_message.S2CRetFriendList) {

	var tmp_info *msg_client_message.FriendInfo
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeFocusPlayerColumn.FillAllListMsg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	msg.FriendList = make([]*msg_client_message.FriendInfo, 0, len(this.m_data))
	for _, val := range this.m_data {
		if nil == val {
			continue
		}

		tmp_info = &msg_client_message.FriendInfo{}
		tmp_info.PlayerId = proto.Int32(val.FriendPId)
		tmp_info.Name = proto.String(val.FriendName)
		tmp_info.Score = proto.Int32(val.MatchScore)
		tmp_info.TongIcon = proto.Int32(val.TongIcon)
		tmp_info.TongName = proto.String(val.TongName)
		msg.FriendList = append(msg.FriendList, tmp_info)
	}

	return
}

func (this *dbPlayerFriendColumn) GetAllIds() (ret_ids []int32) {
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.GetAllIds")
	defer this.m_row.m_lock.UnSafeRUnlock()
	tmp_len := len(this.m_data)
	if tmp_len <= 0 {
		return nil
	}

	ret_ids = make([]int32, 0, len(this.m_data))
	for _, v := range this.m_data {
		ret_ids = append(ret_ids, v.FriendPId)
	}
	return
}

func (this *dbPlayerFocusPlayerColumn) GetAllIds() (ret_ids []int32) {
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.GetAllIds")
	defer this.m_row.m_lock.UnSafeRUnlock()
	tmp_len := len(this.m_data)
	if tmp_len <= 0 {
		return nil
	}

	ret_ids = make([]int32, 0, len(this.m_data))
	for _, v := range this.m_data {
		ret_ids = append(ret_ids, v.FriendPId)
	}
	return
	return
}
