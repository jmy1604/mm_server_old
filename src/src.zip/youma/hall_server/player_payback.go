package main

import (
	"libs/log"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

type PayBackMgr struct {
	id2payback_lock *sync.RWMutex
	id2payback      map[int32]*msg_server_message.PayBackAdd
}

var payback_mgr PayBackMgr

func (this *PayBackMgr) Init() bool {
	this.id2payback_lock = &sync.RWMutex{}
	this.id2payback = make(map[int32]*msg_server_message.PayBackAdd)

	return true
}

func (this *PayBackMgr) AddPayBack(msg *msg_server_message.PayBackAdd) {
	this.id2payback_lock.Lock()
	defer this.id2payback_lock.Unlock()

	pbid := msg.GetPayBackId()
	cur_payback := this.id2payback[pbid]
	if nil != cur_payback {
		log.Error("PayBackMgr AddPayBack paybackid[%d] already be used !", pbid)
		return
	}

	this.id2payback[pbid] = msg

	return
}

func (this *PayBackMgr) RemovePayBack(pb_id int32) {
	this.id2payback_lock.Lock()
	defer this.id2payback_lock.Unlock()

	if nil != this.id2payback[pb_id] {
		delete(this.id2payback, pb_id)
	}

	return
}

func (this *PayBackMgr) OnPlayerLogin(p *Player) {
	if nil == p {
		log.Error("PayBackMgr OnPlayerLogin p nil")
		return
	}

	this.id2payback_lock.RLock()
	defer this.id2payback_lock.RUnlock()

	var new_mail *dbPlayerMailData
	var res2cli *msg_client_message.S2CMailAdd
	for pbid, pb := range this.id2payback {
		if nil == pb {
			continue
		}

		if nil != p.db.PayBacks.Get(pbid) {
			continue
		}

		new_mail = &dbPlayerMailData{}
		new_mail.MailId = p.db.Mails.GetAviMailId()
		new_mail.Chests = pb.GetChestsId()
		new_mail.Coin = pb.GetCoin()
		new_mail.Content = pb.GetMailContent()
		new_mail.Diamond = pb.GetDiamond()
		new_mail.MailTitle = pb.GetMailTitle()
		new_mail.OverUnix = pb.GetOverUnix()
		new_mail.SenderName = "system"
		new_mail.SendUnix = int32(time.Now().Unix())

		p.db.Mails.Add(new_mail)

		res2cli = &msg_client_message.S2CMailAdd{}
		res2cli.MailId = proto.Int32(new_mail.MailId)
		res2cli.Title = proto.String(new_mail.MailTitle)
		res2cli.Chests = new_mail.Chests
		res2cli.Coin = proto.Int32(new_mail.Coin)
		res2cli.Content = proto.String(new_mail.Content)
		res2cli.Diamond = proto.Int32(new_mail.Diamond)
		res2cli.SenderName = proto.String(new_mail.SenderName)
		res2cli.SendUnix = proto.Int32(new_mail.SendUnix)
		res2cli.OverUix = proto.Int32(new_mail.OverUnix)

		p.Send(res2cli)
	}
}
