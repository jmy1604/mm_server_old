package main

import (
	"encoding/json"
	"io/ioutil"
	"libs/log"
)

type WeekTime struct {
	WeekDay int32
	Hour    int32
	Minute  int32
	Second  int32
}

type TongChestOpenTime struct {
	StartTime     WeekTime
	ActEndTime    WeekTime
	RewardEndTime WeekTime
}

type DaySignSumReward struct {
	SignNum int32
	ChestId int32
}

type GlobalConfig struct {
	PlayerInitCards         []int32
	PlayerInitCards1        []int32
	PlayerInitCards2        []int32
	ArenaGoldAwardTimeLimit int32
	InitCoin                int32
	InitDiamond             int32
	ChestSlotCount          int32
	TimeExchangeRate        int32
	WoodChestUnlockTime     int32
	SilverChestUnlockTime   int32
	GoldenChestUnlockTime   int32
	GiantChestUnlockTime    int32
	MagicChestUnlockTime    int32
	RareChestUnlockTime     int32
	EpicChestUnlockTime     int32
	LegendryChestUnlockTime int32

	GooglePayUrl       string
	FaceBookPayUrl     string
	ApplePayUrl        string
	ApplePaySandBoxUrl string

	MaxTongMemberCount int32
	MaxMailCount       int32 // 最大邮件数目
	MaxFightRdCount    int32 // 最大战斗记录数目

	FreeChestId     []int32 // 免费宝箱Id
	FreeChestCdSec  int32   // 免费宝箱的冷却时间
	MaxFreeChestNum int32   // 最大免费宝箱个数

	TowerChestId      []int32 // 奖杯宝箱Id
	TowerChestCdSec   int32   // 奖杯宝箱的冷却时间
	MaxTowerChestNum  int32   // 最大奖杯宝箱个数
	TowerChestNeedNum int32   // 奖杯宝箱需要的塔数

	CreateTongCost       int32 // 帮会创建需要的金币
	MaxTongChatRdNum     int32 // 帮会最大聊天记录数目
	DonationRequestCD    int32 // 帮会捐赠请求CD
	LeaveTongDonateCdSec int32 // 离开帮会之后的捐赠CD
	CommonGoldReward     int32 // 普通卡的捐赠获得的金币
	CommonExpReward      int32 // 普通卡捐赠获得的经验
	RareGoldReward       int32 // 稀有卡的捐赠获得的金币
	RareExpReward        int32 // 稀有卡捐赠获得的经验

	LegendBaseScore int32 // 传说基础分

	TongChestOpenTimes []TongChestOpenTime

	MaxNameLen        int32              // 最大名字长度
	ChgNameCost       []int32            // 改名消耗的钻石
	ChgNameCostLen    int32              // 消耗数组的长度
	DaySignSumRewards []DaySignSumReward // 累计签到奖励
	FirstPayReward    int32              // 首充奖励宝箱Id

	MaxFriendNum int32 // 最大好友数目
}

var global_config GlobalConfig

func global_config_load() bool {
	data, err := ioutil.ReadFile("../game_data/global.json")
	if nil != err {
		log.Error("global_config_load failed to readfile err(%s)!", err.Error())
		return false
	}

	err = json.Unmarshal(data, &global_config)
	if nil != err {
		log.Error("global_config_load json unmarshal failed err(%s)!", err.Error())
		return false
	}

	if global_config.TimeExchangeRate <= 0 {
		log.Error("global_config_load json unmarshal TimeExchangeRate < 0")
		return false
	}

	global_config.ChgNameCostLen = int32(len(global_config.ChgNameCost))

	return true
}
