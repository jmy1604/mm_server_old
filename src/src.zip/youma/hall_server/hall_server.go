package main

import (
	"errors"
	"libs/log"
	"libs/socket"
	"libs/timer"
	"public_message/gen_go/client_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

type HallServer struct {
	start_time         time.Time
	net                *socket.Node
	quit               bool
	shutdown_lock      *sync.Mutex
	shutdown_completed bool
	ticker             *timer.TickTimer
	initialized        bool
	last_gc_time       int32
}

var hall_server HallServer

func (this *HallServer) Init() (ok bool) {
	this.start_time = time.Now()
	this.shutdown_lock = &sync.Mutex{}
	this.net = socket.NewNode(&hall_server, time.Duration(config.RecvMaxMSec), time.Duration(config.SendMaxMSec), 5000, msg_client_message.MessageNames) //(this, 0, 0, 5000, 0, 0, 0, 0, 0)

	err := this.OnInit()
	if err != nil {
		log.Error("服务器初始化失败[%s]", err.Error())
		return
	}

	this.initialized = true

	ok = true
	return
}

func (this *HallServer) Start() (err error) {
	log.Event("服务器已启动", nil, log.Property{"IP", config.ListenClientInIP})
	log.Trace("**************************************************")

	go this.Run()

	err = this.net.Listen(config.ListenClientInIP, config.MaxClientConnections)
	if err != nil {
		log.Error("启动服务器失败 %v", err)
		return
	}

	return
}

func (this *HallServer) Run() {
	defer func() {
		if err := recover(); err != nil {
			log.Stack(err)
		}

		this.shutdown_completed = true
	}()

	this.ticker = timer.NewTickTimer(1000)
	this.ticker.Start()
	defer this.ticker.Stop()

	for {
		select {
		case d, ok := <-this.ticker.Chan:
			{
				if !ok {
					return
				}

				begin := time.Now()
				this.OnTick(d)
				time_cost := time.Now().Sub(begin).Seconds()
				if time_cost > 1 {
					log.Trace("耗时 %v", time_cost)
					if time_cost > 30 {
						log.Error("耗时 %v", time_cost)
					}
				}
			}
		}
	}
}

func (this *HallServer) Shutdown() {
	if !this.initialized {
		return
	}

	this.shutdown_lock.Lock()
	defer this.shutdown_lock.Unlock()

	if this.quit {
		return
	}
	this.quit = true

	log.Trace("关闭游戏主循环")

	begin := time.Now()

	if this.ticker != nil {
		this.ticker.Stop()
	}

	for {
		if this.shutdown_completed {
			break
		}

		time.Sleep(time.Millisecond * 100)
	}

	center_conn.client_node.Shutdown()
	match_conn.client_node.Shutdown()
	room_server_agent_mgr.net.Shutdown()
	this.net.Shutdown()

	log.Trace("关闭游戏主循环耗时 %v 秒", time.Now().Sub(begin).Seconds())

	dbc.Save(false)
}

func (this *HallServer) OnInit() (err error) {
	RegPlayerCardsMsg()
	reg_player_shop_msg()
	reg_player_chest_msg()
	reg_player_tong_msg()
	reg_player_mail_msg()
	reg_player_option_msg()
	reg_player_fight_record_msg()
	reg_player_task_achieve_msg()
	reg_player_sign_msg()
	reg_player_first_pay_msg()
	reg_player_camp_msg()
	reg_player_guide_msg()
	reg_player_friend_msg()
	player_mgr.RegMsgHandler()
	tong_mgr.RegTongMsg()

	if !cfg_player_cards.Load() {
		return errors.New("cfg_player_cards load failed !")
	} else {
		log.Info("cfg_player_cards load succeed !")
	}

	if !cfg_arena.Init() {
		return errors.New("cfg_arena init failed !")
	} else {
		log.Info("cfg_arena init succeed !")
	}

	if !cfg_exp.Init() {
		return errors.New("cfg_exp init failed !")
	} else {
		log.Info("cfg exp init succeed !")
	}

	if !cfg_position.Init() {
		return errors.New("cfg_position init failed !")
	} else {
		log.Info("cfg_position init succeed !")
	}

	if !cfg_cardcompound_cfgmgr.Init() {
		return errors.New("cfg_cardcompound_cfgmgr init failed !")
	} else {
		log.Info("cfg_cardcompound_cfgmgr init succeed !")
	}

	if !shop_cfg_mgr.Init() {
		return errors.New("shop_cfg_mgr init failed !")
	} else {
		log.Info("shop_cfg_mgr init succeed !")
	}

	if !chest_cfg_mgr.Init() {
		return errors.New("chest_cfg_mgr init failed !")
	} else {
		log.Info("chest_cfg_mgr init succeed !")
	}

	if !cfg_mail_mgr.Init() {
		return errors.New("cfg_mail_mgr init failed !")
	} else {
		log.Info("cfg_mail_mgr init succeed !")
	}

	if !cfg_day_sign_mgr.Init() {
		return errors.New("cfg_day_sign_mgr init failed !")
	} else {
		log.Info("cfg_day_sign_mgr init succeed !")
	}

	if !cfg_player_act_mgr.Init() {
		return errors.New("cfg_player_act_mgr init failed !")
	} else {
		log.Info("cfg_player_act_mgr init succeed !")
	}

	if !player_card_up_mgr.Init() {
		return errors.New("player_card_up_mgr init failed !")
	} else {
		log.Info("player_card_up_mgr init succeed !")
	}

	if !player_match_mgr.Init() {
		log.Error("player_match_mgr init failed")
		return errors.New("player_match_mgr init failed !")
	} else {
		log.Info("player_match_mgr init succeed !")
	}

	if !player_score_mgr.Init() {
		log.Error("player_score_mgr init failed")
		return errors.New("player_score_mgr init failed !")
	} else {
		log.Info("player_score_mgr init succeed !")
	}

	if !achieve_task_mgr.Init() {
		log.Error("achieve_task_mgr init failed")
		return errors.New("achieve_task_mgr init failed !")
	} else {
		log.Info("achieve_task_mgr init succeed !")
	}

	if !gm_command_mgr.Init() {
		log.Error("gm_command_mgr init failed")
		return errors.New("gm_command_mgr init failed !")
	} else {
		log.Info("gm_command_mgr init succeed !")
	}

	if !camp_fight_mgr.WaitStateInitOk() {
		log.Error("camp_fight_mgr WaitStateInitOk failed")
		return errors.New("camp_fight_mgr WaitStateInitOk failed !")
	} else {
		log.Info("camp_fight_mgr WaitStateInitOk succeed !")
	}

	//chest_cfg_mgr.OpenChestTest()

	return
}

func (this *HallServer) OnTick(t timer.TickTime) {
	g_up_online_tong_donate()
	player_mgr.OnTick()
	tong_mgr.OnTick()
}

func (this *HallServer) OnAccept(c *socket.TcpConn) {
	log.Info("HallServer OnAccept [%s]", c.GetAddr())
}

func (this *HallServer) OnConnect(c *socket.TcpConn) {

}

func (this *HallServer) OnDisconnect(c *socket.TcpConn, reason socket.E_DISCONNECT_REASON) {
	if c.T > 0 {
		cur_p := player_mgr.GetPlayerById(int32(c.T))
		if nil != cur_p {
			player_mgr.PlayerLogout(cur_p)
		}
	}
	log.Trace("玩家[%d] 断开连接[%v]", c.T, c.GetAddr())
}

func (this *HallServer) CloseConnection(c *socket.TcpConn, reason socket.E_DISCONNECT_REASON) {
	if c == nil {
		log.Error("参数为空")
		return
	}

	c.Close(reason)
}

type MessageHandler func(conn *socket.TcpConn, m proto.Message)

func (this *HallServer) set_ih(type_id uint16, h socket.Handler) {
	t := msg_client_message.MessageTypes[type_id]
	if t == nil {
		log.Error("设置消息句柄失败，不存在的消息类型 %v", type_id)
		return
	}

	this.net.SetHandler(type_id, t, h)
}

func (this *HallServer) SetMessageHandler(type_id uint16, h MessageHandler) {
	if h == nil {
		this.set_ih(type_id, nil)
		return
	}

	this.set_ih(type_id, func(c *socket.TcpConn, m proto.Message) {
		h(c, m)
	})
}

func (this *HallServer) OnUpdate(c *socket.TcpConn, t timer.TickTime) {

}
