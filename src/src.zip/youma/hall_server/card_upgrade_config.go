package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
)

type XmlCardUpgradeItem struct {
	Quality   int32 `xml:"CardQuality,attr"`
	CardLevel int32 `xml:"CardLevel,attr"`
	GoldCost  int32 `xml:"GoldCost,attr"`
	CardCost  int32 `xml:"CardCost,attr"`
	ExpGain   int32 `xml:"ExpGain,attr"`
}

type XmlCardUpgradeConfig struct {
	Items []XmlCardUpgradeItem `xml:"item"`
}

type QualityCardUpCfg struct {
	max_lvl    int32 // 最大等级
	lvl2upcost map[int32]*XmlCardUpgradeItem
}

type PlayerCardUpGradeMgr struct {
	qua2quacardupcfg map[int32]*QualityCardUpCfg
}

var player_card_up_mgr PlayerCardUpGradeMgr

func (this *PlayerCardUpGradeMgr) Init() bool {
	if !this.Load() {
		return false
	}

	log.Info("GetCost test %v", this.GetCardUpCost(1, 1001))
	return true
}

func (this *PlayerCardUpGradeMgr) Load() bool {
	content, err := ioutil.ReadFile("../game_data/cardupgrade.xml")
	if nil != err {
		log.Error("PlayerCardUpGradeMgr load readfile error !")
		return false
	}

	tmp_cfg := &XmlCardUpgradeConfig{}
	err = xml.Unmarshal(content, tmp_cfg)
	if nil != err {
		log.Error("PlayerCardUpGradeMgr load unmarshal error (%s)!", err.Error())
		return false
	}

	this.qua2quacardupcfg = make(map[int32]*QualityCardUpCfg)
	for idx := int32(0); idx < int32(len(tmp_cfg.Items)); idx++ {
		val := &tmp_cfg.Items[idx]
		if nil == val {
			continue
		}

		cur_qua_cfg := this.qua2quacardupcfg[val.Quality]
		if nil == cur_qua_cfg {
			this.qua2quacardupcfg[val.Quality] = &QualityCardUpCfg{}
			this.qua2quacardupcfg[val.Quality].lvl2upcost = make(map[int32]*XmlCardUpgradeItem)
		}

		this.qua2quacardupcfg[val.Quality].lvl2upcost[val.CardLevel] = val
		if val.CardLevel > this.qua2quacardupcfg[val.Quality].max_lvl {
			this.qua2quacardupcfg[val.Quality].max_lvl = val.CardLevel
		}
	}
	return true
}

func (this *PlayerCardUpGradeMgr) GetCardUpCost(card_lvl, card_cfg_id int32) *XmlCardUpgradeItem {
	card_cfg := cfg_player_cards.Map[card_cfg_id]
	if nil == card_cfg {
		log.Error("PlayerCardUpGradeMgr getCardUpCost failed !")
		return nil
	}

	qua_cfg := this.qua2quacardupcfg[card_cfg.Trait]
	if nil == qua_cfg {
		log.Error("PlayerCardUpGradeMgr get qua_cfg[%d] card[%d] faild", card_cfg.Trait, card_cfg_id)
		return nil
	}

	return qua_cfg.lvl2upcost[card_lvl]
}
