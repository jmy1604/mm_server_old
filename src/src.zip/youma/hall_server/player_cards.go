package main

import (
	"libs/log"
	"libs/socket"
	"libs/timer"
	"public_message/gen_go/client_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	CARD_TEAM_CARD_COUNT = 8  // 一个卡组里面有多少个卡片位置
	MAX_CARD_TEAM_COUNT  = 10 // 最大卡组ID

	DEFAULT_CARD_TEAM_0 = 0 // 编号0卡组
	DEFAULT_CARD_TEAM_1 = 1 // 编号1卡组
	DEFAULT_CARD_TEAM_2 = 2 // 编号2卡组
)

// 玩家上阵卡组
func (this *Player) GetCurUseCardTeam() int32 {
	return this.db.Info.GetCurUseCardTeam()
}

func (this *Player) set_cur_use_card_team(teamid int32) {
	this.db.Info.SetCurUseCardTeam(teamid)
}

// 玩家卡片 ============================================================================

func (this *Player) add_card(cfg_id, add_num int32) {

	cur_card := this.db.Cards.Get(cfg_id)
	if nil != cur_card {
		this.db.Cards.IncbyCardCount(cfg_id, add_num)
	} else {
		cur_card := &dbPlayerCardData{}
		cur_card.ConfigId = cfg_id
		cur_card.CardCount = add_num
		cur_card.CardLvl = 1
		this.db.Cards.Add(cur_card)
	}

	return
}

// 玩家卡组 ============================================================================
// 内部接口 使用时候需要在外面判断卡片是否存在，自己是否有此卡片

func (this *Player) check_add_to_card_team(teamid int32, cfgid int32) int32 {
	if teamid < 0 || teamid >= MAX_CARD_TEAM_COUNT {
		log.Error("Player check_add_to_card_team teamid(%d) error !", teamid)
		return -1
	}

	cur_team := this.db.CardTeams.Get(teamid)
	if nil != cur_team {
		log.Info("玩家[%d]添加卡片[%d]到卡组[%d]不为空1")
		if len(cur_team.CardCfgIds) < CARD_TEAM_CARD_COUNT {
			log.Info("玩家[%d]添加卡片[%d]到卡组[%d]不为空2")
			new_ids := make([]int32, CARD_TEAM_CARD_COUNT)
			for idx, id := range cur_team.CardCfgIds {
				if 0 != id {
					new_ids[idx] = id
				}
			}
			cur_team.CardCfgIds = new_ids
		}

		for idx, id := range cur_team.CardCfgIds {
			if 0 == id {
				cur_team.CardCfgIds[idx] = cfgid
				this.db.CardTeams.SetCardCfgIds(teamid, cur_team.CardCfgIds)
				return 0
			}
		}
		return 1
	} else {
		new_card_team := &dbPlayerCardTeamData{}
		new_card_team.TeamId = teamid
		new_card_team.CardCfgIds = make([]int32, CARD_TEAM_CARD_COUNT)
		new_card_team.CardCfgIds[0] = cfgid
		this.db.CardTeams.Add(new_card_team)
		return 0
	}

	return 0
}

func (this *Player) check_set_card_to_team_pos(cfgid, teamid, pos int32) bool {
	if teamid < 0 || teamid >= MAX_CARD_TEAM_COUNT {
		log.Error("Player check_add_to_card_team teamid(%d) error !", teamid)
		return false
	}

	if pos < 0 || pos >= CARD_TEAM_CARD_COUNT {
		log.Error("Player check_add_to_card_team pos(%d) error !", pos)
		return false
	}

	cur_team := this.db.CardTeams.Get(teamid)
	if nil == cur_team {
		log.Error("Player check_add_to_card_team can not find team[%d]", teamid)
		return false
	}

	if len(cur_team.CardCfgIds) < CARD_TEAM_CARD_COUNT {
		new_ids := make([]int32, CARD_TEAM_CARD_COUNT)
		for idx, id := range cur_team.CardCfgIds {
			if 0 != id {
				new_ids[idx] = id
			}
		}
		cur_team.CardCfgIds = new_ids
	}

	if 0 == cur_team.CardCfgIds[pos] {
		log.Error("Player check_add_to_card_team can set to empty pos[pos]", pos)
		return false
	}

	cur_team.CardCfgIds[pos] = cfgid
	this.db.CardTeams.SetCardCfgIds(teamid, cur_team.CardCfgIds)

	return true
}

func (this *Player) check_have_card_team(teamid int32) bool {
	if teamid < 0 || teamid >= MAX_CARD_TEAM_COUNT {
		log.Error("Player check_have_card_team teamid(%d) error !", teamid)
		return false
	}

	if nil != this.db.CardTeams.Get(teamid) {
		return true
	}

	return false
}

func (this *Player) AddCard(cfgid, num int32, reason, modname string, bcardslience, bnotifyslience bool) bool {
	if num < 0 {
		log.Error("Player AddCard param num(%d) < 0 !", num, reason, modname)
		return false
	}
	if nil == cfg_player_cards.Map[cfgid] {
		log.Error("Player AddCard failed no card(%d) cfg !", cfgid, reason, modname)
		return false
	}

	this.add_card(cfgid, num)
	if !bcardslience {
		res_2cli := &msg_client_message.S2CCardAdd{}
		res_2cli.CardCfgId = proto.Int32(cfgid)
		res_2cli.AddNum = proto.Int32(num)
		this.Send(res_2cli)
	}

	this.TaskAchieveOnConditionSet(TASK_ACHIEVE_FINISH_CON_CARD_T_NUM, this.db.Cards.GetCardKindNum(), bnotifyslience)

	ret_val := this.check_add_to_card_team(DEFAULT_CARD_TEAM_0, cfgid)
	if ret_val < 0 {
		log.Error("Player check_add_to_card_team 0 cfgid(%d) failed !", cfgid, reason, modname)
	}

	ret_val = this.check_add_to_card_team(DEFAULT_CARD_TEAM_1, cfgid)
	if ret_val < 0 {
		log.Error("Player check_add_to_card_team 1 cfgid(%d) failed !", cfgid, reason, modname)
	}

	ret_val = this.check_add_to_card_team(DEFAULT_CARD_TEAM_2, cfgid)
	if ret_val < 0 {
		log.Error("Player check_add_to_card_team 2 cfgid(%d) failed !", cfgid, reason, modname)
	}

	log.Info("玩家(%d)添加%d张卡片(%d)功能(%s)模块(%s)!", this.Id, num, cfgid, reason, modname)

	return true
}

func (this *Player) RemoveCard(cfgid, num int32, reason, modname string) bool {
	if num < 0 {
		log.Error("Player RemoveCard num(%d) < 0", num, reason, modname)
		return false
	}

	if nil == cfg_player_cards.Map[cfgid] {
		log.Error("Player RemoveCard no cfgid(%d) !", cfgid, reason, modname)
		return false
	}

	cur_card := this.db.Cards.Get(cfgid)
	if nil == cur_card || num > cur_card.CardCount {
		log.Error("Player RemoveCard not enough cfgid(%d) !", cfgid, reason, modname)
		return false
	}

	if num == cur_card.CardCount {
		this.db.Cards.Remove(cfgid)
		return true
	} else {
		this.db.Cards.IncbyCardCount(cfgid, -num)
	}

	log.Info("玩家(%d)删除%d张卡片(%d)功能(%s)模块(%s)!", this.Id, num, cfgid, reason, modname)
	return true
}

func (this *Player) SetCurUseTeam(teamid int32) int32 {
	if teamid < 0 || teamid >= MAX_CARD_TEAM_COUNT {
		log.Error("Player SetCurUseCardTeam teamid(%d) error !", teamid)
		return -1
	}

	if !this.check_have_card_team(teamid) {
		log.Error("Player SetCurUseTeam not have teamid(%d) !", teamid)
		return -2
	}

	this.set_cur_use_card_team(teamid)

	return teamid
}

//卡片合成次数 ----------------------------------

func (this *Player) GetTodayCardCompoundNum(card_cfg_id int32) int32 {
	last_up_day := timer.GetDayFrom1970WithCfgAndSec(0, this.db.Info.GetLastCardCompoundUpUnix())
	cur_unix_day := timer.GetDayFrom1970WithCfg(0)
	if last_up_day != cur_unix_day {
		this.db.TodayCardCompounds.Clear()
	}

	ret_num, bhas := this.db.TodayCardCompounds.GetTodayCompoundNum(card_cfg_id)
	if bhas {
		return ret_num
	}

	return 0
}

func (this *Player) SyncCardCompound() {
	last_up_day := timer.GetDayFrom1970WithCfgAndSec(0, this.db.Info.GetLastCardCompoundUpUnix())
	cur_unix_day := timer.GetDayFrom1970WithCfg(0)
	if last_up_day != cur_unix_day {
		this.db.TodayCardCompounds.Clear()
		this.db.Info.SetLastCardCompoundUpUnix(int32(time.Now().Unix()))
	}

	res := &msg_client_message.S2CSyncCardCompound{}
	this.db.TodayCardCompounds.FillCardCompoundMsg(res)
	this.Send(res)
}

//=============================================================================

func RegPlayerCardsMsg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SChgCurTeam, C2SChgCurTeamHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SSetCardToTeam, C2SSetCardToTeamHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SCardLvlUp, C2SCardLvlUpHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SCardCompound, C2SCardCompoundHandler)
}

func C2SChgCurTeamHandler(conn *socket.TcpConn, msg proto.Message) {
	if nil == conn {
		log.Error("Player C2SChgCurTeamHandler conn nil !")
		return
	}

	p := player_mgr.GetPlayerById(int32(conn.T))
	if nil == p {
		log.Error("Player C2SChgCurTeamHandler get player[%d] failed", conn.T)
		return
	}

	req := msg.(*msg_client_message.C2SChgCurTeam)
	if nil == req {
		log.Error("Player C2SChgCurTeamHandler req nil")
		return
	}

	if nil == p.db.CardTeams.Get(req.GetTeamId()) {
		log.Error("Player C2SChgCurTeamHandler wrong team id(%d)", req.GetTeamId())
		return
	}

	p.db.Info.SetCurUseCardTeam(req.GetTeamId())

	res_2cli := &msg_client_message.S2CChgCurTeam{}
	res_2cli.TeamId = proto.Int32(req.GetTeamId())
	p.Send(res_2cli)
}

func C2SSetCardToTeamHandler(conn *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SSetCardToTeam)
	if nil == req || nil == conn {
		log.Error("C2SSetCardToTeamHandler req or conn nil !")
		return
	}

	p := player_mgr.GetPlayerById(int32(conn.T))
	if nil == p {
		log.Error("C2SSetCardToTeamHandler get player[%d] failed, maybe not login !", conn.T)
		return
	}

	card_cfg_id := req.GetCardCfgId()
	my_card := p.db.Cards.Get(card_cfg_id)
	if nil == my_card {
		log.Error("C2SSetCardTOTeamHandler get card[%d] failed !", card_cfg_id)
		return
	}

	if p.check_set_card_to_team_pos(card_cfg_id, req.GetTeamId(), req.GetSlotIdx()) {
		res_2cli := &msg_client_message.S2CTeamCardsChg{}
		res_2cli.CardCfgId = proto.Int32(req.GetCardCfgId())
		res_2cli.SlotIdx = proto.Int32(req.GetSlotIdx())
		res_2cli.TeamId = proto.Int32(req.GetTeamId())
		p.Send(res_2cli)
	}

	return
}

func C2SCardLvlUpHandler(conn *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SCardLvlUp)
	if nil == req || nil == conn {
		log.Error("S2CCardLvlUpHandler req or conn nil !")
		return
	}

	p := player_mgr.GetPlayerById(int32(conn.T))
	if nil == p {
		log.Error("S2CCardLvlUpHandler get player[%d] failed, maybe not login !", conn.T)
		return
	}

	card_cfg_id := req.GetCardCfgId()
	my_card := p.db.Cards.Get(card_cfg_id)
	if nil == my_card {
		log.Error("S2CCardLvlUpHandler can not find my card[%d]", card_cfg_id)
		return
	}

	card_up_cost := player_card_up_mgr.GetCardUpCost(my_card.CardLvl+1, card_cfg_id)
	if nil == card_up_cost {
		log.Error("S2CCardLvlUpHandler can not get cost (lvl:%d, cfgid:%d)", my_card.CardLvl, card_cfg_id)
		return
	}

	if p.GetCoin() < card_up_cost.GoldCost {
		log.Error("S2CCardLvlUpHandler not enough gold(my:%d, cost:%d)", p.GetCoin(), card_up_cost.GoldCost)
		return
	}

	if my_card.CardCount < card_up_cost.CardCost {
		log.Error("S2CCardLvlUpHandler not enough cost(cur:%d, cost:%d)", my_card.CardCount, card_up_cost.CardCost)
		return
	}

	cur_coin := p.SubCoin(card_up_cost.GoldCost, "card_lvl_up", "player_cards")
	cur_lvl, cur_exp := p.AddExp(card_up_cost.ExpGain, "card_lvl_up", "player_cards")

	res_2cli := &msg_client_message.S2CCardLvlUp{}
	res_2cli.CardCfgId = proto.Int32(card_cfg_id)
	res_2cli.CardLvl = proto.Int32(my_card.CardLvl + 1)
	res_2cli.CardCount = proto.Int32(my_card.CardCount - card_up_cost.CardCost)
	res_2cli.CurCoin = proto.Int32(cur_coin)
	res_2cli.MyLvl = proto.Int32(cur_lvl)
	res_2cli.MyExp = proto.Int32(cur_exp)
	p.db.Cards.SetCardLvl(card_cfg_id, *res_2cli.CardLvl)
	p.db.Cards.SetCardCount(card_cfg_id, *res_2cli.CardCount)

	p.Send(res_2cli)
}

func C2SCardCompoundHandler(conn *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SCardCompound)
	if nil == req || nil == conn {
		log.Error("S2CCardLvlUpHandler req or conn nil !")
		return
	}

	p := player_mgr.GetPlayerById(int32(conn.T))
	if nil == p {
		log.Error("C2SCardCompoundHandler get player[%d] failed, maybe not login !", conn.T)
		return
	}

	card_cfg_id := req.GetCardCfgId()

	card_cfg := cfg_player_cards.Map[card_cfg_id]
	if nil == card_cfg {
		log.Error("C2SCardCompoundHandler failed to find card_cfg[%d]", card_cfg_id)
		return
	}

	c_count := req.GetCardNum()
	var tmp_key int32
	var compound_cfg *XmlCardCompoundItem
	var my_card *dbPlayerCardData
	res := &msg_client_message.S2CCardCompound{}
	res.CardCfgId = proto.Int32(card_cfg_id)
	bneed_send := false
	for i := int32(0); i < c_count; i++ {
		tmp_key = card_cfg.Trait*CARD_COMPOUND_QUA_KEY_MULTI + p.GetTodayCardCompoundNum(card_cfg_id) + 1
		compound_cfg = cfg_cardcompound_cfgmgr.QuaTime2Cfg[tmp_key]
		if nil == compound_cfg {
			log.Error("C2SCardCompoundHandler failed to find compound cfg[%d]", tmp_key)
			break
		}

		my_card = p.db.Cards.Get(card_cfg_id)
		if nil == my_card {
			log.Error("C2SCardCompoundHandler can not find my card[%d]", card_cfg_id)
			break
		}

		if p.db.Info.GetCardToken1() < compound_cfg.CardTokenCosts[CARD_COMPOUND_TOKEN_TYPE_1-1] ||
			p.db.Info.GetCardToken2() < compound_cfg.CardTokenCosts[CARD_COMPOUND_TOKEN_TYPE_2-1] ||
			p.db.Info.GetCardToken3() < compound_cfg.CardTokenCosts[CARD_COMPOUND_TOKEN_TYPE_3-1] ||
			p.db.Info.GetCardToken4() < compound_cfg.CardTokenCosts[CARD_COMPOUND_TOKEN_TYPE_4-1] ||
			p.db.Info.GetCoin() < compound_cfg.CardCompoundPrice {
			log.Error("C2SCardCompoundHandler not enough cost [%v]", compound_cfg)
			break
		}

		res.CurCardToken1 = proto.Int32(p.SubCardToken1(compound_cfg.CardTokenCosts[CARD_COMPOUND_TOKEN_TYPE_1-1], "card_compound", "card"))
		res.CurCardToken2 = proto.Int32(p.SubCardToken2(compound_cfg.CardTokenCosts[CARD_COMPOUND_TOKEN_TYPE_2-1], "card_compound", "card"))
		res.CurCardToken3 = proto.Int32(p.SubCardToken3(compound_cfg.CardTokenCosts[CARD_COMPOUND_TOKEN_TYPE_3-1], "card_compound", "card"))
		res.CurCardToken4 = proto.Int32(p.SubCardToken4(compound_cfg.CardTokenCosts[CARD_COMPOUND_TOKEN_TYPE_4-1], "card_compound", "card"))

		res.CurCoin = proto.Int32(p.SubCoin(compound_cfg.CardCompoundPrice, "card_compound", "card"))

		res.CurCardNum = proto.Int32(p.db.Cards.IncbyCardCount(card_cfg_id, 1))
		p.db.TodayCardCompounds.IncbyTodayCompoundNum(card_cfg_id, 1)
		bneed_send = true
	}

	if bneed_send {
		p.Send(res)
	}

	return
}
