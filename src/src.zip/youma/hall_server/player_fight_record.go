package main

import (
	"libs/log"
	"libs/socket"
	"public_message/gen_go/client_message"

	"3p/code.google.com.protobuf/proto"
)

func (this *Player) AddFightRecord(fight_rd *dbPlayerFightRecordData) int32 {
	if nil == fight_rd {
		log.Error("Player AddFightRecord fight_rd nil !")
		return -1
	}

	fight_rd.RecordId = this.db.FightRecords.GetAviRecordId()
	this.db.FightRecords.ForceAdd(fight_rd)
	return fight_rd.RecordId
}

// ====================================================================

func reg_player_fight_record_msg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetFightRecord, C2SGetFightRecordHandler)
}

func C2SGetFightRecordHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetFightRecord)
	if nil == req || nil == c {
		log.Error("C2SGetFightRecordHandler c or req nil !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SGetFightRecordHandler not login [%d]", c.T)
		return
	}

	ret_msg := p.db.FightRecords.FillRetClientMsg()
	if nil != ret_msg {
		p.Send(ret_msg)
	}

	return
}
