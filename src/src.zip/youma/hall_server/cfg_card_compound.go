package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"strconv"
	"strings"
)

const (
	CARD_COMPOUND_TOKEN_TYPE_1 = 1
	CARD_COMPOUND_TOKEN_TYPE_2 = 2
	CARD_COMPOUND_TOKEN_TYPE_3 = 3
	CARD_COMPOUND_TOKEN_TYPE_4 = 4

	MAX_CARD_TOKEN_TYPE_NUM = 4

	CARD_COMPOUND_QUA_KEY_MULTI = 1000
)

type XmlCardCompoundItem struct {
	CardQuality             int32  `xml:"CardQuality,attr"`
	CardCompoundTimes       int32  `xml:"CardCompoundTimes,attr"`
	CardCompoundPrice       int32  `xml:"CardCompoundPrice,attr"`
	CardCompoundTokenTypes  string `xml:"CardCompoundTokenType,attr"`
	CardCompoundTokenCounts string `xml:"CardCompoundTokenCount,attr"`
	CardTokenCosts          []int32
}

type XmlCardCompoundConfig struct {
	Items []XmlCardCompoundItem `xml:"item"`
}

type CfgCardCompoundCfgMgr struct {
	QuaTime2Cfg map[int32]*XmlCardCompoundItem
}

var cfg_cardcompound_cfgmgr CfgCardCompoundCfgMgr

func (this *CfgCardCompoundCfgMgr) Init() bool {
	if !this.Load() {
		return false
	}
	return true
}

func (this *CfgCardCompoundCfgMgr) Load() bool {
	content, err := ioutil.ReadFile("../game_data/CardCompound.xml")
	if nil != err {
		log.Error("CfgCardCompoundCfgMgr Load ReadFile error[%s] !", err.Error())
		return false
	}

	tmp_cfg := &XmlCardCompoundConfig{}
	err = xml.Unmarshal(content, tmp_cfg)
	if nil != err {
		log.Error("CfgCardCompoundCfgMgr Load xml unmarshal error [%s]!", err.Error())
		return false
	}

	this.QuaTime2Cfg = make(map[int32]*XmlCardCompoundItem)
	var tmp_val *XmlCardCompoundItem
	tmp_len := int32(0)
	tmp_type := int(0)
	tmp_count := int(0)
	tmp_key := int32(0)
	for idx := int32(0); idx < int32(len(tmp_cfg.Items)); idx++ {
		tmp_val = &tmp_cfg.Items[idx]
		type_strs := strings.Split(tmp_val.CardCompoundTokenTypes, "|")
		tmp_len = int32(len(type_strs))
		count_strs := strings.Split(tmp_val.CardCompoundTokenCounts, "|")
		if tmp_len != int32(len(count_strs)) {
			log.Error("CfgCardCompoundCfgMgr Load type_num[%d] != count_num[%d] ", tmp_len, int32(len(count_strs)))
			return false
		}

		tmp_val.CardTokenCosts = make([]int32, MAX_CARD_TOKEN_TYPE_NUM)
		for j := int32(0); j < tmp_len; j++ {
			tmp_type, err = strconv.Atoi(type_strs[j])
			if nil != err {
				log.Error("CfgCardCompoundCfgMgr Load failed to convert type_str[%s:%s] %v", type_strs[j], err.Error(), tmp_val)
				return false
			}

			tmp_count, err = strconv.Atoi(count_strs[j])
			if nil != err {
				log.Error("CfgCardCompoundCfgMgr Load failed to convert count_str[%s:%s]", count_strs[j], err.Error())
				return false
			}

			if tmp_type < 1 || tmp_type > MAX_CARD_TOKEN_TYPE_NUM {
				log.Error("CfgCardCompoundCfgMgr Load tmp_type[%d] error !", tmp_type)
				return false
			}

			tmp_val.CardTokenCosts[int32(tmp_type)-1] = int32(tmp_count)
		}

		tmp_key = tmp_val.CardQuality*CARD_COMPOUND_QUA_KEY_MULTI + tmp_val.CardCompoundTimes
		this.QuaTime2Cfg[tmp_key] = tmp_val
	}

	log.Info("卡片合成配置 %v", this.QuaTime2Cfg[1001])

	return true
}
