package main

import (
	"libs/log"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"strconv"
	"strings"

	"3p/code.google.com.protobuf/proto"
)

type GmCommandMgr struct {
}

var gm_command_mgr GmCommandMgr

func (this *GmCommandMgr) Init() bool {
	this.RegGmMsg()
	return true
}

// =============================================

func (this *GmCommandMgr) RegGmMsg() {
	center_conn.SetMessageHandler(msg_server_message.ID_C2HGmCommand, C2HGmCommandHandler)
}

func C2HGmCommandHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.C2HGmCommand)
	if nil == c || nil == req {
		log.Error("C2HGmCommandHandler c or req nil !")
		return
	}

	tm_str := req.GetCommand()
	tmp_arr := strings.Split(tm_str, " ")

	tmp_len := int32(len(tmp_arr))
	if len(tmp_arr) < 1 {
		log.Error("C2HGmCommandHandler tmp_arr empty")
		return
	}

	cmd := tmp_arr[0]
	tmp_len--
	switch cmd {
	case "set_lvl":
		{
			if tmp_len < 2 {
				log.Error("gm_cmd[%s] less param [%d]", cmd, tmp_len)
				return
			}

			pid, err := strconv.Atoi(tmp_arr[1])
			if nil != err {
				log.Error("gm_cmd[%s] failed to convert pid [%s]", cmd, tmp_arr[1])
				return
			}

			lvl, err := strconv.Atoi(tmp_arr[2])
			if nil != err || lvl <= 0 {
				log.Error("gm_cmd[%s] failed to convert lvl [%s] [%d]", cmd, tmp_arr[2], lvl)
				return
			}

			p := player_mgr.GetPlayerById(int32(pid))
			if nil == p {
				return
			}

			p.db.Info.SetLvl(int32(lvl))
			res2cli := &msg_client_message.S2CPlayerLvlUp{}
			res2cli.Lvl = proto.Int32(int32(lvl))
			res2cli.Exp = proto.Int32(p.db.Info.GetExp())
			p.Send(res2cli)
		}
	case "give_chest":
		{
			if tmp_len < 2 {
				log.Error("gm_cmd[%s] less param [%d]", cmd, tmp_len)
				return
			}

			pid, err := strconv.Atoi(tmp_arr[1])
			if nil != err {
				log.Error("gm_cmd[%s] failed to convert pid [%s]", cmd, tmp_arr[1])
				return
			}

			p := player_mgr.GetPlayerById(int32(pid))
			if nil == p {
				log.Error("gm_cmd[%s] failed to find player [%d]", cmd, pid)
				return
			}

			chest_id, err := strconv.Atoi(tmp_arr[2])
			if nil != err {
				log.Error("gm_cmd[%s] failed to convert chest_id [%s]", cmd, tmp_arr[2])
				return
			}

			if nil == chest_cfg_mgr.Map[int32(chest_id)] {
				log.Error("gm_cmd[%s] failed to find chest_id [%d]", cmd, chest_id)
				return
			}

			p.AddChest(int32(chest_id), "gm_add", "gm", false)
		}
	case "set_camp":
		{
			if tmp_len < 2 {
				log.Error("gm_cmd[%s] less param [%d]", cmd, tmp_len)
				return
			}

			pid, err := strconv.Atoi(tmp_arr[1])
			if nil != err {
				log.Error("gm_cmd[%s] failed to convert pid [%s]", cmd, tmp_arr[1])
				return
			}

			p := player_mgr.GetPlayerById(int32(pid))
			if nil == p {
				log.Error("gm_cmd[%s] failed to find player [%d]", cmd, pid)
				return
			}

			camp_id, err := strconv.Atoi(tmp_arr[2])
			if nil != err {
				log.Error("gm_cmd[%s] failed to convert camp_id [%s]", cmd, tmp_arr[2])
				return
			}

			if PLAYER_CAMP_1 != camp_id && PLAYER_CAMP_2 != camp_id {
				log.Error("gm_cmd[%s] wrong camp_id [%d]", cmd, camp_id)
				return
			}

			p.db.Info.SetCamp(int32(camp_id))
		}
	case "give_card":
		{
			if tmp_len < 2 {
				log.Error("gm_cmd[%s] less param [%d]", cmd, tmp_len)
				return
			}

			pid, err := strconv.Atoi(tmp_arr[1])
			if nil != err {
				log.Error("gm_cmd[%s] failed to convert pid [%s]", cmd, tmp_arr[1])
				return
			}

			p := player_mgr.GetPlayerById(int32(pid))
			if nil == p {
				log.Error("gm_cmd[%s] failed to find player [%d]", cmd, pid)
				return
			}

			card_id, err := strconv.Atoi(tmp_arr[2])
			if nil != err {
				log.Error("gm_cmd[%s] failed to convert card_id [%s]", cmd, tmp_arr[2])
				return
			}

			p.AddCard(int32(card_id), 1, "gm_give_card", "gm", false, false)
		}
	case "set_score":
		{
			if tmp_len < 2 {
				log.Error("gm_cmd[%s] less param [%d]", cmd, tmp_len)
				return
			}

			pid, err := strconv.Atoi(tmp_arr[1])
			if nil != err {
				log.Error("gm_cmd[%s] failed to convert pid [%s]", cmd, tmp_arr[1])
				return
			}

			p := player_mgr.GetPlayerById(int32(pid))
			if nil == p {
				log.Error("gm_cmd[%s] failed to find player [%d]", cmd, pid)
				return
			}

			new_score, err := strconv.Atoi(tmp_arr[2])
			if nil != err {
				log.Error("gm_cmd[%s] failed to convert new_score [%s]", cmd, tmp_arr[2])
				return
			}

			p.db.Info.SetMatchScore(int32(new_score))
		}
	}
}
