package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"time"
)

type XmlSevenDayItem struct {
	TasksID         int32 `xml:"TasksID,attr"`
	FinishCondition int32 `xml:"FinishCondition,attr"`
	FinishNeedCount int32 `xml:"FinishNeedCount,attr"`
	StartDay        int32 `xml:"Day,attr"`
	LastDays        int32 `xml:"LastDays,attr"`
	Reward          int32 `xml:"Reward,attr"`
}

type XmlSevenDayConfig struct {
	Items              []XmlSevenDayItem `xml:"item"`
	ActivityOriginType int32             `xml:"ActivityOriginType,attr"`
}

type XmlActivityConfig struct {
	SevenDays XmlSevenDayConfig `xml:"SevenDays"`
}

type SevenDayActs struct {
	ActType int32 // 活动类型
	Count   int32
	Array   []*XmlSevenDayItem
}

type CfgPlayerActMananger struct {
	type2sevendayacts map[int32]*SevenDayActs
	id2sevendayact    map[int32]*XmlSevenDayItem
}

var cfg_player_act_mgr CfgPlayerActMananger

func (this *CfgPlayerActMananger) Init() bool {
	if !this.Load() {
		log.Error("CfgPlayerActMananger Init load failed !")
		return false
	}

	log.Info("类型1七天乐", this.type2sevendayacts[1])

	return true
}

func (this *CfgPlayerActMananger) Load() bool {
	content, err := ioutil.ReadFile("../game_data/ActivityConfig.xml")
	if nil != err {
		log.Error("CfgDaySignManager Load read file error [%s]", err.Error())
		return false
	}

	tmp_cfg := &XmlActivityConfig{}
	err = xml.Unmarshal(content, tmp_cfg)
	if nil != err {
		log.Error("CfgPlayerActMananger Load Unmarshal content error !")
		return false
	}

	this.id2sevendayact = make(map[int32]*XmlSevenDayItem)
	this.type2sevendayacts = make(map[int32]*SevenDayActs)
	var tmp_seven *XmlSevenDayItem
	tmp_len := int32(len(tmp_cfg.SevenDays.Items))
	for i := int32(0); i < tmp_len; i++ {
		tmp_seven = &tmp_cfg.SevenDays.Items[i]
		if nil == tmp_seven {
			continue
		}

		if nil == this.type2sevendayacts[tmp_seven.FinishCondition] {
			this.type2sevendayacts[tmp_seven.FinishCondition] = &SevenDayActs{}
			this.type2sevendayacts[tmp_seven.FinishCondition].ActType = tmp_seven.FinishCondition
		}

		this.type2sevendayacts[tmp_seven.FinishCondition].Count++
		this.id2sevendayact[tmp_seven.TasksID] = tmp_seven
	}
	for i := int32(0); i < tmp_len; i++ {
		tmp_seven = &tmp_cfg.SevenDays.Items[i]
		if nil == tmp_seven {
			continue
		}

		if nil == this.type2sevendayacts[tmp_seven.FinishCondition].Array {
			this.type2sevendayacts[tmp_seven.FinishCondition].Array = make([]*XmlSevenDayItem, 0, this.type2sevendayacts[tmp_seven.FinishCondition].Count)
		}

		this.type2sevendayacts[tmp_seven.FinishCondition].Array = append(this.type2sevendayacts[tmp_seven.FinishCondition].Array, tmp_seven)
	}

	log.Info("CfgDaySignManager test %v", tmp_cfg.SevenDays.ActivityOriginType)

	return true
}

func (this *CfgPlayerActMananger) GetSevenDayLeftSec(create_unix_day, cur_unix_day, act_id int32) int32 {
	tmp_seven := this.id2sevendayact[act_id]
	if nil == tmp_seven {
		return 0
	}

	log.Info("CfgPlayerActMananger GetSevenDayLeftSec create_unix_day, cur_unix_day act_id")

	start_day := create_unix_day + tmp_seven.StartDay
	end_day := create_unix_day + tmp_seven.LastDays
	if cur_unix_day >= start_day && cur_unix_day < end_day {
		return (end_day-start_day)*24*3600 - int32(time.Now().Hour()*3600+time.Now().Minute()*60+time.Now().Second())
	}

	return 0
}

func (this *CfgPlayerActMananger) GetSevenDayLeftDays(create_unix_day, cur_unix_day, act_id int32) int32 {
	tmp_seven := this.id2sevendayact[act_id]
	if nil == tmp_seven {
		return 0
	}

	log.Info("CfgPlayerActMananger GetSevenDayLeftSec create_unix_day, cur_unix_day act_id")

	start_day := create_unix_day + tmp_seven.StartDay
	end_day := create_unix_day + tmp_seven.LastDays
	if cur_unix_day >= start_day && cur_unix_day < end_day {
		return (end_day - start_day)
	}

	return 0
}
