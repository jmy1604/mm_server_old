package main

import (
	"libs/log"
	"libs/socket"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"strconv"

	"3p/code.google.com.protobuf/proto"
)

const (
	FRIEND_REQ_TYPE_FRIEND  = 1
	FIREND_REQ_TYPE_FOCUS   = 2
	FRIEND_REQ_TYPE_BEFOCUS = 3
)

// ----------------------------------------------------------------------------

func reg_player_friend_msg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetFriendList, C2SGetFriendListHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SAddFriendByPId, C2SAddFriendByPIdHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SAddFriendByAcc, C2SAddFriendByAccHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SAddFriendAgree, C2SAddFriendAgreeHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SAddFocusByPId, C2SAddFocusByPIdHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SAddFocusByAcc, C2SAddFocusByAccHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SFriendChat, C2SFriendChatHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SFriendRemove, C2SFriendRemoveHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SRemoveFocus, C2SRemoveFocusHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SFriendSearch, C2SFriendSearchHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetOnlineFriends, C2SGetOnlineFriendsHandler)

	center_conn.SetMessageHandler(msg_server_message.ID_AddFriendByPId, C2HNotifyFriendAddReq)
	center_conn.SetMessageHandler(msg_server_message.ID_AgreeAddFriend, C2HAgreeAddFriendHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_GetFocusedPlayerInfo, C2HGetFocusedPlayerInfoHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_RetFocusedPlayerInfo, C2HRetFocusedPlayerInfoHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_FriendChat, C2HFriendChatHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_AddFocusByPId, C2HAddFocusByIdHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_RemoveFriendById, C2HRemoveFriendByIdHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_RemoveFocusById, C2HRemoveFocusByIdHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_FriendSearchResult, C2HFriendSearchResultHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_FriendSearch, C2HFriendSearchHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_RetOnlineFriendIds, C2HRetOnlineFriendsHandler)
}

func C2SGetFriendListHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetFriendList)
	if nil == c || nil == req {
		log.Error("C2SGetFriendListHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SGetFriendListHandler not login [%d]", c.T)
		return
	}

	res2cli := &msg_client_message.S2CRetFriendList{}
	p.db.FriendReqs.FillAllListMsg(res2cli)
	switch req.GetFriendType() {
	case FRIEND_REQ_TYPE_FRIEND:
		{
			p.db.Friends.FillAllListMsg(res2cli)
			p.Send(res2cli)
		}
	case FIREND_REQ_TYPE_FOCUS:
		{
			p.db.FocusPlayers.FillAllListMsg(res2cli)
			p.Send(res2cli)
		}
	case FRIEND_REQ_TYPE_BEFOCUS:
		{
			p.db.BeFocusPlayers.FillAllListMsg(res2cli)
			p.Send(res2cli)
		}
	default:
		{
			log.Error("C2SGetFriendListHandler  [%d] wrong type", c.T, req.GetFriendType())
		}
	}

	return
}

func C2SAddFriendByPIdHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SAddFriendByPId)
	if nil == c || nil == req {
		log.Error("C2SAddFriendByPIdHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SAddFriendByPIdHandler not login [%d]", c.T)
		return
	}

	tgt_pid := req.GetPlayerId()
	if p.Id == tgt_pid {
		log.Error("C2SAddFriendByPIdHandler add self !")
		return
	}

	res2co := &msg_server_message.AddFriendByPId{}
	res2co.PlayerId = proto.Int32(tgt_pid)
	res2co.ReqPlayerId = proto.Int32(p.Id)
	res2co.ReqPlayerName = proto.String(p.db.GetName())
	res2co.ReqPlayerScore = proto.Int32(p.db.Info.GetMatchScore())
	res2co.ReqPlayerTongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
	res2co.ReqPlayerTongName = proto.String(p.db.TongInfo.GetTongName())

	center_conn.Send(res2co)

	return
}

func C2SAddFriendByAccHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SAddFriendByAcc)
	if nil == c || nil == req {
		log.Error("C2SAddFriendByAccHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SAddFriendByAccHandler not login [%d]", c.T)
		return
	}

	tgt_acc := req.GetAccount()
	if tgt_acc == p.Account {
		log.Error("C2SAddFriendByAccHandler add self")
		return
	}

	res2co := &msg_server_message.AddFriendByAcc{}
	res2co.Account = proto.String(tgt_acc)
	res2co.ReqPlayerId = proto.Int32(p.Id)
	res2co.ReqPlayerScore = proto.Int32(p.db.Info.GetMatchScore())
	res2co.ReqPlayerTongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
	res2co.ReqPlayerTongName = proto.String(p.db.TongInfo.GetTongName())

	center_conn.Send(res2co)

	return
}

func C2SAddFriendAgreeHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SAddFriendAgree)
	if nil == c || nil == req {
		log.Error("C2SAddFriendAgreeHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SAddFriendAgreeHandler not login [%d]", c.T)
		return
	}

	req_pid := req.GetPlayerId()
	cur_req := p.db.FriendReqs.Get(req_pid)
	if nil == cur_req {
		log.Error("C2SAddFriendAgreeHandler not in req list !")
		return
	}

	p.db.FriendReqs.Remove(req_pid)

	res2co := &msg_server_message.AgreeAddFriend{}
	res2co.PlayerId = proto.Int32(p.Id)
	res2co.Name = proto.String(p.db.GetName())
	res2co.Score = proto.Int32(p.db.Info.GetMatchScore())
	res2co.TongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
	res2co.TongName = proto.String(p.db.TongInfo.GetTongName())
	res2co.ReqPlayerId = proto.Int32(req.GetPlayerId())

	center_conn.Send(res2co)

	new_db_fri := &dbPlayerFriendData{}
	new_db_fri.FriendPId = cur_req.FriendPId
	new_db_fri.FriendName = cur_req.FriendName
	new_db_fri.MatchScore = cur_req.MatchScore
	new_db_fri.TongIcon = cur_req.TongIcon
	new_db_fri.TongName = cur_req.TongName
	p.db.Friends.TryAddFriend(new_db_fri)

	res2cli := &msg_client_message.S2CFriendAdd{}
	res2cli.PlayerId = proto.Int32(new_db_fri.FriendPId)
	res2cli.Name = proto.String(new_db_fri.FriendName)
	res2cli.Score = proto.Int32(new_db_fri.MatchScore)
	res2cli.TongIcon = proto.Int32(new_db_fri.TongIcon)
	res2cli.TongName = proto.String(new_db_fri.TongName)

	p.Send(res2cli)

	return
}

func C2SFriendRemoveHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SFriendRemove)
	if nil == c || nil == req {
		log.Error("C2SFriendRemoveHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SFriendRemoveHandler not login [%d]", c.T)
		return
	}

	tgp_pid := req.GetPlayerId()
	if nil == p.db.Friends.Get(tgp_pid) {
		log.Error("C2SFriendRemoveHandler not in friend [%d]", tgp_pid)
		return
	}

	p.db.Friends.Remove(tgp_pid)

	req2co := &msg_server_message.RemoveFriendById{}
	req2co.PlayerId = proto.Int32(tgp_pid)
	req2co.ReqPlayerId = proto.Int32(p.Id)

	center_conn.Send(req2co)

	res2cli := &msg_client_message.S2CFriendReomve{}
	res2cli.PlayerId = proto.Int32(tgp_pid)

	p.Send(res2cli)
}

func C2SAddFocusByPIdHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SAddFocusByPId)
	if nil == c || nil == req {
		log.Error("C2SAddFocusByPIdHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SAddFocusByPIdHandler not login [%d]", c.T)
		return
	}

	res2co := &msg_server_message.AddFocusByPId{}
	res2co.PlayerId = proto.Int32(req.GetPlayerId())
	res2co.ReqPlayerId = proto.Int32(p.Id)
	res2co.ReqPlayerScore = proto.Int32(p.db.Info.GetMatchScore())
	res2co.ReqPlayerTongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
	res2co.ReqPlayerTongName = proto.String(p.db.TongInfo.GetTongName())

	center_conn.Send(res2co)

	return
}

func C2SAddFocusByAccHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SAddFocusByAcc)
	if nil == c || nil == req {
		log.Error("C2SAddFocusByAccHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SAddFocusByAccHandler not login [%d]", c.T)
		return
	}

	res2co := &msg_server_message.AddFocusByAcc{}
	res2co.Account = proto.String(req.GetAccount())
	res2co.ReqPlayerId = proto.Int32(p.Id)
	res2co.ReqPlayerScore = proto.Int32(p.db.Info.GetMatchScore())
	res2co.ReqPlayerTongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
	res2co.ReqPlayerTongName = proto.String(p.db.TongInfo.GetTongName())

	center_conn.Send(res2co)

	return
}

func C2SRemoveFocusHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SRemoveFocus)
	if nil == c || nil == req {
		log.Error("C2SRemoveFocusHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SRemoveFocusHandler not login [%d]", c.T)
		return
	}

	tgp_pid := req.GetPlayerId()
	if nil == p.db.FocusPlayers.Get(tgp_pid) {
		log.Error("C2SRemoveFocusHandler not in focus [%d]", tgp_pid)
		return
	}

	p.db.Friends.Remove(tgp_pid)

	req2co := &msg_server_message.RemoveFocusById{}
	req2co.PlayerId = proto.Int32(tgp_pid)
	req2co.ReqPlayerId = proto.Int32(p.Id)

	center_conn.Send(req2co)

	res2cli := &msg_client_message.S2CRemoveFocus{}
	res2cli.PlayerId = proto.Int32(tgp_pid)

	p.Send(res2cli)
}

func C2SFriendChatHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SFriendChat)
	if nil == c || nil == req {
		log.Error("C2SFriendChatHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SFriendChatHandler not login [%d]", c.T)
		return
	}

	req2co := &msg_server_message.FriendChat{}
	req2co.Content = proto.String(req.GetContent())
	req2co.PlayerId = proto.Int32(req.GetPlayerId())
	req2co.SenderId = proto.Int32(p.Id)

	center_conn.Send(req)
}

func C2SFriendSearchHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SFriendSearch)
	if nil == c || nil == req {
		log.Error("C2SFriendSearchHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SFriendSearchHandler not login [%d]", c.T)
		return
	}

	req2co := &msg_server_message.FriendSearch{}
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.Key = proto.String(req.GetKey())

	center_conn.Send(req2co)
	return
}

func C2SGetOnlineFriendsHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetOnlineFriends)
	if nil == c || nil == req {
		log.Error("C2SGetOnlineFriendsHandler c or req nil %v!", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SGetOnlineFriendsHandler not login [%d]", c.T)
		return
	}

	req2co := &msg_server_message.GetOnlineFriendIds{}
	req2co.ReqPlayerId = proto.Int32(p.Id)
	req2co.Key = proto.Int32(req.GetKey())
	switch *req2co.Key {
	case FRIEND_REQ_TYPE_FRIEND:
		{
			req2co.PlayerIds = p.db.Friends.GetAllIds()
			if nil == req2co.PlayerIds {
				log.Trace("C2SGetOnlineFriendsHandler no friends !")
				return
			}
		}
	case FIREND_REQ_TYPE_FOCUS:
		{
			req2co.PlayerIds = p.db.FocusPlayers.GetAllIds()
			if nil == req2co.PlayerIds {
				log.Trace("C2SGetOnlineFriendsHandler no friends !")
				return
			}
		}
	case FRIEND_REQ_TYPE_BEFOCUS:
		{
			log.Trace("C2SGetOnlineFriendsHandler wrong type !")
			return
		}
	}

	center_conn.Send(req2co)
	return
}

// ------------------------------------------------------

func C2HNotifyFriendAddReq(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.AddFriendByPId)
	if nil == c || nil == req {
		log.Error("C2HNotifyFriendAddReq c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(req.GetPlayerId())
	if nil == p {
		log.Error("C2HNotifyFriendAddReq p nil !")
		return
	}

	req_pid := req.GetReqPlayerId()
	if nil != p.db.FriendReqs.Get(req_pid) {
		log.Error("C2HNotifyFriendAddReq already in !")
		return
	}

	new_db_req := &dbPlayerFriendReqData{}
	new_db_req.FriendPId = req.GetReqPlayerId()
	new_db_req.FriendName = req.GetReqPlayerName()
	new_db_req.MatchScore = req.GetReqPlayerScore()
	new_db_req.TongIcon = req.GetReqPlayerTongIcon()
	new_db_req.TongName = req.GetReqPlayerTongName()

	p.db.FriendReqs.Add(new_db_req)

	p.SendAddFriendMail(req.GetPlayerId(), req.GetReqPlayerName())
}

func C2HAgreeAddFriendHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.AgreeAddFriend)
	if nil == req {
		log.Error("C2HAgreeAddFriendHandler req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(req.GetPlayerId())
	if nil == p {
		log.Error("C2HAgreeAddFriendHandler p nil !")
		return
	}

	req_pid := req.GetReqPlayerId()
	req_p := player_mgr.GetPlayerById(req_pid)
	if nil == req_p {
		log.Error("C2HAgreeAddFriendHandler req_p nil")
		return
	}

	new_friend := &dbPlayerFriendData{}
	new_friend.FriendPId = req.GetPlayerId()
	new_friend.FriendName = req.GetName()
	new_friend.TongIcon = req.GetTongIcon()
	new_friend.TongName = req.GetTongName()
	new_friend.MatchScore = req.GetScore()

	if 0 != req_p.db.Friends.TryAddFriend(new_friend) {
		log.Error("C2HAgreeAddFriendHandler failed to add new friend !")
		return
	}

	res2cli := &msg_client_message.S2CFriendAdd{}
	res2cli.PlayerId = proto.Int32(new_friend.FriendPId)
	res2cli.Name = proto.String(new_friend.FriendName)
	res2cli.Score = proto.Int32(new_friend.MatchScore)
	res2cli.TongIcon = proto.Int32(new_friend.TongIcon)
	res2cli.TongName = proto.String(new_friend.TongName)

	req_p.Send(res2cli)

	return
}

func C2HGetFocusedPlayerInfoHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.GetFocusedPlayerInfo)
	if nil == c || nil == req {
		log.Error("C2HGetFocusedPlayerInfoHandler c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(req.GetPlayerId())
	if nil == p {
		log.Error("C2HGetFocusedPlayerInfoHandler p nil !")
		return
	}

	req_pid := req.GetReqPlayerId()
	if nil != p.db.BeFocusPlayers.Get(req_pid) {
		log.Error("C2HGetFocusedPlayerInfoHandler already in !")
		return
	}

	new_db_rd := &dbPlayerBeFocusPlayerData{}
	new_db_rd.FriendPId = req.GetReqPlayerId()
	new_db_rd.FriendName = req.GetReqPlayerName()
	new_db_rd.MatchScore = req.GetReqPlayerScore()
	new_db_rd.TongIcon = req.GetReqPlayerTongIcon()
	new_db_rd.TongName = req.GetReqPlayerTongName()

	p.db.BeFocusPlayers.Add(new_db_rd)

	res2cli := &msg_client_message.S2CBeFocus{}
	res2cli.PlayerId = proto.Int32(req.GetReqPlayerId())
	res2cli.Name = proto.String(req.GetReqPlayerName())
	res2cli.Score = proto.Int32(req.GetReqPlayerScore())
	res2cli.TongIcon = proto.Int32(req.GetReqPlayerTongIcon())
	res2cli.TongName = proto.String(req.GetReqPlayerTongName())

	p.Send(res2cli)

}

func C2HRetFocusedPlayerInfoHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RetFocusedPlayerInfo)
	if nil == c || nil == res {
		log.Error("C2HRRetFocusedPlayerInfoHandler c or req nil [%v]", nil == res)
		return
	}

	req_p := player_mgr.GetPlayerById(res.GetReqPlayerId())
	if nil == req_p {
		log.Error("C2HRRetFocusedPlayerInfoHandler req_p nil !")
		return
	}

	p_id := res.GetPlayerId()
	if nil != req_p.db.FocusPlayers.Get(p_id) {
		log.Error("C2HRRetFocusedPlayerInfoHandler already in !")
		return
	}

	new_db_rd := &dbPlayerFocusPlayerData{}
	new_db_rd.FriendPId = res.GetPlayerId()
	new_db_rd.FriendName = res.GetName()
	new_db_rd.MatchScore = res.GetScore()
	new_db_rd.TongIcon = res.GetTongIcon()
	new_db_rd.TongName = res.GetTongName()

	req_p.db.FocusPlayers.Add(new_db_rd)

	res2cli := &msg_client_message.S2CFocusAdd{}
	res2cli.PlayerId = proto.Int32(new_db_rd.FriendPId)
	res2cli.Name = proto.String(new_db_rd.FriendName)
	res2cli.Score = proto.Int32(new_db_rd.MatchScore)
	res2cli.TongIcon = proto.Int32(new_db_rd.TongIcon)
	res2cli.TongName = proto.String(new_db_rd.TongName)

	req_p.Send(res2cli)

}

func C2HRemoveFriendByIdHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RemoveFriendById)
	if nil == c || nil == res {
		log.Error("C2HRemoveFriendByIdHandler c or req nil [%v]", nil == res)
		return
	}

	p := player_mgr.GetPlayerById(res.GetPlayerId())
	if nil == p {
		log.Error("C2HRemoveFriendByIdHandler p nil !")
		return
	}

	req_pid := res.GetPlayerId()
	if nil != p.db.Friends.Get(req_pid) {
		log.Error("C2HRemoveFriendByIdHandler not in !")
		return
	}

	p.db.Friends.Remove(req_pid)

	res2cli := &msg_client_message.S2CFriendReomve{}
	res2cli.PlayerId = proto.Int32(req_pid)

	p.Send(res2cli)

}

func C2HFriendChatHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.FriendChat)
	if nil == c || nil == res {
		log.Error("C2HFriendChatHandler c or req nil [%v]", nil == res)
		return
	}

	p_id := res.GetPlayerId()

	p := player_mgr.GetPlayerById(p_id)
	if nil == p {
		log.Error("C2HFriendChatHandler failed to find p[%d]", p_id)
		return
	}

	res2cli := &msg_client_message.S2CFriendChat{}
	res2cli.PlayerId = proto.Int32(res.GetSenderId())
	res2cli.Content = proto.String(res.GetContent())

	p.Send(res2cli)

}

func C2HAddFocusByIdHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.AddFocusByPId)
	if nil == c || nil == res {
		log.Error("C2HAddFocusByIdHandler c or res nil [%v]", nil == res)
		return
	}

	p := player_mgr.GetPlayerById(res.GetPlayerId())
	if nil == p {
		log.Error("C2HAddFocusByIdHandler p nil !")
		return
	}

	req_pid := res.GetReqPlayerId()
	if nil != p.db.BeFocusPlayers.Get(req_pid) {
		log.Error("C2HAddFocusByIdHandler already in !")
		return
	}

	new_db_f := &dbPlayerBeFocusPlayerData{}
	new_db_f.FriendPId = res.GetPlayerId()
	new_db_f.FriendName = res.GetReqPlayerName()
	new_db_f.MatchScore = res.GetReqPlayerScore()
	new_db_f.TongIcon = res.GetReqPlayerTongIcon()
	new_db_f.TongName = res.GetReqPlayerTongName()

	p.db.BeFocusPlayers.Add(new_db_f)

	res2cli := &msg_client_message.S2CBeFocus{}
	res2cli.PlayerId = proto.Int32(new_db_f.FriendPId)
	res2cli.Name = proto.String(new_db_f.FriendName)
	res2cli.Score = proto.Int32(new_db_f.MatchScore)
	res2cli.TongIcon = proto.Int32(new_db_f.TongIcon)
	res2cli.TongName = proto.String(new_db_f.TongName)

	p.Send(res2cli)

	res2co := &msg_server_message.RetFocusedPlayerInfo{}
	res2co.PlayerId = proto.Int32(p.Id)
	res2co.Name = proto.String(p.db.GetName())
	res2co.Score = proto.Int32(p.db.Info.GetMatchScore())
	res2co.TongIcon = proto.Int32(p.db.TongInfo.GetTongIcon())
	res2co.TongName = proto.String(p.db.TongInfo.GetTongName())
	res2co.ReqPlayerId = proto.Int32(req_pid)
	center_conn.Send(res2co)

	return
}

func C2HRemoveFocusByIdHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RemoveFocusById)
	if nil == c || nil == res {
		log.Error("C2HRemoveFocusByIdHandler c or res nil [%v]", nil == res)
		return
	}

	p := player_mgr.GetPlayerById(res.GetPlayerId())
	if nil == p {
		log.Error("C2HRemoveFocusByIdHandler p nil !")
		return
	}

	req_pid := res.GetPlayerId()
	if nil != p.db.BeFocusPlayers.Get(req_pid) {
		log.Error("C2HRemoveFocusByIdHandler not in !")
		return
	}

	p.db.BeFocusPlayers.Remove(req_pid)

	res2cli := &msg_client_message.S2CRemoveBeFocus{}
	res2cli.PlayerId = proto.Int32(req_pid)

	p.Send(res2cli)
}

func C2HFriendSearchHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.FriendSearch)
	if nil == c || nil == req {
		log.Error("C2HRemoveFocusByIdHandler c or res nil [%v]", nil == req)
		return
	}

	res2co := &msg_server_message.FriendSearchResult{}
	res2co.PlayerId = proto.Int32(req.GetPlayerId())

	key := req.GetKey()
	var tmp_pid int32

	tmp_ival, err := strconv.Atoi(key)
	if nil == err {
		log.Info("可以转化Id[%d]", tmp_ival)
		tmp_pid = int32(tmp_ival)
	} else {
		log.Info("不可以转化为Id[%s]", key)
	}

	cur_p_num := player_mgr.GetAllPlayerNum()
	var tmp_p *Player
	var tmp_fi *msg_server_message.FriendInfo
	cur_num := int32(0)
	res2co.Records = make([]*msg_server_message.FriendInfo, 0, 20)
	log.Info("搜索好友 %d")
	for idx := int32(0); idx < cur_p_num; idx++ {
		tmp_p = player_mgr.all_player_array[idx]
		if nil == tmp_p {
			continue
		}

		if tmp_pid > 0 && tmp_pid == tmp_p.Id || key == tmp_p.db.GetName() {
			tmp_fi = &msg_server_message.FriendInfo{}
			tmp_fi.PlayerId = proto.Int32(tmp_p.Id)
			tmp_fi.PlayerName = proto.String(tmp_p.db.GetName())
			tmp_fi.PlayerScore = proto.Int32(tmp_p.db.Info.GetMatchScore())
			tmp_fi.PlayerTongIcon = proto.Int32(tmp_p.db.TongInfo.GetTongIcon())
			tmp_fi.PlayerTongName = proto.String(tmp_p.db.TongInfo.GetTongName())

			res2co.Records = append(res2co.Records, tmp_fi)
			cur_num++
			if cur_num >= 20 {
				c.Send(res2co)
				cur_num = int32(0)
				res2co.Records = make([]*msg_server_message.FriendInfo, 0, 20)
			}
		}
	}

	if cur_num > 0 {
		c.Send(res2co)
	}

	return
}

func C2HFriendSearchResultHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.FriendSearchResult)

	p := player_mgr.GetPlayerById(res.GetPlayerId())
	if nil == p {
		log.Error("C2HFriendSearchResultHandler p nil !")
		return
	}

	rds := res.GetRecords()
	tmp_len := int32(len(res.GetRecords()))
	res2cli := &msg_client_message.S2CFriendSearch{}
	res2cli.Result = make([]*msg_client_message.FriendInfo, 0, tmp_len)
	var tmp_rd *msg_client_message.FriendInfo
	for _, val := range rds {
		tmp_rd = &msg_client_message.FriendInfo{}
		tmp_rd.PlayerId = proto.Int32(val.GetPlayerId())
		tmp_rd.Name = proto.String(val.GetPlayerName())
		tmp_rd.Score = proto.Int32(val.GetPlayerScore())
		tmp_rd.TongIcon = proto.Int32(val.GetPlayerTongIcon())
		tmp_rd.TongName = proto.String(val.GetPlayerTongName())

		res2cli.Result = append(res2cli.Result, tmp_rd)
	}

	p.Send(res2cli)

	return
}

func C2HRetOnlineFriendsHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RetOnlineFriendIds)
	p := player_mgr.GetPlayerById(res.GetReqPlayerId())
	if nil == p {
		log.Error("C2HRetOnlineFriendsHandler p nil !")
		return
	}

	res2cli := &msg_client_message.S2CRetOnlineFriends{}
	res2cli.PlayerIds = res.GetPlayerIds()
	res2cli.Key = proto.Int32(res.GetKey())
	p.Send(res2cli)
	return
}
