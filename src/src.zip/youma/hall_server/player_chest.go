package main

import (
	"libs/log"
	"libs/socket"
	"math/rand"
	"public_message/gen_go/client_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

func (this *Player) ChkPlayerFreeChest() int32 {
	cur_unix := int32(time.Now().Unix())
	last_unix := this.db.TowerAndFreeChest.GetLastFreeChestUpUnix()

	cur_mod_sec := global_config.FreeChestCdSec
	cur_free_num := this.db.TowerAndFreeChest.GetCurFreeChestNum()
	if cur_free_num < global_config.MaxFreeChestNum {

		if last_unix <= 0 {
			this.db.TowerAndFreeChest.SetLastFreeChestUpUnix(cur_unix)
			return global_config.FreeChestCdSec
		}

		past_sec := cur_unix - last_unix
		cd_num := past_sec / global_config.FreeChestCdSec
		cur_mod_sec = past_sec - cd_num*global_config.FreeChestCdSec

		new_num := cur_free_num + cd_num
		if new_num >= global_config.MaxFreeChestNum {
			cur_mod_sec = global_config.FreeChestCdSec
			this.db.TowerAndFreeChest.SetLastFreeChestUpUnix(0)
			this.db.TowerAndFreeChest.SetCurFreeChestNum(global_config.MaxFreeChestNum)
		} else {
			this.db.TowerAndFreeChest.SetLastFreeChestUpUnix(cur_unix - cur_mod_sec)
			this.db.TowerAndFreeChest.SetCurFreeChestNum(new_num)
		}
	} else {
		return 0
	}

	return global_config.FreeChestCdSec - cur_mod_sec
}

func (this *Player) ChkPlayerTowerChest() int32 {
	cur_unix := int32(time.Now().Unix())
	last_unix := this.db.TowerAndFreeChest.GetLastTowerChestUpUnix()

	cur_mod_sec := global_config.TowerChestCdSec
	cur_chest_num := this.db.TowerAndFreeChest.GetCurTowerChestNum()
	if cur_chest_num < global_config.MaxTowerChestNum {

		if last_unix <= 0 {
			this.db.TowerAndFreeChest.SetLastTowerChestUpUnix(cur_unix)
			return global_config.FreeChestCdSec
		}

		past_sec := cur_unix - last_unix
		cd_num := past_sec / global_config.FreeChestCdSec
		cur_mod_sec = past_sec - cd_num*global_config.FreeChestCdSec

		new_num := cur_chest_num + cd_num
		if new_num >= global_config.MaxTowerChestNum {
			cur_mod_sec = global_config.TowerChestCdSec
			this.db.TowerAndFreeChest.SetLastTowerChestUpUnix(0)
			this.db.TowerAndFreeChest.SetCurTowerChestNum(global_config.MaxFreeChestNum)
		} else {
			this.db.TowerAndFreeChest.SetLastTowerChestUpUnix(cur_unix - cur_mod_sec)
			this.db.TowerAndFreeChest.SetCurTowerChestNum(new_num)
		}
	} else {
		return 0
	}

	return global_config.TowerChestCdSec - cur_mod_sec
}

func (this *Player) SyncChestInfo() {
	sync_chest := &msg_client_message.S2CChestsSync{}
	sync_chest.CurFreeChestCd = proto.Int32(this.ChkPlayerFreeChest())
	sync_chest.CurFreeChestNum = proto.Int32(this.db.TowerAndFreeChest.GetCurFreeChestNum())
	sync_chest.CurTowerChestCd = proto.Int32(this.ChkPlayerTowerChest())
	sync_chest.CurChestTowerNum = proto.Int32(this.db.TowerAndFreeChest.GetCurTowerChestNum())
	this.db.Chests.FillAllClientChestMsg(sync_chest)

	this.Send(sync_chest)

	return
}

func (this *Player) AddChest(chest_cfg_id int32, reason, mod string, bslience bool) int32 {
	chest_cfg := chest_cfg_mgr.Map[chest_cfg_id]
	if nil == chest_cfg {
		log.Error("Player AddChest failed to get chest cfg[%d]", chest_cfg_id)
		return -1
	}

	pos := this.db.Chests.GetEmptyPos()
	if -1 == pos {
		log.Error("Player AddChest failed to get empty pos")
		return -1
	}

	this.db.Chests.SetChestId(pos, chest_cfg_id)
	this.db.Chests.SetOpenSec(pos, 0)

	log.Info("玩家[%d] 获得宝箱 [%d]", this.Id, chest_cfg_id)
	if !bslience {
		this.SyncChestInfo()
	}

	return pos
}

func (this *Player) OpenChest(chest_id int32, reason, mod string, cost_dimond, pos int32, bslience bool) *msg_client_message.S2COpenChest {
	chest_cfg := chest_cfg_mgr.Map[chest_id]
	if nil == chest_cfg {
		log.Error("Player OpenChest failed to find[%d]", chest_id)
		return nil
	}

	rand.Seed(time.Now().Unix())

	res_2cli := &msg_client_message.S2COpenChest{}
	res_2cli.ChestId = proto.Int32(chest_id)
	res_2cli.ChestPos = proto.Int32(pos)
	coin_rand := chest_cfg.GoldMax - chest_cfg.GoldMin
	cur_coin := this.GetCoin()
	tmp_val := int32(0)
	for i := int32(0); i < chest_cfg.GoldExtractTimes; i++ {
		if coin_rand <= 0 {
			cur_coin = this.AddCoin(chest_cfg.GoldMin, reason, mod)
		} else {
			tmp_val = chest_cfg.GoldMin + rand.Int31n(coin_rand)
			cur_coin = this.AddCoin(tmp_val, reason, mod)
		}
	}

	diamond_rand := chest_cfg.GemMax - chest_cfg.GemMin
	cur_diamond := this.GetDiamond()
	for i := int32(0); i < chest_cfg.GemExtractTimes; i++ {
		if diamond_rand <= 0 {
			cur_diamond = this.AddDiamond(chest_cfg.GemMin, reason, mod)
		} else {
			tmp_val = chest_cfg.GemMin + rand.Int31n(diamond_rand)
			cur_diamond = this.AddDiamond(chest_cfg.GemMin+rand.Int31n(diamond_rand), reason, mod)
		}
	}

	token1_rand := chest_cfg.CardToken1Max - chest_cfg.CardToken2Min
	cur_token1 := this.db.Info.GetCardToken1()
	for i := int32(0); i < chest_cfg.CardToken1ExtraTimes; i++ {
		if token1_rand <= 0 {
			cur_token1 = this.AddCardToken1(chest_cfg.CardToken1Min, reason, mod)
		} else {
			tmp_val = chest_cfg.CardToken1Min + rand.Int31n(token1_rand)
			cur_token1 = this.AddCardToken1(tmp_val, reason, mod)
		}
	}

	token2_rand := chest_cfg.CardToken2Max - chest_cfg.CardToken2Min
	cur_token2 := this.db.Info.GetCardToken2()
	for i := int32(0); i < chest_cfg.CardToken2ExtraTimes; i++ {
		if token2_rand <= 0 {
			cur_token2 = this.AddCardToken2(chest_cfg.CardToken2Min, reason, mod)
		} else {
			tmp_val = chest_cfg.CardToken2Min + rand.Int31n(token2_rand)
			cur_token2 = this.AddCardToken2(tmp_val, reason, mod)
		}
	}

	token3_rand := chest_cfg.CardToken3Max - chest_cfg.CardToken3Min
	cur_token3 := this.db.Info.GetCardToken3()
	for i := int32(0); i < chest_cfg.CardToken3ExtraTimes; i++ {
		if token3_rand <= 0 {
			cur_token3 = this.AddCardToken3(chest_cfg.CardToken3Min, reason, mod)
		} else {
			tmp_val = chest_cfg.CardToken3Min + rand.Int31n(token3_rand)
			cur_token3 = this.AddCardToken3(tmp_val, reason, mod)
		}
	}

	token4_rand := chest_cfg.CardToken4Max - chest_cfg.CardToken4Min
	cur_token4 := this.db.Info.GetCardToken4()
	for i := int32(0); i < chest_cfg.CardToken4ExtraTimes; i++ {
		if token4_rand <= 0 {
			cur_token4 = this.AddCardToken4(chest_cfg.CardToken4Min, reason, mod)
		} else {
			tmp_val = chest_cfg.CardToken4Min + rand.Int31n(token4_rand)
			cur_token4 = this.AddCardToken4(tmp_val, reason, mod)
		}
	}

	res_2cli.CurCoins = proto.Int32(cur_coin)
	res_2cli.CurDiamond = proto.Int32(cur_diamond)
	res_2cli.CurCardToken1 = proto.Int32(cur_token1)
	res_2cli.CurCardToken2 = proto.Int32(cur_token2)
	res_2cli.CurCardToken3 = proto.Int32(cur_token3)
	res_2cli.CurCardToken4 = proto.Int32(cur_token4)

	drop_cards := make(map[int32]int32)
	rand_val := int32(0)
	left_count := chest_cfg.CardAmount
	left_extra := chest_cfg.ExtractingTimes
	if chest_cfg.LegendaryDropID > 0 && chest_cfg.LegendaryAmountOdds > 0 {
		rand_val = rand.Int31n(chest_cfg.LegendaryAmountOdds)
		for _, tmp_amount := range chest_cfg.LegendaryAmountLib {
			if rand_val < tmp_amount.Odds {
				if tmp_amount.Count > 0 && chest_cfg.LegendaryExtraOdds > 0 {
					rand_val = rand.Int31n(chest_cfg.LegendaryExtraOdds)
					for _, tmp_extra := range chest_cfg.LegendaryExtraLib {
						if rand_val < tmp_extra.Odds {
							left_count = left_count - tmp_amount.Count
							left_extra = left_extra - tmp_extra.Count
							chest_cfg_mgr.DoDrop(chest_cfg.LegendaryDropID, tmp_extra.Count, tmp_amount.Count, drop_cards)
							break
						} else {
							rand_val = rand_val - tmp_extra.Odds
						}
					}
				} else {
					log.Info("chest[%d] LegendaryDrop rand zero count dropid[%d] odds[%d]", chest_cfg.ChestID, chest_cfg.LegendaryDropID, chest_cfg.LegendaryExtraOdds)
				}
				break
			} else {
				rand_val = rand_val - tmp_amount.Odds
			}
		}
	} else {
		log.Info("chest[%d] No LegendaryDrop dropid[%d] odds[%d]", chest_cfg.ChestID, chest_cfg.LegendaryDropID, chest_cfg.LegendaryAmountOdds)
	}

	if chest_cfg.EpicDropID > 0 && chest_cfg.EpicAmountOdds > 0 {
		rand_val = rand.Int31n(chest_cfg.EpicAmountOdds)
		for _, tmp_amount := range chest_cfg.EpicAmountLib {
			if rand_val < tmp_amount.Odds {
				if tmp_amount.Count > 0 && chest_cfg.EpicExtraOdds > 0 {
					rand_val = rand.Int31n(chest_cfg.EpicExtraOdds)
					for _, tmp_extra := range chest_cfg.EpicExtraLib {
						if rand_val < tmp_extra.Odds {
							left_count = left_count - tmp_amount.Count
							left_extra = left_extra - tmp_extra.Count
							chest_cfg_mgr.DoDrop(chest_cfg.EpicDropID, tmp_extra.Count, tmp_amount.Count, drop_cards)
							break
						} else {
							rand_val = rand_val - tmp_extra.Odds
						}
					}
				} else {
					log.Info("chest[%d] EpricDrop rand zero count dropid[%d] odds[%d]", chest_cfg.ChestID, chest_cfg.EpicDropID, chest_cfg.EpicAmountOdds)
				}
				break
			} else {
				rand_val = rand_val - tmp_amount.Odds
			}
		}
	} else {
		log.Info("chest[%d] No EpricDrop dropid[%d] odds[%d]", chest_cfg.ChestID, chest_cfg.EpicDropID, chest_cfg.EpicAmountOdds)
	}

	if chest_cfg.RareDropID > 0 && chest_cfg.RareAmountOdds > 0 {
		rand_val = rand.Int31n(chest_cfg.RareAmountOdds)
		for _, tmp_amount := range chest_cfg.RareAmountLib {
			if rand_val < tmp_amount.Odds {
				log.Info("稀有卡随机分支 ", rand_val, tmp_amount.Odds, tmp_amount.Count, chest_cfg.RareAmountOdds)
				if tmp_amount.Count > 0 && chest_cfg.RareAmountOdds > 0 {
					rand_val = rand.Int31n(chest_cfg.RareAmountOdds)
					for _, tmp_extra := range chest_cfg.RareExtraLib {
						if rand_val < tmp_extra.Odds {
							left_count = left_count - tmp_amount.Count
							left_extra = left_extra - tmp_extra.Count
							chest_cfg_mgr.DoDrop(chest_cfg.RareDropID, tmp_extra.Count, tmp_amount.Count, drop_cards)
							break
						} else {
							rand_val = rand_val - tmp_extra.Odds
						}
					}
				} else {
					log.Info("chest[%d] RareDrop zero dropid[%d] odds[%d]", chest_cfg.ChestID, chest_cfg.RareDropID, chest_cfg.RareAmountOdds)
				}
				break
			} else {
				rand_val = rand_val - tmp_amount.Odds
			}
		}
	} else {
		log.Info("chest[%d] No RareDrop dropid[%d] odds[%d]", chest_cfg.ChestID, chest_cfg.RareDropID, chest_cfg.RareAmountOdds)
	}

	if chest_cfg.CommonDropID > 0 {
		log.Info("抽取普通卡", chest_cfg.CommonDropID, left_extra, left_count, drop_cards)
		chest_cfg_mgr.DoDrop(chest_cfg.CommonDropID, left_extra, left_count, drop_cards)
	} else {
		log.Info("chest[%d] No LegendaryDrop dropid[%d] count[%d]", chest_cfg.ChestID, left_extra, left_count)
	}

	if len(drop_cards) > 0 {
		res_2cli.NewCards = make([]*msg_client_message.S2CCardAdd, 0, len(drop_cards))
		var tmp_card_add *msg_client_message.S2CCardAdd
		for cardcfgid, count := range drop_cards {
			this.AddCard(cardcfgid, count, reason, mod, true, false)
			tmp_card_add = &msg_client_message.S2CCardAdd{}
			tmp_card_add.CardCfgId = proto.Int32(cardcfgid)
			tmp_card_add.AddNum = proto.Int32(count)
			res_2cli.NewCards = append(res_2cli.NewCards, tmp_card_add)
		}
		if cost_dimond > 0 {
			res_2cli.CostDiamond = proto.Int32(cost_dimond)
		}
	}

	if !bslience {
		this.Send(res_2cli)
	}

	return res_2cli
}

// =====================================================================

func reg_player_chest_msg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SOpenChest, C2SOpenChestHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SOpenChestDiamond, C2SOpenChestDiamondHanlder)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SOpenFreeChest, C2SOpenFreeChestHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SOpenTowersChest, C2SOpenTowersChestHandler)
}

func C2SOpenChestHandler(c *socket.TcpConn, m proto.Message) {
	req := m.(*msg_client_message.C2SOpenChest)
	if nil == c || nil == req {
		log.Error("C2SOpenChestHandler c or req nil !")
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SOpenChestHandler not login")
		return
	}

	if p.db.Chests.IfHaveOpeningChest() {
		log.Error("C2SOpenChestHandler you have opening chest")
		p.SendError(msg_client_message.E_ERR_OPEN_CHEST_ALREADY_OPENING)
		return
	}

	pos := req.GetChestPos()
	db_chest := p.db.Chests.Get(pos)
	if nil == db_chest || db_chest.ChestId < 0 {
		log.Error("C2SOpenChestHandler not find chest in db bfind(%v)", nil == db_chest)
		return
	}

	cur_unix := int32(time.Now().Unix())

	if db_chest.OpenSec <= 0 {
		p.db.Chests.SetOpenSec(pos, int32(time.Now().Unix()))
		res_2cli := &msg_client_message.S2CStartOpenChest{}
		res_2cli.ChestPos = proto.Int32(pos)
		p.Send(res_2cli)
		return
	} else {
		chest_cfg := chest_cfg_mgr.Map[db_chest.ChestId]
		if nil != chest_cfg {
			if cur_unix-db_chest.OpenSec >= chest_cfg.UnlockSec {
				p.db.Chests.Remove(pos)
				p.OpenChest(db_chest.ChestId, "client_open", "client_req", 0, pos, false)
			} else {
				log.Error("C2SOpenChestHandler can not open now pass_sec[%d] need_sec[%d]!", cur_unix-db_chest.OpenSec, chest_cfg.UnlockSec)
			}

		} else {
			log.Info("C2SOpenChestHandler can not find chest[%d]", db_chest.ChestId)
		}
	}
}

func C2SOpenChestDiamondHanlder(c *socket.TcpConn, m proto.Message) {
	req := m.(*msg_client_message.C2SOpenChestDiamond)
	if nil == req || nil == c {
		log.Error("C2SOpenChestDiamondHanlder req or c nil !")
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SOpenChestDiamondHanlder not login")
		return
	}

	pos := req.GetChestPos()
	db_chest := p.db.Chests.Get(pos)
	if nil == db_chest || db_chest.ChestId < 0 {
		log.Error("C2SOpenChestDiamondHanlder not find chest in db bfind(%v)", nil == db_chest)
		return
	}

	chest_cfg := chest_cfg_mgr.Map[db_chest.ChestId]
	if nil == chest_cfg {
		log.Error("C2SOpenChestDiamondHanlder not find chest_cfg[%d]", db_chest.ChestId)
		return
	}

	left_sec := chest_cfg.UnlockSec
	if db_chest.OpenSec > 0 {
		left_sec = left_sec - (int32(time.Now().Unix()) - db_chest.OpenSec)
		if left_sec < 0 {
			left_sec = 0
		}
	}

	need_diamond := left_sec / global_config.TimeExchangeRate
	if left_sec > need_diamond*global_config.TimeExchangeRate {
		need_diamond++
	}

	log.Info("直接开启宝箱需要的钻石", need_diamond, left_sec, global_config.TimeExchangeRate)

	if p.GetDiamond() < need_diamond {
		log.Error("C2SOpenChestDiamondHanlder not enough diamond !")
		return
	}

	p.db.Chests.Remove(pos)
	p.SubDiamond(need_diamond, "open_chest", "client_req")
	p.OpenChest(db_chest.ChestId, "open_chest", "client_req", need_diamond, pos, false)
	return
}

func C2SOpenFreeChestHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SOpenFreeChest)
	if nil == c || nil == req {
		log.Error("C2SOpenFreeChestHandler c or req nil {%v}", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SOpenFreeChestHandler not login")
		return
	}

	p.ChkPlayerFreeChest()

	cur_free_num := p.db.TowerAndFreeChest.GetCurFreeChestNum()
	if cur_free_num < 1 {
		log.Error("C2SOpenFreeChestHandler no free chest")
		return
	}

	arena_lvl := p.db.Info.GetArenaLvl()
	if arena_lvl < 1 || arena_lvl > int32(len(global_config.FreeChestId)) {
		log.Error("C2SOpenFreeChestHandler arena_lvl[%d] error config_len(%d)", arena_lvl, len(global_config.FreeChestId))
		return
	}

	cur_unix := int32(time.Now().Unix())
	p.db.TowerAndFreeChest.SetCurFreeChestNum(cur_free_num - 1)
	if 0 >= p.db.TowerAndFreeChest.GetLastFreeChestUpUnix() {
		p.db.TowerAndFreeChest.SetLastFreeChestUpUnix(cur_unix)
	}
	p.OpenChest(global_config.FreeChestId[arena_lvl], "open_chest", "free_chest", 0, 0, false)

	res2cli := &msg_client_message.S2CFreeChestUpdate{}
	res2cli.CurFreeChestCd = proto.Int32(global_config.FreeChestCdSec - (cur_unix - p.db.TowerAndFreeChest.GetLastFreeChestUpUnix()))
	res2cli.CurFreeChestNum = proto.Int32(cur_free_num - 1)

	p.Send(res2cli)

	return
}

func C2SOpenTowersChestHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SOpenTowersChest)
	if nil == c || nil == req {
		log.Error("C2SOpenTowersChestHandler c or req nil {%v}", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SOpenTowersChestHandler not login")
		return
	}

	p.ChkPlayerTowerChest()

	cur_tower_num := p.db.TowerAndFreeChest.GetCurFreeChestNum()
	if cur_tower_num < 1 {
		log.Error("C2SOpenTowersChestHandler no tower chest")
		return
	}

	arena_lvl := p.db.Info.GetArenaLvl()
	if arena_lvl < 1 || arena_lvl > int32(len(global_config.TowerChestId)) {
		log.Error("C2SOpenTowersChestHandler arena_lvl[%d] error config_len(%d)", arena_lvl, len(global_config.TowerChestId))
		return
	}

	if p.db.TowerAndFreeChest.GetCurChestTowerNum() < global_config.TowerChestNeedNum {
		log.Error("C2SOpenTowersChestHandler not enough tower[%d] < [%d] !", p.db.TowerAndFreeChest.GetCurChestTowerNum(), global_config.TowerChestNeedNum)
		return
	}

	cur_unix := int32(time.Now().Unix())
	p.db.TowerAndFreeChest.SetCurChestTowerNum(cur_tower_num - 1)
	p.db.TowerAndFreeChest.SetCurChestTowerNum(0)
	if 0 >= p.db.TowerAndFreeChest.GetLastTowerChestUpUnix() {
		p.db.TowerAndFreeChest.SetLastTowerChestUpUnix(cur_unix)
	}
	p.OpenChest(global_config.TowerChestId[arena_lvl], "open_chest", "free_chest", 0, 0, false)

	res2cli := &msg_client_message.S2CSyncTowersChestCd{}
	res2cli.ChestCdSec = proto.Int32(global_config.TowerChestCdSec - (cur_unix - p.db.TowerAndFreeChest.GetLastTowerChestUpUnix()))
	res2cli.CurTowerNum = proto.Int32(cur_tower_num - 1)

	p.Send(res2cli)
}
