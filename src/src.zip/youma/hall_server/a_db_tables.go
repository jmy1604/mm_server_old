package main

import (
	"3p/code.google.com.protobuf/proto"
	_ "3p/mysql"
	"database/sql"
	"errors"
	"fmt"
	"libs/log"
	"math/rand"
	"os"
	"public_message/gen_go/db_hall"
	"sort"
	"strings"
	"sync/atomic"
	"time"
)

type dbArgs struct {
	args  []interface{}
	count int32
}

func new_db_args(count int32) (this *dbArgs) {
	this = &dbArgs{}
	this.args = make([]interface{}, count)
	this.count = 0
	return this
}
func (this *dbArgs) Push(arg interface{}) {
	this.args[this.count] = arg
	this.count++
}
func (this *dbArgs) GetArgs() (args []interface{}) {
	return this.args[0:this.count]
}
func (this *DBC) StmtPrepare(s string) (r *sql.Stmt, e error) {
	this.m_db_lock.Lock("DBC.StmtPrepare")
	defer this.m_db_lock.Unlock()
	return this.m_db.Prepare(s)
}
func (this *DBC) StmtExec(stmt *sql.Stmt, args ...interface{}) (r sql.Result, err error) {
	this.m_db_lock.Lock("DBC.StmtExec")
	defer this.m_db_lock.Unlock()
	return stmt.Exec(args...)
}
func (this *DBC) StmtQuery(stmt *sql.Stmt, args ...interface{}) (r *sql.Rows, err error) {
	this.m_db_lock.Lock("DBC.StmtQuery")
	defer this.m_db_lock.Unlock()
	return stmt.Query(args...)
}
func (this *DBC) StmtQueryRow(stmt *sql.Stmt, args ...interface{}) (r *sql.Row) {
	this.m_db_lock.Lock("DBC.StmtQueryRow")
	defer this.m_db_lock.Unlock()
	return stmt.QueryRow(args...)
}
func (this *DBC) Query(s string, args ...interface{}) (r *sql.Rows, e error) {
	this.m_db_lock.Lock("DBC.Query")
	defer this.m_db_lock.Unlock()
	return this.m_db.Query(s, args...)
}
func (this *DBC) QueryRow(s string, args ...interface{}) (r *sql.Row) {
	this.m_db_lock.Lock("DBC.QueryRow")
	defer this.m_db_lock.Unlock()
	return this.m_db.QueryRow(s, args...)
}
func (this *DBC) Exec(s string, args ...interface{}) (r sql.Result, e error) {
	this.m_db_lock.Lock("DBC.Exec")
	defer this.m_db_lock.Unlock()
	return this.m_db.Exec(s, args...)
}
func (this *DBC) Conn(name string, addr string, acc string, pwd string, db_copy_path string) (err error) {
	log.Trace("%v %v %v %v", name, addr, acc, pwd)
	this.m_db_name = name
	source := acc + ":" + pwd + "@tcp(" + addr + ")/" + name + "?charset=utf8"
	this.m_db, err = sql.Open("mysql", source)
	if err != nil {
		log.Error("open db failed %v", err)
		return
	}

	this.m_db_lock = NewMutex()
	this.m_shutdown_lock = NewMutex()

	if config.DBCST_MAX-config.DBCST_MIN <= 1 {
		return errors.New("DBCST_MAX sub DBCST_MIN should greater than 1s")
	}

	err = this.init_tables()
	if err != nil {
		log.Error("init tables failed")
		return
	}

	if os.MkdirAll(db_copy_path, os.ModePerm) == nil {
		os.Chmod(db_copy_path, os.ModePerm)
	}
	
	this.m_db_last_copy_time = int32(time.Now().Hour())
	this.m_db_copy_path = db_copy_path
	addr_list := strings.Split(addr, ":")
	this.m_db_addr = addr_list[0]
	this.m_db_account = acc
	this.m_db_password = pwd
	this.m_initialized = true

	return
}
func (this *DBC) check_files_exist() (file_name string) {
	f_name := fmt.Sprintf("%v/%v_%v", this.m_db_copy_path, this.m_db_name, time.Now().Format("20060102-15"))
	num := int32(0)
	for {
		if num == 0 {
			file_name = f_name
		} else {
			file_name = f_name + fmt.Sprintf("_%v", num)
		}
		_, err := os.Lstat(file_name)
		if err != nil {
			break
		}
		num++
	}
	return file_name
}
func (this *DBC) Loop() {
	defer func() {
		if err := recover(); err != nil {
			log.Stack(err)
		}

		log.Trace("数据库主循环退出")
		this.m_shutdown_completed = true
	}()

	for {
		t := config.DBCST_MIN + rand.Intn(config.DBCST_MAX-config.DBCST_MIN)
		if t <= 0 {
			t = 600
		}

		for i := 0; i < t; i++ {
			time.Sleep(time.Second)
			if this.m_quit {
				break
			}
		}

		if this.m_quit {
			break
		}

		begin := time.Now()
		err := this.Save(false)
		if err != nil {
			log.Error("save db failed %v", err)
		}
		log.Trace("db存数据花费时长: %v", time.Now().Sub(begin).Nanoseconds())
		
		/*
			now_time_hour := int32(time.Now().Hour())
			if now_time_hour != this.m_db_last_copy_time {
				args := []string {
					fmt.Sprintf("-h%v", this.m_db_addr),
					fmt.Sprintf("-u%v", this.m_db_account),
					fmt.Sprintf("-p%v", this.m_db_password),
					this.m_db_name,
				}
				cmd := exec.Command("mysqldump", args...)
				var out bytes.Buffer
				cmd.Stdout = &out
				cmd_err := cmd.Run()
				if cmd_err == nil {
					file_name := this.check_files_exist()
					file, file_err := os.OpenFile(file_name, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0660)
					defer file.Close()
					if file_err == nil {
						_, write_err := file.Write(out.Bytes())
						if write_err == nil {
							log.Trace("数据库备份成功！备份文件名:%v", file_name)
						} else {
							log.Error("数据库备份文件写入失败！备份文件名%v", file_name)
						}
					} else {
						log.Error("数据库备份文件打开失败！备份文件名%v", file_name)
					}
					file.Close()
				} else {
					log.Error("数据库备份失败！")
				}
				this.m_db_last_copy_time = now_time_hour
			}
		*/
		
		if this.m_quit {
			break
		}
	}

	log.Trace("数据库缓存主循环退出，保存所有数据")

	err := this.Save(true)
	if err != nil {
		log.Error("shutdwon save db failed %v", err)
		return
	}

	err = this.m_db.Close()
	if err != nil {
		log.Error("close db failed %v", err)
		return
	}
}
func (this *DBC) Shutdown() {
	if !this.m_initialized {
		return
	}

	this.m_shutdown_lock.UnSafeLock("DBC.Shutdown")
	defer this.m_shutdown_lock.UnSafeUnlock()

	if this.m_quit {
		return
	}
	this.m_quit = true

	log.Trace("关闭数据库缓存")

	begin := time.Now()

	for {
		if this.m_shutdown_completed {
			break
		}

		time.Sleep(time.Millisecond * 100)
	}

	log.Trace("关闭数据库缓存耗时 %v 秒", time.Now().Sub(begin).Seconds())
}


const DBC_VERSION = 1
const DBC_SUB_VERSION = 0

type dbSmallRankRecordData struct{
	Rank int32
	Id int32
	Val int32
	Name string
	TongName string
	TongIcon int32
}
func (this* dbSmallRankRecordData)from_pb(pb *db.SmallRankRecord){
	if pb == nil {
		return
	}
	this.Rank = pb.GetRank()
	this.Id = pb.GetId()
	this.Val = pb.GetVal()
	this.Name = pb.GetName()
	this.TongName = pb.GetTongName()
	this.TongIcon = pb.GetTongIcon()
	return
}
func (this* dbSmallRankRecordData)to_pb()(pb *db.SmallRankRecord){
	pb = &db.SmallRankRecord{}
	pb.Rank = proto.Int32(this.Rank)
	pb.Id = proto.Int32(this.Id)
	pb.Val = proto.Int32(this.Val)
	pb.Name = proto.String(this.Name)
	pb.TongName = proto.String(this.TongName)
	pb.TongIcon = proto.Int32(this.TongIcon)
	return
}
func (this* dbSmallRankRecordData)clone_to(d *dbSmallRankRecordData){
	d.Rank = this.Rank
	d.Id = this.Id
	d.Val = this.Val
	d.Name = this.Name
	d.TongName = this.TongName
	d.TongIcon = this.TongIcon
	return
}
type dbPlayerInfoData struct{
	Lvl int32
	MatchScore int32
	Coin int32
	Diamond int32
	DayMatchRewardNum int8
	LayMatchRewardTime int32
	CurUseCardTeam int32
	Exp int32
	ArenaLvl int8
	LastShopUpDay int32
	Camp int8
	ChestCycleCount int16
	IfCaptain int8
	CurBestLegScore int16
	LastBestLegScore int16
	WinCount int16
	OftenCard int32
	DonateCount int32
	ChellWinCount int16
	ChellOfenCard int32
	LastDialyTaskUpUinx int32
	LastLegendSwitchUnix int32
	CurLegendScore int32
	IfHaveChooseCamp int8
	ChangeNameCount int16
	CardToken1 int32
	CardToken2 int32
	CardToken3 int32
	CardToken4 int32
	LastCardCompoundUpUnix int32
	CreateUnix int32
	FirstPayState int8
}
func (this* dbPlayerInfoData)from_pb(pb *db.PlayerInfo){
	if pb == nil {
		return
	}
	this.Lvl = pb.GetLvl()
	this.MatchScore = pb.GetMatchScore()
	this.Coin = pb.GetCoin()
	this.Diamond = pb.GetDiamond()
	this.DayMatchRewardNum = int8(pb.GetDayMatchRewardNum())
	this.LayMatchRewardTime = pb.GetLayMatchRewardTime()
	this.CurUseCardTeam = pb.GetCurUseCardTeam()
	this.Exp = pb.GetExp()
	this.ArenaLvl = int8(pb.GetArenaLvl())
	this.LastShopUpDay = pb.GetLastShopUpDay()
	this.Camp = int8(pb.GetCamp())
	this.ChestCycleCount = int16(pb.GetChestCycleCount())
	this.IfCaptain = int8(pb.GetIfCaptain())
	this.CurBestLegScore = int16(pb.GetCurBestLegScore())
	this.LastBestLegScore = int16(pb.GetLastBestLegScore())
	this.WinCount = int16(pb.GetWinCount())
	this.OftenCard = pb.GetOftenCard()
	this.DonateCount = pb.GetDonateCount()
	this.ChellWinCount = int16(pb.GetChellWinCount())
	this.ChellOfenCard = pb.GetChellOfenCard()
	this.LastDialyTaskUpUinx = pb.GetLastDialyTaskUpUinx()
	this.LastLegendSwitchUnix = pb.GetLastLegendSwitchUnix()
	this.CurLegendScore = pb.GetCurLegendScore()
	this.IfHaveChooseCamp = int8(pb.GetIfHaveChooseCamp())
	this.ChangeNameCount = int16(pb.GetChangeNameCount())
	this.CardToken1 = pb.GetCardToken1()
	this.CardToken2 = pb.GetCardToken2()
	this.CardToken3 = pb.GetCardToken3()
	this.CardToken4 = pb.GetCardToken4()
	this.LastCardCompoundUpUnix = pb.GetLastCardCompoundUpUnix()
	this.CreateUnix = pb.GetCreateUnix()
	this.FirstPayState = int8(pb.GetFirstPayState())
	return
}
func (this* dbPlayerInfoData)to_pb()(pb *db.PlayerInfo){
	pb = &db.PlayerInfo{}
	pb.Lvl = proto.Int32(this.Lvl)
	pb.MatchScore = proto.Int32(this.MatchScore)
	pb.Coin = proto.Int32(this.Coin)
	pb.Diamond = proto.Int32(this.Diamond)
	temp_DayMatchRewardNum:=int32(this.DayMatchRewardNum)
	pb.DayMatchRewardNum = proto.Int32(temp_DayMatchRewardNum)
	pb.LayMatchRewardTime = proto.Int32(this.LayMatchRewardTime)
	pb.CurUseCardTeam = proto.Int32(this.CurUseCardTeam)
	pb.Exp = proto.Int32(this.Exp)
	temp_ArenaLvl:=int32(this.ArenaLvl)
	pb.ArenaLvl = proto.Int32(temp_ArenaLvl)
	pb.LastShopUpDay = proto.Int32(this.LastShopUpDay)
	temp_Camp:=int32(this.Camp)
	pb.Camp = proto.Int32(temp_Camp)
	temp_ChestCycleCount:=int32(this.ChestCycleCount)
	pb.ChestCycleCount = proto.Int32(temp_ChestCycleCount)
	temp_IfCaptain:=int32(this.IfCaptain)
	pb.IfCaptain = proto.Int32(temp_IfCaptain)
	temp_CurBestLegScore:=int32(this.CurBestLegScore)
	pb.CurBestLegScore = proto.Int32(temp_CurBestLegScore)
	temp_LastBestLegScore:=int32(this.LastBestLegScore)
	pb.LastBestLegScore = proto.Int32(temp_LastBestLegScore)
	temp_WinCount:=int32(this.WinCount)
	pb.WinCount = proto.Int32(temp_WinCount)
	pb.OftenCard = proto.Int32(this.OftenCard)
	pb.DonateCount = proto.Int32(this.DonateCount)
	temp_ChellWinCount:=int32(this.ChellWinCount)
	pb.ChellWinCount = proto.Int32(temp_ChellWinCount)
	pb.ChellOfenCard = proto.Int32(this.ChellOfenCard)
	pb.LastDialyTaskUpUinx = proto.Int32(this.LastDialyTaskUpUinx)
	pb.LastLegendSwitchUnix = proto.Int32(this.LastLegendSwitchUnix)
	pb.CurLegendScore = proto.Int32(this.CurLegendScore)
	temp_IfHaveChooseCamp:=int32(this.IfHaveChooseCamp)
	pb.IfHaveChooseCamp = proto.Int32(temp_IfHaveChooseCamp)
	temp_ChangeNameCount:=int32(this.ChangeNameCount)
	pb.ChangeNameCount = proto.Int32(temp_ChangeNameCount)
	pb.CardToken1 = proto.Int32(this.CardToken1)
	pb.CardToken2 = proto.Int32(this.CardToken2)
	pb.CardToken3 = proto.Int32(this.CardToken3)
	pb.CardToken4 = proto.Int32(this.CardToken4)
	pb.LastCardCompoundUpUnix = proto.Int32(this.LastCardCompoundUpUnix)
	pb.CreateUnix = proto.Int32(this.CreateUnix)
	temp_FirstPayState:=int32(this.FirstPayState)
	pb.FirstPayState = proto.Int32(temp_FirstPayState)
	return
}
func (this* dbPlayerInfoData)clone_to(d *dbPlayerInfoData){
	d.Lvl = this.Lvl
	d.MatchScore = this.MatchScore
	d.Coin = this.Coin
	d.Diamond = this.Diamond
	d.DayMatchRewardNum = int8(this.DayMatchRewardNum)
	d.LayMatchRewardTime = this.LayMatchRewardTime
	d.CurUseCardTeam = this.CurUseCardTeam
	d.Exp = this.Exp
	d.ArenaLvl = int8(this.ArenaLvl)
	d.LastShopUpDay = this.LastShopUpDay
	d.Camp = int8(this.Camp)
	d.ChestCycleCount = int16(this.ChestCycleCount)
	d.IfCaptain = int8(this.IfCaptain)
	d.CurBestLegScore = int16(this.CurBestLegScore)
	d.LastBestLegScore = int16(this.LastBestLegScore)
	d.WinCount = int16(this.WinCount)
	d.OftenCard = this.OftenCard
	d.DonateCount = this.DonateCount
	d.ChellWinCount = int16(this.ChellWinCount)
	d.ChellOfenCard = this.ChellOfenCard
	d.LastDialyTaskUpUinx = this.LastDialyTaskUpUinx
	d.LastLegendSwitchUnix = this.LastLegendSwitchUnix
	d.CurLegendScore = this.CurLegendScore
	d.IfHaveChooseCamp = int8(this.IfHaveChooseCamp)
	d.ChangeNameCount = int16(this.ChangeNameCount)
	d.CardToken1 = this.CardToken1
	d.CardToken2 = this.CardToken2
	d.CardToken3 = this.CardToken3
	d.CardToken4 = this.CardToken4
	d.LastCardCompoundUpUnix = this.LastCardCompoundUpUnix
	d.CreateUnix = this.CreateUnix
	d.FirstPayState = int8(this.FirstPayState)
	return
}
type dbPlayerTongInfoData struct{
	TongId int32
	TongIcon int32
	TongName string
	TongMemberType int32
	LastLeaveTongUnix int32
	LastCardReqUnix int32
	TodayDonateMax int32
	TodayDonateNum int32
	LastDonateMaxUpUnixD int32
}
func (this* dbPlayerTongInfoData)from_pb(pb *db.PlayerTongInfo){
	if pb == nil {
		return
	}
	this.TongId = pb.GetTongId()
	this.TongIcon = pb.GetTongIcon()
	this.TongName = pb.GetTongName()
	this.TongMemberType = pb.GetTongMemberType()
	this.LastLeaveTongUnix = pb.GetLastLeaveTongUnix()
	this.LastCardReqUnix = pb.GetLastCardReqUnix()
	this.TodayDonateMax = pb.GetTodayDonateMax()
	this.TodayDonateNum = pb.GetTodayDonateNum()
	this.LastDonateMaxUpUnixD = pb.GetLastDonateMaxUpUnixD()
	return
}
func (this* dbPlayerTongInfoData)to_pb()(pb *db.PlayerTongInfo){
	pb = &db.PlayerTongInfo{}
	pb.TongId = proto.Int32(this.TongId)
	pb.TongIcon = proto.Int32(this.TongIcon)
	pb.TongName = proto.String(this.TongName)
	pb.TongMemberType = proto.Int32(this.TongMemberType)
	pb.LastLeaveTongUnix = proto.Int32(this.LastLeaveTongUnix)
	pb.LastCardReqUnix = proto.Int32(this.LastCardReqUnix)
	pb.TodayDonateMax = proto.Int32(this.TodayDonateMax)
	pb.TodayDonateNum = proto.Int32(this.TodayDonateNum)
	pb.LastDonateMaxUpUnixD = proto.Int32(this.LastDonateMaxUpUnixD)
	return
}
func (this* dbPlayerTongInfoData)clone_to(d *dbPlayerTongInfoData){
	d.TongId = this.TongId
	d.TongIcon = this.TongIcon
	d.TongName = this.TongName
	d.TongMemberType = this.TongMemberType
	d.LastLeaveTongUnix = this.LastLeaveTongUnix
	d.LastCardReqUnix = this.LastCardReqUnix
	d.TodayDonateMax = this.TodayDonateMax
	d.TodayDonateNum = this.TodayDonateNum
	d.LastDonateMaxUpUnixD = this.LastDonateMaxUpUnixD
	return
}
type dbPlayerTongDonateData struct{
	PlayerId int32
	DonateNum int32
	DonateUnix int32
}
func (this* dbPlayerTongDonateData)from_pb(pb *db.PlayerTongDonate){
	if pb == nil {
		return
	}
	this.PlayerId = pb.GetPlayerId()
	this.DonateNum = pb.GetDonateNum()
	this.DonateUnix = pb.GetDonateUnix()
	return
}
func (this* dbPlayerTongDonateData)to_pb()(pb *db.PlayerTongDonate){
	pb = &db.PlayerTongDonate{}
	pb.PlayerId = proto.Int32(this.PlayerId)
	pb.DonateNum = proto.Int32(this.DonateNum)
	pb.DonateUnix = proto.Int32(this.DonateUnix)
	return
}
func (this* dbPlayerTongDonateData)clone_to(d *dbPlayerTongDonateData){
	d.PlayerId = this.PlayerId
	d.DonateNum = this.DonateNum
	d.DonateUnix = this.DonateUnix
	return
}
type dbPlayerBeTongDonateData struct{
	PlayerId int32
	PlayerName string
	DonateNum int32
}
func (this* dbPlayerBeTongDonateData)from_pb(pb *db.PlayerBeTongDonate){
	if pb == nil {
		return
	}
	this.PlayerId = pb.GetPlayerId()
	this.PlayerName = pb.GetPlayerName()
	this.DonateNum = pb.GetDonateNum()
	return
}
func (this* dbPlayerBeTongDonateData)to_pb()(pb *db.PlayerBeTongDonate){
	pb = &db.PlayerBeTongDonate{}
	pb.PlayerId = proto.Int32(this.PlayerId)
	pb.PlayerName = proto.String(this.PlayerName)
	pb.DonateNum = proto.Int32(this.DonateNum)
	return
}
func (this* dbPlayerBeTongDonateData)clone_to(d *dbPlayerBeTongDonateData){
	d.PlayerId = this.PlayerId
	d.PlayerName = this.PlayerName
	d.DonateNum = this.DonateNum
	return
}
type dbPlayerCardData struct{
	ConfigId int32
	CardCount int32
	CardLvl int32
}
func (this* dbPlayerCardData)from_pb(pb *db.PlayerCard){
	if pb == nil {
		return
	}
	this.ConfigId = pb.GetConfigId()
	this.CardCount = pb.GetCardCount()
	this.CardLvl = pb.GetCardLvl()
	return
}
func (this* dbPlayerCardData)to_pb()(pb *db.PlayerCard){
	pb = &db.PlayerCard{}
	pb.ConfigId = proto.Int32(this.ConfigId)
	pb.CardCount = proto.Int32(this.CardCount)
	pb.CardLvl = proto.Int32(this.CardLvl)
	return
}
func (this* dbPlayerCardData)clone_to(d *dbPlayerCardData){
	d.ConfigId = this.ConfigId
	d.CardCount = this.CardCount
	d.CardLvl = this.CardLvl
	return
}
type dbPlayerCardTeamData struct{
	TeamId int32
	CardCfgIds []int32
}
func (this* dbPlayerCardTeamData)from_pb(pb *db.PlayerCardTeam){
	if pb == nil {
		this.CardCfgIds = make([]int32,0)
		return
	}
	this.TeamId = pb.GetTeamId()
	this.CardCfgIds = make([]int32,len(pb.GetCardCfgIds()))
	for i, v := range pb.GetCardCfgIds() {
		this.CardCfgIds[i] = v
	}
	return
}
func (this* dbPlayerCardTeamData)to_pb()(pb *db.PlayerCardTeam){
	pb = &db.PlayerCardTeam{}
	pb.TeamId = proto.Int32(this.TeamId)
	pb.CardCfgIds = make([]int32, len(this.CardCfgIds))
	for i, v := range this.CardCfgIds {
		pb.CardCfgIds[i]=v
	}
	return
}
func (this* dbPlayerCardTeamData)clone_to(d *dbPlayerCardTeamData){
	d.TeamId = this.TeamId
	d.CardCfgIds = make([]int32, len(this.CardCfgIds))
	for _ii, _vv := range this.CardCfgIds {
		d.CardCfgIds[_ii]=_vv
	}
	return
}
type dbPlayerShopLatticeData struct{
	Lattice int32
	TodayBuyNum int32
	CardCfgId int32
}
func (this* dbPlayerShopLatticeData)from_pb(pb *db.PlayerShopLattice){
	if pb == nil {
		return
	}
	this.Lattice = pb.GetLattice()
	this.TodayBuyNum = pb.GetTodayBuyNum()
	this.CardCfgId = pb.GetCardCfgId()
	return
}
func (this* dbPlayerShopLatticeData)to_pb()(pb *db.PlayerShopLattice){
	pb = &db.PlayerShopLattice{}
	pb.Lattice = proto.Int32(this.Lattice)
	pb.TodayBuyNum = proto.Int32(this.TodayBuyNum)
	pb.CardCfgId = proto.Int32(this.CardCfgId)
	return
}
func (this* dbPlayerShopLatticeData)clone_to(d *dbPlayerShopLatticeData){
	d.Lattice = this.Lattice
	d.TodayBuyNum = this.TodayBuyNum
	d.CardCfgId = this.CardCfgId
	return
}
type dbPlayerChestData struct{
	Pos int32
	ChestId int32
	OpenSec int32
}
func (this* dbPlayerChestData)from_pb(pb *db.PlayerChest){
	if pb == nil {
		return
	}
	this.Pos = pb.GetPos()
	this.ChestId = pb.GetChestId()
	this.OpenSec = pb.GetOpenSec()
	return
}
func (this* dbPlayerChestData)to_pb()(pb *db.PlayerChest){
	pb = &db.PlayerChest{}
	pb.Pos = proto.Int32(this.Pos)
	pb.ChestId = proto.Int32(this.ChestId)
	pb.OpenSec = proto.Int32(this.OpenSec)
	return
}
func (this* dbPlayerChestData)clone_to(d *dbPlayerChestData){
	d.Pos = this.Pos
	d.ChestId = this.ChestId
	d.OpenSec = this.OpenSec
	return
}
type dbPlayerMailData struct{
	MailId int32
	MailTitle string
	SenderName string
	Content string
	SendUnix int32
	Coin int32
	Diamond int32
	Chests []int32
	ChestNums []int32
	OverUnix int32
	MailType int8
	ReadState int8
	SenderId int32
}
func (this* dbPlayerMailData)from_pb(pb *db.PlayerMail){
	if pb == nil {
		this.Chests = make([]int32,0)
		this.ChestNums = make([]int32,0)
		return
	}
	this.MailId = pb.GetMailId()
	this.MailTitle = pb.GetMailTitle()
	this.SenderName = pb.GetSenderName()
	this.Content = pb.GetContent()
	this.SendUnix = pb.GetSendUnix()
	this.Coin = pb.GetCoin()
	this.Diamond = pb.GetDiamond()
	this.Chests = make([]int32,len(pb.GetChests()))
	for i, v := range pb.GetChests() {
		this.Chests[i] = v
	}
	this.ChestNums = make([]int32,len(pb.GetChestNums()))
	for i, v := range pb.GetChestNums() {
		this.ChestNums[i] = v
	}
	this.OverUnix = pb.GetOverUnix()
	this.MailType = int8(pb.GetMailType())
	this.ReadState = int8(pb.GetReadState())
	this.SenderId = pb.GetSenderId()
	return
}
func (this* dbPlayerMailData)to_pb()(pb *db.PlayerMail){
	pb = &db.PlayerMail{}
	pb.MailId = proto.Int32(this.MailId)
	pb.MailTitle = proto.String(this.MailTitle)
	pb.SenderName = proto.String(this.SenderName)
	pb.Content = proto.String(this.Content)
	pb.SendUnix = proto.Int32(this.SendUnix)
	pb.Coin = proto.Int32(this.Coin)
	pb.Diamond = proto.Int32(this.Diamond)
	pb.Chests = make([]int32, len(this.Chests))
	for i, v := range this.Chests {
		pb.Chests[i]=v
	}
	pb.ChestNums = make([]int32, len(this.ChestNums))
	for i, v := range this.ChestNums {
		pb.ChestNums[i]=v
	}
	pb.OverUnix = proto.Int32(this.OverUnix)
	temp_MailType:=int32(this.MailType)
	pb.MailType = proto.Int32(temp_MailType)
	temp_ReadState:=int32(this.ReadState)
	pb.ReadState = proto.Int32(temp_ReadState)
	pb.SenderId = proto.Int32(this.SenderId)
	return
}
func (this* dbPlayerMailData)clone_to(d *dbPlayerMailData){
	d.MailId = this.MailId
	d.MailTitle = this.MailTitle
	d.SenderName = this.SenderName
	d.Content = this.Content
	d.SendUnix = this.SendUnix
	d.Coin = this.Coin
	d.Diamond = this.Diamond
	d.Chests = make([]int32, len(this.Chests))
	for _ii, _vv := range this.Chests {
		d.Chests[_ii]=_vv
	}
	d.ChestNums = make([]int32, len(this.ChestNums))
	for _ii, _vv := range this.ChestNums {
		d.ChestNums[_ii]=_vv
	}
	d.OverUnix = this.OverUnix
	d.MailType = int8(this.MailType)
	d.ReadState = int8(this.ReadState)
	d.SenderId = this.SenderId
	return
}
type dbPlayerPayBackData struct{
	PayBackId int32
	Value string
}
func (this* dbPlayerPayBackData)from_pb(pb *db.PlayerPayBack){
	if pb == nil {
		return
	}
	this.PayBackId = pb.GetPayBackId()
	this.Value = pb.GetValue()
	return
}
func (this* dbPlayerPayBackData)to_pb()(pb *db.PlayerPayBack){
	pb = &db.PlayerPayBack{}
	pb.PayBackId = proto.Int32(this.PayBackId)
	pb.Value = proto.String(this.Value)
	return
}
func (this* dbPlayerPayBackData)clone_to(d *dbPlayerPayBackData){
	d.PayBackId = this.PayBackId
	d.Value = this.Value
	return
}
type dbPlayerOptionsData struct{
	Values []int32
}
func (this* dbPlayerOptionsData)from_pb(pb *db.PlayerOptions){
	if pb == nil {
		this.Values = make([]int32,0)
		return
	}
	this.Values = make([]int32,len(pb.GetValues()))
	for i, v := range pb.GetValues() {
		this.Values[i] = v
	}
	return
}
func (this* dbPlayerOptionsData)to_pb()(pb *db.PlayerOptions){
	pb = &db.PlayerOptions{}
	pb.Values = make([]int32, len(this.Values))
	for i, v := range this.Values {
		pb.Values[i]=v
	}
	return
}
func (this* dbPlayerOptionsData)clone_to(d *dbPlayerOptionsData){
	d.Values = make([]int32, len(this.Values))
	for _ii, _vv := range this.Values {
		d.Values[_ii]=_vv
	}
	return
}
type dbPlayerFightRecordData struct{
	RecordId int32
	MyCards []int32
	MyCardLvls []int32
	OptCards []int32
	OptCardLvls []int32
	WinnerId int32
	MyTongId int32
	OptTongId int32
	OptPlayerId int32
	MyPlayerName string
	OptPlayerName string
	MyTongName string
	OptTongName string
	MyTongIcon int32
	OpTongIcon int32
	CreateUnix int32
	MatchType int32
	MyTowers int32
	OpTowers int32
	MyMathScore int32
	OpMathScore int32
	MyMathScoreChg int32
}
func (this* dbPlayerFightRecordData)from_pb(pb *db.PlayerFightRecord){
	if pb == nil {
		this.MyCards = make([]int32,0)
		this.MyCardLvls = make([]int32,0)
		this.OptCards = make([]int32,0)
		this.OptCardLvls = make([]int32,0)
		return
	}
	this.RecordId = pb.GetRecordId()
	this.MyCards = make([]int32,len(pb.GetMyCards()))
	for i, v := range pb.GetMyCards() {
		this.MyCards[i] = v
	}
	this.MyCardLvls = make([]int32,len(pb.GetMyCardLvls()))
	for i, v := range pb.GetMyCardLvls() {
		this.MyCardLvls[i] = v
	}
	this.OptCards = make([]int32,len(pb.GetOptCards()))
	for i, v := range pb.GetOptCards() {
		this.OptCards[i] = v
	}
	this.OptCardLvls = make([]int32,len(pb.GetOptCardLvls()))
	for i, v := range pb.GetOptCardLvls() {
		this.OptCardLvls[i] = v
	}
	this.WinnerId = pb.GetWinnerId()
	this.MyTongId = pb.GetMyTongId()
	this.OptTongId = pb.GetOptTongId()
	this.OptPlayerId = pb.GetOptPlayerId()
	this.MyPlayerName = pb.GetMyPlayerName()
	this.OptPlayerName = pb.GetOptPlayerName()
	this.MyTongName = pb.GetMyTongName()
	this.OptTongName = pb.GetOptTongName()
	this.MyTongIcon = pb.GetMyTongIcon()
	this.OpTongIcon = pb.GetOpTongIcon()
	this.CreateUnix = pb.GetCreateUnix()
	this.MatchType = pb.GetMatchType()
	this.MyTowers = pb.GetMyTowers()
	this.OpTowers = pb.GetOpTowers()
	this.MyMathScore = pb.GetMyMathScore()
	this.OpMathScore = pb.GetOpMathScore()
	this.MyMathScoreChg = pb.GetMyMathScoreChg()
	return
}
func (this* dbPlayerFightRecordData)to_pb()(pb *db.PlayerFightRecord){
	pb = &db.PlayerFightRecord{}
	pb.RecordId = proto.Int32(this.RecordId)
	pb.MyCards = make([]int32, len(this.MyCards))
	for i, v := range this.MyCards {
		pb.MyCards[i]=v
	}
	pb.MyCardLvls = make([]int32, len(this.MyCardLvls))
	for i, v := range this.MyCardLvls {
		pb.MyCardLvls[i]=v
	}
	pb.OptCards = make([]int32, len(this.OptCards))
	for i, v := range this.OptCards {
		pb.OptCards[i]=v
	}
	pb.OptCardLvls = make([]int32, len(this.OptCardLvls))
	for i, v := range this.OptCardLvls {
		pb.OptCardLvls[i]=v
	}
	pb.WinnerId = proto.Int32(this.WinnerId)
	pb.MyTongId = proto.Int32(this.MyTongId)
	pb.OptTongId = proto.Int32(this.OptTongId)
	pb.OptPlayerId = proto.Int32(this.OptPlayerId)
	pb.MyPlayerName = proto.String(this.MyPlayerName)
	pb.OptPlayerName = proto.String(this.OptPlayerName)
	pb.MyTongName = proto.String(this.MyTongName)
	pb.OptTongName = proto.String(this.OptTongName)
	pb.MyTongIcon = proto.Int32(this.MyTongIcon)
	pb.OpTongIcon = proto.Int32(this.OpTongIcon)
	pb.CreateUnix = proto.Int32(this.CreateUnix)
	pb.MatchType = proto.Int32(this.MatchType)
	pb.MyTowers = proto.Int32(this.MyTowers)
	pb.OpTowers = proto.Int32(this.OpTowers)
	pb.MyMathScore = proto.Int32(this.MyMathScore)
	pb.OpMathScore = proto.Int32(this.OpMathScore)
	pb.MyMathScoreChg = proto.Int32(this.MyMathScoreChg)
	return
}
func (this* dbPlayerFightRecordData)clone_to(d *dbPlayerFightRecordData){
	d.RecordId = this.RecordId
	d.MyCards = make([]int32, len(this.MyCards))
	for _ii, _vv := range this.MyCards {
		d.MyCards[_ii]=_vv
	}
	d.MyCardLvls = make([]int32, len(this.MyCardLvls))
	for _ii, _vv := range this.MyCardLvls {
		d.MyCardLvls[_ii]=_vv
	}
	d.OptCards = make([]int32, len(this.OptCards))
	for _ii, _vv := range this.OptCards {
		d.OptCards[_ii]=_vv
	}
	d.OptCardLvls = make([]int32, len(this.OptCardLvls))
	for _ii, _vv := range this.OptCardLvls {
		d.OptCardLvls[_ii]=_vv
	}
	d.WinnerId = this.WinnerId
	d.MyTongId = this.MyTongId
	d.OptTongId = this.OptTongId
	d.OptPlayerId = this.OptPlayerId
	d.MyPlayerName = this.MyPlayerName
	d.OptPlayerName = this.OptPlayerName
	d.MyTongName = this.MyTongName
	d.OptTongName = this.OptTongName
	d.MyTongIcon = this.MyTongIcon
	d.OpTongIcon = this.OpTongIcon
	d.CreateUnix = this.CreateUnix
	d.MatchType = this.MatchType
	d.MyTowers = this.MyTowers
	d.OpTowers = this.OpTowers
	d.MyMathScore = this.MyMathScore
	d.OpMathScore = this.OpMathScore
	d.MyMathScoreChg = this.MyMathScoreChg
	return
}
type dbPlayerDialyTaskData struct{
	TaskId int32
	Value int32
	RewardUnix int32
}
func (this* dbPlayerDialyTaskData)from_pb(pb *db.PlayerDialyTask){
	if pb == nil {
		return
	}
	this.TaskId = pb.GetTaskId()
	this.Value = pb.GetValue()
	this.RewardUnix = pb.GetRewardUnix()
	return
}
func (this* dbPlayerDialyTaskData)to_pb()(pb *db.PlayerDialyTask){
	pb = &db.PlayerDialyTask{}
	pb.TaskId = proto.Int32(this.TaskId)
	pb.Value = proto.Int32(this.Value)
	pb.RewardUnix = proto.Int32(this.RewardUnix)
	return
}
func (this* dbPlayerDialyTaskData)clone_to(d *dbPlayerDialyTaskData){
	d.TaskId = this.TaskId
	d.Value = this.Value
	d.RewardUnix = this.RewardUnix
	return
}
type dbPlayerAchieveData struct{
	AchieveId int32
	Value int32
	RewardUnix int32
}
func (this* dbPlayerAchieveData)from_pb(pb *db.PlayerAchieve){
	if pb == nil {
		return
	}
	this.AchieveId = pb.GetAchieveId()
	this.Value = pb.GetValue()
	this.RewardUnix = pb.GetRewardUnix()
	return
}
func (this* dbPlayerAchieveData)to_pb()(pb *db.PlayerAchieve){
	pb = &db.PlayerAchieve{}
	pb.AchieveId = proto.Int32(this.AchieveId)
	pb.Value = proto.Int32(this.Value)
	pb.RewardUnix = proto.Int32(this.RewardUnix)
	return
}
func (this* dbPlayerAchieveData)clone_to(d *dbPlayerAchieveData){
	d.AchieveId = this.AchieveId
	d.Value = this.Value
	d.RewardUnix = this.RewardUnix
	return
}
type dbPlayerSevenActivityData struct{
	ActivityId int32
	Value int32
	RewardUnix int32
}
func (this* dbPlayerSevenActivityData)from_pb(pb *db.PlayerSevenActivity){
	if pb == nil {
		return
	}
	this.ActivityId = pb.GetActivityId()
	this.Value = pb.GetValue()
	this.RewardUnix = pb.GetRewardUnix()
	return
}
func (this* dbPlayerSevenActivityData)to_pb()(pb *db.PlayerSevenActivity){
	pb = &db.PlayerSevenActivity{}
	pb.ActivityId = proto.Int32(this.ActivityId)
	pb.Value = proto.Int32(this.Value)
	pb.RewardUnix = proto.Int32(this.RewardUnix)
	return
}
func (this* dbPlayerSevenActivityData)clone_to(d *dbPlayerSevenActivityData){
	d.ActivityId = this.ActivityId
	d.Value = this.Value
	d.RewardUnix = this.RewardUnix
	return
}
type dbPlayerTowerAndFreeChestData struct{
	LastFreeChestUpUnix int32
	CurFreeChestNum int32
	CurTowerChestNum int8
	CurChestTowerNum int8
	LastTowerChestUpUnix int32
}
func (this* dbPlayerTowerAndFreeChestData)from_pb(pb *db.PlayerTowerAndFreeChest){
	if pb == nil {
		return
	}
	this.LastFreeChestUpUnix = pb.GetLastFreeChestUpUnix()
	this.CurFreeChestNum = pb.GetCurFreeChestNum()
	this.CurTowerChestNum = int8(pb.GetCurTowerChestNum())
	this.CurChestTowerNum = int8(pb.GetCurChestTowerNum())
	this.LastTowerChestUpUnix = pb.GetLastTowerChestUpUnix()
	return
}
func (this* dbPlayerTowerAndFreeChestData)to_pb()(pb *db.PlayerTowerAndFreeChest){
	pb = &db.PlayerTowerAndFreeChest{}
	pb.LastFreeChestUpUnix = proto.Int32(this.LastFreeChestUpUnix)
	pb.CurFreeChestNum = proto.Int32(this.CurFreeChestNum)
	temp_CurTowerChestNum:=int32(this.CurTowerChestNum)
	pb.CurTowerChestNum = proto.Int32(temp_CurTowerChestNum)
	temp_CurChestTowerNum:=int32(this.CurChestTowerNum)
	pb.CurChestTowerNum = proto.Int32(temp_CurChestTowerNum)
	pb.LastTowerChestUpUnix = proto.Int32(this.LastTowerChestUpUnix)
	return
}
func (this* dbPlayerTowerAndFreeChestData)clone_to(d *dbPlayerTowerAndFreeChestData){
	d.LastFreeChestUpUnix = this.LastFreeChestUpUnix
	d.CurFreeChestNum = this.CurFreeChestNum
	d.CurTowerChestNum = int8(this.CurTowerChestNum)
	d.CurChestTowerNum = int8(this.CurChestTowerNum)
	d.LastTowerChestUpUnix = this.LastTowerChestUpUnix
	return
}
type dbPlayerTodayCardCompoundData struct{
	CardCfgId int32
	TodayCompoundNum int32
}
func (this* dbPlayerTodayCardCompoundData)from_pb(pb *db.PlayerTodayCardCompound){
	if pb == nil {
		return
	}
	this.CardCfgId = pb.GetCardCfgId()
	this.TodayCompoundNum = pb.GetTodayCompoundNum()
	return
}
func (this* dbPlayerTodayCardCompoundData)to_pb()(pb *db.PlayerTodayCardCompound){
	pb = &db.PlayerTodayCardCompound{}
	pb.CardCfgId = proto.Int32(this.CardCfgId)
	pb.TodayCompoundNum = proto.Int32(this.TodayCompoundNum)
	return
}
func (this* dbPlayerTodayCardCompoundData)clone_to(d *dbPlayerTodayCardCompoundData){
	d.CardCfgId = this.CardCfgId
	d.TodayCompoundNum = this.TodayCompoundNum
	return
}
type dbPlayerCampFightInfoData struct{
	EnterISOWeek int32
	EnterArenaLvl int32
	CurScore int32
	LastRewardISOWeek int32
}
func (this* dbPlayerCampFightInfoData)from_pb(pb *db.PlayerCampFightInfo){
	if pb == nil {
		return
	}
	this.EnterISOWeek = pb.GetEnterISOWeek()
	this.EnterArenaLvl = pb.GetEnterArenaLvl()
	this.CurScore = pb.GetCurScore()
	this.LastRewardISOWeek = pb.GetLastRewardISOWeek()
	return
}
func (this* dbPlayerCampFightInfoData)to_pb()(pb *db.PlayerCampFightInfo){
	pb = &db.PlayerCampFightInfo{}
	pb.EnterISOWeek = proto.Int32(this.EnterISOWeek)
	pb.EnterArenaLvl = proto.Int32(this.EnterArenaLvl)
	pb.CurScore = proto.Int32(this.CurScore)
	pb.LastRewardISOWeek = proto.Int32(this.LastRewardISOWeek)
	return
}
func (this* dbPlayerCampFightInfoData)clone_to(d *dbPlayerCampFightInfoData){
	d.EnterISOWeek = this.EnterISOWeek
	d.EnterArenaLvl = this.EnterArenaLvl
	d.CurScore = this.CurScore
	d.LastRewardISOWeek = this.LastRewardISOWeek
	return
}
type dbPlayerSignInfoData struct{
	LastSignDay int32
	CurSignSum int32
	CurSignSumMonth int32
	CurSignDays []int32
	RewardSignSum []int32
}
func (this* dbPlayerSignInfoData)from_pb(pb *db.PlayerSignInfo){
	if pb == nil {
		this.CurSignDays = make([]int32,0)
		this.RewardSignSum = make([]int32,0)
		return
	}
	this.LastSignDay = pb.GetLastSignDay()
	this.CurSignSum = pb.GetCurSignSum()
	this.CurSignSumMonth = pb.GetCurSignSumMonth()
	this.CurSignDays = make([]int32,len(pb.GetCurSignDays()))
	for i, v := range pb.GetCurSignDays() {
		this.CurSignDays[i] = v
	}
	this.RewardSignSum = make([]int32,len(pb.GetRewardSignSum()))
	for i, v := range pb.GetRewardSignSum() {
		this.RewardSignSum[i] = v
	}
	return
}
func (this* dbPlayerSignInfoData)to_pb()(pb *db.PlayerSignInfo){
	pb = &db.PlayerSignInfo{}
	pb.LastSignDay = proto.Int32(this.LastSignDay)
	pb.CurSignSum = proto.Int32(this.CurSignSum)
	pb.CurSignSumMonth = proto.Int32(this.CurSignSumMonth)
	pb.CurSignDays = make([]int32, len(this.CurSignDays))
	for i, v := range this.CurSignDays {
		pb.CurSignDays[i]=v
	}
	pb.RewardSignSum = make([]int32, len(this.RewardSignSum))
	for i, v := range this.RewardSignSum {
		pb.RewardSignSum[i]=v
	}
	return
}
func (this* dbPlayerSignInfoData)clone_to(d *dbPlayerSignInfoData){
	d.LastSignDay = this.LastSignDay
	d.CurSignSum = this.CurSignSum
	d.CurSignSumMonth = this.CurSignSumMonth
	d.CurSignDays = make([]int32, len(this.CurSignDays))
	for _ii, _vv := range this.CurSignDays {
		d.CurSignDays[_ii]=_vv
	}
	d.RewardSignSum = make([]int32, len(this.RewardSignSum))
	for _ii, _vv := range this.RewardSignSum {
		d.RewardSignSum[_ii]=_vv
	}
	return
}
type dbPlayerGuidesData struct{
	GuideId int32
	SetUnix int32
}
func (this* dbPlayerGuidesData)from_pb(pb *db.PlayerGuides){
	if pb == nil {
		return
	}
	this.GuideId = pb.GetGuideId()
	this.SetUnix = pb.GetSetUnix()
	return
}
func (this* dbPlayerGuidesData)to_pb()(pb *db.PlayerGuides){
	pb = &db.PlayerGuides{}
	pb.GuideId = proto.Int32(this.GuideId)
	pb.SetUnix = proto.Int32(this.SetUnix)
	return
}
func (this* dbPlayerGuidesData)clone_to(d *dbPlayerGuidesData){
	d.GuideId = this.GuideId
	d.SetUnix = this.SetUnix
	return
}
type dbPlayerFriendData struct{
	FriendPId int32
	FriendName string
	MatchScore int32
	TongIcon int32
	TongName string
}
func (this* dbPlayerFriendData)from_pb(pb *db.PlayerFriend){
	if pb == nil {
		return
	}
	this.FriendPId = pb.GetFriendPId()
	this.FriendName = pb.GetFriendName()
	this.MatchScore = pb.GetMatchScore()
	this.TongIcon = pb.GetTongIcon()
	this.TongName = pb.GetTongName()
	return
}
func (this* dbPlayerFriendData)to_pb()(pb *db.PlayerFriend){
	pb = &db.PlayerFriend{}
	pb.FriendPId = proto.Int32(this.FriendPId)
	pb.FriendName = proto.String(this.FriendName)
	pb.MatchScore = proto.Int32(this.MatchScore)
	pb.TongIcon = proto.Int32(this.TongIcon)
	pb.TongName = proto.String(this.TongName)
	return
}
func (this* dbPlayerFriendData)clone_to(d *dbPlayerFriendData){
	d.FriendPId = this.FriendPId
	d.FriendName = this.FriendName
	d.MatchScore = this.MatchScore
	d.TongIcon = this.TongIcon
	d.TongName = this.TongName
	return
}
type dbPlayerFriendReqData struct{
	FriendPId int32
	FriendName string
	MatchScore int32
	TongIcon int32
	TongName string
	ReqUnix int32
}
func (this* dbPlayerFriendReqData)from_pb(pb *db.PlayerFriendReq){
	if pb == nil {
		return
	}
	this.FriendPId = pb.GetFriendPId()
	this.FriendName = pb.GetFriendName()
	this.MatchScore = pb.GetMatchScore()
	this.TongIcon = pb.GetTongIcon()
	this.TongName = pb.GetTongName()
	this.ReqUnix = pb.GetReqUnix()
	return
}
func (this* dbPlayerFriendReqData)to_pb()(pb *db.PlayerFriendReq){
	pb = &db.PlayerFriendReq{}
	pb.FriendPId = proto.Int32(this.FriendPId)
	pb.FriendName = proto.String(this.FriendName)
	pb.MatchScore = proto.Int32(this.MatchScore)
	pb.TongIcon = proto.Int32(this.TongIcon)
	pb.TongName = proto.String(this.TongName)
	pb.ReqUnix = proto.Int32(this.ReqUnix)
	return
}
func (this* dbPlayerFriendReqData)clone_to(d *dbPlayerFriendReqData){
	d.FriendPId = this.FriendPId
	d.FriendName = this.FriendName
	d.MatchScore = this.MatchScore
	d.TongIcon = this.TongIcon
	d.TongName = this.TongName
	d.ReqUnix = this.ReqUnix
	return
}
type dbPlayerFocusPlayerData struct{
	FriendPId int32
	FriendName string
	MatchScore int32
	TongIcon int32
	TongName string
}
func (this* dbPlayerFocusPlayerData)from_pb(pb *db.PlayerFocusPlayer){
	if pb == nil {
		return
	}
	this.FriendPId = pb.GetFriendPId()
	this.FriendName = pb.GetFriendName()
	this.MatchScore = pb.GetMatchScore()
	this.TongIcon = pb.GetTongIcon()
	this.TongName = pb.GetTongName()
	return
}
func (this* dbPlayerFocusPlayerData)to_pb()(pb *db.PlayerFocusPlayer){
	pb = &db.PlayerFocusPlayer{}
	pb.FriendPId = proto.Int32(this.FriendPId)
	pb.FriendName = proto.String(this.FriendName)
	pb.MatchScore = proto.Int32(this.MatchScore)
	pb.TongIcon = proto.Int32(this.TongIcon)
	pb.TongName = proto.String(this.TongName)
	return
}
func (this* dbPlayerFocusPlayerData)clone_to(d *dbPlayerFocusPlayerData){
	d.FriendPId = this.FriendPId
	d.FriendName = this.FriendName
	d.MatchScore = this.MatchScore
	d.TongIcon = this.TongIcon
	d.TongName = this.TongName
	return
}
type dbPlayerBeFocusPlayerData struct{
	FriendPId int32
	FriendName string
	MatchScore int32
	TongIcon int32
	TongName string
}
func (this* dbPlayerBeFocusPlayerData)from_pb(pb *db.PlayerBeFocusPlayer){
	if pb == nil {
		return
	}
	this.FriendPId = pb.GetFriendPId()
	this.FriendName = pb.GetFriendName()
	this.MatchScore = pb.GetMatchScore()
	this.TongIcon = pb.GetTongIcon()
	this.TongName = pb.GetTongName()
	return
}
func (this* dbPlayerBeFocusPlayerData)to_pb()(pb *db.PlayerBeFocusPlayer){
	pb = &db.PlayerBeFocusPlayer{}
	pb.FriendPId = proto.Int32(this.FriendPId)
	pb.FriendName = proto.String(this.FriendName)
	pb.MatchScore = proto.Int32(this.MatchScore)
	pb.TongIcon = proto.Int32(this.TongIcon)
	pb.TongName = proto.String(this.TongName)
	return
}
func (this* dbPlayerBeFocusPlayerData)clone_to(d *dbPlayerBeFocusPlayerData){
	d.FriendPId = this.FriendPId
	d.FriendName = this.FriendName
	d.MatchScore = this.MatchScore
	d.TongIcon = this.TongIcon
	d.TongName = this.TongName
	return
}
type dbTongTongDataData struct{
	Name string
	PubContent string
	WeekDonate int32
	JoinType int8
	JoinScore int16
	Pos int16
	Icon int16
	CaptainId int32
	TongChestScore int32
	IfTongChestClear int32
	LastWeekDonateUpWeek int32
}
func (this* dbTongTongDataData)from_pb(pb *db.TongTongData){
	if pb == nil {
		return
	}
	this.Name = pb.GetName()
	this.PubContent = pb.GetPubContent()
	this.WeekDonate = pb.GetWeekDonate()
	this.JoinType = int8(pb.GetJoinType())
	this.JoinScore = int16(pb.GetJoinScore())
	this.Pos = int16(pb.GetPos())
	this.Icon = int16(pb.GetIcon())
	this.CaptainId = pb.GetCaptainId()
	this.TongChestScore = pb.GetTongChestScore()
	this.IfTongChestClear = pb.GetIfTongChestClear()
	this.LastWeekDonateUpWeek = pb.GetLastWeekDonateUpWeek()
	return
}
func (this* dbTongTongDataData)to_pb()(pb *db.TongTongData){
	pb = &db.TongTongData{}
	pb.Name = proto.String(this.Name)
	pb.PubContent = proto.String(this.PubContent)
	pb.WeekDonate = proto.Int32(this.WeekDonate)
	temp_JoinType:=int32(this.JoinType)
	pb.JoinType = proto.Int32(temp_JoinType)
	temp_JoinScore:=int32(this.JoinScore)
	pb.JoinScore = proto.Int32(temp_JoinScore)
	temp_Pos:=int32(this.Pos)
	pb.Pos = proto.Int32(temp_Pos)
	temp_Icon:=int32(this.Icon)
	pb.Icon = proto.Int32(temp_Icon)
	pb.CaptainId = proto.Int32(this.CaptainId)
	pb.TongChestScore = proto.Int32(this.TongChestScore)
	pb.IfTongChestClear = proto.Int32(this.IfTongChestClear)
	pb.LastWeekDonateUpWeek = proto.Int32(this.LastWeekDonateUpWeek)
	return
}
func (this* dbTongTongDataData)clone_to(d *dbTongTongDataData){
	d.Name = this.Name
	d.PubContent = this.PubContent
	d.WeekDonate = this.WeekDonate
	d.JoinType = int8(this.JoinType)
	d.JoinScore = int16(this.JoinScore)
	d.Pos = int16(this.Pos)
	d.Icon = int16(this.Icon)
	d.CaptainId = this.CaptainId
	d.TongChestScore = this.TongChestScore
	d.IfTongChestClear = this.IfTongChestClear
	d.LastWeekDonateUpWeek = this.LastWeekDonateUpWeek
	return
}
type dbTongTongMemberData struct{
	MemberId int32
	PlayerId int32
	PlayerName string
	Score int16
	Donate int16
	MemberType int8
}
func (this* dbTongTongMemberData)from_pb(pb *db.TongTongMember){
	if pb == nil {
		return
	}
	this.MemberId = pb.GetMemberId()
	this.PlayerId = pb.GetPlayerId()
	this.PlayerName = pb.GetPlayerName()
	this.Score = int16(pb.GetScore())
	this.Donate = int16(pb.GetDonate())
	this.MemberType = int8(pb.GetMemberType())
	return
}
func (this* dbTongTongMemberData)to_pb()(pb *db.TongTongMember){
	pb = &db.TongTongMember{}
	pb.MemberId = proto.Int32(this.MemberId)
	pb.PlayerId = proto.Int32(this.PlayerId)
	pb.PlayerName = proto.String(this.PlayerName)
	temp_Score:=int32(this.Score)
	pb.Score = proto.Int32(temp_Score)
	temp_Donate:=int32(this.Donate)
	pb.Donate = proto.Int32(temp_Donate)
	temp_MemberType:=int32(this.MemberType)
	pb.MemberType = proto.Int32(temp_MemberType)
	return
}
func (this* dbTongTongMemberData)clone_to(d *dbTongTongMemberData){
	d.MemberId = this.MemberId
	d.PlayerId = this.PlayerId
	d.PlayerName = this.PlayerName
	d.Score = int16(this.Score)
	d.Donate = int16(this.Donate)
	d.MemberType = int8(this.MemberType)
	return
}
type dbTongTongJoinData struct{
	PlayerId int32
	PlayerName string
	JoinSec int32
	PlayerScore int32
}
func (this* dbTongTongJoinData)from_pb(pb *db.TongTongJoin){
	if pb == nil {
		return
	}
	this.PlayerId = pb.GetPlayerId()
	this.PlayerName = pb.GetPlayerName()
	this.JoinSec = pb.GetJoinSec()
	this.PlayerScore = pb.GetPlayerScore()
	return
}
func (this* dbTongTongJoinData)to_pb()(pb *db.TongTongJoin){
	pb = &db.TongTongJoin{}
	pb.PlayerId = proto.Int32(this.PlayerId)
	pb.PlayerName = proto.String(this.PlayerName)
	pb.JoinSec = proto.Int32(this.JoinSec)
	pb.PlayerScore = proto.Int32(this.PlayerScore)
	return
}
func (this* dbTongTongJoinData)clone_to(d *dbTongTongJoinData){
	d.PlayerId = this.PlayerId
	d.PlayerName = this.PlayerName
	d.JoinSec = this.JoinSec
	d.PlayerScore = this.PlayerScore
	return
}
type dbTongTongChatRecordData struct{
	Index int32
	SenderId int32
	SenderName string
	MsgContent string
	SendTime int32
}
func (this* dbTongTongChatRecordData)from_pb(pb *db.TongTongChatRecord){
	if pb == nil {
		return
	}
	this.Index = pb.GetIndex()
	this.SenderId = pb.GetSenderId()
	this.SenderName = pb.GetSenderName()
	this.MsgContent = pb.GetMsgContent()
	this.SendTime = pb.GetSendTime()
	return
}
func (this* dbTongTongChatRecordData)to_pb()(pb *db.TongTongChatRecord){
	pb = &db.TongTongChatRecord{}
	pb.Index = proto.Int32(this.Index)
	pb.SenderId = proto.Int32(this.SenderId)
	pb.SenderName = proto.String(this.SenderName)
	pb.MsgContent = proto.String(this.MsgContent)
	pb.SendTime = proto.Int32(this.SendTime)
	return
}
func (this* dbTongTongChatRecordData)clone_to(d *dbTongTongChatRecordData){
	d.Index = this.Index
	d.SenderId = this.SenderId
	d.SenderName = this.SenderName
	d.MsgContent = this.MsgContent
	d.SendTime = this.SendTime
	return
}
type dbTongTongCardReqData struct{
	PlayerId int32
	PlayerName string
	CardCfgId int32
	CurGetNum int32
	MaxGetNum int32
	ReqUnix int32
}
func (this* dbTongTongCardReqData)from_pb(pb *db.TongTongCardReq){
	if pb == nil {
		return
	}
	this.PlayerId = pb.GetPlayerId()
	this.PlayerName = pb.GetPlayerName()
	this.CardCfgId = pb.GetCardCfgId()
	this.CurGetNum = pb.GetCurGetNum()
	this.MaxGetNum = pb.GetMaxGetNum()
	this.ReqUnix = pb.GetReqUnix()
	return
}
func (this* dbTongTongCardReqData)to_pb()(pb *db.TongTongCardReq){
	pb = &db.TongTongCardReq{}
	pb.PlayerId = proto.Int32(this.PlayerId)
	pb.PlayerName = proto.String(this.PlayerName)
	pb.CardCfgId = proto.Int32(this.CardCfgId)
	pb.CurGetNum = proto.Int32(this.CurGetNum)
	pb.MaxGetNum = proto.Int32(this.MaxGetNum)
	pb.ReqUnix = proto.Int32(this.ReqUnix)
	return
}
func (this* dbTongTongCardReqData)clone_to(d *dbTongTongCardReqData){
	d.PlayerId = this.PlayerId
	d.PlayerName = this.PlayerName
	d.CardCfgId = this.CardCfgId
	d.CurGetNum = this.CurGetNum
	d.MaxGetNum = this.MaxGetNum
	d.ReqUnix = this.ReqUnix
	return
}
type dbTongTongChestOpenData struct{
	PlayerId int32
	WinScore int32
	ReqUnix int32
}
func (this* dbTongTongChestOpenData)from_pb(pb *db.TongTongChestOpen){
	if pb == nil {
		return
	}
	this.PlayerId = pb.GetPlayerId()
	this.WinScore = pb.GetWinScore()
	this.ReqUnix = pb.GetReqUnix()
	return
}
func (this* dbTongTongChestOpenData)to_pb()(pb *db.TongTongChestOpen){
	pb = &db.TongTongChestOpen{}
	pb.PlayerId = proto.Int32(this.PlayerId)
	pb.WinScore = proto.Int32(this.WinScore)
	pb.ReqUnix = proto.Int32(this.ReqUnix)
	return
}
func (this* dbTongTongChestOpenData)clone_to(d *dbTongTongChestOpenData){
	d.PlayerId = this.PlayerId
	d.WinScore = this.WinScore
	d.ReqUnix = this.ReqUnix
	return
}

func (this *dbPlayerRow)GetAccount( )(r string ){
	this.m_lock.UnSafeRLock("dbPlayerRow.GetdbPlayerAccountColumn")
	defer this.m_lock.UnSafeRUnlock()
	return string(this.m_Account)
}
func (this *dbPlayerRow)SetAccount(v string){
	this.m_lock.UnSafeLock("dbPlayerRow.SetdbPlayerAccountColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_Account=string(v)
	this.m_Account_changed=true
	return
}
func (this *dbPlayerRow)GetName( )(r string ){
	this.m_lock.UnSafeRLock("dbPlayerRow.GetdbPlayerNameColumn")
	defer this.m_lock.UnSafeRUnlock()
	return string(this.m_Name)
}
func (this *dbPlayerRow)SetName(v string){
	this.m_lock.UnSafeLock("dbPlayerRow.SetdbPlayerNameColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_Name=string(v)
	this.m_Name_changed=true
	return
}
type dbPlayerInfoColumn struct{
	m_row *dbPlayerRow
	m_data *dbPlayerInfoData
	m_changed bool
}
func (this *dbPlayerInfoColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbPlayerInfoData{}
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerInfo{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_data = &dbPlayerInfoData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbPlayerInfoColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerInfoColumn)Get( )(v *dbPlayerInfoData ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbPlayerInfoData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbPlayerInfoColumn)Set(v dbPlayerInfoData ){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbPlayerInfoData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbPlayerInfoColumn)GetLvl( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetLvl")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.Lvl
	return
}
func (this *dbPlayerInfoColumn)SetLvl(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetLvl")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Lvl = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetMatchScore( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetMatchScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.MatchScore
	return
}
func (this *dbPlayerInfoColumn)SetMatchScore(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetMatchScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.MatchScore = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyMatchScore(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyMatchScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.MatchScore += v
	this.m_changed = true
	return this.m_data.MatchScore
}
func (this *dbPlayerInfoColumn)GetCoin( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetCoin")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.Coin
	return
}
func (this *dbPlayerInfoColumn)SetCoin(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetCoin")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Coin = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyCoin(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyCoin")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Coin += v
	this.m_changed = true
	return this.m_data.Coin
}
func (this *dbPlayerInfoColumn)GetDiamond( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetDiamond")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.Diamond
	return
}
func (this *dbPlayerInfoColumn)SetDiamond(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetDiamond")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Diamond = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyDiamond(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyDiamond")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Diamond += v
	this.m_changed = true
	return this.m_data.Diamond
}
func (this *dbPlayerInfoColumn)GetDayMatchRewardNum( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetDayMatchRewardNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.DayMatchRewardNum)
	return
}
func (this *dbPlayerInfoColumn)SetDayMatchRewardNum(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetDayMatchRewardNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.DayMatchRewardNum = int8(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyDayMatchRewardNum(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyDayMatchRewardNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.DayMatchRewardNum += int8(v)
	this.m_changed = true
	return int32(this.m_data.DayMatchRewardNum)
}
func (this *dbPlayerInfoColumn)GetLayMatchRewardTime( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetLayMatchRewardTime")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LayMatchRewardTime
	return
}
func (this *dbPlayerInfoColumn)SetLayMatchRewardTime(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetLayMatchRewardTime")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LayMatchRewardTime = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetCurUseCardTeam( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetCurUseCardTeam")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurUseCardTeam
	return
}
func (this *dbPlayerInfoColumn)SetCurUseCardTeam(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetCurUseCardTeam")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurUseCardTeam = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetExp( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetExp")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.Exp
	return
}
func (this *dbPlayerInfoColumn)SetExp(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetExp")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Exp = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyExp(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyExp")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Exp += v
	this.m_changed = true
	return this.m_data.Exp
}
func (this *dbPlayerInfoColumn)GetArenaLvl( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetArenaLvl")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.ArenaLvl)
	return
}
func (this *dbPlayerInfoColumn)SetArenaLvl(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetArenaLvl")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.ArenaLvl = int8(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetLastShopUpDay( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetLastShopUpDay")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastShopUpDay
	return
}
func (this *dbPlayerInfoColumn)SetLastShopUpDay(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetLastShopUpDay")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastShopUpDay = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetCamp( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetCamp")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.Camp)
	return
}
func (this *dbPlayerInfoColumn)SetCamp(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetCamp")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Camp = int8(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetChestCycleCount( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetChestCycleCount")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.ChestCycleCount)
	return
}
func (this *dbPlayerInfoColumn)SetChestCycleCount(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetChestCycleCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.ChestCycleCount = int16(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyChestCycleCount(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyChestCycleCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.ChestCycleCount += int16(v)
	this.m_changed = true
	return int32(this.m_data.ChestCycleCount)
}
func (this *dbPlayerInfoColumn)GetIfCaptain( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetIfCaptain")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.IfCaptain)
	return
}
func (this *dbPlayerInfoColumn)SetIfCaptain(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetIfCaptain")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.IfCaptain = int8(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetCurBestLegScore( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetCurBestLegScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.CurBestLegScore)
	return
}
func (this *dbPlayerInfoColumn)SetCurBestLegScore(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetCurBestLegScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurBestLegScore = int16(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetLastBestLegScore( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetLastBestLegScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.LastBestLegScore)
	return
}
func (this *dbPlayerInfoColumn)SetLastBestLegScore(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetLastBestLegScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastBestLegScore = int16(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetWinCount( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetWinCount")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.WinCount)
	return
}
func (this *dbPlayerInfoColumn)SetWinCount(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetWinCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.WinCount = int16(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyWinCount(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyWinCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.WinCount += int16(v)
	this.m_changed = true
	return int32(this.m_data.WinCount)
}
func (this *dbPlayerInfoColumn)GetOftenCard( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetOftenCard")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.OftenCard
	return
}
func (this *dbPlayerInfoColumn)SetOftenCard(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetOftenCard")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.OftenCard = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetDonateCount( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetDonateCount")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.DonateCount
	return
}
func (this *dbPlayerInfoColumn)SetDonateCount(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetDonateCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.DonateCount = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyDonateCount(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyDonateCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.DonateCount += v
	this.m_changed = true
	return this.m_data.DonateCount
}
func (this *dbPlayerInfoColumn)GetChellWinCount( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetChellWinCount")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.ChellWinCount)
	return
}
func (this *dbPlayerInfoColumn)SetChellWinCount(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetChellWinCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.ChellWinCount = int16(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyChellWinCount(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyChellWinCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.ChellWinCount += int16(v)
	this.m_changed = true
	return int32(this.m_data.ChellWinCount)
}
func (this *dbPlayerInfoColumn)GetChellOfenCard( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetChellOfenCard")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.ChellOfenCard
	return
}
func (this *dbPlayerInfoColumn)SetChellOfenCard(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetChellOfenCard")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.ChellOfenCard = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetLastDialyTaskUpUinx( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetLastDialyTaskUpUinx")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastDialyTaskUpUinx
	return
}
func (this *dbPlayerInfoColumn)SetLastDialyTaskUpUinx(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetLastDialyTaskUpUinx")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastDialyTaskUpUinx = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetLastLegendSwitchUnix( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetLastLegendSwitchUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastLegendSwitchUnix
	return
}
func (this *dbPlayerInfoColumn)SetLastLegendSwitchUnix(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetLastLegendSwitchUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastLegendSwitchUnix = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetCurLegendScore( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetCurLegendScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurLegendScore
	return
}
func (this *dbPlayerInfoColumn)SetCurLegendScore(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetCurLegendScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurLegendScore = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyCurLegendScore(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyCurLegendScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurLegendScore += v
	this.m_changed = true
	return this.m_data.CurLegendScore
}
func (this *dbPlayerInfoColumn)GetIfHaveChooseCamp( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetIfHaveChooseCamp")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.IfHaveChooseCamp)
	return
}
func (this *dbPlayerInfoColumn)SetIfHaveChooseCamp(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetIfHaveChooseCamp")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.IfHaveChooseCamp = int8(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetChangeNameCount( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetChangeNameCount")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.ChangeNameCount)
	return
}
func (this *dbPlayerInfoColumn)SetChangeNameCount(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetChangeNameCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.ChangeNameCount = int16(v)
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyChangeNameCount(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyChangeNameCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.ChangeNameCount += int16(v)
	this.m_changed = true
	return int32(this.m_data.ChangeNameCount)
}
func (this *dbPlayerInfoColumn)GetCardToken1( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetCardToken1")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CardToken1
	return
}
func (this *dbPlayerInfoColumn)SetCardToken1(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetCardToken1")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CardToken1 = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyCardToken1(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyCardToken1")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CardToken1 += v
	this.m_changed = true
	return this.m_data.CardToken1
}
func (this *dbPlayerInfoColumn)GetCardToken2( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetCardToken2")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CardToken2
	return
}
func (this *dbPlayerInfoColumn)SetCardToken2(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetCardToken2")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CardToken2 = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyCardToken2(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyCardToken2")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CardToken2 += v
	this.m_changed = true
	return this.m_data.CardToken2
}
func (this *dbPlayerInfoColumn)GetCardToken3( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetCardToken3")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CardToken3
	return
}
func (this *dbPlayerInfoColumn)SetCardToken3(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetCardToken3")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CardToken3 = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyCardToken3(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyCardToken3")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CardToken3 += v
	this.m_changed = true
	return this.m_data.CardToken3
}
func (this *dbPlayerInfoColumn)GetCardToken4( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetCardToken4")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CardToken4
	return
}
func (this *dbPlayerInfoColumn)SetCardToken4(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetCardToken4")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CardToken4 = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)IncbyCardToken4(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.IncbyCardToken4")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CardToken4 += v
	this.m_changed = true
	return this.m_data.CardToken4
}
func (this *dbPlayerInfoColumn)GetLastCardCompoundUpUnix( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetLastCardCompoundUpUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastCardCompoundUpUnix
	return
}
func (this *dbPlayerInfoColumn)SetLastCardCompoundUpUnix(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetLastCardCompoundUpUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastCardCompoundUpUnix = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetCreateUnix( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetCreateUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CreateUnix
	return
}
func (this *dbPlayerInfoColumn)SetCreateUnix(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetCreateUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CreateUnix = v
	this.m_changed = true
	return
}
func (this *dbPlayerInfoColumn)GetFirstPayState( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerInfoColumn.GetFirstPayState")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.FirstPayState)
	return
}
func (this *dbPlayerInfoColumn)SetFirstPayState(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerInfoColumn.SetFirstPayState")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.FirstPayState = int8(v)
	this.m_changed = true
	return
}
type dbPlayerTongInfoColumn struct{
	m_row *dbPlayerRow
	m_data *dbPlayerTongInfoData
	m_changed bool
}
func (this *dbPlayerTongInfoColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbPlayerTongInfoData{}
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerTongInfo{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_data = &dbPlayerTongInfoData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbPlayerTongInfoColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerTongInfoColumn)Get( )(v *dbPlayerTongInfoData ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongInfoColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbPlayerTongInfoData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbPlayerTongInfoColumn)Set(v dbPlayerTongInfoData ){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbPlayerTongInfoData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbPlayerTongInfoColumn)GetTongId( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongInfoColumn.GetTongId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.TongId
	return
}
func (this *dbPlayerTongInfoColumn)SetTongId(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.SetTongId")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.TongId = v
	this.m_changed = true
	return
}
func (this *dbPlayerTongInfoColumn)GetTongIcon( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongInfoColumn.GetTongIcon")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.TongIcon
	return
}
func (this *dbPlayerTongInfoColumn)SetTongIcon(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.SetTongIcon")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.TongIcon = v
	this.m_changed = true
	return
}
func (this *dbPlayerTongInfoColumn)GetTongName( )(v string ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongInfoColumn.GetTongName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.TongName
	return
}
func (this *dbPlayerTongInfoColumn)SetTongName(v string){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.SetTongName")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.TongName = v
	this.m_changed = true
	return
}
func (this *dbPlayerTongInfoColumn)GetTongMemberType( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongInfoColumn.GetTongMemberType")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.TongMemberType
	return
}
func (this *dbPlayerTongInfoColumn)SetTongMemberType(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.SetTongMemberType")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.TongMemberType = v
	this.m_changed = true
	return
}
func (this *dbPlayerTongInfoColumn)GetLastLeaveTongUnix( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongInfoColumn.GetLastLeaveTongUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastLeaveTongUnix
	return
}
func (this *dbPlayerTongInfoColumn)SetLastLeaveTongUnix(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.SetLastLeaveTongUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastLeaveTongUnix = v
	this.m_changed = true
	return
}
func (this *dbPlayerTongInfoColumn)GetLastCardReqUnix( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongInfoColumn.GetLastCardReqUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastCardReqUnix
	return
}
func (this *dbPlayerTongInfoColumn)SetLastCardReqUnix(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.SetLastCardReqUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastCardReqUnix = v
	this.m_changed = true
	return
}
func (this *dbPlayerTongInfoColumn)GetTodayDonateMax( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongInfoColumn.GetTodayDonateMax")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.TodayDonateMax
	return
}
func (this *dbPlayerTongInfoColumn)SetTodayDonateMax(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.SetTodayDonateMax")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.TodayDonateMax = v
	this.m_changed = true
	return
}
func (this *dbPlayerTongInfoColumn)GetTodayDonateNum( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongInfoColumn.GetTodayDonateNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.TodayDonateNum
	return
}
func (this *dbPlayerTongInfoColumn)SetTodayDonateNum(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.SetTodayDonateNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.TodayDonateNum = v
	this.m_changed = true
	return
}
func (this *dbPlayerTongInfoColumn)IncbyTodayDonateNum(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.IncbyTodayDonateNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.TodayDonateNum += v
	this.m_changed = true
	return this.m_data.TodayDonateNum
}
func (this *dbPlayerTongInfoColumn)GetLastDonateMaxUpUnixD( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongInfoColumn.GetLastDonateMaxUpUnixD")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastDonateMaxUpUnixD
	return
}
func (this *dbPlayerTongInfoColumn)SetLastDonateMaxUpUnixD(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongInfoColumn.SetLastDonateMaxUpUnixD")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastDonateMaxUpUnixD = v
	this.m_changed = true
	return
}
type dbPlayerTongDonateColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerTongDonateData
	m_changed bool
}
func (this *dbPlayerTongDonateColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerTongDonateList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerTongDonateData{}
		d.from_pb(v)
		this.m_data[int32(d.PlayerId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerTongDonateColumn)save( )(data []byte,err error){
	pb := &db.PlayerTongDonateList{}
	pb.List=make([]*db.PlayerTongDonate,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerTongDonateColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongDonateColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerTongDonateColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongDonateColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerTongDonateColumn)GetAll()(list []dbPlayerTongDonateData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongDonateColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerTongDonateData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerTongDonateColumn)Get(id int32)(v *dbPlayerTongDonateData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongDonateColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerTongDonateData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerTongDonateColumn)Set(v dbPlayerTongDonateData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongDonateColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.PlayerId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.PlayerId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerTongDonateColumn)Add(v *dbPlayerTongDonateData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongDonateColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.PlayerId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.PlayerId)
		return false
	}
	d:=&dbPlayerTongDonateData{}
	v.clone_to(d)
	this.m_data[int32(v.PlayerId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerTongDonateColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongDonateColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerTongDonateColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongDonateColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerTongDonateData)
	this.m_changed = true
	return
}
func (this *dbPlayerTongDonateColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongDonateColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerTongDonateColumn)GetDonateNum(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongDonateColumn.GetDonateNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.DonateNum
	return v,true
}
func (this *dbPlayerTongDonateColumn)SetDonateNum(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongDonateColumn.SetDonateNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.DonateNum = v
	this.m_changed = true
	return true
}
func (this *dbPlayerTongDonateColumn)GetDonateUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTongDonateColumn.GetDonateUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.DonateUnix
	return v,true
}
func (this *dbPlayerTongDonateColumn)SetDonateUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerTongDonateColumn.SetDonateUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.DonateUnix = v
	this.m_changed = true
	return true
}
type dbPlayerBeTongDonateColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerBeTongDonateData
	m_changed bool
}
func (this *dbPlayerBeTongDonateColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerBeTongDonateList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerBeTongDonateData{}
		d.from_pb(v)
		this.m_data[int32(d.PlayerId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerBeTongDonateColumn)save( )(data []byte,err error){
	pb := &db.PlayerBeTongDonateList{}
	pb.List=make([]*db.PlayerBeTongDonate,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerBeTongDonateColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeTongDonateColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerBeTongDonateColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeTongDonateColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerBeTongDonateColumn)GetAll()(list []dbPlayerBeTongDonateData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeTongDonateColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerBeTongDonateData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerBeTongDonateColumn)Get(id int32)(v *dbPlayerBeTongDonateData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeTongDonateColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerBeTongDonateData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerBeTongDonateColumn)Set(v dbPlayerBeTongDonateData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeTongDonateColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.PlayerId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.PlayerId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerBeTongDonateColumn)Add(v *dbPlayerBeTongDonateData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeTongDonateColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.PlayerId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.PlayerId)
		return false
	}
	d:=&dbPlayerBeTongDonateData{}
	v.clone_to(d)
	this.m_data[int32(v.PlayerId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerBeTongDonateColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeTongDonateColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerBeTongDonateColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeTongDonateColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerBeTongDonateData)
	this.m_changed = true
	return
}
func (this *dbPlayerBeTongDonateColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeTongDonateColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerBeTongDonateColumn)GetPlayerName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeTongDonateColumn.GetPlayerName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.PlayerName
	return v,true
}
func (this *dbPlayerBeTongDonateColumn)SetPlayerName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeTongDonateColumn.SetPlayerName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.PlayerName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerBeTongDonateColumn)GetDonateNum(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeTongDonateColumn.GetDonateNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.DonateNum
	return v,true
}
func (this *dbPlayerBeTongDonateColumn)SetDonateNum(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeTongDonateColumn.SetDonateNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.DonateNum = v
	this.m_changed = true
	return true
}
type dbPlayerCardColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerCardData
	m_changed bool
}
func (this *dbPlayerCardColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerCardList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerCardData{}
		d.from_pb(v)
		this.m_data[int32(d.ConfigId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerCardColumn)save( )(data []byte,err error){
	pb := &db.PlayerCardList{}
	pb.List=make([]*db.PlayerCard,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerCardColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerCardColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerCardColumn)GetAll()(list []dbPlayerCardData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerCardData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerCardColumn)Get(id int32)(v *dbPlayerCardData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerCardData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerCardColumn)Set(v dbPlayerCardData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.ConfigId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.ConfigId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerCardColumn)Add(v *dbPlayerCardData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.ConfigId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.ConfigId)
		return false
	}
	d:=&dbPlayerCardData{}
	v.clone_to(d)
	this.m_data[int32(v.ConfigId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerCardColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerCardColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerCardData)
	this.m_changed = true
	return
}
func (this *dbPlayerCardColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerCardColumn)GetCardCount(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetCardCount")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.CardCount
	return v,true
}
func (this *dbPlayerCardColumn)SetCardCount(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardColumn.SetCardCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.CardCount = v
	this.m_changed = true
	return true
}
func (this *dbPlayerCardColumn)IncbyCardCount(id int32,v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardColumn.IncbyCardCount")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		d = &dbPlayerCardData{}
		this.m_data[id] = d
	}
	d.CardCount +=  v
	this.m_changed = true
	return d.CardCount
}
func (this *dbPlayerCardColumn)GetCardLvl(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetCardLvl")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.CardLvl
	return v,true
}
func (this *dbPlayerCardColumn)SetCardLvl(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardColumn.SetCardLvl")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.CardLvl = v
	this.m_changed = true
	return true
}
func (this *dbPlayerCardColumn)IncbyCardLvl(id int32,v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardColumn.IncbyCardLvl")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		d = &dbPlayerCardData{}
		this.m_data[id] = d
	}
	d.CardLvl +=  v
	this.m_changed = true
	return d.CardLvl
}
type dbPlayerCardTeamColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerCardTeamData
	m_changed bool
}
func (this *dbPlayerCardTeamColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerCardTeamList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerCardTeamData{}
		d.from_pb(v)
		this.m_data[int32(d.TeamId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerCardTeamColumn)save( )(data []byte,err error){
	pb := &db.PlayerCardTeamList{}
	pb.List=make([]*db.PlayerCardTeam,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerCardTeamColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardTeamColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerCardTeamColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardTeamColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerCardTeamColumn)GetAll()(list []dbPlayerCardTeamData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardTeamColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerCardTeamData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerCardTeamColumn)Get(id int32)(v *dbPlayerCardTeamData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardTeamColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerCardTeamData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerCardTeamColumn)Set(v dbPlayerCardTeamData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardTeamColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.TeamId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.TeamId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerCardTeamColumn)Add(v *dbPlayerCardTeamData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardTeamColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.TeamId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.TeamId)
		return false
	}
	d:=&dbPlayerCardTeamData{}
	v.clone_to(d)
	this.m_data[int32(v.TeamId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerCardTeamColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardTeamColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerCardTeamColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardTeamColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerCardTeamData)
	this.m_changed = true
	return
}
func (this *dbPlayerCardTeamColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardTeamColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerCardTeamColumn)GetCardCfgIds(id int32)(v []int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardTeamColumn.GetCardCfgIds")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = make([]int32, len(d.CardCfgIds))
	for _ii, _vv := range d.CardCfgIds {
		v[_ii]=_vv
	}
	return v,true
}
func (this *dbPlayerCardTeamColumn)SetCardCfgIds(id int32,v []int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerCardTeamColumn.SetCardCfgIds")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.CardCfgIds = make([]int32, len(v))
	for _ii, _vv := range v {
		d.CardCfgIds[_ii]=_vv
	}
	this.m_changed = true
	return true
}
type dbPlayerShopLatticeColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerShopLatticeData
	m_changed bool
}
func (this *dbPlayerShopLatticeColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerShopLatticeList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerShopLatticeData{}
		d.from_pb(v)
		this.m_data[int32(d.Lattice)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerShopLatticeColumn)save( )(data []byte,err error){
	pb := &db.PlayerShopLatticeList{}
	pb.List=make([]*db.PlayerShopLattice,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerShopLatticeColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerShopLatticeColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerShopLatticeColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerShopLatticeColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerShopLatticeColumn)GetAll()(list []dbPlayerShopLatticeData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerShopLatticeColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerShopLatticeData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerShopLatticeColumn)Get(id int32)(v *dbPlayerShopLatticeData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerShopLatticeColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerShopLatticeData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerShopLatticeColumn)Set(v dbPlayerShopLatticeData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerShopLatticeColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.Lattice)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.Lattice)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerShopLatticeColumn)Add(v *dbPlayerShopLatticeData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerShopLatticeColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.Lattice)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.Lattice)
		return false
	}
	d:=&dbPlayerShopLatticeData{}
	v.clone_to(d)
	this.m_data[int32(v.Lattice)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerShopLatticeColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerShopLatticeColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerShopLatticeColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerShopLatticeColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerShopLatticeData)
	this.m_changed = true
	return
}
func (this *dbPlayerShopLatticeColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerShopLatticeColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerShopLatticeColumn)GetTodayBuyNum(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerShopLatticeColumn.GetTodayBuyNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.TodayBuyNum
	return v,true
}
func (this *dbPlayerShopLatticeColumn)SetTodayBuyNum(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerShopLatticeColumn.SetTodayBuyNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.TodayBuyNum = v
	this.m_changed = true
	return true
}
func (this *dbPlayerShopLatticeColumn)IncbyTodayBuyNum(id int32,v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerShopLatticeColumn.IncbyTodayBuyNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		d = &dbPlayerShopLatticeData{}
		this.m_data[id] = d
	}
	d.TodayBuyNum +=  v
	this.m_changed = true
	return d.TodayBuyNum
}
func (this *dbPlayerShopLatticeColumn)GetCardCfgId(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerShopLatticeColumn.GetCardCfgId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.CardCfgId
	return v,true
}
func (this *dbPlayerShopLatticeColumn)SetCardCfgId(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerShopLatticeColumn.SetCardCfgId")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.CardCfgId = v
	this.m_changed = true
	return true
}
type dbPlayerChestColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerChestData
	m_changed bool
}
func (this *dbPlayerChestColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerChestList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerChestData{}
		d.from_pb(v)
		this.m_data[int32(d.Pos)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerChestColumn)save( )(data []byte,err error){
	pb := &db.PlayerChestList{}
	pb.List=make([]*db.PlayerChest,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerChestColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerChestColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerChestColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerChestColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerChestColumn)GetAll()(list []dbPlayerChestData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerChestColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerChestData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerChestColumn)Get(id int32)(v *dbPlayerChestData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerChestColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerChestData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerChestColumn)Set(v dbPlayerChestData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerChestColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.Pos)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.Pos)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerChestColumn)Add(v *dbPlayerChestData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerChestColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.Pos)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.Pos)
		return false
	}
	d:=&dbPlayerChestData{}
	v.clone_to(d)
	this.m_data[int32(v.Pos)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerChestColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerChestColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerChestColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerChestColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerChestData)
	this.m_changed = true
	return
}
func (this *dbPlayerChestColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerChestColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerChestColumn)GetChestId(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerChestColumn.GetChestId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.ChestId
	return v,true
}
func (this *dbPlayerChestColumn)SetChestId(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerChestColumn.SetChestId")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.ChestId = v
	this.m_changed = true
	return true
}
func (this *dbPlayerChestColumn)GetOpenSec(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerChestColumn.GetOpenSec")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.OpenSec
	return v,true
}
func (this *dbPlayerChestColumn)SetOpenSec(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerChestColumn.SetOpenSec")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OpenSec = v
	this.m_changed = true
	return true
}
type dbPlayerMailColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerMailData
	m_changed bool
}
func (this *dbPlayerMailColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerMailList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerMailData{}
		d.from_pb(v)
		this.m_data[int32(d.MailId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerMailColumn)save( )(data []byte,err error){
	pb := &db.PlayerMailList{}
	pb.List=make([]*db.PlayerMail,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerMailColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerMailColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerMailColumn)GetAll()(list []dbPlayerMailData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerMailData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerMailColumn)Get(id int32)(v *dbPlayerMailData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerMailData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerMailColumn)Set(v dbPlayerMailData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.MailId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.MailId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)Add(v *dbPlayerMailData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.MailId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.MailId)
		return false
	}
	d:=&dbPlayerMailData{}
	v.clone_to(d)
	this.m_data[int32(v.MailId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerMailColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerMailData)
	this.m_changed = true
	return
}
func (this *dbPlayerMailColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerMailColumn)GetMailTitle(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetMailTitle")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MailTitle
	return v,true
}
func (this *dbPlayerMailColumn)SetMailTitle(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetMailTitle")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MailTitle = v
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetSenderName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetSenderName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.SenderName
	return v,true
}
func (this *dbPlayerMailColumn)SetSenderName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetSenderName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.SenderName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetContent(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetContent")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.Content
	return v,true
}
func (this *dbPlayerMailColumn)SetContent(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetContent")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.Content = v
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetSendUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetSendUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.SendUnix
	return v,true
}
func (this *dbPlayerMailColumn)SetSendUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetSendUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.SendUnix = v
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetCoin(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetCoin")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.Coin
	return v,true
}
func (this *dbPlayerMailColumn)SetCoin(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetCoin")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.Coin = v
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetDiamond(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetDiamond")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.Diamond
	return v,true
}
func (this *dbPlayerMailColumn)SetDiamond(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetDiamond")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.Diamond = v
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetChests(id int32)(v []int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetChests")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = make([]int32, len(d.Chests))
	for _ii, _vv := range d.Chests {
		v[_ii]=_vv
	}
	return v,true
}
func (this *dbPlayerMailColumn)SetChests(id int32,v []int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetChests")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.Chests = make([]int32, len(v))
	for _ii, _vv := range v {
		d.Chests[_ii]=_vv
	}
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetChestNums(id int32)(v []int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetChestNums")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = make([]int32, len(d.ChestNums))
	for _ii, _vv := range d.ChestNums {
		v[_ii]=_vv
	}
	return v,true
}
func (this *dbPlayerMailColumn)SetChestNums(id int32,v []int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetChestNums")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.ChestNums = make([]int32, len(v))
	for _ii, _vv := range v {
		d.ChestNums[_ii]=_vv
	}
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetOverUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetOverUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.OverUnix
	return v,true
}
func (this *dbPlayerMailColumn)SetOverUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetOverUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OverUnix = v
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetMailType(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetMailType")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = int32(d.MailType)
	return v,true
}
func (this *dbPlayerMailColumn)SetMailType(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetMailType")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MailType = int8(v)
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetReadState(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetReadState")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = int32(d.ReadState)
	return v,true
}
func (this *dbPlayerMailColumn)SetReadState(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetReadState")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.ReadState = int8(v)
	this.m_changed = true
	return true
}
func (this *dbPlayerMailColumn)GetSenderId(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerMailColumn.GetSenderId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.SenderId
	return v,true
}
func (this *dbPlayerMailColumn)SetSenderId(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerMailColumn.SetSenderId")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.SenderId = v
	this.m_changed = true
	return true
}
type dbPlayerPayBackColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerPayBackData
	m_changed bool
}
func (this *dbPlayerPayBackColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerPayBackList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerPayBackData{}
		d.from_pb(v)
		this.m_data[int32(d.PayBackId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerPayBackColumn)save( )(data []byte,err error){
	pb := &db.PlayerPayBackList{}
	pb.List=make([]*db.PlayerPayBack,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerPayBackColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerPayBackColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerPayBackColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerPayBackColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerPayBackColumn)GetAll()(list []dbPlayerPayBackData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerPayBackColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerPayBackData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerPayBackColumn)Get(id int32)(v *dbPlayerPayBackData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerPayBackColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerPayBackData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerPayBackColumn)Set(v dbPlayerPayBackData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerPayBackColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.PayBackId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.PayBackId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerPayBackColumn)Add(v *dbPlayerPayBackData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerPayBackColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.PayBackId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.PayBackId)
		return false
	}
	d:=&dbPlayerPayBackData{}
	v.clone_to(d)
	this.m_data[int32(v.PayBackId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerPayBackColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerPayBackColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerPayBackColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerPayBackColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerPayBackData)
	this.m_changed = true
	return
}
func (this *dbPlayerPayBackColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerPayBackColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerPayBackColumn)GetValue(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerPayBackColumn.GetValue")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.Value
	return v,true
}
func (this *dbPlayerPayBackColumn)SetValue(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerPayBackColumn.SetValue")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.Value = v
	this.m_changed = true
	return true
}
type dbPlayerOptionsColumn struct{
	m_row *dbPlayerRow
	m_data *dbPlayerOptionsData
	m_changed bool
}
func (this *dbPlayerOptionsColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbPlayerOptionsData{}
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerOptions{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_data = &dbPlayerOptionsData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbPlayerOptionsColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerOptionsColumn)Get( )(v *dbPlayerOptionsData ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerOptionsColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbPlayerOptionsData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbPlayerOptionsColumn)Set(v dbPlayerOptionsData ){
	this.m_row.m_lock.UnSafeLock("dbPlayerOptionsColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbPlayerOptionsData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbPlayerOptionsColumn)GetValues( )(v []int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerOptionsColumn.GetValues")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]int32, len(this.m_data.Values))
	for _ii, _vv := range this.m_data.Values {
		v[_ii]=_vv
	}
	return
}
func (this *dbPlayerOptionsColumn)SetValues(v []int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerOptionsColumn.SetValues")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Values = make([]int32, len(v))
	for _ii, _vv := range v {
		this.m_data.Values[_ii]=_vv
	}
	this.m_changed = true
	return
}
type dbPlayerFightRecordColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerFightRecordData
	m_changed bool
}
func (this *dbPlayerFightRecordColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerFightRecordList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerFightRecordData{}
		d.from_pb(v)
		this.m_data[int32(d.RecordId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerFightRecordColumn)save( )(data []byte,err error){
	pb := &db.PlayerFightRecordList{}
	pb.List=make([]*db.PlayerFightRecord,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerFightRecordColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerFightRecordColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerFightRecordColumn)GetAll()(list []dbPlayerFightRecordData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerFightRecordData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerFightRecordColumn)Get(id int32)(v *dbPlayerFightRecordData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerFightRecordData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerFightRecordColumn)Set(v dbPlayerFightRecordData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.RecordId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.RecordId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)Add(v *dbPlayerFightRecordData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.RecordId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.RecordId)
		return false
	}
	d:=&dbPlayerFightRecordData{}
	v.clone_to(d)
	this.m_data[int32(v.RecordId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerFightRecordColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerFightRecordData)
	this.m_changed = true
	return
}
func (this *dbPlayerFightRecordColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerFightRecordColumn)GetMyCards(id int32)(v []int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetMyCards")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = make([]int32, len(d.MyCards))
	for _ii, _vv := range d.MyCards {
		v[_ii]=_vv
	}
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetMyCards(id int32,v []int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetMyCards")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MyCards = make([]int32, len(v))
	for _ii, _vv := range v {
		d.MyCards[_ii]=_vv
	}
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetMyCardLvls(id int32)(v []int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetMyCardLvls")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = make([]int32, len(d.MyCardLvls))
	for _ii, _vv := range d.MyCardLvls {
		v[_ii]=_vv
	}
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetMyCardLvls(id int32,v []int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetMyCardLvls")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MyCardLvls = make([]int32, len(v))
	for _ii, _vv := range v {
		d.MyCardLvls[_ii]=_vv
	}
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetOptCards(id int32)(v []int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetOptCards")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = make([]int32, len(d.OptCards))
	for _ii, _vv := range d.OptCards {
		v[_ii]=_vv
	}
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetOptCards(id int32,v []int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetOptCards")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OptCards = make([]int32, len(v))
	for _ii, _vv := range v {
		d.OptCards[_ii]=_vv
	}
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetOptCardLvls(id int32)(v []int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetOptCardLvls")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = make([]int32, len(d.OptCardLvls))
	for _ii, _vv := range d.OptCardLvls {
		v[_ii]=_vv
	}
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetOptCardLvls(id int32,v []int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetOptCardLvls")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OptCardLvls = make([]int32, len(v))
	for _ii, _vv := range v {
		d.OptCardLvls[_ii]=_vv
	}
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetWinnerId(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetWinnerId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.WinnerId
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetWinnerId(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetWinnerId")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.WinnerId = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetMyTongId(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetMyTongId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MyTongId
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetMyTongId(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetMyTongId")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MyTongId = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetOptTongId(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetOptTongId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.OptTongId
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetOptTongId(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetOptTongId")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OptTongId = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetOptPlayerId(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetOptPlayerId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.OptPlayerId
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetOptPlayerId(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetOptPlayerId")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OptPlayerId = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetMyPlayerName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetMyPlayerName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MyPlayerName
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetMyPlayerName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetMyPlayerName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MyPlayerName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetOptPlayerName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetOptPlayerName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.OptPlayerName
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetOptPlayerName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetOptPlayerName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OptPlayerName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetMyTongName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetMyTongName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MyTongName
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetMyTongName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetMyTongName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MyTongName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetOptTongName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetOptTongName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.OptTongName
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetOptTongName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetOptTongName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OptTongName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetMyTongIcon(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetMyTongIcon")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MyTongIcon
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetMyTongIcon(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetMyTongIcon")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MyTongIcon = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetOpTongIcon(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetOpTongIcon")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.OpTongIcon
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetOpTongIcon(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetOpTongIcon")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OpTongIcon = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetCreateUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetCreateUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.CreateUnix
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetCreateUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetCreateUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.CreateUnix = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetMatchType(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetMatchType")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MatchType
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetMatchType(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetMatchType")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MatchType = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetMyTowers(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetMyTowers")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MyTowers
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetMyTowers(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetMyTowers")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MyTowers = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetOpTowers(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetOpTowers")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.OpTowers
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetOpTowers(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetOpTowers")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OpTowers = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetMyMathScore(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetMyMathScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MyMathScore
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetMyMathScore(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetMyMathScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MyMathScore = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetOpMathScore(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetOpMathScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.OpMathScore
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetOpMathScore(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetOpMathScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.OpMathScore = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFightRecordColumn)GetMyMathScoreChg(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFightRecordColumn.GetMyMathScoreChg")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MyMathScoreChg
	return v,true
}
func (this *dbPlayerFightRecordColumn)SetMyMathScoreChg(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFightRecordColumn.SetMyMathScoreChg")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MyMathScoreChg = v
	this.m_changed = true
	return true
}
type dbPlayerDialyTaskColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerDialyTaskData
	m_changed bool
}
func (this *dbPlayerDialyTaskColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerDialyTaskList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerDialyTaskData{}
		d.from_pb(v)
		this.m_data[int32(d.TaskId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerDialyTaskColumn)save( )(data []byte,err error){
	pb := &db.PlayerDialyTaskList{}
	pb.List=make([]*db.PlayerDialyTask,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerDialyTaskColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerDialyTaskColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerDialyTaskColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerDialyTaskColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerDialyTaskColumn)GetAll()(list []dbPlayerDialyTaskData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerDialyTaskColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerDialyTaskData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerDialyTaskColumn)Get(id int32)(v *dbPlayerDialyTaskData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerDialyTaskColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerDialyTaskData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerDialyTaskColumn)Set(v dbPlayerDialyTaskData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerDialyTaskColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.TaskId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.TaskId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerDialyTaskColumn)Add(v *dbPlayerDialyTaskData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerDialyTaskColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.TaskId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.TaskId)
		return false
	}
	d:=&dbPlayerDialyTaskData{}
	v.clone_to(d)
	this.m_data[int32(v.TaskId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerDialyTaskColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerDialyTaskColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerDialyTaskColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerDialyTaskColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerDialyTaskData)
	this.m_changed = true
	return
}
func (this *dbPlayerDialyTaskColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerDialyTaskColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerDialyTaskColumn)GetValue(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerDialyTaskColumn.GetValue")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.Value
	return v,true
}
func (this *dbPlayerDialyTaskColumn)SetValue(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerDialyTaskColumn.SetValue")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.Value = v
	this.m_changed = true
	return true
}
func (this *dbPlayerDialyTaskColumn)IncbyValue(id int32,v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerDialyTaskColumn.IncbyValue")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		d = &dbPlayerDialyTaskData{}
		this.m_data[id] = d
	}
	d.Value +=  v
	this.m_changed = true
	return d.Value
}
func (this *dbPlayerDialyTaskColumn)GetRewardUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerDialyTaskColumn.GetRewardUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.RewardUnix
	return v,true
}
func (this *dbPlayerDialyTaskColumn)SetRewardUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerDialyTaskColumn.SetRewardUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.RewardUnix = v
	this.m_changed = true
	return true
}
type dbPlayerAchieveColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerAchieveData
	m_changed bool
}
func (this *dbPlayerAchieveColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerAchieveList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerAchieveData{}
		d.from_pb(v)
		this.m_data[int32(d.AchieveId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerAchieveColumn)save( )(data []byte,err error){
	pb := &db.PlayerAchieveList{}
	pb.List=make([]*db.PlayerAchieve,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerAchieveColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerAchieveColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerAchieveColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerAchieveColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerAchieveColumn)GetAll()(list []dbPlayerAchieveData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerAchieveColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerAchieveData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerAchieveColumn)Get(id int32)(v *dbPlayerAchieveData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerAchieveColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerAchieveData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerAchieveColumn)Set(v dbPlayerAchieveData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerAchieveColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.AchieveId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.AchieveId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerAchieveColumn)Add(v *dbPlayerAchieveData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerAchieveColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.AchieveId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.AchieveId)
		return false
	}
	d:=&dbPlayerAchieveData{}
	v.clone_to(d)
	this.m_data[int32(v.AchieveId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerAchieveColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerAchieveColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerAchieveColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerAchieveColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerAchieveData)
	this.m_changed = true
	return
}
func (this *dbPlayerAchieveColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerAchieveColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerAchieveColumn)GetValue(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerAchieveColumn.GetValue")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.Value
	return v,true
}
func (this *dbPlayerAchieveColumn)SetValue(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerAchieveColumn.SetValue")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.Value = v
	this.m_changed = true
	return true
}
func (this *dbPlayerAchieveColumn)IncbyValue(id int32,v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerAchieveColumn.IncbyValue")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		d = &dbPlayerAchieveData{}
		this.m_data[id] = d
	}
	d.Value +=  v
	this.m_changed = true
	return d.Value
}
func (this *dbPlayerAchieveColumn)GetRewardUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerAchieveColumn.GetRewardUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.RewardUnix
	return v,true
}
func (this *dbPlayerAchieveColumn)SetRewardUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerAchieveColumn.SetRewardUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.RewardUnix = v
	this.m_changed = true
	return true
}
type dbPlayerSevenActivityColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerSevenActivityData
	m_changed bool
}
func (this *dbPlayerSevenActivityColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerSevenActivityList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerSevenActivityData{}
		d.from_pb(v)
		this.m_data[int32(d.ActivityId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerSevenActivityColumn)save( )(data []byte,err error){
	pb := &db.PlayerSevenActivityList{}
	pb.List=make([]*db.PlayerSevenActivity,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerSevenActivityColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSevenActivityColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerSevenActivityColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSevenActivityColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerSevenActivityColumn)GetAll()(list []dbPlayerSevenActivityData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSevenActivityColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerSevenActivityData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerSevenActivityColumn)Get(id int32)(v *dbPlayerSevenActivityData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSevenActivityColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerSevenActivityData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerSevenActivityColumn)Set(v dbPlayerSevenActivityData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerSevenActivityColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.ActivityId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.ActivityId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerSevenActivityColumn)Add(v *dbPlayerSevenActivityData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerSevenActivityColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.ActivityId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.ActivityId)
		return false
	}
	d:=&dbPlayerSevenActivityData{}
	v.clone_to(d)
	this.m_data[int32(v.ActivityId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerSevenActivityColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerSevenActivityColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerSevenActivityColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerSevenActivityColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerSevenActivityData)
	this.m_changed = true
	return
}
func (this *dbPlayerSevenActivityColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSevenActivityColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerSevenActivityColumn)GetValue(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSevenActivityColumn.GetValue")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.Value
	return v,true
}
func (this *dbPlayerSevenActivityColumn)SetValue(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerSevenActivityColumn.SetValue")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.Value = v
	this.m_changed = true
	return true
}
func (this *dbPlayerSevenActivityColumn)IncbyValue(id int32,v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerSevenActivityColumn.IncbyValue")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		d = &dbPlayerSevenActivityData{}
		this.m_data[id] = d
	}
	d.Value +=  v
	this.m_changed = true
	return d.Value
}
func (this *dbPlayerSevenActivityColumn)GetRewardUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSevenActivityColumn.GetRewardUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.RewardUnix
	return v,true
}
func (this *dbPlayerSevenActivityColumn)SetRewardUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerSevenActivityColumn.SetRewardUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.RewardUnix = v
	this.m_changed = true
	return true
}
type dbPlayerTowerAndFreeChestColumn struct{
	m_row *dbPlayerRow
	m_data *dbPlayerTowerAndFreeChestData
	m_changed bool
}
func (this *dbPlayerTowerAndFreeChestColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbPlayerTowerAndFreeChestData{}
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerTowerAndFreeChest{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_data = &dbPlayerTowerAndFreeChestData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)Get( )(v *dbPlayerTowerAndFreeChestData ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTowerAndFreeChestColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbPlayerTowerAndFreeChestData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)Set(v dbPlayerTowerAndFreeChestData ){
	this.m_row.m_lock.UnSafeLock("dbPlayerTowerAndFreeChestColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbPlayerTowerAndFreeChestData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)GetLastFreeChestUpUnix( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTowerAndFreeChestColumn.GetLastFreeChestUpUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastFreeChestUpUnix
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)SetLastFreeChestUpUnix(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTowerAndFreeChestColumn.SetLastFreeChestUpUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastFreeChestUpUnix = v
	this.m_changed = true
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)GetCurFreeChestNum( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTowerAndFreeChestColumn.GetCurFreeChestNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurFreeChestNum
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)SetCurFreeChestNum(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTowerAndFreeChestColumn.SetCurFreeChestNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurFreeChestNum = v
	this.m_changed = true
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)GetCurTowerChestNum( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTowerAndFreeChestColumn.GetCurTowerChestNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.CurTowerChestNum)
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)SetCurTowerChestNum(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTowerAndFreeChestColumn.SetCurTowerChestNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurTowerChestNum = int8(v)
	this.m_changed = true
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)IncbyCurTowerChestNum(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTowerAndFreeChestColumn.IncbyCurTowerChestNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurTowerChestNum += int8(v)
	this.m_changed = true
	return int32(this.m_data.CurTowerChestNum)
}
func (this *dbPlayerTowerAndFreeChestColumn)GetCurChestTowerNum( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTowerAndFreeChestColumn.GetCurChestTowerNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.CurChestTowerNum)
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)SetCurChestTowerNum(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTowerAndFreeChestColumn.SetCurChestTowerNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurChestTowerNum = int8(v)
	this.m_changed = true
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)IncbyCurChestTowerNum(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTowerAndFreeChestColumn.IncbyCurChestTowerNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurChestTowerNum += int8(v)
	this.m_changed = true
	return int32(this.m_data.CurChestTowerNum)
}
func (this *dbPlayerTowerAndFreeChestColumn)GetLastTowerChestUpUnix( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTowerAndFreeChestColumn.GetLastTowerChestUpUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastTowerChestUpUnix
	return
}
func (this *dbPlayerTowerAndFreeChestColumn)SetLastTowerChestUpUnix(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTowerAndFreeChestColumn.SetLastTowerChestUpUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastTowerChestUpUnix = v
	this.m_changed = true
	return
}
type dbPlayerTodayCardCompoundColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerTodayCardCompoundData
	m_changed bool
}
func (this *dbPlayerTodayCardCompoundColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerTodayCardCompoundList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerTodayCardCompoundData{}
		d.from_pb(v)
		this.m_data[int32(d.CardCfgId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerTodayCardCompoundColumn)save( )(data []byte,err error){
	pb := &db.PlayerTodayCardCompoundList{}
	pb.List=make([]*db.PlayerTodayCardCompound,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerTodayCardCompoundColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTodayCardCompoundColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerTodayCardCompoundColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTodayCardCompoundColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerTodayCardCompoundColumn)GetAll()(list []dbPlayerTodayCardCompoundData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTodayCardCompoundColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerTodayCardCompoundData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerTodayCardCompoundColumn)Get(id int32)(v *dbPlayerTodayCardCompoundData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTodayCardCompoundColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerTodayCardCompoundData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerTodayCardCompoundColumn)Set(v dbPlayerTodayCardCompoundData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerTodayCardCompoundColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.CardCfgId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.CardCfgId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerTodayCardCompoundColumn)Add(v *dbPlayerTodayCardCompoundData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerTodayCardCompoundColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.CardCfgId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.CardCfgId)
		return false
	}
	d:=&dbPlayerTodayCardCompoundData{}
	v.clone_to(d)
	this.m_data[int32(v.CardCfgId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerTodayCardCompoundColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTodayCardCompoundColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerTodayCardCompoundColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerTodayCardCompoundColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerTodayCardCompoundData)
	this.m_changed = true
	return
}
func (this *dbPlayerTodayCardCompoundColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTodayCardCompoundColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerTodayCardCompoundColumn)GetTodayCompoundNum(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerTodayCardCompoundColumn.GetTodayCompoundNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.TodayCompoundNum
	return v,true
}
func (this *dbPlayerTodayCardCompoundColumn)SetTodayCompoundNum(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerTodayCardCompoundColumn.SetTodayCompoundNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.TodayCompoundNum = v
	this.m_changed = true
	return true
}
func (this *dbPlayerTodayCardCompoundColumn)IncbyTodayCompoundNum(id int32,v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerTodayCardCompoundColumn.IncbyTodayCompoundNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		d = &dbPlayerTodayCardCompoundData{}
		this.m_data[id] = d
	}
	d.TodayCompoundNum +=  v
	this.m_changed = true
	return d.TodayCompoundNum
}
type dbPlayerCampFightInfoColumn struct{
	m_row *dbPlayerRow
	m_data *dbPlayerCampFightInfoData
	m_changed bool
}
func (this *dbPlayerCampFightInfoColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbPlayerCampFightInfoData{}
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerCampFightInfo{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_data = &dbPlayerCampFightInfoData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbPlayerCampFightInfoColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerCampFightInfoColumn)Get( )(v *dbPlayerCampFightInfoData ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCampFightInfoColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbPlayerCampFightInfoData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbPlayerCampFightInfoColumn)Set(v dbPlayerCampFightInfoData ){
	this.m_row.m_lock.UnSafeLock("dbPlayerCampFightInfoColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbPlayerCampFightInfoData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbPlayerCampFightInfoColumn)GetEnterISOWeek( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCampFightInfoColumn.GetEnterISOWeek")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.EnterISOWeek
	return
}
func (this *dbPlayerCampFightInfoColumn)SetEnterISOWeek(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerCampFightInfoColumn.SetEnterISOWeek")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.EnterISOWeek = v
	this.m_changed = true
	return
}
func (this *dbPlayerCampFightInfoColumn)GetEnterArenaLvl( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCampFightInfoColumn.GetEnterArenaLvl")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.EnterArenaLvl
	return
}
func (this *dbPlayerCampFightInfoColumn)SetEnterArenaLvl(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerCampFightInfoColumn.SetEnterArenaLvl")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.EnterArenaLvl = v
	this.m_changed = true
	return
}
func (this *dbPlayerCampFightInfoColumn)GetCurScore( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCampFightInfoColumn.GetCurScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurScore
	return
}
func (this *dbPlayerCampFightInfoColumn)SetCurScore(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerCampFightInfoColumn.SetCurScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurScore = v
	this.m_changed = true
	return
}
func (this *dbPlayerCampFightInfoColumn)IncbyCurScore(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerCampFightInfoColumn.IncbyCurScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurScore += v
	this.m_changed = true
	return this.m_data.CurScore
}
func (this *dbPlayerCampFightInfoColumn)GetLastRewardISOWeek( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerCampFightInfoColumn.GetLastRewardISOWeek")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastRewardISOWeek
	return
}
func (this *dbPlayerCampFightInfoColumn)SetLastRewardISOWeek(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerCampFightInfoColumn.SetLastRewardISOWeek")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastRewardISOWeek = v
	this.m_changed = true
	return
}
type dbPlayerSignInfoColumn struct{
	m_row *dbPlayerRow
	m_data *dbPlayerSignInfoData
	m_changed bool
}
func (this *dbPlayerSignInfoColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbPlayerSignInfoData{}
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerSignInfo{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_data = &dbPlayerSignInfoData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbPlayerSignInfoColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerSignInfoColumn)Get( )(v *dbPlayerSignInfoData ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSignInfoColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbPlayerSignInfoData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbPlayerSignInfoColumn)Set(v dbPlayerSignInfoData ){
	this.m_row.m_lock.UnSafeLock("dbPlayerSignInfoColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbPlayerSignInfoData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbPlayerSignInfoColumn)GetLastSignDay( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSignInfoColumn.GetLastSignDay")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastSignDay
	return
}
func (this *dbPlayerSignInfoColumn)SetLastSignDay(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerSignInfoColumn.SetLastSignDay")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastSignDay = v
	this.m_changed = true
	return
}
func (this *dbPlayerSignInfoColumn)GetCurSignSum( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSignInfoColumn.GetCurSignSum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurSignSum
	return
}
func (this *dbPlayerSignInfoColumn)SetCurSignSum(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerSignInfoColumn.SetCurSignSum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurSignSum = v
	this.m_changed = true
	return
}
func (this *dbPlayerSignInfoColumn)IncbyCurSignSum(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerSignInfoColumn.IncbyCurSignSum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurSignSum += v
	this.m_changed = true
	return this.m_data.CurSignSum
}
func (this *dbPlayerSignInfoColumn)GetCurSignSumMonth( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSignInfoColumn.GetCurSignSumMonth")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CurSignSumMonth
	return
}
func (this *dbPlayerSignInfoColumn)SetCurSignSumMonth(v int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerSignInfoColumn.SetCurSignSumMonth")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurSignSumMonth = v
	this.m_changed = true
	return
}
func (this *dbPlayerSignInfoColumn)GetCurSignDays( )(v []int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSignInfoColumn.GetCurSignDays")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]int32, len(this.m_data.CurSignDays))
	for _ii, _vv := range this.m_data.CurSignDays {
		v[_ii]=_vv
	}
	return
}
func (this *dbPlayerSignInfoColumn)SetCurSignDays(v []int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerSignInfoColumn.SetCurSignDays")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CurSignDays = make([]int32, len(v))
	for _ii, _vv := range v {
		this.m_data.CurSignDays[_ii]=_vv
	}
	this.m_changed = true
	return
}
func (this *dbPlayerSignInfoColumn)GetRewardSignSum( )(v []int32 ){
	this.m_row.m_lock.UnSafeRLock("dbPlayerSignInfoColumn.GetRewardSignSum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = make([]int32, len(this.m_data.RewardSignSum))
	for _ii, _vv := range this.m_data.RewardSignSum {
		v[_ii]=_vv
	}
	return
}
func (this *dbPlayerSignInfoColumn)SetRewardSignSum(v []int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerSignInfoColumn.SetRewardSignSum")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.RewardSignSum = make([]int32, len(v))
	for _ii, _vv := range v {
		this.m_data.RewardSignSum[_ii]=_vv
	}
	this.m_changed = true
	return
}
type dbPlayerGuidesColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerGuidesData
	m_changed bool
}
func (this *dbPlayerGuidesColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerGuidesList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerGuidesData{}
		d.from_pb(v)
		this.m_data[int32(d.GuideId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerGuidesColumn)save( )(data []byte,err error){
	pb := &db.PlayerGuidesList{}
	pb.List=make([]*db.PlayerGuides,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerGuidesColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerGuidesColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerGuidesColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerGuidesColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerGuidesColumn)GetAll()(list []dbPlayerGuidesData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerGuidesColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerGuidesData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerGuidesColumn)Get(id int32)(v *dbPlayerGuidesData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerGuidesColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerGuidesData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerGuidesColumn)Set(v dbPlayerGuidesData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerGuidesColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.GuideId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.GuideId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerGuidesColumn)Add(v *dbPlayerGuidesData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerGuidesColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.GuideId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.GuideId)
		return false
	}
	d:=&dbPlayerGuidesData{}
	v.clone_to(d)
	this.m_data[int32(v.GuideId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerGuidesColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerGuidesColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerGuidesColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerGuidesColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerGuidesData)
	this.m_changed = true
	return
}
func (this *dbPlayerGuidesColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerGuidesColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerGuidesColumn)GetSetUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerGuidesColumn.GetSetUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.SetUnix
	return v,true
}
func (this *dbPlayerGuidesColumn)SetSetUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerGuidesColumn.SetSetUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.SetUnix = v
	this.m_changed = true
	return true
}
type dbPlayerFriendColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerFriendData
	m_changed bool
}
func (this *dbPlayerFriendColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerFriendList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerFriendData{}
		d.from_pb(v)
		this.m_data[int32(d.FriendPId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerFriendColumn)save( )(data []byte,err error){
	pb := &db.PlayerFriendList{}
	pb.List=make([]*db.PlayerFriend,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerFriendColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerFriendColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerFriendColumn)GetAll()(list []dbPlayerFriendData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerFriendData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerFriendColumn)Get(id int32)(v *dbPlayerFriendData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerFriendData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerFriendColumn)Set(v dbPlayerFriendData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.FriendPId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.FriendPId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendColumn)Add(v *dbPlayerFriendData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.FriendPId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.FriendPId)
		return false
	}
	d:=&dbPlayerFriendData{}
	v.clone_to(d)
	this.m_data[int32(v.FriendPId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerFriendColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerFriendData)
	this.m_changed = true
	return
}
func (this *dbPlayerFriendColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerFriendColumn)GetFriendName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.GetFriendName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.FriendName
	return v,true
}
func (this *dbPlayerFriendColumn)SetFriendName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendColumn.SetFriendName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.FriendName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendColumn)GetMatchScore(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.GetMatchScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MatchScore
	return v,true
}
func (this *dbPlayerFriendColumn)SetMatchScore(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendColumn.SetMatchScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MatchScore = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendColumn)GetTongIcon(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.GetTongIcon")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.TongIcon
	return v,true
}
func (this *dbPlayerFriendColumn)SetTongIcon(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendColumn.SetTongIcon")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.TongIcon = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendColumn)GetTongName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendColumn.GetTongName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.TongName
	return v,true
}
func (this *dbPlayerFriendColumn)SetTongName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendColumn.SetTongName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.TongName = v
	this.m_changed = true
	return true
}
type dbPlayerFriendReqColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerFriendReqData
	m_changed bool
}
func (this *dbPlayerFriendReqColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerFriendReqList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerFriendReqData{}
		d.from_pb(v)
		this.m_data[int32(d.FriendPId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerFriendReqColumn)save( )(data []byte,err error){
	pb := &db.PlayerFriendReqList{}
	pb.List=make([]*db.PlayerFriendReq,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerFriendReqColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerFriendReqColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerFriendReqColumn)GetAll()(list []dbPlayerFriendReqData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerFriendReqData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerFriendReqColumn)Get(id int32)(v *dbPlayerFriendReqData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerFriendReqData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerFriendReqColumn)Set(v dbPlayerFriendReqData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendReqColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.FriendPId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.FriendPId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendReqColumn)Add(v *dbPlayerFriendReqData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendReqColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.FriendPId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.FriendPId)
		return false
	}
	d:=&dbPlayerFriendReqData{}
	v.clone_to(d)
	this.m_data[int32(v.FriendPId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendReqColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendReqColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerFriendReqColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendReqColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerFriendReqData)
	this.m_changed = true
	return
}
func (this *dbPlayerFriendReqColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerFriendReqColumn)GetFriendName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.GetFriendName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.FriendName
	return v,true
}
func (this *dbPlayerFriendReqColumn)SetFriendName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendReqColumn.SetFriendName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.FriendName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendReqColumn)GetMatchScore(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.GetMatchScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MatchScore
	return v,true
}
func (this *dbPlayerFriendReqColumn)SetMatchScore(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendReqColumn.SetMatchScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MatchScore = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendReqColumn)GetTongIcon(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.GetTongIcon")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.TongIcon
	return v,true
}
func (this *dbPlayerFriendReqColumn)SetTongIcon(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendReqColumn.SetTongIcon")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.TongIcon = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendReqColumn)GetTongName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.GetTongName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.TongName
	return v,true
}
func (this *dbPlayerFriendReqColumn)SetTongName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendReqColumn.SetTongName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.TongName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFriendReqColumn)GetReqUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFriendReqColumn.GetReqUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.ReqUnix
	return v,true
}
func (this *dbPlayerFriendReqColumn)SetReqUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFriendReqColumn.SetReqUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.ReqUnix = v
	this.m_changed = true
	return true
}
type dbPlayerFocusPlayerColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerFocusPlayerData
	m_changed bool
}
func (this *dbPlayerFocusPlayerColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerFocusPlayerList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerFocusPlayerData{}
		d.from_pb(v)
		this.m_data[int32(d.FriendPId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerFocusPlayerColumn)save( )(data []byte,err error){
	pb := &db.PlayerFocusPlayerList{}
	pb.List=make([]*db.PlayerFocusPlayer,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerFocusPlayerColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerFocusPlayerColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerFocusPlayerColumn)GetAll()(list []dbPlayerFocusPlayerData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerFocusPlayerData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerFocusPlayerColumn)Get(id int32)(v *dbPlayerFocusPlayerData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerFocusPlayerData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerFocusPlayerColumn)Set(v dbPlayerFocusPlayerData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFocusPlayerColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.FriendPId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.FriendPId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerFocusPlayerColumn)Add(v *dbPlayerFocusPlayerData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFocusPlayerColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.FriendPId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.FriendPId)
		return false
	}
	d:=&dbPlayerFocusPlayerData{}
	v.clone_to(d)
	this.m_data[int32(v.FriendPId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerFocusPlayerColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerFocusPlayerColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerFocusPlayerColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerFocusPlayerColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerFocusPlayerData)
	this.m_changed = true
	return
}
func (this *dbPlayerFocusPlayerColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerFocusPlayerColumn)GetFriendName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.GetFriendName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.FriendName
	return v,true
}
func (this *dbPlayerFocusPlayerColumn)SetFriendName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFocusPlayerColumn.SetFriendName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.FriendName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFocusPlayerColumn)GetMatchScore(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.GetMatchScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MatchScore
	return v,true
}
func (this *dbPlayerFocusPlayerColumn)SetMatchScore(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFocusPlayerColumn.SetMatchScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MatchScore = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFocusPlayerColumn)GetTongIcon(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.GetTongIcon")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.TongIcon
	return v,true
}
func (this *dbPlayerFocusPlayerColumn)SetTongIcon(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFocusPlayerColumn.SetTongIcon")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.TongIcon = v
	this.m_changed = true
	return true
}
func (this *dbPlayerFocusPlayerColumn)GetTongName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerFocusPlayerColumn.GetTongName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.TongName
	return v,true
}
func (this *dbPlayerFocusPlayerColumn)SetTongName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerFocusPlayerColumn.SetTongName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.TongName = v
	this.m_changed = true
	return true
}
type dbPlayerBeFocusPlayerColumn struct{
	m_row *dbPlayerRow
	m_data map[int32]*dbPlayerBeFocusPlayerData
	m_changed bool
}
func (this *dbPlayerBeFocusPlayerColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.PlayerBeFocusPlayerList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetPlayerId())
		return
	}
	for _, v := range pb.List {
		d := &dbPlayerBeFocusPlayerData{}
		d.from_pb(v)
		this.m_data[int32(d.FriendPId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbPlayerBeFocusPlayerColumn)save( )(data []byte,err error){
	pb := &db.PlayerBeFocusPlayerList{}
	pb.List=make([]*db.PlayerBeFocusPlayer,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetPlayerId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbPlayerBeFocusPlayerColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeFocusPlayerColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbPlayerBeFocusPlayerColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeFocusPlayerColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbPlayerBeFocusPlayerColumn)GetAll()(list []dbPlayerBeFocusPlayerData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeFocusPlayerColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbPlayerBeFocusPlayerData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbPlayerBeFocusPlayerColumn)Get(id int32)(v *dbPlayerBeFocusPlayerData){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeFocusPlayerColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbPlayerBeFocusPlayerData{}
	d.clone_to(v)
	return
}
func (this *dbPlayerBeFocusPlayerColumn)Set(v dbPlayerBeFocusPlayerData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeFocusPlayerColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.FriendPId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), v.FriendPId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbPlayerBeFocusPlayerColumn)Add(v *dbPlayerBeFocusPlayerData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeFocusPlayerColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.FriendPId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetPlayerId(), v.FriendPId)
		return false
	}
	d:=&dbPlayerBeFocusPlayerData{}
	v.clone_to(d)
	this.m_data[int32(v.FriendPId)]=d
	this.m_changed = true
	return true
}
func (this *dbPlayerBeFocusPlayerColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeFocusPlayerColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbPlayerBeFocusPlayerColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeFocusPlayerColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbPlayerBeFocusPlayerData)
	this.m_changed = true
	return
}
func (this *dbPlayerBeFocusPlayerColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeFocusPlayerColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbPlayerBeFocusPlayerColumn)GetFriendName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeFocusPlayerColumn.GetFriendName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.FriendName
	return v,true
}
func (this *dbPlayerBeFocusPlayerColumn)SetFriendName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeFocusPlayerColumn.SetFriendName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.FriendName = v
	this.m_changed = true
	return true
}
func (this *dbPlayerBeFocusPlayerColumn)GetMatchScore(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeFocusPlayerColumn.GetMatchScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MatchScore
	return v,true
}
func (this *dbPlayerBeFocusPlayerColumn)SetMatchScore(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeFocusPlayerColumn.SetMatchScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.MatchScore = v
	this.m_changed = true
	return true
}
func (this *dbPlayerBeFocusPlayerColumn)GetTongIcon(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeFocusPlayerColumn.GetTongIcon")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.TongIcon
	return v,true
}
func (this *dbPlayerBeFocusPlayerColumn)SetTongIcon(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeFocusPlayerColumn.SetTongIcon")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.TongIcon = v
	this.m_changed = true
	return true
}
func (this *dbPlayerBeFocusPlayerColumn)GetTongName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbPlayerBeFocusPlayerColumn.GetTongName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.TongName
	return v,true
}
func (this *dbPlayerBeFocusPlayerColumn)SetTongName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbPlayerBeFocusPlayerColumn.SetTongName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetPlayerId(), id)
		return
	}
	d.TongName = v
	this.m_changed = true
	return true
}
type dbPlayerRow struct {
	m_table *dbPlayerTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_PlayerId        int32
	m_Account_changed bool
	m_Account string
	m_Name_changed bool
	m_Name string
	Info dbPlayerInfoColumn
	TongInfo dbPlayerTongInfoColumn
	TongDonates dbPlayerTongDonateColumn
	BeTongDonates dbPlayerBeTongDonateColumn
	Cards dbPlayerCardColumn
	CardTeams dbPlayerCardTeamColumn
	ShopLattices dbPlayerShopLatticeColumn
	Chests dbPlayerChestColumn
	Mails dbPlayerMailColumn
	PayBacks dbPlayerPayBackColumn
	Options dbPlayerOptionsColumn
	FightRecords dbPlayerFightRecordColumn
	DialyTasks dbPlayerDialyTaskColumn
	Achieves dbPlayerAchieveColumn
	SevenActivitys dbPlayerSevenActivityColumn
	TowerAndFreeChest dbPlayerTowerAndFreeChestColumn
	TodayCardCompounds dbPlayerTodayCardCompoundColumn
	CampFightInfo dbPlayerCampFightInfoColumn
	SignInfo dbPlayerSignInfoColumn
	Guidess dbPlayerGuidesColumn
	Friends dbPlayerFriendColumn
	FriendReqs dbPlayerFriendReqColumn
	FocusPlayers dbPlayerFocusPlayerColumn
	BeFocusPlayers dbPlayerBeFocusPlayerColumn
}
func new_dbPlayerRow(table *dbPlayerTable, PlayerId int32) (r *dbPlayerRow) {
	this := &dbPlayerRow{}
	this.m_table = table
	this.m_PlayerId = PlayerId
	this.m_lock = NewRWMutex()
	this.m_Account_changed=true
	this.m_Name_changed=true
	this.Info.m_row=this
	this.Info.m_data=&dbPlayerInfoData{}
	this.TongInfo.m_row=this
	this.TongInfo.m_data=&dbPlayerTongInfoData{}
	this.TongDonates.m_row=this
	this.TongDonates.m_data=make(map[int32]*dbPlayerTongDonateData)
	this.BeTongDonates.m_row=this
	this.BeTongDonates.m_data=make(map[int32]*dbPlayerBeTongDonateData)
	this.Cards.m_row=this
	this.Cards.m_data=make(map[int32]*dbPlayerCardData)
	this.CardTeams.m_row=this
	this.CardTeams.m_data=make(map[int32]*dbPlayerCardTeamData)
	this.ShopLattices.m_row=this
	this.ShopLattices.m_data=make(map[int32]*dbPlayerShopLatticeData)
	this.Chests.m_row=this
	this.Chests.m_data=make(map[int32]*dbPlayerChestData)
	this.Mails.m_row=this
	this.Mails.m_data=make(map[int32]*dbPlayerMailData)
	this.PayBacks.m_row=this
	this.PayBacks.m_data=make(map[int32]*dbPlayerPayBackData)
	this.Options.m_row=this
	this.Options.m_data=&dbPlayerOptionsData{}
	this.FightRecords.m_row=this
	this.FightRecords.m_data=make(map[int32]*dbPlayerFightRecordData)
	this.DialyTasks.m_row=this
	this.DialyTasks.m_data=make(map[int32]*dbPlayerDialyTaskData)
	this.Achieves.m_row=this
	this.Achieves.m_data=make(map[int32]*dbPlayerAchieveData)
	this.SevenActivitys.m_row=this
	this.SevenActivitys.m_data=make(map[int32]*dbPlayerSevenActivityData)
	this.TowerAndFreeChest.m_row=this
	this.TowerAndFreeChest.m_data=&dbPlayerTowerAndFreeChestData{}
	this.TodayCardCompounds.m_row=this
	this.TodayCardCompounds.m_data=make(map[int32]*dbPlayerTodayCardCompoundData)
	this.CampFightInfo.m_row=this
	this.CampFightInfo.m_data=&dbPlayerCampFightInfoData{}
	this.SignInfo.m_row=this
	this.SignInfo.m_data=&dbPlayerSignInfoData{}
	this.Guidess.m_row=this
	this.Guidess.m_data=make(map[int32]*dbPlayerGuidesData)
	this.Friends.m_row=this
	this.Friends.m_data=make(map[int32]*dbPlayerFriendData)
	this.FriendReqs.m_row=this
	this.FriendReqs.m_data=make(map[int32]*dbPlayerFriendReqData)
	this.FocusPlayers.m_row=this
	this.FocusPlayers.m_data=make(map[int32]*dbPlayerFocusPlayerData)
	this.BeFocusPlayers.m_row=this
	this.BeFocusPlayers.m_data=make(map[int32]*dbPlayerBeFocusPlayerData)
	return this
}
func (this *dbPlayerRow) GetPlayerId() (r int32) {
	return this.m_PlayerId
}
func (this *dbPlayerRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbPlayerRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(27)
		db_args.Push(this.m_PlayerId)
		db_args.Push(this.m_Account)
		db_args.Push(this.m_Name)
		dInfo,db_err:=this.Info.save()
		if db_err!=nil{
			log.Error("insert save Info failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dInfo)
		dTongInfo,db_err:=this.TongInfo.save()
		if db_err!=nil{
			log.Error("insert save TongInfo failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dTongInfo)
		dTongDonates,db_err:=this.TongDonates.save()
		if db_err!=nil{
			log.Error("insert save TongDonate failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dTongDonates)
		dBeTongDonates,db_err:=this.BeTongDonates.save()
		if db_err!=nil{
			log.Error("insert save BeTongDonate failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dBeTongDonates)
		dCards,db_err:=this.Cards.save()
		if db_err!=nil{
			log.Error("insert save Card failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dCards)
		dCardTeams,db_err:=this.CardTeams.save()
		if db_err!=nil{
			log.Error("insert save CardTeam failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dCardTeams)
		dShopLattices,db_err:=this.ShopLattices.save()
		if db_err!=nil{
			log.Error("insert save ShopLattice failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dShopLattices)
		dChests,db_err:=this.Chests.save()
		if db_err!=nil{
			log.Error("insert save Chest failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dChests)
		dMails,db_err:=this.Mails.save()
		if db_err!=nil{
			log.Error("insert save Mail failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dMails)
		dPayBacks,db_err:=this.PayBacks.save()
		if db_err!=nil{
			log.Error("insert save PayBack failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dPayBacks)
		dOptions,db_err:=this.Options.save()
		if db_err!=nil{
			log.Error("insert save Options failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dOptions)
		dFightRecords,db_err:=this.FightRecords.save()
		if db_err!=nil{
			log.Error("insert save FightRecord failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dFightRecords)
		dDialyTasks,db_err:=this.DialyTasks.save()
		if db_err!=nil{
			log.Error("insert save DialyTask failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dDialyTasks)
		dAchieves,db_err:=this.Achieves.save()
		if db_err!=nil{
			log.Error("insert save Achieve failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dAchieves)
		dSevenActivitys,db_err:=this.SevenActivitys.save()
		if db_err!=nil{
			log.Error("insert save SevenActivity failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dSevenActivitys)
		dTowerAndFreeChest,db_err:=this.TowerAndFreeChest.save()
		if db_err!=nil{
			log.Error("insert save TowerAndFreeChest failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dTowerAndFreeChest)
		dTodayCardCompounds,db_err:=this.TodayCardCompounds.save()
		if db_err!=nil{
			log.Error("insert save TodayCardCompound failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dTodayCardCompounds)
		dCampFightInfo,db_err:=this.CampFightInfo.save()
		if db_err!=nil{
			log.Error("insert save CampFightInfo failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dCampFightInfo)
		dSignInfo,db_err:=this.SignInfo.save()
		if db_err!=nil{
			log.Error("insert save SignInfo failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dSignInfo)
		dGuidess,db_err:=this.Guidess.save()
		if db_err!=nil{
			log.Error("insert save Guides failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dGuidess)
		dFriends,db_err:=this.Friends.save()
		if db_err!=nil{
			log.Error("insert save Friend failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dFriends)
		dFriendReqs,db_err:=this.FriendReqs.save()
		if db_err!=nil{
			log.Error("insert save FriendReq failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dFriendReqs)
		dFocusPlayers,db_err:=this.FocusPlayers.save()
		if db_err!=nil{
			log.Error("insert save FocusPlayer failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dFocusPlayers)
		dBeFocusPlayers,db_err:=this.BeFocusPlayers.save()
		if db_err!=nil{
			log.Error("insert save BeFocusPlayer failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dBeFocusPlayers)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.m_Account_changed||this.m_Name_changed||this.Info.m_changed||this.TongInfo.m_changed||this.TongDonates.m_changed||this.BeTongDonates.m_changed||this.Cards.m_changed||this.CardTeams.m_changed||this.ShopLattices.m_changed||this.Chests.m_changed||this.Mails.m_changed||this.PayBacks.m_changed||this.Options.m_changed||this.FightRecords.m_changed||this.DialyTasks.m_changed||this.Achieves.m_changed||this.SevenActivitys.m_changed||this.TowerAndFreeChest.m_changed||this.TodayCardCompounds.m_changed||this.CampFightInfo.m_changed||this.SignInfo.m_changed||this.Guidess.m_changed||this.Friends.m_changed||this.FriendReqs.m_changed||this.FocusPlayers.m_changed||this.BeFocusPlayers.m_changed{
			update_string = "UPDATE Players SET "
			db_args:=new_db_args(27)
			if this.m_Account_changed{
				update_string+="Account=?,"
				db_args.Push(this.m_Account)
			}
			if this.m_Name_changed{
				update_string+="Name=?,"
				db_args.Push(this.m_Name)
			}
			if this.Info.m_changed{
				update_string+="Info=?,"
				dInfo,err:=this.Info.save()
				if err!=nil{
					log.Error("update save Info failed")
					return err,false,0,"",nil
				}
				db_args.Push(dInfo)
			}
			if this.TongInfo.m_changed{
				update_string+="TongInfo=?,"
				dTongInfo,err:=this.TongInfo.save()
				if err!=nil{
					log.Error("update save TongInfo failed")
					return err,false,0,"",nil
				}
				db_args.Push(dTongInfo)
			}
			if this.TongDonates.m_changed{
				update_string+="TongDonates=?,"
				dTongDonates,err:=this.TongDonates.save()
				if err!=nil{
					log.Error("insert save TongDonate failed")
					return err,false,0,"",nil
				}
				db_args.Push(dTongDonates)
			}
			if this.BeTongDonates.m_changed{
				update_string+="BeTongDonates=?,"
				dBeTongDonates,err:=this.BeTongDonates.save()
				if err!=nil{
					log.Error("insert save BeTongDonate failed")
					return err,false,0,"",nil
				}
				db_args.Push(dBeTongDonates)
			}
			if this.Cards.m_changed{
				update_string+="Cards=?,"
				dCards,err:=this.Cards.save()
				if err!=nil{
					log.Error("insert save Card failed")
					return err,false,0,"",nil
				}
				db_args.Push(dCards)
			}
			if this.CardTeams.m_changed{
				update_string+="CardTeams=?,"
				dCardTeams,err:=this.CardTeams.save()
				if err!=nil{
					log.Error("insert save CardTeam failed")
					return err,false,0,"",nil
				}
				db_args.Push(dCardTeams)
			}
			if this.ShopLattices.m_changed{
				update_string+="ShopLattices=?,"
				dShopLattices,err:=this.ShopLattices.save()
				if err!=nil{
					log.Error("insert save ShopLattice failed")
					return err,false,0,"",nil
				}
				db_args.Push(dShopLattices)
			}
			if this.Chests.m_changed{
				update_string+="Chests=?,"
				dChests,err:=this.Chests.save()
				if err!=nil{
					log.Error("insert save Chest failed")
					return err,false,0,"",nil
				}
				db_args.Push(dChests)
			}
			if this.Mails.m_changed{
				update_string+="Mails=?,"
				dMails,err:=this.Mails.save()
				if err!=nil{
					log.Error("insert save Mail failed")
					return err,false,0,"",nil
				}
				db_args.Push(dMails)
			}
			if this.PayBacks.m_changed{
				update_string+="PayBacks=?,"
				dPayBacks,err:=this.PayBacks.save()
				if err!=nil{
					log.Error("insert save PayBack failed")
					return err,false,0,"",nil
				}
				db_args.Push(dPayBacks)
			}
			if this.Options.m_changed{
				update_string+="Options=?,"
				dOptions,err:=this.Options.save()
				if err!=nil{
					log.Error("update save Options failed")
					return err,false,0,"",nil
				}
				db_args.Push(dOptions)
			}
			if this.FightRecords.m_changed{
				update_string+="FightRecords=?,"
				dFightRecords,err:=this.FightRecords.save()
				if err!=nil{
					log.Error("insert save FightRecord failed")
					return err,false,0,"",nil
				}
				db_args.Push(dFightRecords)
			}
			if this.DialyTasks.m_changed{
				update_string+="DialyTasks=?,"
				dDialyTasks,err:=this.DialyTasks.save()
				if err!=nil{
					log.Error("insert save DialyTask failed")
					return err,false,0,"",nil
				}
				db_args.Push(dDialyTasks)
			}
			if this.Achieves.m_changed{
				update_string+="Achieves=?,"
				dAchieves,err:=this.Achieves.save()
				if err!=nil{
					log.Error("insert save Achieve failed")
					return err,false,0,"",nil
				}
				db_args.Push(dAchieves)
			}
			if this.SevenActivitys.m_changed{
				update_string+="SevenActivitys=?,"
				dSevenActivitys,err:=this.SevenActivitys.save()
				if err!=nil{
					log.Error("insert save SevenActivity failed")
					return err,false,0,"",nil
				}
				db_args.Push(dSevenActivitys)
			}
			if this.TowerAndFreeChest.m_changed{
				update_string+="TowerAndFreeChest=?,"
				dTowerAndFreeChest,err:=this.TowerAndFreeChest.save()
				if err!=nil{
					log.Error("update save TowerAndFreeChest failed")
					return err,false,0,"",nil
				}
				db_args.Push(dTowerAndFreeChest)
			}
			if this.TodayCardCompounds.m_changed{
				update_string+="TodayCardCompounds=?,"
				dTodayCardCompounds,err:=this.TodayCardCompounds.save()
				if err!=nil{
					log.Error("insert save TodayCardCompound failed")
					return err,false,0,"",nil
				}
				db_args.Push(dTodayCardCompounds)
			}
			if this.CampFightInfo.m_changed{
				update_string+="CampFightInfo=?,"
				dCampFightInfo,err:=this.CampFightInfo.save()
				if err!=nil{
					log.Error("update save CampFightInfo failed")
					return err,false,0,"",nil
				}
				db_args.Push(dCampFightInfo)
			}
			if this.SignInfo.m_changed{
				update_string+="SignInfo=?,"
				dSignInfo,err:=this.SignInfo.save()
				if err!=nil{
					log.Error("update save SignInfo failed")
					return err,false,0,"",nil
				}
				db_args.Push(dSignInfo)
			}
			if this.Guidess.m_changed{
				update_string+="Guidess=?,"
				dGuidess,err:=this.Guidess.save()
				if err!=nil{
					log.Error("insert save Guides failed")
					return err,false,0,"",nil
				}
				db_args.Push(dGuidess)
			}
			if this.Friends.m_changed{
				update_string+="Friends=?,"
				dFriends,err:=this.Friends.save()
				if err!=nil{
					log.Error("insert save Friend failed")
					return err,false,0,"",nil
				}
				db_args.Push(dFriends)
			}
			if this.FriendReqs.m_changed{
				update_string+="FriendReqs=?,"
				dFriendReqs,err:=this.FriendReqs.save()
				if err!=nil{
					log.Error("insert save FriendReq failed")
					return err,false,0,"",nil
				}
				db_args.Push(dFriendReqs)
			}
			if this.FocusPlayers.m_changed{
				update_string+="FocusPlayers=?,"
				dFocusPlayers,err:=this.FocusPlayers.save()
				if err!=nil{
					log.Error("insert save FocusPlayer failed")
					return err,false,0,"",nil
				}
				db_args.Push(dFocusPlayers)
			}
			if this.BeFocusPlayers.m_changed{
				update_string+="BeFocusPlayers=?,"
				dBeFocusPlayers,err:=this.BeFocusPlayers.save()
				if err!=nil{
					log.Error("insert save BeFocusPlayer failed")
					return err,false,0,"",nil
				}
				db_args.Push(dBeFocusPlayers)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE PlayerId=?"
			db_args.Push(this.m_PlayerId)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.m_Account_changed = false
	this.m_Name_changed = false
	this.Info.m_changed = false
	this.TongInfo.m_changed = false
	this.TongDonates.m_changed = false
	this.BeTongDonates.m_changed = false
	this.Cards.m_changed = false
	this.CardTeams.m_changed = false
	this.ShopLattices.m_changed = false
	this.Chests.m_changed = false
	this.Mails.m_changed = false
	this.PayBacks.m_changed = false
	this.Options.m_changed = false
	this.FightRecords.m_changed = false
	this.DialyTasks.m_changed = false
	this.Achieves.m_changed = false
	this.SevenActivitys.m_changed = false
	this.TowerAndFreeChest.m_changed = false
	this.TodayCardCompounds.m_changed = false
	this.CampFightInfo.m_changed = false
	this.SignInfo.m_changed = false
	this.Guidess.m_changed = false
	this.Friends.m_changed = false
	this.FriendReqs.m_changed = false
	this.FocusPlayers.m_changed = false
	this.BeFocusPlayers.m_changed = false
	if release && this.m_loaded {
		atomic.AddInt32(&this.m_table.m_gc_n, -1)
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbPlayerRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT Players exec failed %v ", this.m_PlayerId)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE Players exec failed %v", this.m_PlayerId)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
func (this *dbPlayerRow) Touch(releasable bool) {
	this.m_touch = int32(time.Now().Unix())
	this.m_releasable = releasable
}
type dbPlayerRowSort struct {
	rows []*dbPlayerRow
}
func (this *dbPlayerRowSort) Len() (length int) {
	return len(this.rows)
}
func (this *dbPlayerRowSort) Less(i int, j int) (less bool) {
	return this.rows[i].m_touch < this.rows[j].m_touch
}
func (this *dbPlayerRowSort) Swap(i int, j int) {
	temp := this.rows[i]
	this.rows[i] = this.rows[j]
	this.rows[j] = temp
}
type dbPlayerTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_rows map[int32]*dbPlayerRow
	m_new_rows map[int32]*dbPlayerRow
	m_removed_rows map[int32]*dbPlayerRow
	m_gc_n int32
	m_gcing int32
	m_pool_size int32
	m_preload_select_stmt *sql.Stmt
	m_preload_max_id int32
	m_save_insert_stmt *sql.Stmt
	m_delete_stmt *sql.Stmt
}
func new_dbPlayerTable(dbc *DBC) (this *dbPlayerTable) {
	this = &dbPlayerTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	this.m_rows = make(map[int32]*dbPlayerRow)
	this.m_new_rows = make(map[int32]*dbPlayerRow)
	this.m_removed_rows = make(map[int32]*dbPlayerRow)
	return this
}
func (this *dbPlayerTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS Players(PlayerId int(11),PRIMARY KEY (PlayerId))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS Players failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='Players'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasAccount := columns["Account"]
	if !hasAccount {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN Account varchar(45)")
		if err != nil {
			log.Error("ADD COLUMN Account failed")
			return
		}
	}
	_, hasName := columns["Name"]
	if !hasName {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN Name varchar(45)")
		if err != nil {
			log.Error("ADD COLUMN Name failed")
			return
		}
	}
	_, hasInfo := columns["Info"]
	if !hasInfo {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN Info LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN Info failed")
			return
		}
	}
	_, hasTongInfo := columns["TongInfo"]
	if !hasTongInfo {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN TongInfo LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN TongInfo failed")
			return
		}
	}
	_, hasTongDonate := columns["TongDonates"]
	if !hasTongDonate {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN TongDonates LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN TongDonates failed")
			return
		}
	}
	_, hasBeTongDonate := columns["BeTongDonates"]
	if !hasBeTongDonate {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN BeTongDonates LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN BeTongDonates failed")
			return
		}
	}
	_, hasCard := columns["Cards"]
	if !hasCard {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN Cards LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN Cards failed")
			return
		}
	}
	_, hasCardTeam := columns["CardTeams"]
	if !hasCardTeam {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN CardTeams LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN CardTeams failed")
			return
		}
	}
	_, hasShopLattice := columns["ShopLattices"]
	if !hasShopLattice {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN ShopLattices LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN ShopLattices failed")
			return
		}
	}
	_, hasChest := columns["Chests"]
	if !hasChest {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN Chests LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN Chests failed")
			return
		}
	}
	_, hasMail := columns["Mails"]
	if !hasMail {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN Mails LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN Mails failed")
			return
		}
	}
	_, hasPayBack := columns["PayBacks"]
	if !hasPayBack {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN PayBacks LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN PayBacks failed")
			return
		}
	}
	_, hasOptions := columns["Options"]
	if !hasOptions {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN Options LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN Options failed")
			return
		}
	}
	_, hasFightRecord := columns["FightRecords"]
	if !hasFightRecord {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN FightRecords LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN FightRecords failed")
			return
		}
	}
	_, hasDialyTask := columns["DialyTasks"]
	if !hasDialyTask {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN DialyTasks LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN DialyTasks failed")
			return
		}
	}
	_, hasAchieve := columns["Achieves"]
	if !hasAchieve {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN Achieves LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN Achieves failed")
			return
		}
	}
	_, hasSevenActivity := columns["SevenActivitys"]
	if !hasSevenActivity {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN SevenActivitys LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN SevenActivitys failed")
			return
		}
	}
	_, hasTowerAndFreeChest := columns["TowerAndFreeChest"]
	if !hasTowerAndFreeChest {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN TowerAndFreeChest LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN TowerAndFreeChest failed")
			return
		}
	}
	_, hasTodayCardCompound := columns["TodayCardCompounds"]
	if !hasTodayCardCompound {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN TodayCardCompounds LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN TodayCardCompounds failed")
			return
		}
	}
	_, hasCampFightInfo := columns["CampFightInfo"]
	if !hasCampFightInfo {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN CampFightInfo LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN CampFightInfo failed")
			return
		}
	}
	_, hasSignInfo := columns["SignInfo"]
	if !hasSignInfo {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN SignInfo LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN SignInfo failed")
			return
		}
	}
	_, hasGuides := columns["Guidess"]
	if !hasGuides {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN Guidess LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN Guidess failed")
			return
		}
	}
	_, hasFriend := columns["Friends"]
	if !hasFriend {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN Friends LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN Friends failed")
			return
		}
	}
	_, hasFriendReq := columns["FriendReqs"]
	if !hasFriendReq {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN FriendReqs LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN FriendReqs failed")
			return
		}
	}
	_, hasFocusPlayer := columns["FocusPlayers"]
	if !hasFocusPlayer {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN FocusPlayers LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN FocusPlayers failed")
			return
		}
	}
	_, hasBeFocusPlayer := columns["BeFocusPlayers"]
	if !hasBeFocusPlayer {
		_, err = this.m_dbc.Exec("ALTER TABLE Players ADD COLUMN BeFocusPlayers LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN BeFocusPlayers failed")
			return
		}
	}
	return
}
func (this *dbPlayerTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT PlayerId,Account,Name,Info,TongInfo,TongDonates,BeTongDonates,Cards,CardTeams,ShopLattices,Chests,Mails,PayBacks,Options,FightRecords,DialyTasks,Achieves,SevenActivitys,TowerAndFreeChest,TodayCardCompounds,CampFightInfo,SignInfo,Guidess,Friends,FriendReqs,FocusPlayers,BeFocusPlayers FROM Players")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbPlayerTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO Players (PlayerId,Account,Name,Info,TongInfo,TongDonates,BeTongDonates,Cards,CardTeams,ShopLattices,Chests,Mails,PayBacks,Options,FightRecords,DialyTasks,Achieves,SevenActivitys,TowerAndFreeChest,TodayCardCompounds,CampFightInfo,SignInfo,Guidess,Friends,FriendReqs,FocusPlayers,BeFocusPlayers) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbPlayerTable) prepare_delete_stmt() (err error) {
	this.m_delete_stmt,err=this.m_dbc.StmtPrepare("DELETE FROM Players WHERE PlayerId=?")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbPlayerTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	err=this.prepare_delete_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbPlayerTable) Preload() (err error) {
	r, err := this.m_dbc.StmtQuery(this.m_preload_select_stmt)
	if err != nil {
		log.Error("SELECT")
		return
	}
	var PlayerId int32
	var dAccount string
	var dName string
	var dInfo []byte
	var dTongInfo []byte
	var dTongDonates []byte
	var dBeTongDonates []byte
	var dCards []byte
	var dCardTeams []byte
	var dShopLattices []byte
	var dChests []byte
	var dMails []byte
	var dPayBacks []byte
	var dOptions []byte
	var dFightRecords []byte
	var dDialyTasks []byte
	var dAchieves []byte
	var dSevenActivitys []byte
	var dTowerAndFreeChest []byte
	var dTodayCardCompounds []byte
	var dCampFightInfo []byte
	var dSignInfo []byte
	var dGuidess []byte
	var dFriends []byte
	var dFriendReqs []byte
	var dFocusPlayers []byte
	var dBeFocusPlayers []byte
		this.m_preload_max_id = 0
	for r.Next() {
		err = r.Scan(&PlayerId,&dAccount,&dName,&dInfo,&dTongInfo,&dTongDonates,&dBeTongDonates,&dCards,&dCardTeams,&dShopLattices,&dChests,&dMails,&dPayBacks,&dOptions,&dFightRecords,&dDialyTasks,&dAchieves,&dSevenActivitys,&dTowerAndFreeChest,&dTodayCardCompounds,&dCampFightInfo,&dSignInfo,&dGuidess,&dFriends,&dFriendReqs,&dFocusPlayers,&dBeFocusPlayers)
		if err != nil {
			log.Error("Scan")
			return
		}
		if PlayerId>this.m_preload_max_id{
			this.m_preload_max_id =PlayerId
		}
		row := new_dbPlayerRow(this,PlayerId)
		row.m_Account=dAccount
		row.m_Name=dName
		err = row.Info.load(dInfo)
		if err != nil {
			log.Error("Info %v", PlayerId)
			return
		}
		err = row.TongInfo.load(dTongInfo)
		if err != nil {
			log.Error("TongInfo %v", PlayerId)
			return
		}
		err = row.TongDonates.load(dTongDonates)
		if err != nil {
			log.Error("TongDonates %v", PlayerId)
			return
		}
		err = row.BeTongDonates.load(dBeTongDonates)
		if err != nil {
			log.Error("BeTongDonates %v", PlayerId)
			return
		}
		err = row.Cards.load(dCards)
		if err != nil {
			log.Error("Cards %v", PlayerId)
			return
		}
		err = row.CardTeams.load(dCardTeams)
		if err != nil {
			log.Error("CardTeams %v", PlayerId)
			return
		}
		err = row.ShopLattices.load(dShopLattices)
		if err != nil {
			log.Error("ShopLattices %v", PlayerId)
			return
		}
		err = row.Chests.load(dChests)
		if err != nil {
			log.Error("Chests %v", PlayerId)
			return
		}
		err = row.Mails.load(dMails)
		if err != nil {
			log.Error("Mails %v", PlayerId)
			return
		}
		err = row.PayBacks.load(dPayBacks)
		if err != nil {
			log.Error("PayBacks %v", PlayerId)
			return
		}
		err = row.Options.load(dOptions)
		if err != nil {
			log.Error("Options %v", PlayerId)
			return
		}
		err = row.FightRecords.load(dFightRecords)
		if err != nil {
			log.Error("FightRecords %v", PlayerId)
			return
		}
		err = row.DialyTasks.load(dDialyTasks)
		if err != nil {
			log.Error("DialyTasks %v", PlayerId)
			return
		}
		err = row.Achieves.load(dAchieves)
		if err != nil {
			log.Error("Achieves %v", PlayerId)
			return
		}
		err = row.SevenActivitys.load(dSevenActivitys)
		if err != nil {
			log.Error("SevenActivitys %v", PlayerId)
			return
		}
		err = row.TowerAndFreeChest.load(dTowerAndFreeChest)
		if err != nil {
			log.Error("TowerAndFreeChest %v", PlayerId)
			return
		}
		err = row.TodayCardCompounds.load(dTodayCardCompounds)
		if err != nil {
			log.Error("TodayCardCompounds %v", PlayerId)
			return
		}
		err = row.CampFightInfo.load(dCampFightInfo)
		if err != nil {
			log.Error("CampFightInfo %v", PlayerId)
			return
		}
		err = row.SignInfo.load(dSignInfo)
		if err != nil {
			log.Error("SignInfo %v", PlayerId)
			return
		}
		err = row.Guidess.load(dGuidess)
		if err != nil {
			log.Error("Guidess %v", PlayerId)
			return
		}
		err = row.Friends.load(dFriends)
		if err != nil {
			log.Error("Friends %v", PlayerId)
			return
		}
		err = row.FriendReqs.load(dFriendReqs)
		if err != nil {
			log.Error("FriendReqs %v", PlayerId)
			return
		}
		err = row.FocusPlayers.load(dFocusPlayers)
		if err != nil {
			log.Error("FocusPlayers %v", PlayerId)
			return
		}
		err = row.BeFocusPlayers.load(dBeFocusPlayers)
		if err != nil {
			log.Error("BeFocusPlayers %v", PlayerId)
			return
		}
		row.m_Account_changed=false
		row.m_Name_changed=false
		row.m_valid = true
		this.m_rows[PlayerId]=row
	}
	return
}
func (this *dbPlayerTable) GetPreloadedMaxId() (max_id int32) {
	return this.m_preload_max_id
}
func (this *dbPlayerTable) fetch_rows(rows map[int32]*dbPlayerRow) (r map[int32]*dbPlayerRow) {
	this.m_lock.UnSafeLock("dbPlayerTable.fetch_rows")
	defer this.m_lock.UnSafeUnlock()
	r = make(map[int32]*dbPlayerRow)
	for i, v := range rows {
		r[i] = v
	}
	return r
}
func (this *dbPlayerTable) fetch_new_rows() (new_rows map[int32]*dbPlayerRow) {
	this.m_lock.UnSafeLock("dbPlayerTable.fetch_new_rows")
	defer this.m_lock.UnSafeUnlock()
	new_rows = make(map[int32]*dbPlayerRow)
	for i, v := range this.m_new_rows {
		_, has := this.m_rows[i]
		if has {
			log.Error("rows already has new rows %v", i)
			continue
		}
		this.m_rows[i] = v
		new_rows[i] = v
	}
	for i, _ := range new_rows {
		delete(this.m_new_rows, i)
	}
	return
}
func (this *dbPlayerTable) save_rows(rows map[int32]*dbPlayerRow, quick bool) {
	for _, v := range rows {
		if this.m_dbc.m_quit && !quick {
			return
		}
		err, delay, _ := v.Save(false)
		if err != nil {
			log.Error("save failed %v", err)
		}
		if this.m_dbc.m_quit && !quick {
			return
		}
		if delay&&!quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
}
func (this *dbPlayerTable) Save(quick bool) (err error){
	removed_rows := this.fetch_rows(this.m_removed_rows)
	for _, v := range removed_rows {
		_, err := this.m_dbc.StmtExec(this.m_delete_stmt, v.GetPlayerId())
		if err != nil {
			log.Error("exec delete stmt failed %v", err)
		}
		v.m_valid = false
		if !quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
	this.m_removed_rows = make(map[int32]*dbPlayerRow)
	rows := this.fetch_rows(this.m_rows)
	this.save_rows(rows, quick)
	new_rows := this.fetch_new_rows()
	this.save_rows(new_rows, quick)
	return
}
func (this *dbPlayerTable) AddRow(PlayerId int32) (row *dbPlayerRow) {
	this.m_lock.UnSafeLock("dbPlayerTable.AddRow")
	defer this.m_lock.UnSafeUnlock()
	row = new_dbPlayerRow(this,PlayerId)
	row.m_new = true
	row.m_loaded = true
	row.m_valid = true
	_, has := this.m_new_rows[PlayerId]
	if has{
		log.Error("已经存在 %v", PlayerId)
		return nil
	}
	this.m_new_rows[PlayerId] = row
	atomic.AddInt32(&this.m_gc_n,1)
	return row
}
func (this *dbPlayerTable) RemoveRow(PlayerId int32) {
	this.m_lock.UnSafeLock("dbPlayerTable.RemoveRow")
	defer this.m_lock.UnSafeUnlock()
	row := this.m_rows[PlayerId]
	if row != nil {
		row.m_remove = true
		row = this.m_removed_rows[PlayerId]
		if row != nil {
			log.Error("rows and removed rows both has %v", PlayerId)
			row.m_remove = true
			delete(this.m_rows,PlayerId)
			this.m_removed_rows[PlayerId] = row
		} else {
			delete(this.m_rows, PlayerId)
		}
		_, has_new := this.m_new_rows[PlayerId]
		if has_new {
			delete(this.m_new_rows, PlayerId)
			log.Error("rows and new_rows both has %v", PlayerId)
		}
	} else {
		row = this.m_removed_rows[PlayerId]
		if row == nil {
			_, has_new := this.m_new_rows[PlayerId]
			if has_new {
				delete(this.m_new_rows, PlayerId)
			} else {
				log.Error("row not exist %v", PlayerId)
			}
		} else {
			log.Error("already removed %v", PlayerId)
			_, has_new := this.m_new_rows[PlayerId]
			if has_new {
				delete(this.m_new_rows, PlayerId)
				log.Error("removed rows and new_rows both has %v", PlayerId)
			}
		}
	}
}
func (this *dbPlayerTable) GetRow(PlayerId int32) (row *dbPlayerRow) {
	this.m_lock.UnSafeRLock("dbPlayerTable.GetRow")
	defer this.m_lock.UnSafeRUnlock()
	row = this.m_rows[PlayerId]
	if row == nil {
		row = this.m_new_rows[PlayerId]
	}
	return row
}
func (this *dbGooglePayRecordRow)GetSn( )(r string ){
	this.m_lock.UnSafeRLock("dbGooglePayRecordRow.GetdbGooglePayRecordSnColumn")
	defer this.m_lock.UnSafeRUnlock()
	return string(this.m_Sn)
}
func (this *dbGooglePayRecordRow)SetSn(v string){
	this.m_lock.UnSafeLock("dbGooglePayRecordRow.SetdbGooglePayRecordSnColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_Sn=string(v)
	this.m_Sn_changed=true
	return
}
func (this *dbGooglePayRecordRow)GetBid( )(r string ){
	this.m_lock.UnSafeRLock("dbGooglePayRecordRow.GetdbGooglePayRecordBidColumn")
	defer this.m_lock.UnSafeRUnlock()
	return string(this.m_Bid)
}
func (this *dbGooglePayRecordRow)SetBid(v string){
	this.m_lock.UnSafeLock("dbGooglePayRecordRow.SetdbGooglePayRecordBidColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_Bid=string(v)
	this.m_Bid_changed=true
	return
}
func (this *dbGooglePayRecordRow)GetPlayerId( )(r int32 ){
	this.m_lock.UnSafeRLock("dbGooglePayRecordRow.GetdbGooglePayRecordPlayerIdColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_PlayerId)
}
func (this *dbGooglePayRecordRow)SetPlayerId(v int32){
	this.m_lock.UnSafeLock("dbGooglePayRecordRow.SetdbGooglePayRecordPlayerIdColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_PlayerId=int32(v)
	this.m_PlayerId_changed=true
	return
}
func (this *dbGooglePayRecordRow)GetPayTime( )(r int32 ){
	this.m_lock.UnSafeRLock("dbGooglePayRecordRow.GetdbGooglePayRecordPayTimeColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_PayTime)
}
func (this *dbGooglePayRecordRow)SetPayTime(v int32){
	this.m_lock.UnSafeLock("dbGooglePayRecordRow.SetdbGooglePayRecordPayTimeColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_PayTime=int32(v)
	this.m_PayTime_changed=true
	return
}
type dbGooglePayRecordRow struct {
	m_table *dbGooglePayRecordTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_KeyId        int32
	m_Sn_changed bool
	m_Sn string
	m_Bid_changed bool
	m_Bid string
	m_PlayerId_changed bool
	m_PlayerId int32
	m_PayTime_changed bool
	m_PayTime int32
}
func new_dbGooglePayRecordRow(table *dbGooglePayRecordTable, KeyId int32) (r *dbGooglePayRecordRow) {
	this := &dbGooglePayRecordRow{}
	this.m_table = table
	this.m_KeyId = KeyId
	this.m_lock = NewRWMutex()
	this.m_Sn_changed=true
	this.m_Bid_changed=true
	this.m_PlayerId_changed=true
	this.m_PayTime_changed=true
	return this
}
func (this *dbGooglePayRecordRow) GetKeyId() (r int32) {
	return this.m_KeyId
}
func (this *dbGooglePayRecordRow) Load() (err error) {
	this.m_table.GC()
	this.m_lock.UnSafeLock("dbGooglePayRecordRow.Load")
	defer this.m_lock.UnSafeUnlock()
	if this.m_loaded {
		return
	}
	var dBid string
	var dPlayerId int32
	var dPayTime int32
	r := this.m_table.m_dbc.StmtQueryRow(this.m_table.m_load_select_stmt, this.m_KeyId)
	err = r.Scan(&dBid,&dPlayerId,&dPayTime)
	if err != nil {
		log.Error("scan")
		return
	}
		this.m_Bid=dBid
		this.m_PlayerId=dPlayerId
		this.m_PayTime=dPayTime
	this.m_loaded=true
	this.m_Bid_changed=false
	this.m_PlayerId_changed=false
	this.m_PayTime_changed=false
	this.Touch(false)
	atomic.AddInt32(&this.m_table.m_gc_n,1)
	return
}
func (this *dbGooglePayRecordRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbGooglePayRecordRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(5)
		db_args.Push(this.m_KeyId)
		db_args.Push(this.m_Sn)
		db_args.Push(this.m_Bid)
		db_args.Push(this.m_PlayerId)
		db_args.Push(this.m_PayTime)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.m_Sn_changed||this.m_Bid_changed||this.m_PlayerId_changed||this.m_PayTime_changed{
			update_string = "UPDATE GooglePayRecords SET "
			db_args:=new_db_args(5)
			if this.m_Sn_changed{
				update_string+="Sn=?,"
				db_args.Push(this.m_Sn)
			}
			if this.m_Bid_changed{
				update_string+="Bid=?,"
				db_args.Push(this.m_Bid)
			}
			if this.m_PlayerId_changed{
				update_string+="PlayerId=?,"
				db_args.Push(this.m_PlayerId)
			}
			if this.m_PayTime_changed{
				update_string+="PayTime=?,"
				db_args.Push(this.m_PayTime)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE KeyId=?"
			db_args.Push(this.m_KeyId)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.m_Sn_changed = false
	this.m_Bid_changed = false
	this.m_PlayerId_changed = false
	this.m_PayTime_changed = false
	if release && this.m_loaded {
		atomic.AddInt32(&this.m_table.m_gc_n, -1)
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbGooglePayRecordRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT GooglePayRecords exec failed %v ", this.m_KeyId)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE GooglePayRecords exec failed %v", this.m_KeyId)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
func (this *dbGooglePayRecordRow) Touch(releasable bool) {
	this.m_touch = int32(time.Now().Unix())
	this.m_releasable = releasable
}
type dbGooglePayRecordRowSort struct {
	rows []*dbGooglePayRecordRow
}
func (this *dbGooglePayRecordRowSort) Len() (length int) {
	return len(this.rows)
}
func (this *dbGooglePayRecordRowSort) Less(i int, j int) (less bool) {
	return this.rows[i].m_touch < this.rows[j].m_touch
}
func (this *dbGooglePayRecordRowSort) Swap(i int, j int) {
	temp := this.rows[i]
	this.rows[i] = this.rows[j]
	this.rows[j] = temp
}
type dbGooglePayRecordTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_rows map[int32]*dbGooglePayRecordRow
	m_new_rows map[int32]*dbGooglePayRecordRow
	m_removed_rows map[int32]*dbGooglePayRecordRow
	m_gc_n int32
	m_gcing int32
	m_pool_size int32
	m_preload_select_stmt *sql.Stmt
	m_preload_max_id int32
	m_load_select_stmt *sql.Stmt
	m_save_insert_stmt *sql.Stmt
	m_delete_stmt *sql.Stmt
	m_max_id int32
	m_max_id_changed bool
}
func new_dbGooglePayRecordTable(dbc *DBC) (this *dbGooglePayRecordTable) {
	this = &dbGooglePayRecordTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	this.m_rows = make(map[int32]*dbGooglePayRecordRow)
	this.m_new_rows = make(map[int32]*dbGooglePayRecordRow)
	this.m_removed_rows = make(map[int32]*dbGooglePayRecordRow)
	return this
}
func (this *dbGooglePayRecordTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS GooglePayRecordsMaxId(PlaceHolder int(11),MaxKeyId int(11),PRIMARY KEY (PlaceHolder))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS GooglePayRecordsMaxId failed")
		return
	}
	r := this.m_dbc.QueryRow("SELECT Count(*) FROM GooglePayRecordsMaxId WHERE PlaceHolder=0")
	if r != nil {
		var count int32
		err = r.Scan(&count)
		if err != nil {
			log.Error("scan count failed")
			return
		}
		if count == 0 {
		_, err = this.m_dbc.Exec("INSERT INTO GooglePayRecordsMaxId (PlaceHolder,MaxKeyId) VALUES (0,0)")
			if err != nil {
				log.Error("INSERTGooglePayRecordsMaxId failed")
				return
			}
		}
	}
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS GooglePayRecords(KeyId int(11),PRIMARY KEY (KeyId))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS GooglePayRecords failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='GooglePayRecords'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasSn := columns["Sn"]
	if !hasSn {
		_, err = this.m_dbc.Exec("ALTER TABLE GooglePayRecords ADD COLUMN Sn varchar(45)")
		if err != nil {
			log.Error("ADD COLUMN Sn failed")
			return
		}
	}
	_, hasBid := columns["Bid"]
	if !hasBid {
		_, err = this.m_dbc.Exec("ALTER TABLE GooglePayRecords ADD COLUMN Bid varchar(45)")
		if err != nil {
			log.Error("ADD COLUMN Bid failed")
			return
		}
	}
	_, hasPlayerId := columns["PlayerId"]
	if !hasPlayerId {
		_, err = this.m_dbc.Exec("ALTER TABLE GooglePayRecords ADD COLUMN PlayerId int(11)")
		if err != nil {
			log.Error("ADD COLUMN PlayerId failed")
			return
		}
	}
	_, hasPayTime := columns["PayTime"]
	if !hasPayTime {
		_, err = this.m_dbc.Exec("ALTER TABLE GooglePayRecords ADD COLUMN PayTime int(11)")
		if err != nil {
			log.Error("ADD COLUMN PayTime failed")
			return
		}
	}
	return
}
func (this *dbGooglePayRecordTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT KeyId,Sn FROM GooglePayRecords")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbGooglePayRecordTable) prepare_load_select_stmt() (err error) {
	this.m_load_select_stmt,err=this.m_dbc.StmtPrepare("SELECT Bid,PlayerId,PayTime FROM GooglePayRecords WHERE KeyId=?")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbGooglePayRecordTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO GooglePayRecords (KeyId,Sn,Bid,PlayerId,PayTime) VALUES (?,?,?,?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbGooglePayRecordTable) prepare_delete_stmt() (err error) {
	this.m_delete_stmt,err=this.m_dbc.StmtPrepare("DELETE FROM GooglePayRecords WHERE KeyId=?")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbGooglePayRecordTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_load_select_stmt()
	if err!=nil{
		log.Error("prepare_load_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	err=this.prepare_delete_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbGooglePayRecordTable) Preload() (err error) {
	r_max_id := this.m_dbc.QueryRow("SELECT MaxKeyId FROM GooglePayRecordsMaxId WHERE PLACEHOLDER=0")
	if r_max_id != nil {
		err = r_max_id.Scan(&this.m_max_id)
		if err != nil {
			log.Error("scan max id failed")
			return
		}
	}
	r, err := this.m_dbc.StmtQuery(this.m_preload_select_stmt)
	if err != nil {
		log.Error("SELECT")
		return
	}
	var KeyId int32
	var dSn string
	for r.Next() {
		err = r.Scan(&KeyId,&dSn)
		if err != nil {
			log.Error("Scan")
			return
		}
		if KeyId>this.m_max_id{
			log.Error("max id ext")
			this.m_max_id = KeyId
			this.m_max_id_changed = true
		}
		row := new_dbGooglePayRecordRow(this,KeyId)
		row.m_Sn=dSn
		row.m_Sn_changed=false
		row.m_valid = true
		this.m_rows[KeyId]=row
	}
	return
}
func (this *dbGooglePayRecordTable) GetPreloadedMaxId() (max_id int32) {
	return this.m_preload_max_id
}
func (this *dbGooglePayRecordTable) fetch_rows(rows map[int32]*dbGooglePayRecordRow) (r map[int32]*dbGooglePayRecordRow) {
	this.m_lock.UnSafeLock("dbGooglePayRecordTable.fetch_rows")
	defer this.m_lock.UnSafeUnlock()
	r = make(map[int32]*dbGooglePayRecordRow)
	for i, v := range rows {
		r[i] = v
	}
	return r
}
func (this *dbGooglePayRecordTable) fetch_new_rows() (new_rows map[int32]*dbGooglePayRecordRow) {
	this.m_lock.UnSafeLock("dbGooglePayRecordTable.fetch_new_rows")
	defer this.m_lock.UnSafeUnlock()
	new_rows = make(map[int32]*dbGooglePayRecordRow)
	for i, v := range this.m_new_rows {
		_, has := this.m_rows[i]
		if has {
			log.Error("rows already has new rows %v", i)
			continue
		}
		this.m_rows[i] = v
		new_rows[i] = v
	}
	for i, _ := range new_rows {
		delete(this.m_new_rows, i)
	}
	return
}
func (this *dbGooglePayRecordTable) save_rows(rows map[int32]*dbGooglePayRecordRow, quick bool) {
	for _, v := range rows {
		if this.m_dbc.m_quit && !quick {
			return
		}
		err, delay, _ := v.Save(false)
		if err != nil {
			log.Error("save failed %v", err)
		}
		if this.m_dbc.m_quit && !quick {
			return
		}
		if delay&&!quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
}
func (this *dbGooglePayRecordTable) Save(quick bool) (err error){
	if this.m_max_id_changed {
		max_id := atomic.LoadInt32(&this.m_max_id)
		_, err := this.m_dbc.Exec("UPDATE GooglePayRecordsMaxId SET MaxKeyId=?", max_id)
		if err != nil {
			log.Error("save max id failed %v", err)
		}
	}
	removed_rows := this.fetch_rows(this.m_removed_rows)
	for _, v := range removed_rows {
		_, err := this.m_dbc.StmtExec(this.m_delete_stmt, v.GetKeyId())
		if err != nil {
			log.Error("exec delete stmt failed %v", err)
		}
		v.m_valid = false
		if !quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
	this.m_removed_rows = make(map[int32]*dbGooglePayRecordRow)
	rows := this.fetch_rows(this.m_rows)
	this.save_rows(rows, quick)
	new_rows := this.fetch_new_rows()
	this.save_rows(new_rows, quick)
	return
}
func (this *dbGooglePayRecordTable) AddRow() (row *dbGooglePayRecordRow) {
	this.GC()
	this.m_lock.UnSafeLock("dbGooglePayRecordTable.AddRow")
	defer this.m_lock.UnSafeUnlock()
	KeyId := atomic.AddInt32(&this.m_max_id, 1)
	this.m_max_id_changed = true
	row = new_dbGooglePayRecordRow(this,KeyId)
	row.m_new = true
	row.m_loaded = true
	row.m_valid = true
	this.m_new_rows[KeyId] = row
	atomic.AddInt32(&this.m_gc_n,1)
	return row
}
func (this *dbGooglePayRecordTable) RemoveRow(KeyId int32) {
	this.m_lock.UnSafeLock("dbGooglePayRecordTable.RemoveRow")
	defer this.m_lock.UnSafeUnlock()
	row := this.m_rows[KeyId]
	if row != nil {
		row.m_remove = true
		row = this.m_removed_rows[KeyId]
		if row != nil {
			log.Error("rows and removed rows both has %v", KeyId)
			row.m_remove = true
			delete(this.m_rows,KeyId)
			this.m_removed_rows[KeyId] = row
		} else {
			delete(this.m_rows, KeyId)
		}
		_, has_new := this.m_new_rows[KeyId]
		if has_new {
			delete(this.m_new_rows, KeyId)
			log.Error("rows and new_rows both has %v", KeyId)
		}
	} else {
		row = this.m_removed_rows[KeyId]
		if row == nil {
			_, has_new := this.m_new_rows[KeyId]
			if has_new {
				delete(this.m_new_rows, KeyId)
			} else {
				log.Error("row not exist %v", KeyId)
			}
		} else {
			log.Error("already removed %v", KeyId)
			_, has_new := this.m_new_rows[KeyId]
			if has_new {
				delete(this.m_new_rows, KeyId)
				log.Error("removed rows and new_rows both has %v", KeyId)
			}
		}
	}
}
func (this *dbGooglePayRecordTable) GetRow(KeyId int32) (row *dbGooglePayRecordRow) {
	this.m_lock.UnSafeRLock("dbGooglePayRecordTable.GetRow")
	defer this.m_lock.UnSafeRUnlock()
	row = this.m_rows[KeyId]
	if row == nil {
		row = this.m_new_rows[KeyId]
	}
	return row
}
func (this *dbGooglePayRecordTable) SetPoolSize(n int32) {
	this.m_pool_size = n
}
func (this *dbGooglePayRecordTable) GC() {
	if this.m_pool_size<=0{
		return
	}
	if !atomic.CompareAndSwapInt32(&this.m_gcing, 0, 1) {
		return
	}
	defer atomic.StoreInt32(&this.m_gcing, 0)
	n := atomic.LoadInt32(&this.m_gc_n)
	if float32(n) < float32(this.m_pool_size)*1.2 {
		return
	}
	max := (n - this.m_pool_size) / 2
	arr := dbGooglePayRecordRowSort{}
	rows := this.fetch_rows(this.m_rows)
	arr.rows = make([]*dbGooglePayRecordRow, len(rows))
	index := 0
	for _, v := range rows {
		arr.rows[index] = v
		index++
	}
	sort.Sort(&arr)
	count := int32(0)
	for _, v := range arr.rows {
		err, _, released := v.Save(true)
		if err != nil {
			log.Error("release failed %v", err)
			continue
		}
		if released {
			count++
			if count > max {
				return
			}
		}
	}
	return
}
func (this *dbApplePayRecordRow)GetSn( )(r string ){
	this.m_lock.UnSafeRLock("dbApplePayRecordRow.GetdbApplePayRecordSnColumn")
	defer this.m_lock.UnSafeRUnlock()
	return string(this.m_Sn)
}
func (this *dbApplePayRecordRow)SetSn(v string){
	this.m_lock.UnSafeLock("dbApplePayRecordRow.SetdbApplePayRecordSnColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_Sn=string(v)
	this.m_Sn_changed=true
	return
}
func (this *dbApplePayRecordRow)GetBid( )(r string ){
	this.m_lock.UnSafeRLock("dbApplePayRecordRow.GetdbApplePayRecordBidColumn")
	defer this.m_lock.UnSafeRUnlock()
	return string(this.m_Bid)
}
func (this *dbApplePayRecordRow)SetBid(v string){
	this.m_lock.UnSafeLock("dbApplePayRecordRow.SetdbApplePayRecordBidColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_Bid=string(v)
	this.m_Bid_changed=true
	return
}
func (this *dbApplePayRecordRow)GetPlayerId( )(r int32 ){
	this.m_lock.UnSafeRLock("dbApplePayRecordRow.GetdbApplePayRecordPlayerIdColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_PlayerId)
}
func (this *dbApplePayRecordRow)SetPlayerId(v int32){
	this.m_lock.UnSafeLock("dbApplePayRecordRow.SetdbApplePayRecordPlayerIdColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_PlayerId=int32(v)
	this.m_PlayerId_changed=true
	return
}
func (this *dbApplePayRecordRow)GetPayTime( )(r int32 ){
	this.m_lock.UnSafeRLock("dbApplePayRecordRow.GetdbApplePayRecordPayTimeColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_PayTime)
}
func (this *dbApplePayRecordRow)SetPayTime(v int32){
	this.m_lock.UnSafeLock("dbApplePayRecordRow.SetdbApplePayRecordPayTimeColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_PayTime=int32(v)
	this.m_PayTime_changed=true
	return
}
type dbApplePayRecordRow struct {
	m_table *dbApplePayRecordTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_KeyId        int32
	m_Sn_changed bool
	m_Sn string
	m_Bid_changed bool
	m_Bid string
	m_PlayerId_changed bool
	m_PlayerId int32
	m_PayTime_changed bool
	m_PayTime int32
}
func new_dbApplePayRecordRow(table *dbApplePayRecordTable, KeyId int32) (r *dbApplePayRecordRow) {
	this := &dbApplePayRecordRow{}
	this.m_table = table
	this.m_KeyId = KeyId
	this.m_lock = NewRWMutex()
	this.m_Sn_changed=true
	this.m_Bid_changed=true
	this.m_PlayerId_changed=true
	this.m_PayTime_changed=true
	return this
}
func (this *dbApplePayRecordRow) GetKeyId() (r int32) {
	return this.m_KeyId
}
func (this *dbApplePayRecordRow) Load() (err error) {
	this.m_table.GC()
	this.m_lock.UnSafeLock("dbApplePayRecordRow.Load")
	defer this.m_lock.UnSafeUnlock()
	if this.m_loaded {
		return
	}
	var dBid string
	var dPlayerId int32
	var dPayTime int32
	r := this.m_table.m_dbc.StmtQueryRow(this.m_table.m_load_select_stmt, this.m_KeyId)
	err = r.Scan(&dBid,&dPlayerId,&dPayTime)
	if err != nil {
		log.Error("scan")
		return
	}
		this.m_Bid=dBid
		this.m_PlayerId=dPlayerId
		this.m_PayTime=dPayTime
	this.m_loaded=true
	this.m_Bid_changed=false
	this.m_PlayerId_changed=false
	this.m_PayTime_changed=false
	this.Touch(false)
	atomic.AddInt32(&this.m_table.m_gc_n,1)
	return
}
func (this *dbApplePayRecordRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbApplePayRecordRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(5)
		db_args.Push(this.m_KeyId)
		db_args.Push(this.m_Sn)
		db_args.Push(this.m_Bid)
		db_args.Push(this.m_PlayerId)
		db_args.Push(this.m_PayTime)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.m_Sn_changed||this.m_Bid_changed||this.m_PlayerId_changed||this.m_PayTime_changed{
			update_string = "UPDATE ApplePayRecords SET "
			db_args:=new_db_args(5)
			if this.m_Sn_changed{
				update_string+="Sn=?,"
				db_args.Push(this.m_Sn)
			}
			if this.m_Bid_changed{
				update_string+="Bid=?,"
				db_args.Push(this.m_Bid)
			}
			if this.m_PlayerId_changed{
				update_string+="PlayerId=?,"
				db_args.Push(this.m_PlayerId)
			}
			if this.m_PayTime_changed{
				update_string+="PayTime=?,"
				db_args.Push(this.m_PayTime)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE KeyId=?"
			db_args.Push(this.m_KeyId)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.m_Sn_changed = false
	this.m_Bid_changed = false
	this.m_PlayerId_changed = false
	this.m_PayTime_changed = false
	if release && this.m_loaded {
		atomic.AddInt32(&this.m_table.m_gc_n, -1)
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbApplePayRecordRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT ApplePayRecords exec failed %v ", this.m_KeyId)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE ApplePayRecords exec failed %v", this.m_KeyId)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
func (this *dbApplePayRecordRow) Touch(releasable bool) {
	this.m_touch = int32(time.Now().Unix())
	this.m_releasable = releasable
}
type dbApplePayRecordRowSort struct {
	rows []*dbApplePayRecordRow
}
func (this *dbApplePayRecordRowSort) Len() (length int) {
	return len(this.rows)
}
func (this *dbApplePayRecordRowSort) Less(i int, j int) (less bool) {
	return this.rows[i].m_touch < this.rows[j].m_touch
}
func (this *dbApplePayRecordRowSort) Swap(i int, j int) {
	temp := this.rows[i]
	this.rows[i] = this.rows[j]
	this.rows[j] = temp
}
type dbApplePayRecordTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_rows map[int32]*dbApplePayRecordRow
	m_new_rows map[int32]*dbApplePayRecordRow
	m_removed_rows map[int32]*dbApplePayRecordRow
	m_gc_n int32
	m_gcing int32
	m_pool_size int32
	m_preload_select_stmt *sql.Stmt
	m_preload_max_id int32
	m_load_select_stmt *sql.Stmt
	m_save_insert_stmt *sql.Stmt
	m_delete_stmt *sql.Stmt
	m_max_id int32
	m_max_id_changed bool
}
func new_dbApplePayRecordTable(dbc *DBC) (this *dbApplePayRecordTable) {
	this = &dbApplePayRecordTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	this.m_rows = make(map[int32]*dbApplePayRecordRow)
	this.m_new_rows = make(map[int32]*dbApplePayRecordRow)
	this.m_removed_rows = make(map[int32]*dbApplePayRecordRow)
	return this
}
func (this *dbApplePayRecordTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS ApplePayRecordsMaxId(PlaceHolder int(11),MaxKeyId int(11),PRIMARY KEY (PlaceHolder))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS ApplePayRecordsMaxId failed")
		return
	}
	r := this.m_dbc.QueryRow("SELECT Count(*) FROM ApplePayRecordsMaxId WHERE PlaceHolder=0")
	if r != nil {
		var count int32
		err = r.Scan(&count)
		if err != nil {
			log.Error("scan count failed")
			return
		}
		if count == 0 {
		_, err = this.m_dbc.Exec("INSERT INTO ApplePayRecordsMaxId (PlaceHolder,MaxKeyId) VALUES (0,0)")
			if err != nil {
				log.Error("INSERTApplePayRecordsMaxId failed")
				return
			}
		}
	}
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS ApplePayRecords(KeyId int(11),PRIMARY KEY (KeyId))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS ApplePayRecords failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='ApplePayRecords'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasSn := columns["Sn"]
	if !hasSn {
		_, err = this.m_dbc.Exec("ALTER TABLE ApplePayRecords ADD COLUMN Sn varchar(45)")
		if err != nil {
			log.Error("ADD COLUMN Sn failed")
			return
		}
	}
	_, hasBid := columns["Bid"]
	if !hasBid {
		_, err = this.m_dbc.Exec("ALTER TABLE ApplePayRecords ADD COLUMN Bid varchar(45)")
		if err != nil {
			log.Error("ADD COLUMN Bid failed")
			return
		}
	}
	_, hasPlayerId := columns["PlayerId"]
	if !hasPlayerId {
		_, err = this.m_dbc.Exec("ALTER TABLE ApplePayRecords ADD COLUMN PlayerId int(11)")
		if err != nil {
			log.Error("ADD COLUMN PlayerId failed")
			return
		}
	}
	_, hasPayTime := columns["PayTime"]
	if !hasPayTime {
		_, err = this.m_dbc.Exec("ALTER TABLE ApplePayRecords ADD COLUMN PayTime int(11)")
		if err != nil {
			log.Error("ADD COLUMN PayTime failed")
			return
		}
	}
	return
}
func (this *dbApplePayRecordTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT KeyId,Sn FROM ApplePayRecords")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbApplePayRecordTable) prepare_load_select_stmt() (err error) {
	this.m_load_select_stmt,err=this.m_dbc.StmtPrepare("SELECT Bid,PlayerId,PayTime FROM ApplePayRecords WHERE KeyId=?")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbApplePayRecordTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO ApplePayRecords (KeyId,Sn,Bid,PlayerId,PayTime) VALUES (?,?,?,?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbApplePayRecordTable) prepare_delete_stmt() (err error) {
	this.m_delete_stmt,err=this.m_dbc.StmtPrepare("DELETE FROM ApplePayRecords WHERE KeyId=?")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbApplePayRecordTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_load_select_stmt()
	if err!=nil{
		log.Error("prepare_load_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	err=this.prepare_delete_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbApplePayRecordTable) Preload() (err error) {
	r_max_id := this.m_dbc.QueryRow("SELECT MaxKeyId FROM ApplePayRecordsMaxId WHERE PLACEHOLDER=0")
	if r_max_id != nil {
		err = r_max_id.Scan(&this.m_max_id)
		if err != nil {
			log.Error("scan max id failed")
			return
		}
	}
	r, err := this.m_dbc.StmtQuery(this.m_preload_select_stmt)
	if err != nil {
		log.Error("SELECT")
		return
	}
	var KeyId int32
	var dSn string
	for r.Next() {
		err = r.Scan(&KeyId,&dSn)
		if err != nil {
			log.Error("Scan")
			return
		}
		if KeyId>this.m_max_id{
			log.Error("max id ext")
			this.m_max_id = KeyId
			this.m_max_id_changed = true
		}
		row := new_dbApplePayRecordRow(this,KeyId)
		row.m_Sn=dSn
		row.m_Sn_changed=false
		row.m_valid = true
		this.m_rows[KeyId]=row
	}
	return
}
func (this *dbApplePayRecordTable) GetPreloadedMaxId() (max_id int32) {
	return this.m_preload_max_id
}
func (this *dbApplePayRecordTable) fetch_rows(rows map[int32]*dbApplePayRecordRow) (r map[int32]*dbApplePayRecordRow) {
	this.m_lock.UnSafeLock("dbApplePayRecordTable.fetch_rows")
	defer this.m_lock.UnSafeUnlock()
	r = make(map[int32]*dbApplePayRecordRow)
	for i, v := range rows {
		r[i] = v
	}
	return r
}
func (this *dbApplePayRecordTable) fetch_new_rows() (new_rows map[int32]*dbApplePayRecordRow) {
	this.m_lock.UnSafeLock("dbApplePayRecordTable.fetch_new_rows")
	defer this.m_lock.UnSafeUnlock()
	new_rows = make(map[int32]*dbApplePayRecordRow)
	for i, v := range this.m_new_rows {
		_, has := this.m_rows[i]
		if has {
			log.Error("rows already has new rows %v", i)
			continue
		}
		this.m_rows[i] = v
		new_rows[i] = v
	}
	for i, _ := range new_rows {
		delete(this.m_new_rows, i)
	}
	return
}
func (this *dbApplePayRecordTable) save_rows(rows map[int32]*dbApplePayRecordRow, quick bool) {
	for _, v := range rows {
		if this.m_dbc.m_quit && !quick {
			return
		}
		err, delay, _ := v.Save(false)
		if err != nil {
			log.Error("save failed %v", err)
		}
		if this.m_dbc.m_quit && !quick {
			return
		}
		if delay&&!quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
}
func (this *dbApplePayRecordTable) Save(quick bool) (err error){
	if this.m_max_id_changed {
		max_id := atomic.LoadInt32(&this.m_max_id)
		_, err := this.m_dbc.Exec("UPDATE ApplePayRecordsMaxId SET MaxKeyId=?", max_id)
		if err != nil {
			log.Error("save max id failed %v", err)
		}
	}
	removed_rows := this.fetch_rows(this.m_removed_rows)
	for _, v := range removed_rows {
		_, err := this.m_dbc.StmtExec(this.m_delete_stmt, v.GetKeyId())
		if err != nil {
			log.Error("exec delete stmt failed %v", err)
		}
		v.m_valid = false
		if !quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
	this.m_removed_rows = make(map[int32]*dbApplePayRecordRow)
	rows := this.fetch_rows(this.m_rows)
	this.save_rows(rows, quick)
	new_rows := this.fetch_new_rows()
	this.save_rows(new_rows, quick)
	return
}
func (this *dbApplePayRecordTable) AddRow() (row *dbApplePayRecordRow) {
	this.GC()
	this.m_lock.UnSafeLock("dbApplePayRecordTable.AddRow")
	defer this.m_lock.UnSafeUnlock()
	KeyId := atomic.AddInt32(&this.m_max_id, 1)
	this.m_max_id_changed = true
	row = new_dbApplePayRecordRow(this,KeyId)
	row.m_new = true
	row.m_loaded = true
	row.m_valid = true
	this.m_new_rows[KeyId] = row
	atomic.AddInt32(&this.m_gc_n,1)
	return row
}
func (this *dbApplePayRecordTable) RemoveRow(KeyId int32) {
	this.m_lock.UnSafeLock("dbApplePayRecordTable.RemoveRow")
	defer this.m_lock.UnSafeUnlock()
	row := this.m_rows[KeyId]
	if row != nil {
		row.m_remove = true
		row = this.m_removed_rows[KeyId]
		if row != nil {
			log.Error("rows and removed rows both has %v", KeyId)
			row.m_remove = true
			delete(this.m_rows,KeyId)
			this.m_removed_rows[KeyId] = row
		} else {
			delete(this.m_rows, KeyId)
		}
		_, has_new := this.m_new_rows[KeyId]
		if has_new {
			delete(this.m_new_rows, KeyId)
			log.Error("rows and new_rows both has %v", KeyId)
		}
	} else {
		row = this.m_removed_rows[KeyId]
		if row == nil {
			_, has_new := this.m_new_rows[KeyId]
			if has_new {
				delete(this.m_new_rows, KeyId)
			} else {
				log.Error("row not exist %v", KeyId)
			}
		} else {
			log.Error("already removed %v", KeyId)
			_, has_new := this.m_new_rows[KeyId]
			if has_new {
				delete(this.m_new_rows, KeyId)
				log.Error("removed rows and new_rows both has %v", KeyId)
			}
		}
	}
}
func (this *dbApplePayRecordTable) GetRow(KeyId int32) (row *dbApplePayRecordRow) {
	this.m_lock.UnSafeRLock("dbApplePayRecordTable.GetRow")
	defer this.m_lock.UnSafeRUnlock()
	row = this.m_rows[KeyId]
	if row == nil {
		row = this.m_new_rows[KeyId]
	}
	return row
}
func (this *dbApplePayRecordTable) SetPoolSize(n int32) {
	this.m_pool_size = n
}
func (this *dbApplePayRecordTable) GC() {
	if this.m_pool_size<=0{
		return
	}
	if !atomic.CompareAndSwapInt32(&this.m_gcing, 0, 1) {
		return
	}
	defer atomic.StoreInt32(&this.m_gcing, 0)
	n := atomic.LoadInt32(&this.m_gc_n)
	if float32(n) < float32(this.m_pool_size)*1.2 {
		return
	}
	max := (n - this.m_pool_size) / 2
	arr := dbApplePayRecordRowSort{}
	rows := this.fetch_rows(this.m_rows)
	arr.rows = make([]*dbApplePayRecordRow, len(rows))
	index := 0
	for _, v := range rows {
		arr.rows[index] = v
		index++
	}
	sort.Sort(&arr)
	count := int32(0)
	for _, v := range arr.rows {
		err, _, released := v.Save(true)
		if err != nil {
			log.Error("release failed %v", err)
			continue
		}
		if released {
			count++
			if count > max {
				return
			}
		}
	}
	return
}
func (this *dbFaceBPayRecordRow)GetSn( )(r string ){
	this.m_lock.UnSafeRLock("dbFaceBPayRecordRow.GetdbFaceBPayRecordSnColumn")
	defer this.m_lock.UnSafeRUnlock()
	return string(this.m_Sn)
}
func (this *dbFaceBPayRecordRow)SetSn(v string){
	this.m_lock.UnSafeLock("dbFaceBPayRecordRow.SetdbFaceBPayRecordSnColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_Sn=string(v)
	this.m_Sn_changed=true
	return
}
func (this *dbFaceBPayRecordRow)GetBid( )(r string ){
	this.m_lock.UnSafeRLock("dbFaceBPayRecordRow.GetdbFaceBPayRecordBidColumn")
	defer this.m_lock.UnSafeRUnlock()
	return string(this.m_Bid)
}
func (this *dbFaceBPayRecordRow)SetBid(v string){
	this.m_lock.UnSafeLock("dbFaceBPayRecordRow.SetdbFaceBPayRecordBidColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_Bid=string(v)
	this.m_Bid_changed=true
	return
}
func (this *dbFaceBPayRecordRow)GetPlayerId( )(r int32 ){
	this.m_lock.UnSafeRLock("dbFaceBPayRecordRow.GetdbFaceBPayRecordPlayerIdColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_PlayerId)
}
func (this *dbFaceBPayRecordRow)SetPlayerId(v int32){
	this.m_lock.UnSafeLock("dbFaceBPayRecordRow.SetdbFaceBPayRecordPlayerIdColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_PlayerId=int32(v)
	this.m_PlayerId_changed=true
	return
}
func (this *dbFaceBPayRecordRow)GetPayTime( )(r int32 ){
	this.m_lock.UnSafeRLock("dbFaceBPayRecordRow.GetdbFaceBPayRecordPayTimeColumn")
	defer this.m_lock.UnSafeRUnlock()
	return int32(this.m_PayTime)
}
func (this *dbFaceBPayRecordRow)SetPayTime(v int32){
	this.m_lock.UnSafeLock("dbFaceBPayRecordRow.SetdbFaceBPayRecordPayTimeColumn")
	defer this.m_lock.UnSafeUnlock()
	this.m_PayTime=int32(v)
	this.m_PayTime_changed=true
	return
}
type dbFaceBPayRecordRow struct {
	m_table *dbFaceBPayRecordTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_KeyId        int32
	m_Sn_changed bool
	m_Sn string
	m_Bid_changed bool
	m_Bid string
	m_PlayerId_changed bool
	m_PlayerId int32
	m_PayTime_changed bool
	m_PayTime int32
}
func new_dbFaceBPayRecordRow(table *dbFaceBPayRecordTable, KeyId int32) (r *dbFaceBPayRecordRow) {
	this := &dbFaceBPayRecordRow{}
	this.m_table = table
	this.m_KeyId = KeyId
	this.m_lock = NewRWMutex()
	this.m_Sn_changed=true
	this.m_Bid_changed=true
	this.m_PlayerId_changed=true
	this.m_PayTime_changed=true
	return this
}
func (this *dbFaceBPayRecordRow) GetKeyId() (r int32) {
	return this.m_KeyId
}
func (this *dbFaceBPayRecordRow) Load() (err error) {
	this.m_table.GC()
	this.m_lock.UnSafeLock("dbFaceBPayRecordRow.Load")
	defer this.m_lock.UnSafeUnlock()
	if this.m_loaded {
		return
	}
	var dBid string
	var dPlayerId int32
	var dPayTime int32
	r := this.m_table.m_dbc.StmtQueryRow(this.m_table.m_load_select_stmt, this.m_KeyId)
	err = r.Scan(&dBid,&dPlayerId,&dPayTime)
	if err != nil {
		log.Error("scan")
		return
	}
		this.m_Bid=dBid
		this.m_PlayerId=dPlayerId
		this.m_PayTime=dPayTime
	this.m_loaded=true
	this.m_Bid_changed=false
	this.m_PlayerId_changed=false
	this.m_PayTime_changed=false
	this.Touch(false)
	atomic.AddInt32(&this.m_table.m_gc_n,1)
	return
}
func (this *dbFaceBPayRecordRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbFaceBPayRecordRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(5)
		db_args.Push(this.m_KeyId)
		db_args.Push(this.m_Sn)
		db_args.Push(this.m_Bid)
		db_args.Push(this.m_PlayerId)
		db_args.Push(this.m_PayTime)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.m_Sn_changed||this.m_Bid_changed||this.m_PlayerId_changed||this.m_PayTime_changed{
			update_string = "UPDATE FaceBPayRecords SET "
			db_args:=new_db_args(5)
			if this.m_Sn_changed{
				update_string+="Sn=?,"
				db_args.Push(this.m_Sn)
			}
			if this.m_Bid_changed{
				update_string+="Bid=?,"
				db_args.Push(this.m_Bid)
			}
			if this.m_PlayerId_changed{
				update_string+="PlayerId=?,"
				db_args.Push(this.m_PlayerId)
			}
			if this.m_PayTime_changed{
				update_string+="PayTime=?,"
				db_args.Push(this.m_PayTime)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE KeyId=?"
			db_args.Push(this.m_KeyId)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.m_Sn_changed = false
	this.m_Bid_changed = false
	this.m_PlayerId_changed = false
	this.m_PayTime_changed = false
	if release && this.m_loaded {
		atomic.AddInt32(&this.m_table.m_gc_n, -1)
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbFaceBPayRecordRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT FaceBPayRecords exec failed %v ", this.m_KeyId)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE FaceBPayRecords exec failed %v", this.m_KeyId)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
func (this *dbFaceBPayRecordRow) Touch(releasable bool) {
	this.m_touch = int32(time.Now().Unix())
	this.m_releasable = releasable
}
type dbFaceBPayRecordRowSort struct {
	rows []*dbFaceBPayRecordRow
}
func (this *dbFaceBPayRecordRowSort) Len() (length int) {
	return len(this.rows)
}
func (this *dbFaceBPayRecordRowSort) Less(i int, j int) (less bool) {
	return this.rows[i].m_touch < this.rows[j].m_touch
}
func (this *dbFaceBPayRecordRowSort) Swap(i int, j int) {
	temp := this.rows[i]
	this.rows[i] = this.rows[j]
	this.rows[j] = temp
}
type dbFaceBPayRecordTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_rows map[int32]*dbFaceBPayRecordRow
	m_new_rows map[int32]*dbFaceBPayRecordRow
	m_removed_rows map[int32]*dbFaceBPayRecordRow
	m_gc_n int32
	m_gcing int32
	m_pool_size int32
	m_preload_select_stmt *sql.Stmt
	m_preload_max_id int32
	m_load_select_stmt *sql.Stmt
	m_save_insert_stmt *sql.Stmt
	m_delete_stmt *sql.Stmt
	m_max_id int32
	m_max_id_changed bool
}
func new_dbFaceBPayRecordTable(dbc *DBC) (this *dbFaceBPayRecordTable) {
	this = &dbFaceBPayRecordTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	this.m_rows = make(map[int32]*dbFaceBPayRecordRow)
	this.m_new_rows = make(map[int32]*dbFaceBPayRecordRow)
	this.m_removed_rows = make(map[int32]*dbFaceBPayRecordRow)
	return this
}
func (this *dbFaceBPayRecordTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS FaceBPayRecordsMaxId(PlaceHolder int(11),MaxKeyId int(11),PRIMARY KEY (PlaceHolder))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS FaceBPayRecordsMaxId failed")
		return
	}
	r := this.m_dbc.QueryRow("SELECT Count(*) FROM FaceBPayRecordsMaxId WHERE PlaceHolder=0")
	if r != nil {
		var count int32
		err = r.Scan(&count)
		if err != nil {
			log.Error("scan count failed")
			return
		}
		if count == 0 {
		_, err = this.m_dbc.Exec("INSERT INTO FaceBPayRecordsMaxId (PlaceHolder,MaxKeyId) VALUES (0,0)")
			if err != nil {
				log.Error("INSERTFaceBPayRecordsMaxId failed")
				return
			}
		}
	}
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS FaceBPayRecords(KeyId int(11),PRIMARY KEY (KeyId))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS FaceBPayRecords failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='FaceBPayRecords'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasSn := columns["Sn"]
	if !hasSn {
		_, err = this.m_dbc.Exec("ALTER TABLE FaceBPayRecords ADD COLUMN Sn varchar(45)")
		if err != nil {
			log.Error("ADD COLUMN Sn failed")
			return
		}
	}
	_, hasBid := columns["Bid"]
	if !hasBid {
		_, err = this.m_dbc.Exec("ALTER TABLE FaceBPayRecords ADD COLUMN Bid varchar(45)")
		if err != nil {
			log.Error("ADD COLUMN Bid failed")
			return
		}
	}
	_, hasPlayerId := columns["PlayerId"]
	if !hasPlayerId {
		_, err = this.m_dbc.Exec("ALTER TABLE FaceBPayRecords ADD COLUMN PlayerId int(11)")
		if err != nil {
			log.Error("ADD COLUMN PlayerId failed")
			return
		}
	}
	_, hasPayTime := columns["PayTime"]
	if !hasPayTime {
		_, err = this.m_dbc.Exec("ALTER TABLE FaceBPayRecords ADD COLUMN PayTime int(11)")
		if err != nil {
			log.Error("ADD COLUMN PayTime failed")
			return
		}
	}
	return
}
func (this *dbFaceBPayRecordTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT KeyId,Sn FROM FaceBPayRecords")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbFaceBPayRecordTable) prepare_load_select_stmt() (err error) {
	this.m_load_select_stmt,err=this.m_dbc.StmtPrepare("SELECT Bid,PlayerId,PayTime FROM FaceBPayRecords WHERE KeyId=?")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbFaceBPayRecordTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO FaceBPayRecords (KeyId,Sn,Bid,PlayerId,PayTime) VALUES (?,?,?,?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbFaceBPayRecordTable) prepare_delete_stmt() (err error) {
	this.m_delete_stmt,err=this.m_dbc.StmtPrepare("DELETE FROM FaceBPayRecords WHERE KeyId=?")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbFaceBPayRecordTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_load_select_stmt()
	if err!=nil{
		log.Error("prepare_load_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	err=this.prepare_delete_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbFaceBPayRecordTable) Preload() (err error) {
	r_max_id := this.m_dbc.QueryRow("SELECT MaxKeyId FROM FaceBPayRecordsMaxId WHERE PLACEHOLDER=0")
	if r_max_id != nil {
		err = r_max_id.Scan(&this.m_max_id)
		if err != nil {
			log.Error("scan max id failed")
			return
		}
	}
	r, err := this.m_dbc.StmtQuery(this.m_preload_select_stmt)
	if err != nil {
		log.Error("SELECT")
		return
	}
	var KeyId int32
	var dSn string
	for r.Next() {
		err = r.Scan(&KeyId,&dSn)
		if err != nil {
			log.Error("Scan")
			return
		}
		if KeyId>this.m_max_id{
			log.Error("max id ext")
			this.m_max_id = KeyId
			this.m_max_id_changed = true
		}
		row := new_dbFaceBPayRecordRow(this,KeyId)
		row.m_Sn=dSn
		row.m_Sn_changed=false
		row.m_valid = true
		this.m_rows[KeyId]=row
	}
	return
}
func (this *dbFaceBPayRecordTable) GetPreloadedMaxId() (max_id int32) {
	return this.m_preload_max_id
}
func (this *dbFaceBPayRecordTable) fetch_rows(rows map[int32]*dbFaceBPayRecordRow) (r map[int32]*dbFaceBPayRecordRow) {
	this.m_lock.UnSafeLock("dbFaceBPayRecordTable.fetch_rows")
	defer this.m_lock.UnSafeUnlock()
	r = make(map[int32]*dbFaceBPayRecordRow)
	for i, v := range rows {
		r[i] = v
	}
	return r
}
func (this *dbFaceBPayRecordTable) fetch_new_rows() (new_rows map[int32]*dbFaceBPayRecordRow) {
	this.m_lock.UnSafeLock("dbFaceBPayRecordTable.fetch_new_rows")
	defer this.m_lock.UnSafeUnlock()
	new_rows = make(map[int32]*dbFaceBPayRecordRow)
	for i, v := range this.m_new_rows {
		_, has := this.m_rows[i]
		if has {
			log.Error("rows already has new rows %v", i)
			continue
		}
		this.m_rows[i] = v
		new_rows[i] = v
	}
	for i, _ := range new_rows {
		delete(this.m_new_rows, i)
	}
	return
}
func (this *dbFaceBPayRecordTable) save_rows(rows map[int32]*dbFaceBPayRecordRow, quick bool) {
	for _, v := range rows {
		if this.m_dbc.m_quit && !quick {
			return
		}
		err, delay, _ := v.Save(false)
		if err != nil {
			log.Error("save failed %v", err)
		}
		if this.m_dbc.m_quit && !quick {
			return
		}
		if delay&&!quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
}
func (this *dbFaceBPayRecordTable) Save(quick bool) (err error){
	if this.m_max_id_changed {
		max_id := atomic.LoadInt32(&this.m_max_id)
		_, err := this.m_dbc.Exec("UPDATE FaceBPayRecordsMaxId SET MaxKeyId=?", max_id)
		if err != nil {
			log.Error("save max id failed %v", err)
		}
	}
	removed_rows := this.fetch_rows(this.m_removed_rows)
	for _, v := range removed_rows {
		_, err := this.m_dbc.StmtExec(this.m_delete_stmt, v.GetKeyId())
		if err != nil {
			log.Error("exec delete stmt failed %v", err)
		}
		v.m_valid = false
		if !quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
	this.m_removed_rows = make(map[int32]*dbFaceBPayRecordRow)
	rows := this.fetch_rows(this.m_rows)
	this.save_rows(rows, quick)
	new_rows := this.fetch_new_rows()
	this.save_rows(new_rows, quick)
	return
}
func (this *dbFaceBPayRecordTable) AddRow() (row *dbFaceBPayRecordRow) {
	this.GC()
	this.m_lock.UnSafeLock("dbFaceBPayRecordTable.AddRow")
	defer this.m_lock.UnSafeUnlock()
	KeyId := atomic.AddInt32(&this.m_max_id, 1)
	this.m_max_id_changed = true
	row = new_dbFaceBPayRecordRow(this,KeyId)
	row.m_new = true
	row.m_loaded = true
	row.m_valid = true
	this.m_new_rows[KeyId] = row
	atomic.AddInt32(&this.m_gc_n,1)
	return row
}
func (this *dbFaceBPayRecordTable) RemoveRow(KeyId int32) {
	this.m_lock.UnSafeLock("dbFaceBPayRecordTable.RemoveRow")
	defer this.m_lock.UnSafeUnlock()
	row := this.m_rows[KeyId]
	if row != nil {
		row.m_remove = true
		row = this.m_removed_rows[KeyId]
		if row != nil {
			log.Error("rows and removed rows both has %v", KeyId)
			row.m_remove = true
			delete(this.m_rows,KeyId)
			this.m_removed_rows[KeyId] = row
		} else {
			delete(this.m_rows, KeyId)
		}
		_, has_new := this.m_new_rows[KeyId]
		if has_new {
			delete(this.m_new_rows, KeyId)
			log.Error("rows and new_rows both has %v", KeyId)
		}
	} else {
		row = this.m_removed_rows[KeyId]
		if row == nil {
			_, has_new := this.m_new_rows[KeyId]
			if has_new {
				delete(this.m_new_rows, KeyId)
			} else {
				log.Error("row not exist %v", KeyId)
			}
		} else {
			log.Error("already removed %v", KeyId)
			_, has_new := this.m_new_rows[KeyId]
			if has_new {
				delete(this.m_new_rows, KeyId)
				log.Error("removed rows and new_rows both has %v", KeyId)
			}
		}
	}
}
func (this *dbFaceBPayRecordTable) GetRow(KeyId int32) (row *dbFaceBPayRecordRow) {
	this.m_lock.UnSafeRLock("dbFaceBPayRecordTable.GetRow")
	defer this.m_lock.UnSafeRUnlock()
	row = this.m_rows[KeyId]
	if row == nil {
		row = this.m_new_rows[KeyId]
	}
	return row
}
func (this *dbFaceBPayRecordTable) SetPoolSize(n int32) {
	this.m_pool_size = n
}
func (this *dbFaceBPayRecordTable) GC() {
	if this.m_pool_size<=0{
		return
	}
	if !atomic.CompareAndSwapInt32(&this.m_gcing, 0, 1) {
		return
	}
	defer atomic.StoreInt32(&this.m_gcing, 0)
	n := atomic.LoadInt32(&this.m_gc_n)
	if float32(n) < float32(this.m_pool_size)*1.2 {
		return
	}
	max := (n - this.m_pool_size) / 2
	arr := dbFaceBPayRecordRowSort{}
	rows := this.fetch_rows(this.m_rows)
	arr.rows = make([]*dbFaceBPayRecordRow, len(rows))
	index := 0
	for _, v := range rows {
		arr.rows[index] = v
		index++
	}
	sort.Sort(&arr)
	count := int32(0)
	for _, v := range arr.rows {
		err, _, released := v.Save(true)
		if err != nil {
			log.Error("release failed %v", err)
			continue
		}
		if released {
			count++
			if count > max {
				return
			}
		}
	}
	return
}
type dbTongTongDataColumn struct{
	m_row *dbTongRow
	m_data *dbTongTongDataData
	m_changed bool
}
func (this *dbTongTongDataColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_data = &dbTongTongDataData{}
		this.m_changed = false
		return nil
	}
	pb := &db.TongTongData{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetTongId())
		return
	}
	this.m_data = &dbTongTongDataData{}
	this.m_data.from_pb(pb)
	this.m_changed = false
	return
}
func (this *dbTongTongDataColumn)save( )(data []byte,err error){
	pb:=this.m_data.to_pb()
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetTongId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbTongTongDataColumn)Get( )(v *dbTongTongDataData ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v=&dbTongTongDataData{}
	this.m_data.clone_to(v)
	return
}
func (this *dbTongTongDataColumn)Set(v dbTongTongDataData ){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=&dbTongTongDataData{}
	v.clone_to(this.m_data)
	this.m_changed=true
	return
}
func (this *dbTongTongDataColumn)GetName( )(v string ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.Name
	return
}
func (this *dbTongTongDataColumn)SetName(v string){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetName")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Name = v
	this.m_changed = true
	return
}
func (this *dbTongTongDataColumn)GetPubContent( )(v string ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetPubContent")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.PubContent
	return
}
func (this *dbTongTongDataColumn)SetPubContent(v string){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetPubContent")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.PubContent = v
	this.m_changed = true
	return
}
func (this *dbTongTongDataColumn)GetWeekDonate( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetWeekDonate")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.WeekDonate
	return
}
func (this *dbTongTongDataColumn)SetWeekDonate(v int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetWeekDonate")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.WeekDonate = v
	this.m_changed = true
	return
}
func (this *dbTongTongDataColumn)IncbyWeekDonate(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.IncbyWeekDonate")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.WeekDonate += v
	this.m_changed = true
	return this.m_data.WeekDonate
}
func (this *dbTongTongDataColumn)GetJoinType( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetJoinType")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.JoinType)
	return
}
func (this *dbTongTongDataColumn)SetJoinType(v int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetJoinType")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.JoinType = int8(v)
	this.m_changed = true
	return
}
func (this *dbTongTongDataColumn)GetJoinScore( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetJoinScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.JoinScore)
	return
}
func (this *dbTongTongDataColumn)SetJoinScore(v int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetJoinScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.JoinScore = int16(v)
	this.m_changed = true
	return
}
func (this *dbTongTongDataColumn)GetPos( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetPos")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.Pos)
	return
}
func (this *dbTongTongDataColumn)SetPos(v int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetPos")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Pos = int16(v)
	this.m_changed = true
	return
}
func (this *dbTongTongDataColumn)GetIcon( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetIcon")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = int32(this.m_data.Icon)
	return
}
func (this *dbTongTongDataColumn)SetIcon(v int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetIcon")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.Icon = int16(v)
	this.m_changed = true
	return
}
func (this *dbTongTongDataColumn)GetCaptainId( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetCaptainId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.CaptainId
	return
}
func (this *dbTongTongDataColumn)SetCaptainId(v int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetCaptainId")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.CaptainId = v
	this.m_changed = true
	return
}
func (this *dbTongTongDataColumn)GetTongChestScore( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetTongChestScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.TongChestScore
	return
}
func (this *dbTongTongDataColumn)SetTongChestScore(v int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetTongChestScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.TongChestScore = v
	this.m_changed = true
	return
}
func (this *dbTongTongDataColumn)IncbyTongChestScore(v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.IncbyTongChestScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.TongChestScore += v
	this.m_changed = true
	return this.m_data.TongChestScore
}
func (this *dbTongTongDataColumn)GetIfTongChestClear( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetIfTongChestClear")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.IfTongChestClear
	return
}
func (this *dbTongTongDataColumn)SetIfTongChestClear(v int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetIfTongChestClear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.IfTongChestClear = v
	this.m_changed = true
	return
}
func (this *dbTongTongDataColumn)GetLastWeekDonateUpWeek( )(v int32 ){
	this.m_row.m_lock.UnSafeRLock("dbTongTongDataColumn.GetLastWeekDonateUpWeek")
	defer this.m_row.m_lock.UnSafeRUnlock()
	v = this.m_data.LastWeekDonateUpWeek
	return
}
func (this *dbTongTongDataColumn)SetLastWeekDonateUpWeek(v int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongDataColumn.SetLastWeekDonateUpWeek")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data.LastWeekDonateUpWeek = v
	this.m_changed = true
	return
}
type dbTongTongMemberColumn struct{
	m_row *dbTongRow
	m_data map[int32]*dbTongTongMemberData
	m_max_id int32
	m_changed bool
}
func (this *dbTongTongMemberColumn)load(max_id int32, data []byte)(err error){
	this.m_max_id=max_id
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.TongTongMemberList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetTongId())
		return
	}
	for _, v := range pb.List {
		d := &dbTongTongMemberData{}
		d.from_pb(v)
		this.m_data[int32(d.MemberId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbTongTongMemberColumn)save( )(max_id int32,data []byte,err error){
	max_id=this.m_max_id

	pb := &db.TongTongMemberList{}
	pb.List=make([]*db.TongTongMember,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetTongId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbTongTongMemberColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbTongTongMemberColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbTongTongMemberColumn)GetAll()(list []dbTongTongMemberData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbTongTongMemberData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbTongTongMemberColumn)Get(id int32)(v *dbTongTongMemberData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbTongTongMemberData{}
	d.clone_to(v)
	return
}
func (this *dbTongTongMemberColumn)Set(v dbTongTongMemberData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.MemberId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), v.MemberId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbTongTongMemberColumn)Add(v *dbTongTongMemberData)(id int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_max_id++
	id=this.m_max_id
	v.MemberId=id
	d:=&dbTongTongMemberData{}
	v.clone_to(d)
	this.m_data[v.MemberId]=d
	this.m_changed = true
	return
}
func (this *dbTongTongMemberColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbTongTongMemberColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbTongTongMemberData)
	this.m_changed = true
	return
}
func (this *dbTongTongMemberColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbTongTongMemberColumn)GetPlayerId(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetPlayerId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.PlayerId
	return v,true
}
func (this *dbTongTongMemberColumn)SetPlayerId(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.SetPlayerId")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.PlayerId = v
	this.m_changed = true
	return true
}
func (this *dbTongTongMemberColumn)NumByPlayerId(v int32)(n int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.NumByPlayerId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	n = 0
	for _, d := range this.m_data {
		if d.PlayerId==v{
			n++
		}
	}
	return
}
func (this *dbTongTongMemberColumn)FindAllByPlayerId(v int32)(list []*dbTongTongMemberData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.FindAllByPlayerId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	n := 0
	for _, d := range this.m_data {
		if d.PlayerId==v{
			n++
		}
	}
	list = make([]*dbTongTongMemberData, n)
	i := 0
	for _, d := range this.m_data {
		if d.PlayerId==v{
		data := &dbTongTongMemberData{}
		d.clone_to(data)
		list[i] = data
		i++
		}
	}
	return
}
func (this *dbTongTongMemberColumn)FindOneByPlayerId(v int32)(r *dbTongTongMemberData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.FindOneByPlayerId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for _, d := range this.m_data {
		if d.PlayerId==v{
			r = &dbTongTongMemberData{}
			d.clone_to(r)
			break
		}
	}
	return
}
func (this *dbTongTongMemberColumn)RemoveAllByPlayerId(p int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.RemoveAllByPlayerId")
	defer this.m_row.m_lock.UnSafeUnlock()
	for i,v:=range this.m_data{
		if v.PlayerId==p{
			delete(this.m_data,i)
		}
	}
	this.m_changed = true
	return
}
func (this *dbTongTongMemberColumn)GetPlayerName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetPlayerName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.PlayerName
	return v,true
}
func (this *dbTongTongMemberColumn)SetPlayerName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.SetPlayerName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.PlayerName = v
	this.m_changed = true
	return true
}
func (this *dbTongTongMemberColumn)GetScore(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = int32(d.Score)
	return v,true
}
func (this *dbTongTongMemberColumn)SetScore(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.SetScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.Score = int16(v)
	this.m_changed = true
	return true
}
func (this *dbTongTongMemberColumn)NumByScore(v int32)(n int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.NumByScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	n = 0
	for _, d := range this.m_data {
		if d.Score==int16(v){
			n++
		}
	}
	return
}
func (this *dbTongTongMemberColumn)FindAllByScore(v int32)(list []*dbTongTongMemberData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.FindAllByScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	n := 0
	for _, d := range this.m_data {
		if d.Score==int16(v){
			n++
		}
	}
	list = make([]*dbTongTongMemberData, n)
	i := 0
	for _, d := range this.m_data {
		if d.Score==int16(v){
		data := &dbTongTongMemberData{}
		d.clone_to(data)
		list[i] = data
		i++
		}
	}
	return
}
func (this *dbTongTongMemberColumn)FindOneByScore(v int32)(r *dbTongTongMemberData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.FindOneByScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for _, d := range this.m_data {
		if d.Score==int16(v){
			r = &dbTongTongMemberData{}
			d.clone_to(r)
			break
		}
	}
	return
}
func (this *dbTongTongMemberColumn)RemoveAllByScore(p int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.RemoveAllByScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	for i,v:=range this.m_data{
		if v.Score==int16(p){
			delete(this.m_data,i)
		}
	}
	this.m_changed = true
	return
}
func (this *dbTongTongMemberColumn)GetDonate(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetDonate")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = int32(d.Donate)
	return v,true
}
func (this *dbTongTongMemberColumn)SetDonate(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.SetDonate")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.Donate = int16(v)
	this.m_changed = true
	return true
}
func (this *dbTongTongMemberColumn)IncbyDonate(id int32,v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.IncbyDonate")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		d = &dbTongTongMemberData{}
		this.m_data[id] = d
	}
	d.Donate += int16(v)
	this.m_changed = true
	return int32(d.Donate)
}
func (this *dbTongTongMemberColumn)GetMemberType(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongMemberColumn.GetMemberType")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = int32(d.MemberType)
	return v,true
}
func (this *dbTongTongMemberColumn)SetMemberType(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongMemberColumn.SetMemberType")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.MemberType = int8(v)
	this.m_changed = true
	return true
}
type dbTongTongJoinColumn struct{
	m_row *dbTongRow
	m_data map[int32]*dbTongTongJoinData
	m_changed bool
}
func (this *dbTongTongJoinColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.TongTongJoinList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetTongId())
		return
	}
	for _, v := range pb.List {
		d := &dbTongTongJoinData{}
		d.from_pb(v)
		this.m_data[int32(d.PlayerId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbTongTongJoinColumn)save( )(data []byte,err error){
	pb := &db.TongTongJoinList{}
	pb.List=make([]*db.TongTongJoin,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetTongId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbTongTongJoinColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongJoinColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbTongTongJoinColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongJoinColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbTongTongJoinColumn)GetAll()(list []dbTongTongJoinData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongJoinColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbTongTongJoinData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbTongTongJoinColumn)Get(id int32)(v *dbTongTongJoinData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongJoinColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbTongTongJoinData{}
	d.clone_to(v)
	return
}
func (this *dbTongTongJoinColumn)Set(v dbTongTongJoinData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongJoinColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.PlayerId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), v.PlayerId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbTongTongJoinColumn)Add(v *dbTongTongJoinData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongJoinColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.PlayerId)]
	if has {
		log.Error("already added %v %v",this.m_row.GetTongId(), v.PlayerId)
		return false
	}
	d:=&dbTongTongJoinData{}
	v.clone_to(d)
	this.m_data[int32(v.PlayerId)]=d
	this.m_changed = true
	return true
}
func (this *dbTongTongJoinColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongJoinColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbTongTongJoinColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbTongTongJoinColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbTongTongJoinData)
	this.m_changed = true
	return
}
func (this *dbTongTongJoinColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongJoinColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbTongTongJoinColumn)GetPlayerName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongJoinColumn.GetPlayerName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.PlayerName
	return v,true
}
func (this *dbTongTongJoinColumn)SetPlayerName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongJoinColumn.SetPlayerName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.PlayerName = v
	this.m_changed = true
	return true
}
func (this *dbTongTongJoinColumn)GetJoinSec(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongJoinColumn.GetJoinSec")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.JoinSec
	return v,true
}
func (this *dbTongTongJoinColumn)SetJoinSec(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongJoinColumn.SetJoinSec")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.JoinSec = v
	this.m_changed = true
	return true
}
func (this *dbTongTongJoinColumn)GetPlayerScore(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongJoinColumn.GetPlayerScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.PlayerScore
	return v,true
}
func (this *dbTongTongJoinColumn)SetPlayerScore(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongJoinColumn.SetPlayerScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.PlayerScore = v
	this.m_changed = true
	return true
}
type dbTongTongChatRecordColumn struct{
	m_row *dbTongRow
	m_data map[int32]*dbTongTongChatRecordData
	m_changed bool
}
func (this *dbTongTongChatRecordColumn)load(data []byte)(err error){
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.TongTongChatRecordList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetTongId())
		return
	}
	for _, v := range pb.List {
		d := &dbTongTongChatRecordData{}
		d.from_pb(v)
		this.m_data[int32(d.Index)] = d
	}
	this.m_changed = false
	return
}
func (this *dbTongTongChatRecordColumn)save( )(data []byte,err error){
	pb := &db.TongTongChatRecordList{}
	pb.List=make([]*db.TongTongChatRecord,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetTongId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbTongTongChatRecordColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChatRecordColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbTongTongChatRecordColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChatRecordColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbTongTongChatRecordColumn)GetAll()(list []dbTongTongChatRecordData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChatRecordColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbTongTongChatRecordData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbTongTongChatRecordColumn)Get(id int32)(v *dbTongTongChatRecordData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChatRecordColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbTongTongChatRecordData{}
	d.clone_to(v)
	return
}
func (this *dbTongTongChatRecordColumn)Set(v dbTongTongChatRecordData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongChatRecordColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.Index)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), v.Index)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbTongTongChatRecordColumn)Add(v *dbTongTongChatRecordData)(ok bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongChatRecordColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[int32(v.Index)]
	if has {
		log.Error("already added %v %v",this.m_row.GetTongId(), v.Index)
		return false
	}
	d:=&dbTongTongChatRecordData{}
	v.clone_to(d)
	this.m_data[int32(v.Index)]=d
	this.m_changed = true
	return true
}
func (this *dbTongTongChatRecordColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongChatRecordColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbTongTongChatRecordColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbTongTongChatRecordColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbTongTongChatRecordData)
	this.m_changed = true
	return
}
func (this *dbTongTongChatRecordColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChatRecordColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbTongTongChatRecordColumn)GetSenderId(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChatRecordColumn.GetSenderId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.SenderId
	return v,true
}
func (this *dbTongTongChatRecordColumn)SetSenderId(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongChatRecordColumn.SetSenderId")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.SenderId = v
	this.m_changed = true
	return true
}
func (this *dbTongTongChatRecordColumn)GetSenderName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChatRecordColumn.GetSenderName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.SenderName
	return v,true
}
func (this *dbTongTongChatRecordColumn)SetSenderName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongChatRecordColumn.SetSenderName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.SenderName = v
	this.m_changed = true
	return true
}
func (this *dbTongTongChatRecordColumn)GetMsgContent(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChatRecordColumn.GetMsgContent")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MsgContent
	return v,true
}
func (this *dbTongTongChatRecordColumn)SetMsgContent(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongChatRecordColumn.SetMsgContent")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.MsgContent = v
	this.m_changed = true
	return true
}
func (this *dbTongTongChatRecordColumn)GetSendTime(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChatRecordColumn.GetSendTime")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.SendTime
	return v,true
}
func (this *dbTongTongChatRecordColumn)SetSendTime(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongChatRecordColumn.SetSendTime")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.SendTime = v
	this.m_changed = true
	return true
}
type dbTongTongCardReqColumn struct{
	m_row *dbTongRow
	m_data map[int32]*dbTongTongCardReqData
	m_max_id int32
	m_changed bool
}
func (this *dbTongTongCardReqColumn)load(max_id int32, data []byte)(err error){
	this.m_max_id=max_id
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.TongTongCardReqList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetTongId())
		return
	}
	for _, v := range pb.List {
		d := &dbTongTongCardReqData{}
		d.from_pb(v)
		this.m_data[int32(d.PlayerId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbTongTongCardReqColumn)save( )(max_id int32,data []byte,err error){
	max_id=this.m_max_id

	pb := &db.TongTongCardReqList{}
	pb.List=make([]*db.TongTongCardReq,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetTongId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbTongTongCardReqColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbTongTongCardReqColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbTongTongCardReqColumn)GetAll()(list []dbTongTongCardReqData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbTongTongCardReqData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbTongTongCardReqColumn)Get(id int32)(v *dbTongTongCardReqData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbTongTongCardReqData{}
	d.clone_to(v)
	return
}
func (this *dbTongTongCardReqColumn)Set(v dbTongTongCardReqData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.PlayerId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), v.PlayerId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbTongTongCardReqColumn)Add(v *dbTongTongCardReqData)(id int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_max_id++
	id=this.m_max_id
	v.PlayerId=id
	d:=&dbTongTongCardReqData{}
	v.clone_to(d)
	this.m_data[v.PlayerId]=d
	this.m_changed = true
	return
}
func (this *dbTongTongCardReqColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbTongTongCardReqColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbTongTongCardReqData)
	this.m_changed = true
	return
}
func (this *dbTongTongCardReqColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbTongTongCardReqColumn)GetPlayerName(id int32)(v string ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.GetPlayerName")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.PlayerName
	return v,true
}
func (this *dbTongTongCardReqColumn)SetPlayerName(id int32,v string)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.SetPlayerName")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.PlayerName = v
	this.m_changed = true
	return true
}
func (this *dbTongTongCardReqColumn)GetCardCfgId(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.GetCardCfgId")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.CardCfgId
	return v,true
}
func (this *dbTongTongCardReqColumn)SetCardCfgId(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.SetCardCfgId")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.CardCfgId = v
	this.m_changed = true
	return true
}
func (this *dbTongTongCardReqColumn)GetCurGetNum(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.GetCurGetNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.CurGetNum
	return v,true
}
func (this *dbTongTongCardReqColumn)SetCurGetNum(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.SetCurGetNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.CurGetNum = v
	this.m_changed = true
	return true
}
func (this *dbTongTongCardReqColumn)GetMaxGetNum(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.GetMaxGetNum")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.MaxGetNum
	return v,true
}
func (this *dbTongTongCardReqColumn)SetMaxGetNum(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.SetMaxGetNum")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.MaxGetNum = v
	this.m_changed = true
	return true
}
func (this *dbTongTongCardReqColumn)GetReqUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongCardReqColumn.GetReqUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.ReqUnix
	return v,true
}
func (this *dbTongTongCardReqColumn)SetReqUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongCardReqColumn.SetReqUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.ReqUnix = v
	this.m_changed = true
	return true
}
type dbTongTongChestOpenColumn struct{
	m_row *dbTongRow
	m_data map[int32]*dbTongTongChestOpenData
	m_max_id int32
	m_changed bool
}
func (this *dbTongTongChestOpenColumn)load(max_id int32, data []byte)(err error){
	this.m_max_id=max_id
	if data == nil || len(data) == 0 {
		this.m_changed = false
		return nil
	}
	pb := &db.TongTongChestOpenList{}
	err = proto.Unmarshal(data, pb)
	if err != nil {
		log.Error("Unmarshal %v", this.m_row.GetTongId())
		return
	}
	for _, v := range pb.List {
		d := &dbTongTongChestOpenData{}
		d.from_pb(v)
		this.m_data[int32(d.PlayerId)] = d
	}
	this.m_changed = false
	return
}
func (this *dbTongTongChestOpenColumn)save( )(max_id int32,data []byte,err error){
	max_id=this.m_max_id

	pb := &db.TongTongChestOpenList{}
	pb.List=make([]*db.TongTongChestOpen,len(this.m_data))
	i:=0
	for _, v := range this.m_data {
		pb.List[i] = v.to_pb()
		i++
	}
	data, err = proto.Marshal(pb)
	if err != nil {
		log.Error("Marshal %v", this.m_row.GetTongId())
		return
	}
	this.m_changed = false
	return
}
func (this *dbTongTongChestOpenColumn)HasIndex(id int32)(has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChestOpenColumn.HasIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	_, has = this.m_data[id]
	return
}
func (this *dbTongTongChestOpenColumn)GetAllIndex()(list []int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChestOpenColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]int32, len(this.m_data))
	i := 0
	for k, _ := range this.m_data {
		list[i] = k
		i++
	}
	return
}
func (this *dbTongTongChestOpenColumn)GetAll()(list []dbTongTongChestOpenData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChestOpenColumn.GetAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	list = make([]dbTongTongChestOpenData, len(this.m_data))
	i := 0
	for _, v := range this.m_data {
		v.clone_to(&list[i])
		i++
	}
	return
}
func (this *dbTongTongChestOpenColumn)Get(id int32)(v *dbTongTongChestOpenData){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChestOpenColumn.Get")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return nil
	}
	v=&dbTongTongChestOpenData{}
	d.clone_to(v)
	return
}
func (this *dbTongTongChestOpenColumn)Set(v dbTongTongChestOpenData)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongChestOpenColumn.Set")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[int32(v.PlayerId)]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), v.PlayerId)
		return false
	}
	v.clone_to(d)
	this.m_changed = true
	return true
}
func (this *dbTongTongChestOpenColumn)Add(v *dbTongTongChestOpenData)(id int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongChestOpenColumn.Add")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_max_id++
	id=this.m_max_id
	v.PlayerId=id
	d:=&dbTongTongChestOpenData{}
	v.clone_to(d)
	this.m_data[v.PlayerId]=d
	this.m_changed = true
	return
}
func (this *dbTongTongChestOpenColumn)Remove(id int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongChestOpenColumn.Remove")
	defer this.m_row.m_lock.UnSafeUnlock()
	_, has := this.m_data[id]
	if has {
		delete(this.m_data,id)
	}
	this.m_changed = true
	return
}
func (this *dbTongTongChestOpenColumn)Clear(){
	this.m_row.m_lock.UnSafeLock("dbTongTongChestOpenColumn.Clear")
	defer this.m_row.m_lock.UnSafeUnlock()
	this.m_data=make(map[int32]*dbTongTongChestOpenData)
	this.m_changed = true
	return
}
func (this *dbTongTongChestOpenColumn)NumAll()(n int32){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChestOpenColumn.NumAll")
	defer this.m_row.m_lock.UnSafeRUnlock()
	return int32(len(this.m_data))
}
func (this *dbTongTongChestOpenColumn)GetWinScore(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChestOpenColumn.GetWinScore")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.WinScore
	return v,true
}
func (this *dbTongTongChestOpenColumn)SetWinScore(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongChestOpenColumn.SetWinScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.WinScore = v
	this.m_changed = true
	return true
}
func (this *dbTongTongChestOpenColumn)IncbyWinScore(id int32,v int32)(r int32){
	this.m_row.m_lock.UnSafeLock("dbTongTongChestOpenColumn.IncbyWinScore")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		d = &dbTongTongChestOpenData{}
		this.m_data[id] = d
	}
	d.WinScore +=  v
	this.m_changed = true
	return d.WinScore
}
func (this *dbTongTongChestOpenColumn)GetReqUnix(id int32)(v int32 ,has bool){
	this.m_row.m_lock.UnSafeRLock("dbTongTongChestOpenColumn.GetReqUnix")
	defer this.m_row.m_lock.UnSafeRUnlock()
	d := this.m_data[id]
	if d==nil{
		return
	}
	v = d.ReqUnix
	return v,true
}
func (this *dbTongTongChestOpenColumn)SetReqUnix(id int32,v int32)(has bool){
	this.m_row.m_lock.UnSafeLock("dbTongTongChestOpenColumn.SetReqUnix")
	defer this.m_row.m_lock.UnSafeUnlock()
	d := this.m_data[id]
	if d==nil{
		log.Error("not exist %v %v",this.m_row.GetTongId(), id)
		return
	}
	d.ReqUnix = v
	this.m_changed = true
	return true
}
type dbTongRow struct {
	m_table *dbTongTable
	m_lock       *RWMutex
	m_loaded  bool
	m_new     bool
	m_remove  bool
	m_touch      int32
	m_releasable bool
	m_valid   bool
	m_TongId        int32
	TongData dbTongTongDataColumn
	TongMembers dbTongTongMemberColumn
	TongJoins dbTongTongJoinColumn
	TongChatRecords dbTongTongChatRecordColumn
	TongCardReqs dbTongTongCardReqColumn
	TongChestOpens dbTongTongChestOpenColumn
}
func new_dbTongRow(table *dbTongTable, TongId int32) (r *dbTongRow) {
	this := &dbTongRow{}
	this.m_table = table
	this.m_TongId = TongId
	this.m_lock = NewRWMutex()
	this.TongData.m_row=this
	this.TongData.m_data=&dbTongTongDataData{}
	this.TongMembers.m_row=this
	this.TongMembers.m_data=make(map[int32]*dbTongTongMemberData)
	this.TongJoins.m_row=this
	this.TongJoins.m_data=make(map[int32]*dbTongTongJoinData)
	this.TongChatRecords.m_row=this
	this.TongChatRecords.m_data=make(map[int32]*dbTongTongChatRecordData)
	this.TongCardReqs.m_row=this
	this.TongCardReqs.m_data=make(map[int32]*dbTongTongCardReqData)
	this.TongChestOpens.m_row=this
	this.TongChestOpens.m_data=make(map[int32]*dbTongTongChestOpenData)
	return this
}
func (this *dbTongRow) GetTongId() (r int32) {
	return this.m_TongId
}
func (this *dbTongRow) save_data(release bool) (err error, released bool, state int32, update_string string, args []interface{}) {
	this.m_lock.UnSafeLock("dbTongRow.save_data")
	defer this.m_lock.UnSafeUnlock()
	if this.m_new {
		db_args:=new_db_args(10)
		db_args.Push(this.m_TongId)
		dTongData,db_err:=this.TongData.save()
		if db_err!=nil{
			log.Error("insert save TongData failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dTongData)
		dMaxTongMemberId,dTongMembers,db_err:=this.TongMembers.save()
		if db_err!=nil{
			log.Error("insert save TongMember failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dMaxTongMemberId)
		db_args.Push(dTongMembers)
		dTongJoins,db_err:=this.TongJoins.save()
		if db_err!=nil{
			log.Error("insert save TongJoin failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dTongJoins)
		dTongChatRecords,db_err:=this.TongChatRecords.save()
		if db_err!=nil{
			log.Error("insert save TongChatRecord failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dTongChatRecords)
		dMaxTongCardReqId,dTongCardReqs,db_err:=this.TongCardReqs.save()
		if db_err!=nil{
			log.Error("insert save TongCardReq failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dMaxTongCardReqId)
		db_args.Push(dTongCardReqs)
		dMaxTongChestOpenId,dTongChestOpens,db_err:=this.TongChestOpens.save()
		if db_err!=nil{
			log.Error("insert save TongChestOpen failed")
			return db_err,false,0,"",nil
		}
		db_args.Push(dMaxTongChestOpenId)
		db_args.Push(dTongChestOpens)
		args=db_args.GetArgs()
		state = 1
	} else {
		if this.TongData.m_changed||this.TongMembers.m_changed||this.TongJoins.m_changed||this.TongChatRecords.m_changed||this.TongCardReqs.m_changed||this.TongChestOpens.m_changed{
			update_string = "UPDATE Tongs SET "
			db_args:=new_db_args(10)
			if this.TongData.m_changed{
				update_string+="TongData=?,"
				dTongData,err:=this.TongData.save()
				if err!=nil{
					log.Error("update save TongData failed")
					return err,false,0,"",nil
				}
				db_args.Push(dTongData)
			}
			if this.TongMembers.m_changed{
				update_string+="MaxTongMemberId=?,"
				update_string+="TongMembers=?,"
				dMaxTongMemberId,dTongMembers,err:=this.TongMembers.save()
				if err!=nil{
					log.Error("insert save TongMember failed")
					return err,false,0,"",nil
				}
				db_args.Push(dMaxTongMemberId)
				db_args.Push(dTongMembers)
			}
			if this.TongJoins.m_changed{
				update_string+="TongJoins=?,"
				dTongJoins,err:=this.TongJoins.save()
				if err!=nil{
					log.Error("insert save TongJoin failed")
					return err,false,0,"",nil
				}
				db_args.Push(dTongJoins)
			}
			if this.TongChatRecords.m_changed{
				update_string+="TongChatRecords=?,"
				dTongChatRecords,err:=this.TongChatRecords.save()
				if err!=nil{
					log.Error("insert save TongChatRecord failed")
					return err,false,0,"",nil
				}
				db_args.Push(dTongChatRecords)
			}
			if this.TongCardReqs.m_changed{
				update_string+="MaxTongCardReqId=?,"
				update_string+="TongCardReqs=?,"
				dMaxTongCardReqId,dTongCardReqs,err:=this.TongCardReqs.save()
				if err!=nil{
					log.Error("insert save TongCardReq failed")
					return err,false,0,"",nil
				}
				db_args.Push(dMaxTongCardReqId)
				db_args.Push(dTongCardReqs)
			}
			if this.TongChestOpens.m_changed{
				update_string+="MaxTongChestOpenId=?,"
				update_string+="TongChestOpens=?,"
				dMaxTongChestOpenId,dTongChestOpens,err:=this.TongChestOpens.save()
				if err!=nil{
					log.Error("insert save TongChestOpen failed")
					return err,false,0,"",nil
				}
				db_args.Push(dMaxTongChestOpenId)
				db_args.Push(dTongChestOpens)
			}
			update_string = strings.TrimRight(update_string, ", ")
			update_string+=" WHERE TongId=?"
			db_args.Push(this.m_TongId)
			args=db_args.GetArgs()
			state = 2
		}
	}
	this.m_new = false
	this.TongData.m_changed = false
	this.TongMembers.m_changed = false
	this.TongJoins.m_changed = false
	this.TongChatRecords.m_changed = false
	this.TongCardReqs.m_changed = false
	this.TongChestOpens.m_changed = false
	if release && this.m_loaded {
		atomic.AddInt32(&this.m_table.m_gc_n, -1)
		this.m_loaded = false
		released = true
	}
	return nil,released,state,update_string,args
}
func (this *dbTongRow) Save(release bool) (err error, d bool, released bool) {
	err,released, state, update_string, args := this.save_data(release)
	if err != nil {
		log.Error("save data failed")
		return err, false, false
	}
	if state == 0 {
		d = false
	} else if state == 1 {
		_, err = this.m_table.m_dbc.StmtExec(this.m_table.m_save_insert_stmt, args...)
		if err != nil {
			log.Error("INSERT Tongs exec failed %v ", this.m_TongId)
			return err, false, released
		}
		d = true
	} else if state == 2 {
		_, err = this.m_table.m_dbc.Exec(update_string, args...)
		if err != nil {
			log.Error("UPDATE Tongs exec failed %v", this.m_TongId)
			return err, false, released
		}
		d = true
	}
	return nil, d, released
}
func (this *dbTongRow) Touch(releasable bool) {
	this.m_touch = int32(time.Now().Unix())
	this.m_releasable = releasable
}
type dbTongRowSort struct {
	rows []*dbTongRow
}
func (this *dbTongRowSort) Len() (length int) {
	return len(this.rows)
}
func (this *dbTongRowSort) Less(i int, j int) (less bool) {
	return this.rows[i].m_touch < this.rows[j].m_touch
}
func (this *dbTongRowSort) Swap(i int, j int) {
	temp := this.rows[i]
	this.rows[i] = this.rows[j]
	this.rows[j] = temp
}
type dbTongTable struct{
	m_dbc *DBC
	m_lock *RWMutex
	m_rows map[int32]*dbTongRow
	m_new_rows map[int32]*dbTongRow
	m_removed_rows map[int32]*dbTongRow
	m_gc_n int32
	m_gcing int32
	m_pool_size int32
	m_preload_select_stmt *sql.Stmt
	m_preload_max_id int32
	m_save_insert_stmt *sql.Stmt
	m_delete_stmt *sql.Stmt
}
func new_dbTongTable(dbc *DBC) (this *dbTongTable) {
	this = &dbTongTable{}
	this.m_dbc = dbc
	this.m_lock = NewRWMutex()
	this.m_rows = make(map[int32]*dbTongRow)
	this.m_new_rows = make(map[int32]*dbTongRow)
	this.m_removed_rows = make(map[int32]*dbTongRow)
	return this
}
func (this *dbTongTable) check_create_table() (err error) {
	_, err = this.m_dbc.Exec("CREATE TABLE IF NOT EXISTS Tongs(TongId int(11),PRIMARY KEY (TongId))ENGINE=MyISAM")
	if err != nil {
		log.Error("CREATE TABLE IF NOT EXISTS Tongs failed")
		return
	}
	rows, err := this.m_dbc.Query("SELECT COLUMN_NAME,ORDINAL_POSITION FROM information_schema.`COLUMNS` WHERE TABLE_SCHEMA=? AND TABLE_NAME='Tongs'", this.m_dbc.m_db_name)
	if err != nil {
		log.Error("SELECT information_schema failed")
		return
	}
	columns := make(map[string]int32)
	for rows.Next() {
		var column_name string
		var ordinal_position int32
		err = rows.Scan(&column_name, &ordinal_position)
		if err != nil {
			log.Error("scan information_schema row failed")
			return
		}
		if ordinal_position < 1 {
			log.Error("col ordinal out of range")
			continue
		}
		columns[column_name] = ordinal_position
	}
	_, hasTongData := columns["TongData"]
	if !hasTongData {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN TongData LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN TongData failed")
			return
		}
	}
	_, hasMaxTongMember := columns["MaxTongMemberId"]
	if !hasMaxTongMember {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN MaxTongMemberId int(11) DEFAULT 0")
		if err != nil {
			log.Error("ADD COLUMN map index MaxTongMemberId failed")
			return
		}
	}
	_, hasTongMember := columns["TongMembers"]
	if !hasTongMember {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN TongMembers LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN TongMembers failed")
			return
		}
	}
	_, hasTongJoin := columns["TongJoins"]
	if !hasTongJoin {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN TongJoins LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN TongJoins failed")
			return
		}
	}
	_, hasTongChatRecord := columns["TongChatRecords"]
	if !hasTongChatRecord {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN TongChatRecords LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN TongChatRecords failed")
			return
		}
	}
	_, hasMaxTongCardReq := columns["MaxTongCardReqId"]
	if !hasMaxTongCardReq {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN MaxTongCardReqId int(11) DEFAULT 0")
		if err != nil {
			log.Error("ADD COLUMN map index MaxTongCardReqId failed")
			return
		}
	}
	_, hasTongCardReq := columns["TongCardReqs"]
	if !hasTongCardReq {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN TongCardReqs LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN TongCardReqs failed")
			return
		}
	}
	_, hasMaxTongChestOpen := columns["MaxTongChestOpenId"]
	if !hasMaxTongChestOpen {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN MaxTongChestOpenId int(11) DEFAULT 0")
		if err != nil {
			log.Error("ADD COLUMN map index MaxTongChestOpenId failed")
			return
		}
	}
	_, hasTongChestOpen := columns["TongChestOpens"]
	if !hasTongChestOpen {
		_, err = this.m_dbc.Exec("ALTER TABLE Tongs ADD COLUMN TongChestOpens LONGBLOB")
		if err != nil {
			log.Error("ADD COLUMN TongChestOpens failed")
			return
		}
	}
	return
}
func (this *dbTongTable) prepare_preload_select_stmt() (err error) {
	this.m_preload_select_stmt,err=this.m_dbc.StmtPrepare("SELECT TongId,TongData,MaxTongMemberId,TongMembers,TongJoins,TongChatRecords,MaxTongCardReqId,TongCardReqs,MaxTongChestOpenId,TongChestOpens FROM Tongs")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbTongTable) prepare_save_insert_stmt()(err error){
	this.m_save_insert_stmt,err=this.m_dbc.StmtPrepare("INSERT INTO Tongs (TongId,TongData,MaxTongMemberId,TongMembers,TongJoins,TongChatRecords,MaxTongCardReqId,TongCardReqs,MaxTongChestOpenId,TongChestOpens) VALUES (?,?,?,?,?,?,?,?,?,?)")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbTongTable) prepare_delete_stmt() (err error) {
	this.m_delete_stmt,err=this.m_dbc.StmtPrepare("DELETE FROM Tongs WHERE TongId=?")
	if err!=nil{
		log.Error("prepare failed")
		return
	}
	return
}
func (this *dbTongTable) Init() (err error) {
	err=this.check_create_table()
	if err!=nil{
		log.Error("check_create_table failed")
		return
	}
	err=this.prepare_preload_select_stmt()
	if err!=nil{
		log.Error("prepare_preload_select_stmt failed")
		return
	}
	err=this.prepare_save_insert_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	err=this.prepare_delete_stmt()
	if err!=nil{
		log.Error("prepare_save_insert_stmt failed")
		return
	}
	return
}
func (this *dbTongTable) Preload() (err error) {
	r, err := this.m_dbc.StmtQuery(this.m_preload_select_stmt)
	if err != nil {
		log.Error("SELECT")
		return
	}
	var TongId int32
	var dTongData []byte
	var dMaxTongMemberId int32
	var dTongMembers []byte
	var dTongJoins []byte
	var dTongChatRecords []byte
	var dMaxTongCardReqId int32
	var dTongCardReqs []byte
	var dMaxTongChestOpenId int32
	var dTongChestOpens []byte
		this.m_preload_max_id = 0
	for r.Next() {
		err = r.Scan(&TongId,&dTongData,&dMaxTongMemberId,&dTongMembers,&dTongJoins,&dTongChatRecords,&dMaxTongCardReqId,&dTongCardReqs,&dMaxTongChestOpenId,&dTongChestOpens)
		if err != nil {
			log.Error("Scan")
			return
		}
		if TongId>this.m_preload_max_id{
			this.m_preload_max_id =TongId
		}
		row := new_dbTongRow(this,TongId)
		err = row.TongData.load(dTongData)
		if err != nil {
			log.Error("TongData %v", TongId)
			return
		}
		err = row.TongMembers.load(dMaxTongMemberId,dTongMembers)
		if err != nil {
			log.Error("TongMembers %v", TongId)
			return
		}
		err = row.TongJoins.load(dTongJoins)
		if err != nil {
			log.Error("TongJoins %v", TongId)
			return
		}
		err = row.TongChatRecords.load(dTongChatRecords)
		if err != nil {
			log.Error("TongChatRecords %v", TongId)
			return
		}
		err = row.TongCardReqs.load(dMaxTongCardReqId,dTongCardReqs)
		if err != nil {
			log.Error("TongCardReqs %v", TongId)
			return
		}
		err = row.TongChestOpens.load(dMaxTongChestOpenId,dTongChestOpens)
		if err != nil {
			log.Error("TongChestOpens %v", TongId)
			return
		}
		row.m_valid = true
		this.m_rows[TongId]=row
	}
	return
}
func (this *dbTongTable) GetPreloadedMaxId() (max_id int32) {
	return this.m_preload_max_id
}
func (this *dbTongTable) fetch_rows(rows map[int32]*dbTongRow) (r map[int32]*dbTongRow) {
	this.m_lock.UnSafeLock("dbTongTable.fetch_rows")
	defer this.m_lock.UnSafeUnlock()
	r = make(map[int32]*dbTongRow)
	for i, v := range rows {
		r[i] = v
	}
	return r
}
func (this *dbTongTable) fetch_new_rows() (new_rows map[int32]*dbTongRow) {
	this.m_lock.UnSafeLock("dbTongTable.fetch_new_rows")
	defer this.m_lock.UnSafeUnlock()
	new_rows = make(map[int32]*dbTongRow)
	for i, v := range this.m_new_rows {
		_, has := this.m_rows[i]
		if has {
			log.Error("rows already has new rows %v", i)
			continue
		}
		this.m_rows[i] = v
		new_rows[i] = v
	}
	for i, _ := range new_rows {
		delete(this.m_new_rows, i)
	}
	return
}
func (this *dbTongTable) save_rows(rows map[int32]*dbTongRow, quick bool) {
	for _, v := range rows {
		if this.m_dbc.m_quit && !quick {
			return
		}
		err, delay, _ := v.Save(false)
		if err != nil {
			log.Error("save failed %v", err)
		}
		if this.m_dbc.m_quit && !quick {
			return
		}
		if delay&&!quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
}
func (this *dbTongTable) Save(quick bool) (err error){
	removed_rows := this.fetch_rows(this.m_removed_rows)
	for _, v := range removed_rows {
		_, err := this.m_dbc.StmtExec(this.m_delete_stmt, v.GetTongId())
		if err != nil {
			log.Error("exec delete stmt failed %v", err)
		}
		v.m_valid = false
		if !quick {
			time.Sleep(time.Millisecond * 5)
		}
	}
	this.m_removed_rows = make(map[int32]*dbTongRow)
	rows := this.fetch_rows(this.m_rows)
	this.save_rows(rows, quick)
	new_rows := this.fetch_new_rows()
	this.save_rows(new_rows, quick)
	return
}
func (this *dbTongTable) AddRow(TongId int32) (row *dbTongRow) {
	this.m_lock.UnSafeLock("dbTongTable.AddRow")
	defer this.m_lock.UnSafeUnlock()
	row = new_dbTongRow(this,TongId)
	row.m_new = true
	row.m_loaded = true
	row.m_valid = true
	_, has := this.m_new_rows[TongId]
	if has{
		log.Error("已经存在 %v", TongId)
		return nil
	}
	this.m_new_rows[TongId] = row
	atomic.AddInt32(&this.m_gc_n,1)
	return row
}
func (this *dbTongTable) RemoveRow(TongId int32) {
	this.m_lock.UnSafeLock("dbTongTable.RemoveRow")
	defer this.m_lock.UnSafeUnlock()
	row := this.m_rows[TongId]
	if row != nil {
		row.m_remove = true
		delete(this.m_rows, TongId)

		rm_row := this.m_removed_rows[TongId]
		if rm_row != nil {
			log.Error("rows and removed rows both has %v", TongId)
		}
		this.m_removed_rows[TongId] = row

		_, has_new := this.m_new_rows[TongId]
		if has_new {
			delete(this.m_new_rows, TongId)
			log.Error("rows and new_rows both has %v", TongId)
		}
	} else {
		row = this.m_removed_rows[TongId]
		if row == nil {
			_, has_new := this.m_new_rows[TongId]
			if has_new {
				delete(this.m_new_rows, TongId)
			} else {
				log.Error("row not exist %v", TongId)
			}
		} else {
			log.Error("already removed %v", TongId)
			_, has_new := this.m_new_rows[TongId]
			if has_new {
				delete(this.m_new_rows, TongId)
				log.Error("removed rows and new_rows both has %v", TongId)
			}
		}
	}
}
func (this *dbTongTable) GetRow(TongId int32) (row *dbTongRow) {
	this.m_lock.UnSafeRLock("dbTongTable.GetRow")
	defer this.m_lock.UnSafeRUnlock()
	row = this.m_rows[TongId]
	if row == nil {
		row = this.m_new_rows[TongId]
	}
	return row
}

type DBC struct {
	m_db_name            string
	m_db                 *sql.DB
	m_db_lock            *Mutex
	m_initialized        bool
	m_quit               bool
	m_shutdown_completed bool
	m_shutdown_lock      *Mutex
	m_db_last_copy_time	int32
	m_db_copy_path		string
	m_db_addr			string
	m_db_account			string
	m_db_password		string
	Players *dbPlayerTable
	GooglePayRecords *dbGooglePayRecordTable
	ApplePayRecords *dbApplePayRecordTable
	FaceBPayRecords *dbFaceBPayRecordTable
	Tongs *dbTongTable
}
func (this *DBC)init_tables()(err error){
	this.Players = new_dbPlayerTable(this)
	err = this.Players.Init()
	if err != nil {
		log.Error("init Players table failed")
		return
	}
	this.GooglePayRecords = new_dbGooglePayRecordTable(this)
	err = this.GooglePayRecords.Init()
	if err != nil {
		log.Error("init GooglePayRecords table failed")
		return
	}
	this.ApplePayRecords = new_dbApplePayRecordTable(this)
	err = this.ApplePayRecords.Init()
	if err != nil {
		log.Error("init ApplePayRecords table failed")
		return
	}
	this.FaceBPayRecords = new_dbFaceBPayRecordTable(this)
	err = this.FaceBPayRecords.Init()
	if err != nil {
		log.Error("init FaceBPayRecords table failed")
		return
	}
	this.Tongs = new_dbTongTable(this)
	err = this.Tongs.Init()
	if err != nil {
		log.Error("init Tongs table failed")
		return
	}
	return
}
func (this *DBC)Preload()(err error){
	err = this.Players.Preload()
	if err != nil {
		log.Error("preload Players table failed")
		return
	}
	err = this.GooglePayRecords.Preload()
	if err != nil {
		log.Error("preload GooglePayRecords table failed")
		return
	}
	err = this.ApplePayRecords.Preload()
	if err != nil {
		log.Error("preload ApplePayRecords table failed")
		return
	}
	err = this.FaceBPayRecords.Preload()
	if err != nil {
		log.Error("preload FaceBPayRecords table failed")
		return
	}
	err = this.Tongs.Preload()
	if err != nil {
		log.Error("preload Tongs table failed")
		return
	}
	err = this.on_preload()
	if err != nil {
		log.Error("on_preload failed")
		return
	}
	err = this.Save(true)
	if err != nil {
		log.Error("save on preload failed")
		return
	}
	return
}
func (this *DBC)Save(quick bool)(err error){
	err = this.Players.Save(quick)
	if err != nil {
		log.Error("save Players table failed")
		return
	}
	err = this.GooglePayRecords.Save(quick)
	if err != nil {
		log.Error("save GooglePayRecords table failed")
		return
	}
	err = this.ApplePayRecords.Save(quick)
	if err != nil {
		log.Error("save ApplePayRecords table failed")
		return
	}
	err = this.FaceBPayRecords.Save(quick)
	if err != nil {
		log.Error("save FaceBPayRecords table failed")
		return
	}
	err = this.Tongs.Save(quick)
	if err != nil {
		log.Error("save Tongs table failed")
		return
	}
	return
}
