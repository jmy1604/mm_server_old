package main

import (
	"libs/log"
	"libs/socket"
	"libs/timer"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	MIN_TONG_ACT_CD_SEC          = 5  // 帮会操作最下时间间隔
	G_UP_ONLINE_TONG_DONATE_TIME = 30 // 刷新在线玩家捐赠上限的间隔
)

var g_last_up_p_tong_donate_frame int32 // 上一次更新在线玩家当天捐赠上线的帧
var g_last_up_p_tong_donate_unix int32  // 上一次更新在线玩家当天捐赠上线的时间

func g_up_online_tong_donate() {
	cur_unix := int32(time.Now().Unix())
	if cur_unix-g_last_up_p_tong_donate_frame < G_UP_ONLINE_TONG_DONATE_TIME {
		return
	}

	g_last_up_p_tong_donate_frame = cur_unix
	if timer.GetDayFrom1970WithCfgAndSec(0, g_last_up_p_tong_donate_unix) == timer.GetDayFrom1970WithCfg(0) {
		return
	}

	log.Info("g_up_online_tong_donate")
	g_last_up_p_tong_donate_unix = cur_unix

	var tmp_p *Player
	cur_online_num := player_mgr.GetCurOnlineNum()
	for idx := int32(0); idx < cur_online_num; idx++ {
		tmp_p = player_mgr.ol_player_array[idx]
		if nil == tmp_p {
			continue
		}

		tmp_p.ChkTodayMaxDonate()
	}

	return
}

func (this *Player) ChkTodayMaxDonate() {
	arena_lvl := this.db.Info.GetArenaLvl()
	arena_cfg := cfg_arena.Map[arena_lvl]
	if nil == arena_cfg {
		log.Error("Player ChkTodayMaxDonate failed find anena_cfg[%d]", arena_lvl)
		return
	}

	cur_unix_d := timer.GetDayFrom1970WithCfg(0)
	if cur_unix_d != this.db.TongInfo.GetLastDonateMaxUpUnixD() {
		this.db.TongInfo.SetTodayDonateMax(arena_cfg.DonationUpper)
		this.db.TongInfo.SetTodayDonateNum(0)
	}

	return
}

/*
func (this *Player) DoPlayerTongLogin() {
	this.ChkTodayMaxDonate()

	tong_id := this.db.TongInfo.GetTongId()
	if tong_id > 0 {
		req2c := &msg_server_message.SetTongMemberOnOffline{}
		req2c.PlayerId = proto.Int32(this.Id)
		req2c.TongId = proto.Int32(tong_id)
		req2c.OnOffLine = proto.Int32(1)
		center_conn.Send(req2c)
	}
}

func (this *Player) DoPlayerTongLogout() {
	tong_id := this.db.TongInfo.GetTongId()
	if tong_id > 0 {
		req2c := &msg_server_message.SetTongMemberOnOffline{}
		req2c.PlayerId = proto.Int32(this.Id)
		req2c.TongId = proto.Int32(tong_id)
		req2c.OnOffLine = proto.Int32(0)
		center_conn.Send(req2c)
	}
}
*/

// ===========================================================

func reg_player_tong_msg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SCreateTong, C2SCreateTongHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetTongInfo, C2SGetTongInfoHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetRecommendTong, C2SGetRecommendTongHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongSearch, C2STongSearchHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongEnter, C2STongEnterHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SEnterTongAgree, C2SEnterTongAgreeHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongEnterRefuse, C2STongEnterRefuseHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SLeaveTong, C2SLeaveTongHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongSetChg, C2STongSetChgHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongPubChg, C2STongPubChgHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongChat, C2STongChatHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongCardReq, C2STongCardReqHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongCardDonate, C2STongCardDonateHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetBeDonate, C2SGetBeDonateHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SOpenTongChest, C2SOpenTongChestHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongFriendMatch, C2STongFriendMatchHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongFriendCancel, C2STongFriendCancelHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2STongFriendEnter, C2STongFriendEnterHandler)

	center_conn.SetMessageHandler(msg_server_message.ID_CreateTongOk, C2HCreateTongOkHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_CreateTongFailed, C2HCreateTongFailedHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_RetTongInfo, C2HRetTongInfoHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_RetRecommendTong, C2HRetcommendTongHanlder)
	center_conn.SetMessageHandler(msg_server_message.ID_RetTongSearch, C2HRetTongSearchHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_EnterTongRequest, C2HEnterTongRequestHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_SetPlayerTongInfo, C2HSetPlayerTongInfoHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_ClearPlayerTongInfo, C2HClearPlayerTongInfoHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyPlayerEnter, C2HNotifyPlayerEnterHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyPlayerRefuse, C2HNotifyPlayerRefuseHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyTongMemberOnOffline, C2HNotifyTongMemberOnOfflineHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyTongSetChg, C2HNotifyTongSetChgHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyTongPubChg, C2HNotifyTongPubChgHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyTongChatSend, C2HNotifyTongChatSendHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyTongCardReq, C2HNotifyTongCardReqHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyTongDonateCard, C2HNotifyTongDonateCardHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyTongChestScoreChg, C2HNotifyTongChestScoreChgHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyTongMemberScoreChg, C2HNotifyTongMemberScoreChgHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_RetTongChestOpen, C2HRetTongChestOpenHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyTongFriendMatch, C2HNotifyTongFriendMatchHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_NotifyTongFriendCancel, C2HNotifyTongFriendCancelHandler)
}

func C2SCreateTongHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SCreateTong)
	if nil == c || nil == req {
		log.Error("C2SCreateTongHandler c or req nil (%v)", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SCreateTongHandler not login [%d]", p.Id)
		return
	}

	if int32(time.Now().Unix())-p.p_cache.last_tong_act_unix < MIN_TONG_ACT_CD_SEC {
		log.Error("C2SCreateTongHandler[%d] act to many !!", p.Id)
		return
	}

	if p.db.TongInfo.GetTongId() > 0 {
		log.Error("C2SCreateTongHandler[%d] already in tong[%d]", p.Id, p.db.TongInfo.GetTongId())
		return
	}

	if p.GetCoin() < global_config.CreateTongCost {
		log.Error("C2SCreateTongHandler[%d] not enough coin", p.Id)
		return
	}

	req2co := &msg_server_message.CreateTong{}
	req2co.CreatorId = proto.Int32(p.Id)
	req2co.CreatorName = proto.String(p.db.GetName())
	req2co.Icon = proto.Int32(req.GetIcon())
	req2co.JoinScore = proto.Int32(req.GetJoinScore())
	req2co.JoinType = proto.Int32(req.GetJoinType())
	req2co.Pos = proto.Int32(req.GetPos())
	req2co.Score = proto.Int32(p.GetMatchScore())
	req2co.TongName = proto.String(req.GetTongName())
	req2co.TongPub = proto.String(req.GetDesc())

	center_conn.Send(req2co)

	return
}

func C2HCreateTongOkHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.CreateTongOk)
	if nil == res || nil == c {
		log.Error("C2HCreateTongOkHandler c or res nil [%v]", nil == res)
		return
	}

	p := player_mgr.GetPlayerById(res.GetCreatorId())
	if nil == p {
		log.Error("C2HCreateTongOkHandler failed to get player by id[%d]", res.GetCreatorId())
		return
	}

	p.SubCoin(global_config.CreateTongCost, "create_tong_cost", "tong")

	p.db.TongInfo.SetTongId(res.GetTongId())
	p.db.TongInfo.SetTongIcon(res.GetIcon())
	p.db.TongInfo.SetTongName(res.GetTongName())
	p.db.TongInfo.SetTongMemberType(TONG_MEMBER_CAPTAIN)

	res2cli := &msg_client_message.S2CCreateTongOk{}
	res2cli.Icon = proto.Int32(res.GetIcon())
	res2cli.JoinScore = proto.Int32(res.GetJoinScore())
	res2cli.JoinType = proto.Int32(res.GetJoinType())
	res2cli.Pos = proto.Int32(res.GetPos())
	res2cli.TongId = proto.Int32(res.GetTongId())
	res2cli.TongName = proto.String(res.GetTongName())
	res2cli.Desc = proto.String(res.GetTongPub())
	res2cli.CurCoin = proto.Int32(p.db.Info.GetCoin())

	p.Send(res2cli)
}

func C2HCreateTongFailedHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.CreateTongFailed)
	if nil == res || nil == c {
		log.Error("C2HCreateTongFailedHandler res or c nil[%v] !", nil == c)
		return
	}

	pid := res.GetCreatorId()
	p := player_mgr.GetPlayerById(pid)
	if nil == p {
		log.Error("C2HCreateTongFailedHandler get p by id[%d] failed", pid)
		return
	}

	res2cli := &msg_client_message.S2CCreateTongFailed{}
	res2cli.Reason = proto.Int32(res.GetReason())

	p.Send(res2cli)
}

func C2SGetTongInfoHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetTongInfo)
	if nil == c || nil == req {
		log.Error("C2SGetTongInfoHandler c nil")
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SGetTongInfoHandler GetPlayerById failed[%d] !", c.T)
		return
	}

	tong_id := req.GetTongId()
	if 0 == tong_id {
		tong_id = p.db.TongInfo.GetTongId()
	}

	if 0 >= tong_id {
		log.Info("C2SGetTongInfoHandler[%d] tong_id[%d] <= 0 !", c.T, tong_id)
		req2co := &msg_server_message.GetRecommendTong{}
		req2co.PlayerId = proto.Int32(p.Id)

		center_conn.Send(req2co)
		return
	}

	req2co := &msg_server_message.GetTongInfo{}
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.TongId = proto.Int32(tong_id)
	if tong_id == p.db.TongInfo.GetTongId() {
		req2co.IfOwnTong = proto.Int32(1)
	} else {
		log.Info("不是自己帮会 %d != %d", tong_id, p.db.TongInfo.GetTongId())
	}

	center_conn.Send(req2co)

	return
}

func C2HRetTongInfoHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RetTongInfo)
	if nil == c || nil == res {
		log.Error("C2HRetTongInfoHandler param error !")
		return
	}

	pid := res.GetPlayerId()
	p := player_mgr.GetPlayerById(pid)
	if nil == p {
		log.Error("C2HRetTongInfoHandler param error !")
		return
	}

	tong_id := res.GetTongId()

	res2cli := &msg_client_message.S2CRetTongInfo{}
	res2cli.Icon = proto.Int32(res.GetIcon())
	res2cli.JoinType = proto.Int32(res.GetJoinType())
	res2cli.JoinScore = proto.Int32(res.GetJoinScore())
	res2cli.Pos = proto.Int32(res.GetPos())
	res2cli.TongId = proto.Int32(tong_id)
	res2cli.TongName = proto.String(res.GetTongName())
	res2cli.TongScore = proto.Int32(res.GetTongScore())
	res2cli.TongPub = proto.String(res.GetTongPub())
	res2cli.IfEnter = proto.Int32(res.GetIfEnter())

	res2cli.Members = make([]*msg_client_message.TongMemberInfo, 0, len(res.GetMembers()))
	var tmp_m *msg_client_message.TongMemberInfo
	for _, val := range res.GetMembers() {
		if nil == val {
			continue
		}

		tmp_m = &msg_client_message.TongMemberInfo{}
		tmp_m.Donate = proto.Int32(val.GetDonate())
		tmp_m.Name = proto.String(val.GetName())
		tmp_m.Score = proto.Int32(val.GetScore())
		tmp_m.Title = proto.Int32(val.GetTitle())
		tmp_m.IfOnline = proto.Int32(val.GetIfOnline())
		tmp_m.PlayerId = proto.Int32(val.GetPlayerId())
		res2cli.Members = append(res2cli.Members, tmp_m)
	}

	if tong_id == p.db.TongInfo.GetTongId() {
		cur_unix := int32(time.Now().Unix())
		donate_cd_leave := global_config.LeaveTongDonateCdSec - (cur_unix - p.db.TongInfo.GetLastLeaveTongUnix())
		donate_cd := global_config.DonationRequestCD - (cur_unix - p.db.TongInfo.GetLastCardReqUnix())
		if donate_cd < donate_cd_leave {
			donate_cd = donate_cd_leave
		}

		if donate_cd < 0 {
			donate_cd = 0
		}

		res2cli.TongDonateCdSec = proto.Int32(donate_cd)
		res2cli.TongChestState = proto.Int32(res.GetTongChestState())
		res2cli.TongChestLeftSec = proto.Int32(res.GetTongChestLeftSec())
		res2cli.TongChestScore = proto.Int32(res.GetTongChestScore())
		res2cli.IfGetTongChest = proto.Int32(res.GetIfGetTongChest())

		var tmp_c *msg_client_message.TongChatRecord
		res2cli.ChatList = make([]*msg_client_message.TongChatRecord, 0, len(res.GetChatRds()))
		for _, val := range res.GetChatRds() {
			if nil == val {
				continue
			}

			tmp_c = &msg_client_message.TongChatRecord{}
			tmp_c.SendId = proto.Int32(val.GetSenderId())
			tmp_c.SenderName = proto.String(val.GetSenderName())
			tmp_c.Content = proto.String(val.GetContent())
			tmp_c.SendUnix = proto.Int32(val.GetSendUnix())
			res2cli.ChatList = append(res2cli.ChatList, tmp_c)
		}

		var tmp_r *msg_client_message.TongCardReq
		res2cli.CardReqs = make([]*msg_client_message.TongCardReq, 0, len(res.GetCardReqs()))
		for _, val := range res.GetCardReqs() {
			if nil == val {
				continue
			}

			tmp_r = &msg_client_message.TongCardReq{}
			tmp_r.ReqId = proto.Int32(val.GetReqId())
			tmp_r.ReqPid = proto.Int32(val.GetPlayerId())
			tmp_r.ReqPName = proto.String(val.GetPlayerName())
			tmp_r.CardCfgId = proto.Int32(val.GetCardCfgId())
			tmp_r.CurGetNum = proto.Int32(val.GetCurGetNum())
			tmp_r.MaxGetNum = proto.Int32(val.GetMaxGetNum())
			tmp_r.ReqUnix = proto.Int32(val.GetSendUnix())
			res2cli.CardReqs = append(res2cli.CardReqs, tmp_r)
		}

		if int32(time.Now().Unix())-p.p_cache.last_donate_chk_unix > 30 {
			p.db.TongDonates.ChkTimeOver()
			p.p_cache.last_donate_chk_unix = int32(time.Now().Unix())
		}
		p.db.TongDonates.FillAllClientMsg(res2cli)

		var tmp_fm *msg_client_message.TongFriendMatch
		res2cli.FriendMatchs = make([]*msg_client_message.TongFriendMatch, 0, len(res.GetFriendMatchs()))
		for _, val := range res.GetFriendMatchs() {
			if nil == val {
				continue
			}

			tmp_fm = &msg_client_message.TongFriendMatch{}
			tmp_fm.PlayerId = proto.Int32(val.GetPlayerId())
			tmp_fm.PlayerName = proto.String(val.GetName())
			res2cli.FriendMatchs = append(res2cli.FriendMatchs, tmp_fm)
		}

		var tmp_join *msg_client_message.TongRequestJoin
		res2cli.JoinList = make([]*msg_client_message.TongRequestJoin, 0, len(res.GetJoinList()))
		for _, val := range res.GetJoinList() {
			if nil == val {
				continue
			}

			tmp_join = &msg_client_message.TongRequestJoin{}
			tmp_join.PlayerId = proto.Int32(val.GetPlayerId())
			tmp_join.PlayerName = proto.String(val.GetPlayerName())
			tmp_join.Score = proto.Int32(val.GetScore())
			tmp_join.JoinSec = proto.Int32(val.GetJoinSec())
			res2cli.JoinList = append(res2cli.JoinList, tmp_join)
		}
	}

	p.Send(res2cli)

	return
}

func C2SGetRecommendTongHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetRecommendTong)
	if nil == c || nil == req {
		log.Error("C2SGetRecommendTongHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SGetRecommendTongHandler not login [%d]", c.T)
		return
	}

	req2co := &msg_server_message.GetRecommendTong{}
	req2co.PlayerId = proto.Int32(p.Id)

	center_conn.Send(req2co)
	return
}

func C2STongSetChgHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongSetChg)
	if nil == c || nil == req {
		log.Error("C2STongSetChgHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2STongSetChgHandler not login [%d]", c.T)
		return
	}

	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2STongSetChgHandler not in tong !")
		return
	}

	req2co := &msg_server_message.TongSetChg{}
	req2co.Icon = proto.Int32(req.GetIcon())
	req2co.JoinScore = proto.Int32(req.GetJoinScore())
	req2co.JoinType = proto.Int32(req.GetJoinType())
	req2co.Pos = proto.Int32(req.GetPos())
	req2co.TongName = proto.String(req.GetTongName())
	req2co.TongId = proto.Int32(tong_id)

	center_conn.Send(req2co)
	return
}

func C2STongPubChgHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongPubChg)
	if nil == c || nil == req {
		log.Error("C2STongPubChgHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2STongPubChgHandler not login [%d]", c.T)
		return
	}

	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2STongPubChgHandler not in tong !")
		return
	}

	req2co := &msg_server_message.TongPubChg{}
	req2co.TongPub = proto.String(req.GetTongPub())
	req2co.TongId = proto.Int32(tong_id)

	center_conn.Send(req2co)
	return
}

func C2STongChatHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongChat)
	if nil == c || nil == req {
		log.Error("C2SC2STongChatHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SC2STongChatHandler not login [%d]", c.T)
		return
	}
	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2SC2STongChatHandler not in tong !")
		return
	}

	req2co := &msg_server_message.TongChatSend{}
	req2co.Content = proto.String(req.GetContent())
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.PlayerName = proto.String(p.db.GetName())
	req2co.TongId = proto.Int32(tong_id)

	center_conn.Send(req2co)
}

func C2STongCardReqHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongCardReq)
	if nil == c || nil == req {
		log.Error("C2STongCardReqHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2STongCardReqHandler not login [%d]", c.T)
		return
	}
	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2STongCardReqHandler not in tong !")
		p.SendError(msg_client_message.E_ERR_NOT_IN_TONG)
		return
	}

	card_cfg := cfg_player_cards.Map[req.GetCardCfgId()]
	if nil == card_cfg {
		log.Error("C2STongCardReqHandler failed to find card_cfg[%d]", req.CardCfgId)
		return
	}

	arena_cfg := cfg_arena.Map[p.db.Info.GetArenaLvl()]
	if nil == arena_cfg {
		log.Error("C2STongCardReqHandler failed to find arean_cfg[%d]", p.db.Info.GetArenaLvl())
		return
	}

	max_num := int32(0)
	if CARD_TRAIT_COMMON == card_cfg.Trait {
		max_num = arena_cfg.SeekCommon
	} else if CARD_TRAIT_RARE == card_cfg.Trait {
		max_num = arena_cfg.SeekRare
	} else {
		log.Error("C2STongCardReqHandler card[%d] trait err !", card_cfg.Trait)
		return
	}

	cur_unix := int32(time.Now().Unix())
	if cur_unix-p.db.TongInfo.GetLastCardReqUnix() < global_config.DonationRequestCD {
		p.SendError(msg_client_message.E_ERR_TONG_REQ_CD)
		log.Error("C2STongCardReqHandler reqcd cur[%d] last[%d]", cur_unix, p.db.TongInfo.GetLastCardReqUnix())
		return
	}

	if cur_unix-p.db.TongInfo.GetLastLeaveTongUnix() < global_config.LeaveTongDonateCdSec {
		p.SendError(msg_client_message.E_ERR_TONG_REQ_CD)
		log.Error("C2STongCardReqHandler leave tongcd cur[%d] last[%d]", cur_unix, p.db.TongInfo.GetLastLeaveTongUnix())
		return
	}

	req2co := &msg_server_message.TongCardReq{}
	req2co.CardCfgId = proto.Int32(card_cfg.ConfigId)
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.PlayerName = proto.String(p.db.GetName())
	req2co.TongId = proto.Int32(tong_id)
	req2co.MaxGetNum = proto.Int32(max_num)
	p.db.TongInfo.SetLastCardReqUnix(cur_unix)
	center_conn.Send(req2co)
}

func C2STongCardDonateHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongCardDonate)
	if nil == c || nil == req {
		log.Error("C2STongCardDonateHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2STongCardDonateHandler not login [%d]", c.T)
		return
	}
	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2STongCardDonateHandler not in tong !")
		return
	}

	card_cfgid := req.GetCardCfgId()
	card_cfg := cfg_player_cards.Map[card_cfgid]
	if nil == card_cfg {
		log.Error("C2STongCardDonateHandler failed to find card_cfg[%d]", card_cfgid)
		return
	}

	cur_card_num, bhas := p.db.Cards.GetCardCount(card_cfgid)
	if !bhas || cur_card_num < 1 {
		log.Error("C2STongCardDonateHandler[%d] no enough cards[%d] !", c.T, card_cfgid)
		return
	}

	arena_cfg := cfg_arena.Map[p.db.Info.GetArenaLvl()]
	if nil == arena_cfg {
		log.Error("C2STongCardDonateHandler[%d] failed to find arean_cfg[%d]", c.T, p.db.Info.GetArenaLvl())
		return
	}

	single_donate_max := arena_cfg.SingleCommon
	switch card_cfg.Trait {
	case CARD_TRAIT_RARE:
		{
			single_donate_max = arena_cfg.SingleRare
		}
	case CARD_TRAIT_EPIC:
		{
			single_donate_max = 1
		}
	case CARD_TRAIT_LEGEND:
		{
			single_donate_max = 0
		}
	}

	cur_donate_num, bhas := p.db.TongDonates.GetDonateNum(req.GetOpPlayerId())
	if bhas && cur_donate_num >= single_donate_max {
		log.Error("C2STongCardDonateHandler[%d] single donate max [%d] !", c.T, single_donate_max)
		return
	}

	if p.db.TongInfo.GetTodayDonateNum() >= p.db.TongInfo.GetTodayDonateMax() {
		log.Error("C2STongCardDonateHandler[%d] total donate max [%d] !", c.T, p.db.TongInfo.GetTodayDonateMax())
		return
	}

	cur_unix := int32(time.Now().Unix())
	if cur_unix-p.db.TongInfo.GetLastLeaveTongUnix() < global_config.LeaveTongDonateCdSec {
		log.Error("C2STongCardDonateHandler leave tongcd cur[%d] last[%d]", cur_unix, p.db.TongInfo.GetLastLeaveTongUnix())
		return
	}

	p.db.TongInfo.IncbyTodayDonateNum(1)

	req2co := &msg_server_message.TongDonateCard{}
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.PlayerName = proto.String(p.db.GetName())
	req2co.TongId = proto.Int32(tong_id)
	req2co.TgtPlayerId = proto.Int32(req.GetOpPlayerId())
	req2co.CardCfgId = proto.Int32(card_cfgid)
	center_conn.Send(req2co)
}

func C2SGetBeDonateHandler(c *socket.TcpConn, msg proto.Message) {

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SGetBeDonateHandler not login [%d]", c.T)
		return
	}

	res2cli := &msg_client_message.S2CRetBeDonate{}
	p.db.BeTongDonates.FillAllMsgAndRest(res2cli)
	if len(res2cli.BeDonateList) > 0 {
		p.Send(res2cli)
	}
}

func C2SOpenTongChestHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SOpenTongChest)
	if nil == c || nil == req {
		log.Error("C2SOpenTongChestHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SOpenTongChestHandler not login [%d]", c.T)
		return
	}
	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2SOpenTongChestHandler not in tong !")
		return
	}

	req2co := &msg_server_message.TongChestOpen{}
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.TongId = proto.Int32(tong_id)
	req2co.ArenaLvl = proto.Int32(p.db.Info.GetArenaLvl())

	center_conn.Send(req2co)
}

func C2STongFriendMatchHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongFriendMatch)
	if nil == c || nil == req {
		log.Error("C2STongFriendMatchHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2STongFriendMatchHandler not login [%d]", c.T)
		return
	}
	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2STongFriendMatchHandler not in tong !")
		return
	}

	cur_team := p.db.CardTeams.Get(p.db.Info.GetCurUseCardTeam())
	if nil == cur_team || len(cur_team.CardCfgIds) <= 0 {
		log.Error("cur_team cardcfgids zero !!")
		p.db.Info.SetCurUseCardTeam(DEFAULT_CARD_TEAM_0)
		cur_team = p.db.CardTeams.Get(DEFAULT_CARD_TEAM_0)
	}

	nozero_cards := make([]int32, 0, len(cur_team.CardCfgIds))
	for _, val := range cur_team.CardCfgIds {
		if val <= 0 {
			continue
		}

		nozero_cards = append(nozero_cards, val)
	}

	if len(nozero_cards) < 1 {
		log.Error("C2STongFriendMatchHandler card_team have not no zero cards !", p.Id, cur_team.TeamId)
		return
	}

	req2co := &msg_server_message.TongFriendMatch{}
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.TongId = proto.Int32(tong_id)
	req2co.CardIds = nozero_cards
	req2co.CardLvls = p.db.Cards.GetCardsLvls(nozero_cards)
	req2co.Score = proto.Int32(p.GetMatchScore())
	req2co.HallId = proto.Int32(config.ServerId)

	center_conn.Send(req2co)
}

func C2STongFriendCancelHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongFriendCancel)
	if nil == c || nil == req {
		log.Error("C2STongFriendCancelHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2STongFriendCancelHandler not login [%d]", c.T)
		return
	}
	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2STongFriendCancelHandler not in tong !")
		return
	}

	req2co := &msg_server_message.TongFriendCancel{}
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.TongId = proto.Int32(tong_id)

	center_conn.Send(req2co)
}

func C2STongFriendEnterHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongFriendEnter)
	if nil == c || nil == req {
		log.Error("C2STongFriendEnterHandler c or req nil[%v] !", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2STongFriendEnterHandler not login [%d]", c.T)
		return
	}
	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2STongFriendEnterHandler not in tong !")
		return
	}

	cur_team := p.db.CardTeams.Get(p.db.Info.GetCurUseCardTeam())
	if nil == cur_team || len(cur_team.CardCfgIds) <= 0 {
		log.Error("cur_team cardcfgids zero !!")
		p.db.Info.SetCurUseCardTeam(DEFAULT_CARD_TEAM_0)
		cur_team = p.db.CardTeams.Get(DEFAULT_CARD_TEAM_0)
	}

	nozero_cards := make([]int32, 0, len(cur_team.CardCfgIds))
	for _, val := range cur_team.CardCfgIds {
		if val <= 0 {
			continue
		}

		nozero_cards = append(nozero_cards, val)
	}

	if len(nozero_cards) < 1 {
		log.Error("C2STongFriendEnterHandler card_team have not no zero cards !", p.Id, cur_team.TeamId)
		return
	}

	req2co := &msg_server_message.TongFriendEnter{}
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.TongId = proto.Int32(tong_id)
	req2co.CardIds = nozero_cards
	req2co.CardLvls = p.db.Cards.GetCardsLvls(nozero_cards)
	req2co.PlayerName = proto.String(p.db.GetName())
	req2co.Score = proto.Int32(p.GetMatchScore())
	req2co.HallId = proto.Int32(config.ServerId)
	req2co.TgtPlayerId = proto.Int32(req.GetTgtPlayerId())

	center_conn.Send(req2co)
}

// ----------------------------------------------------------------------------------------------

func C2HRetcommendTongHanlder(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RetRecommendTong)
	if nil == c || nil == res {
		log.Error("C2HRetcommendTongHanlder c or res nil [%v]", nil == res)
		return
	}

	pid := res.GetPlayerId()
	p := player_mgr.GetPlayerById(pid)
	if nil == p {
		log.Error("C2HRetcommendTongHanlder GetPlayerById[%d] failed !", pid)
		return
	}

	res2cli := &msg_client_message.S2CRetRecommendTong{}
	res2cli.Tongs = make([]*msg_client_message.TongSummary, 0, len(res.GetTongs()))
	var tmp_t *msg_client_message.TongSummary
	for _, tmp_svr_t := range res.GetTongs() {
		if nil == tmp_svr_t {
			continue
		}

		tmp_t = &msg_client_message.TongSummary{}
		tmp_t.Icon = proto.Int32(tmp_svr_t.GetIcon())
		tmp_t.MemCount = proto.Int32(tmp_svr_t.GetMemCount())
		tmp_t.Name = proto.String(tmp_svr_t.GetName())
		tmp_t.TongScore = proto.Int32(tmp_svr_t.GetTongScore())
		tmp_t.TongId = proto.Int32(tmp_svr_t.GetTongId())
		res2cli.Tongs = append(res2cli.Tongs, tmp_t)
	}

	p.Send(res2cli)
	return
}

func C2STongSearchHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongSearch)
	if nil == c || nil == req {
		log.Error("C2STongSearchHandler param error !")
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2STongSearchHandler not login [%d]", c.T)
		return
	}

	req2co := &msg_server_message.TongSearch{}
	req2co.MaxCount = proto.Int32(req.GetMaxCount())
	req2co.MinCount = proto.Int32(req.GetMinCount())
	req2co.MinScore = proto.Int32(req.GetMinScore())
	req2co.Name = proto.String(req.GetName())
	req2co.OnlyCanJoin = proto.Int32(req.GetOnlyCanJoin())
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.Pos = proto.Int32(req.GetPos())

	center_conn.Send(req2co)

	return
}

func C2HRetTongSearchHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RetTongSearch)
	if nil == c || nil == res {
		log.Error("H2CRetTongSearchHandler c or req nil[%v]", nil == res)
		return
	}

	pid := res.GetPlayerId()
	p := player_mgr.GetPlayerById(pid)
	if nil == p {
		log.Error("H2CRetTongSearchHandler get p[%d] failed !!", pid)
		return
	}

	res2cli := &msg_client_message.S2CRetTongSearch{}
	res2cli.Tongs = make([]*msg_client_message.TongSummary, 0, len(res.GetTongList()))
	var tmp_t *msg_client_message.TongSummary
	for _, tmp_svr_t := range res.GetTongList() {
		if nil == tmp_svr_t {
			continue
		}

		tmp_t = &msg_client_message.TongSummary{}
		tmp_t.Icon = proto.Int32(tmp_svr_t.GetIcon())
		tmp_t.MemCount = proto.Int32(tmp_svr_t.GetMemCount())
		tmp_t.Name = proto.String(tmp_svr_t.GetName())
		tmp_t.TongScore = proto.Int32(tmp_svr_t.GetTongScore())
		tmp_t.TongId = proto.Int32(tmp_svr_t.GetTongId())
		res2cli.Tongs = append(res2cli.Tongs, tmp_t)
	}

	p.Send(res2cli)

	return
}

func C2STongEnterHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongEnter)
	if nil == c || nil == req {
		log.Error("C2STongEnterHandler c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2STongEnterHandler not login [%d]", c.T)
		return
	}

	if int32(time.Now().Unix())-p.p_cache.last_tong_act_unix < MIN_TONG_ACT_CD_SEC {
		log.Trace("C2STongEnterHandler in cding [%d]", p.Id)
		return
	}

	if p.db.TongInfo.GetTongId() > 0 {
		log.Trace("C2STongEnterHanlder already in tong[%d]", p.db.TongInfo.GetTongId())
		return
	}

	req2co := &msg_server_message.EnterTong{}
	req2co.PlayerId = proto.Int32(p.Id)
	req2co.PlayerName = proto.String(p.db.GetName())
	req2co.Score = proto.Int32(p.GetMatchScore())
	req2co.TongId = proto.Int32(req.GetTongId())
	center_conn.Send(req2co)
	return
}

func C2HEnterTongRequestHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.EnterTongRequest)
	if nil == c || nil == req {
		log.Error("C2HEnterTongRequestHandler c or req nil[%v]", nil == req)
		return
	}

	onlinepids := req.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CEnterTongRequest{}
	tmp_res.JoinSec = proto.Int32(req.GetJoinSec())
	tmp_res.PlayerId = proto.Int32(req.GetPlayerId())
	tmp_res.PlayerName = proto.String(req.GetPlayerName())
	tmp_res.PlayerScore = proto.Int32(req.GetPlayerScore())
	var p *Player
	for _, pid := range onlinepids {
		p = player_mgr.GetPlayerById(pid)
		if nil == p {
			continue
		}

		p.Send(tmp_res)
	}
}

func C2SEnterTongAgreeHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SEnterTongAgree)
	if nil == c || nil == req {
		log.Error("C2SEnterTongAgreeHandler c or req nil[%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SEnterTongAgreeHandler not login[%d]", c.T)
		return
	}

	tong_id := p.db.TongInfo.GetTongId()
	if 0 >= tong_id {
		log.Error("C2SEnterTongAgreeHandler[%d] not in tong[%d]", p.Id, tong_id)
		return
	}

	req2c := &msg_server_message.EnterTongAgree{}
	req2c.PlayerId = proto.Int32(req.GetPlayerId())
	req2c.TongId = proto.Int32(tong_id)
	req2c.OpPlayerId = proto.Int32(p.Id)

	center_conn.Send(req2c)
	return
}

func C2STongEnterRefuseHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2STongEnterRefuse)
	if nil == c || nil == req {
		log.Error("C2STongEnterRefuseHandler c or req nil[%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2STongEnterRefuseHandler not login[%d]", c.T)
		return
	}

	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2STongEnterRefuseHandler tong_id(%d<=0)", tong_id)
		return
	}

	req2co := &msg_server_message.EnterTongRefuse{}
	req2co.OpPlayerId = proto.Int32(p.Id)
	req2co.PlayerId = proto.Int32(req.GetPlayerId())
	req2co.TongId = proto.Int32(tong_id)
	center_conn.Send(req2co)
	return
}

func C2HSetPlayerTongInfoHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.SetPlayerTongInfo)
	if nil == c || nil == req {
		log.Error("C2HSetPlayerTongInfoHandler c or req nil [%v]!", nil == req)
		return
	}

	pid := req.GetPlayerId()
	p := player_mgr.GetPlayerById(pid)
	if nil == p {
		log.Error("C2HSetPlayerTongInfoHandler failed to get player[%d]", pid)
		return
	}

	if p.db.TongInfo.GetTongId() > 0 {
		log.Error("C2HSetPlayerTongInfoHandler already in tong")
		return
	}

	p.db.TongInfo.SetTongIcon(req.GetTongIcon())
	p.db.TongInfo.SetTongId(req.GetTongId())
	p.db.TongInfo.SetTongName(req.GetTongName())
	p.db.TongInfo.SetTongMemberType(req.GetMemberType())
	if 1 != req.GetNotBack() {
		res2c := &msg_server_message.SetPlayerTongInfoOk{}
		res2c.PlayerId = proto.Int32(pid)
		res2c.TongId = proto.Int32(req.GetTongId())
		res2c.PrePos = proto.Int32(req.GetPrePos())
		res2c.IfOnline = proto.Int32(p.IfOnline())

		c.Send(res2c)
	}

	return
}

func C2SLeaveTongHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SLeaveTong)
	if nil == req || nil == c {
		log.Error("C2SLeaveTongHandler c or req nil[%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SLeaveTongHandler not login[%d]", c.T)
		return
	}

	tong_id := p.db.TongInfo.GetTongId()
	if tong_id <= 0 {
		log.Error("C2SLeaveTongHandler tong_id[%d] <= 0 !", tong_id)
		return
	}

	p.db.TongInfo.SetTongId(0)
	p.db.TongInfo.SetLastLeaveTongUnix(int32(time.Now().Unix()))
	p.db.TongDonates.Clear()

	req2c := &msg_server_message.TongLeave{}
	req2c.PlayerId = proto.Int32(p.Id)
	req2c.TongId = proto.Int32(tong_id)

	center_conn.Send(req2c)
	return
}

func C2HClearPlayerTongInfoHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.ClearPlayerTongInfo)
	if nil == c || nil == req {
		log.Error("C2HClearPlayerTongInfoHandler c or req nil[%v]", nil == req)
		return
	}

	pid := req.GetPlayerId()
	p := player_mgr.GetPlayerById(pid)
	if nil != p {
		p.db.TongInfo.SetTongId(0)
	}

	res2cli := &msg_client_message.S2CLeaveTongOk{}
	res2cli.PlayerId = proto.Int32(pid)
	onlinepids := req.GetOnlinePlayers()

	for _, pid := range onlinepids {
		p = player_mgr.GetPlayerById(pid)
		if nil == p {
			continue
		}

		p.Send(res2cli)
	}

	return
}

func C2HNotifyPlayerEnterHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.NotifyPlayerEnter)
	if nil == c || nil == res {
		log.Error("C2HNotifyPlayerEnter c or res nil[%v]", nil == res)
		return
	}

	onlinepids := res.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyPlayerEnter{}
	tmp_res.OpPlayerName = proto.String(res.GetOpPlayerName())
	tmp_res.PlayerId = proto.Int32(res.GetPlayerId())
	tmp_res.PlayerName = proto.String(res.GetPlayerName())
	tmp_res.PlayerScore = proto.Int32(res.GetPlayerScore())
	tmp_res.IfOnline = proto.Int32(res.GetIfOnline())

	var p *Player
	for _, pid := range onlinepids {
		p = player_mgr.GetPlayerById(pid)
		if nil == p {
			continue
		}

		p.Send(tmp_res)
	}

	return
}

func C2HNotifyPlayerRefuseHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.NotifyPlayerRefuse)
	if nil == c || nil == res {
		log.Error("C2HNotifyPlayerRefuseHandler c or res nil [%v]", nil == res)
		return
	}

	onlinepids := res.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyPlayerRefuse{}
	tmp_res.OpPlayerName = proto.String(res.GetOpPlayerName())
	tmp_res.PlayerId = proto.Int32(res.GetPlayerId())

	var p *Player
	for _, pid := range onlinepids {
		p = player_mgr.GetPlayerById(pid)
		if nil == p {
			continue
		}

		p.Send(tmp_res)
	}

	return
}

func C2HNotifyTongMemberOnOfflineHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.NotifyTongMemberOnOffline)
	if nil == c || nil == res {
		log.Error("C2HNotifyTongMemberOnOfflineHandler c or res nil [%v]", nil == res)
		return
	}

	onlinepids := res.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyMemberOnOff{}
	tmp_res.PlayerId = proto.Int32(res.GetPlayerId())
	tmp_res.OnOffLine = proto.Int32(res.GetOnOffLine())

	var p *Player
	for _, pid := range onlinepids {
		p = player_mgr.GetPlayerById(pid)
		if nil == p {
			continue
		}

		p.Send(tmp_res)
	}
}

func C2HNotifyTongSetChgHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.NotifyTongSetChg)
	if nil == c || nil == res {
		log.Error("C2HNotifyTongSetChgHandler c or res nil [%v]", nil == res)
		return
	}

	onlinepids := res.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyTongSetChg{}
	tmp_res.Icon = proto.Int32(res.GetIcon())
	tmp_res.JoinScore = proto.Int32(res.GetJoinScore())
	tmp_res.JoinType = proto.Int32(res.GetJoinType())
	tmp_res.Pos = proto.Int32(res.GetPos())
	tmp_res.TongName = proto.String(res.GetTongName())

	var p *Player
	for _, pid := range onlinepids {
		p = player_mgr.GetPlayerById(pid)
		if nil == p {
			continue
		}

		p.Send(tmp_res)
	}
}

func C2HNotifyTongPubChgHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.NotifyTongPubChg)
	if nil == c || nil == res {
		log.Error("C2HNotifyTongPubChgHandler c or res nil [%v]", nil == res)
		return
	}

	onlinepids := res.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyTongPubChg{}
	tmp_res.TongPub = proto.String(res.GetTongPub())

	var p *Player
	for _, pid := range onlinepids {
		p = player_mgr.GetPlayerById(pid)
		if nil == p {
			continue
		}

		p.Send(tmp_res)
	}
}

func C2HNotifyTongChatSendHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.NotifyTongChatSend)
	if nil == c || nil == res {
		log.Error("C2HNotifyTongChatSendHandler c or res nil [%v]", nil == res)
		return
	}

	onlinepids := res.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyTongChat{}
	tmp_res.SendId = proto.Int32(res.GetPlayerId())
	tmp_res.SendName = proto.String(res.GetPlayerName())
	tmp_res.Content = proto.String(res.GetContent())
	tmp_res.SendUnix = proto.Int32(res.GetSendUnix())

	var p *Player
	for _, pid := range onlinepids {
		p = player_mgr.GetPlayerById(pid)
		if nil == p {
			continue
		}

		p.Send(tmp_res)
	}
}

func C2HNotifyTongCardReqHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.NotifyTongCardReq)
	if nil == c || nil == res {
		log.Error("C2HNotifyTongChatSendHandler c or res nil [%v]", nil == res)
		return
	}

	onlinepids := res.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyTongCardReq{}
	tmp_res.PlayerId = proto.Int32(res.GetPlayerId())
	tmp_res.PlayerName = proto.String(res.GetPlayerName())
	tmp_res.CardCfgId = proto.Int32(res.GetCardCfgId())
	tmp_res.MaxGetNum = proto.Int32(res.GetMaxGetNum())
	tmp_res.ReqUnix = proto.Int32(res.GetReqUnix())

	var p *Player
	for _, pid := range onlinepids {
		p = player_mgr.GetPlayerById(pid)
		if nil == p {
			continue
		}

		p.Send(tmp_res)
	}
}

func C2HNotifyTongDonateCardHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.NotifyTongDonateCard)
	if nil == c || nil == res {
		log.Error("C2HNotifyTongDonateCardHandler c or res nil [%v]", nil == res)
		return
	}

	card_cfgid := res.GetCardCfgId()
	card_cfg := cfg_player_cards.Map[card_cfgid]
	if nil == card_cfg {
		log.Error("C2HNotifyTongDonateCardHandler fail to get card_cfg[%d]", card_cfgid)
		return
	}
	do_pid := res.GetPlayerId()
	op_pid := res.GetTgtPlayerId()
	onlinepids := res.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyTongCardDonate{}
	tmp_res.PlayerId = proto.Int32(do_pid)
	tmp_res.OpPlayerId = proto.Int32(op_pid)

	var tmp_p *Player
	for _, pid := range onlinepids {
		if pid == do_pid {
			continue
		}

		tmp_p = player_mgr.GetPlayerById(pid)
		if nil == tmp_p {
			continue
		}

		tmp_p.Send(tmp_res)
	}

	p := player_mgr.GetPlayerById(do_pid)
	if nil != p {
		p.db.Cards.IncbyCardCount(card_cfgid, -1)
		p.db.TongInfo.IncbyTodayDonateNum(1)
		arena_lvl := p.db.Info.GetArenaLvl()
		arena_cfg := cfg_arena.Map[arena_lvl]
		if nil == arena_cfg {
			log.Error("C2HNotifyTongDonateCardHandler failed to get arena_cfg [%d]", arena_lvl)
			return
		}

		switch card_cfg.Trait {
		case CARD_TRAIT_COMMON:
			{
				p.AddCoin(global_config.CommonGoldReward, "donatecard", "tong")
				tmp_res.GetCoin = proto.Int32(global_config.CommonGoldReward)
				p.AddExp(global_config.CommonExpReward, "donatecard", "tong")
				tmp_res.GetExp = proto.Int32(global_config.CommonExpReward)
			}
		default:
			{
				p.AddCoin(global_config.RareGoldReward, "donatecard", "tong")
				tmp_res.GetCoin = proto.Int32(global_config.RareGoldReward)
				p.AddExp(global_config.RareExpReward, "donatecard", "tong")
				tmp_res.GetExp = proto.Int32(global_config.RareExpReward)
			}
		}

		p.Send(tmp_res)
	}

	op_p := player_mgr.GetPlayerById(op_pid)
	if nil != op_p {
		p.db.BeTongDonates.AddByMsg(res)
	}

	return
}

func C2HNotifyTongChestScoreChgHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.NotifyTongChestScoreChg)
	if nil == c || nil == res {
		log.Error("C2HNotifyTongChestScoreChgHandler c or res nil [%v]", nil == res)
		return
	}

	onlinepids := res.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyTongChestScoreChg{}
	tmp_res.TongChestScore = proto.Int32(res.GetCurScore())

	var tmp_p *Player
	for _, pid := range onlinepids {

		tmp_p = player_mgr.GetPlayerById(pid)
		if nil == tmp_p {
			continue
		}

		tmp_p.Send(tmp_res)
	}

	return
}

func C2HNotifyTongMemberScoreChgHandler(c *CenterConnection, msg proto.Message) {
	notify := msg.(*msg_server_message.NotifyTongMemberScoreChg)
	if nil == c || nil == notify {
		log.Error("C2HNotifyTongMemberScoreChgHandler c or notify nil [%v]", nil == notify)
		return
	}

	onlinepids := notify.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyTongMemberScoreChg{}
	tmp_res.PlayerId = proto.Int32(notify.GetPlayerId())
	tmp_res.PlayerScore = proto.Int32(notify.GetCurScore())

	var tmp_p *Player
	for _, pid := range onlinepids {

		tmp_p = player_mgr.GetPlayerById(pid)
		if nil == tmp_p {
			continue
		}

		tmp_p.Send(tmp_res)
	}

	return
}

func C2HRetTongChestOpenHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.RetTongChestOpen)
	if nil == c || nil == res {
		log.Error("C2HRetTongChestOpenHandler c or res nil [%v]", nil == res)
		return
	}

	pid := res.GetPlayerId()
	tmp_p := player_mgr.GetPlayerById(pid)
	if nil == tmp_p {
		log.Error("C2HRetTongChestOpenHandler failed to find player by Id[%d]", pid)
		return
	}

	res2cli := &msg_client_message.S2COpenTongChest{}
	res2cli.Result = tmp_p.OpenChest(res.GetChestId(), "TongChestOpen", "Tong", 0, 0, false)

	tmp_p.Send(res2cli)

	return
}

func C2HNotifyTongFriendMatchHandler(c *CenterConnection, msg proto.Message) {
	notify := msg.(*msg_server_message.NotifyTongFriendMatch)
	if nil == c || nil == notify {
		log.Error("C2HNotifyTongFriendMatchHandler c or notify error [%v]!", nil == notify)
		return
	}

	onlinepids := notify.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyTongFriendMatch{}
	tmp_res.PlayerId = proto.Int32(notify.GetPlayerId())

	var tmp_p *Player
	for _, pid := range onlinepids {

		tmp_p = player_mgr.GetPlayerById(pid)
		if nil == tmp_p {
			continue
		}

		tmp_p.Send(tmp_res)
	}

	return
}

func C2HNotifyTongFriendCancelHandler(c *CenterConnection, msg proto.Message) {
	notify := msg.(*msg_server_message.NotifyTongFriendCancel)
	if nil == c || nil == notify {
		log.Error("C2HNotifyTongFriendCancelHandler c or notify error [%v]!", nil == notify)
		return
	}

	onlinepids := notify.GetOnlinePlayers()
	tmp_res := &msg_client_message.S2CNotifyTongFriendCancel{}
	tmp_res.PlayerId = proto.Int32(notify.GetPlayerId())

	var tmp_p *Player
	for _, pid := range onlinepids {

		tmp_p = player_mgr.GetPlayerById(pid)
		if nil == tmp_p {
			continue
		}

		tmp_p.Send(tmp_res)
	}

	return
}
