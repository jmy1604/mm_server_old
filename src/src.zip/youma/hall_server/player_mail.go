package main

import (
	"libs/log"
	"libs/socket"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	MAIL_ADD_FRIEND_ID = 7
)

func (this *Player) AddMail(msg *msg_server_message.MailAdd) {
	if nil == msg {
		log.Error("Player AddSystemMail msg nil")
		return
	}

	new_mail_id := this.db.Mails.GetAviMailId()

	new_mail := &dbPlayerMailData{}
	new_mail.MailId = new_mail_id
	new_mail.SenderName = msg.GetSenderName()
	new_mail.Content = msg.GetContent()
	new_mail.MailTitle = msg.GetTitle()
	new_mail.Coin = msg.GetCoin()
	new_mail.Diamond = msg.GetDiamond()
	new_mail.Chests = msg.GetChests()
	new_mail.ChestNums = msg.GetChestNums()
	new_mail.SendUnix = msg.GetSendUnix()
	new_mail.OverUnix = msg.GetOverUnix()
	new_mail.MailType = int8(msg.GetMailType())

	this.db.Mails.Add(new_mail)

	res2cli := &msg_client_message.S2CMailAdd{}
	res2cli.MailId = proto.Int32(new_mail.MailId)
	res2cli.Title = proto.String(new_mail.MailTitle)
	res2cli.Chests = msg.GetChests()
	res2cli.ChestNums = msg.GetChestNums()
	res2cli.Coin = proto.Int32(new_mail.Coin)
	res2cli.Content = proto.String(new_mail.Content)
	res2cli.Diamond = proto.Int32(new_mail.Diamond)
	res2cli.SenderName = proto.String(new_mail.SenderName)
	res2cli.SendUnix = proto.Int32(new_mail.SendUnix)
	res2cli.OverUix = proto.Int32(new_mail.OverUnix)

	this.Send(res2cli)

	return
}

func (this *Player) SendMailByMailId(mail_id int32, reason, mod string) {
	mail_cfg := cfg_mail_mgr.Map[mail_id]
	if nil == mail_cfg {
		log.Error("Player SendMailByMailId failed to find mail[%d]", mail_id)
		return
	}

	new_mail_id := this.db.Mails.GetAviMailId()
	new_mail := &dbPlayerMailData{}
	new_mail.MailId = new_mail_id
	new_mail.Chests = mail_cfg.RewardIds
	new_mail.ChestNums = mail_cfg.RewardNums
	new_mail.SendUnix = int32(time.Now().Unix())
	new_mail.OverUnix = new_mail.SendUnix + mail_cfg.MailDuration
	new_mail.MailType = int8(mail_cfg.MailId)

	this.db.Mails.Add(new_mail)
}

func (this *Player) SendAddFriendMail(playerid int32, playername string) {
	mail_cfg := cfg_mail_mgr.Map[MAIL_ADD_FRIEND_ID]
	if nil == mail_cfg {
		log.Error("Player SendMailByMailId failed to find mail[%d]", MAIL_ADD_FRIEND_ID)
		return
	}

	new_mail_id := this.db.Mails.GetAviMailId()
	new_mail := &dbPlayerMailData{}
	new_mail.MailId = new_mail_id
	new_mail.Chests = mail_cfg.RewardIds
	new_mail.ChestNums = mail_cfg.RewardNums
	new_mail.SendUnix = int32(time.Now().Unix())
	new_mail.OverUnix = new_mail.SendUnix + mail_cfg.MailDuration
	new_mail.MailType = int8(MAIL_ADD_FRIEND_ID)
	new_mail.SenderId = playerid
	new_mail.SenderName = playername
	this.db.Mails.Add(new_mail)

	res2cli := &msg_client_message.S2CMailAdd{}
	res2cli.MailId = proto.Int32(new_mail.MailId)
	res2cli.Title = proto.String(new_mail.MailTitle)
	res2cli.SenderName = proto.String(new_mail.SenderName)
	res2cli.SendUnix = proto.Int32(new_mail.SendUnix)
	res2cli.SenderId = proto.Int32(new_mail.SenderId)
	res2cli.OverUix = proto.Int32(new_mail.OverUnix)

	this.Send(res2cli)
}

// ===============================================================

func reg_player_mail_msg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetMailList, C2SGetMailListHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetMailAttach, C2SGetMailAttachHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SMailRemove, C2SMailRemoveHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SSetMailRead, C2SSetMailReadHandler)

	center_conn.SetMessageHandler(msg_server_message.ID_MailAdd, C2HMailAddHandler)
}

func C2SGetMailListHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetMailList)
	if nil == c || nil == req {
		log.Error("C2SGetMailListHandler c or req nil[%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SGetMailListHandler not login [%d]", c.T)
		return
	}

	res2cli := p.db.Mails.FillMsgList()
	if nil != res2cli {
		p.Send(res2cli)
	}

	log.Info("C2SGetMailListHandler get maillist [%v]!", res2cli)

	return
}

func C2SGetMailAttachHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetMailAttach)
	if nil == c || nil == req {
		log.Error("C2SGetMailAttachHandler c or req nil[%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SGetMailListHandler not login [%d]", c.T)
		return
	}

	mail_id := req.GetMailId()
	db_mail := p.db.Mails.Get(mail_id)
	if nil == db_mail {
		log.Error("C2SGetMailListHandler failed to get mail[%d]", mail_id)
		return
	}

	res2cli := &msg_client_message.S2CGetMailAttach{}
	res2cli.MailCoin = proto.Int32(p.AddCoin(db_mail.Coin, "mail_get_attach", "mail"))
	res2cli.MainDiamond = proto.Int32(p.AddDiamond(db_mail.Diamond, "mail_get_attach", "mail"))
	chest_total_num := int32(0)
	for _, val := range db_mail.ChestNums {
		chest_total_num += val
	}
	num_len := len(db_mail.ChestNums)

	res2cli.ChestOpens = make([]*msg_client_message.S2COpenChest, 0, chest_total_num)
	var tmp_open *msg_client_message.S2COpenChest
	for idx, chest_id := range db_mail.Chests {
		if idx >= num_len {
			break
		}
		chest_num := db_mail.ChestNums[idx]
		for i := int32(0); i < chest_num; i++ {
			tmp_open = p.OpenChest(chest_id, "mail_get_attach", "mail", 0, 0, true)
			res2cli.ChestOpens = append(res2cli.ChestOpens, tmp_open)
		}
	}
	res2cli.CurCoin = proto.Int32(p.db.Info.GetCoin())
	res2cli.CurDiamond = proto.Int32(p.db.Info.GetDiamond())
	res2cli.MailId = proto.Int32(mail_id)

	p.db.Mails.Remove(mail_id)

	p.Send(res2cli)
}

func C2SMailRemoveHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SMailRemove)
	if nil == c || nil == req {
		log.Error("C2SMailRemoveHandler c or req nil[%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SMailRemoveHandler not login [%d]", c.T)
		return
	}

	mail_id := req.GetMailId()
	p.db.Mails.Remove(mail_id)

	log.Info("玩家[%d] 删除邮件[%d]", p.Id, mail_id)
	return
}

func C2SSetMailReadHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SSetMailRead)
	if nil == c || nil == req {
		log.Error("C2SSetMailReadHandler c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SSetMailReadHandler not login [%d]", c.T)
		return
	}

	mail_id := req.GetMailId()
	p.db.Mails.SetReadState(mail_id, 1)

	return
}

// -----------------------------------------------------

func C2HMailAddHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.MailAdd)
	if nil == c || nil == req {
		log.Error("C2HMailAddHandler c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(req.GetPlayerId())
	if nil == p {
		log.Error("C2HMailAddHandler failed to get player(%d)", req.GetPlayerId())
		return
	}

	p.AddMail(req)

	return
}
