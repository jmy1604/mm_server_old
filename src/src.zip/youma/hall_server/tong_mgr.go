package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"libs/server_conn"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	TONG_MGR_RECOMMEND_CD_SEC  = 1
	DEFAULT_RECOMMEND_TONG_NUM = 20
	DEFAULT_TONG_SEARCH_NUM    = 50
	DEFAULT_TONG_ARRAY_MAX     = 1

	TONG_CHEST_CLOSE  = 0
	TONG_CHEST_OPEN   = 1
	TONG_CHEST_REWARD = 2

	TONG_SCORE_CHG_CHK_FRAME = 60
)

type XmlTongChestItem struct {
	Level       int32 `xml:"Level,attr"`
	ArenaRating int32 `xml:"ArenaRating,attr"`
	TotalCrowns int32 `xml:"TotalCrowns,attr"`
	ChestID     int32 `xml:"ChestID,attr"`
}

type XmlTongChestConfig struct {
	Items []XmlTongChestItem `xml:"item"`
}

type TongArenaLvlChests struct {
	start_score int32
	end_score   int32
	Lvl2Items   map[int32]*XmlTongChestItem
}

type TongMgr struct {
	id2tong_lock   *sync.RWMutex
	id2tong        map[int32]*Tong // 服务器帮会列表
	id2arrayidx    map[int32]int32 // 帮会在数组中的位置
	array_tong     []*Tong
	cur_tong_count int32
	array_tong_max int32

	last_recommend   *msg_server_message.RetRecommendTong
	last_recommend_t int32

	cur_tong_chest_state int32
	tongchestcfg         []*TongArenaLvlChests
	cur_act_left_sec     int32
	last_act_chk_unix    int32

	tong_score_rank *SmallRankService

	score_chg_chk_frame    int32 // 帮会积分变化检查帧
	score_chg_tongids      map[int32]int32
	score_chg_tongids_lock *sync.RWMutex
}

var tong_mgr TongMgr

func (this *TongMgr) Init() bool {
	this.id2tong_lock = &sync.RWMutex{}
	this.id2tong = make(map[int32]*Tong)
	this.score_chg_tongids = make(map[int32]int32)
	this.score_chg_tongids_lock = &sync.RWMutex{}

	this.LoadTongChestCfg()
	this.CheckTongChestActState()

	return true
}

func (this *TongMgr) LoadTongChestCfg() bool {
	content, err := ioutil.ReadFile("../game_data/ClanChestConfig.xml")
	if nil != err {
		log.Error("TongMgr LoadTongChestCfg failed err[%s]", err.Error())
		return false
	}

	tmp_cfg := &XmlTongChestConfig{}
	err = xml.Unmarshal(content, &tmp_cfg)
	if nil != err {
		log.Error("TongMgr LoadTongChestCfg xml unmarshal error[%s]", err.Error())
		return false
	}

	tmp_len := int32(len(tmp_cfg.Items))
	if tmp_len < 1 {
		log.Error("TongMgr LoadTongChestCfg tmp_len[%d] < 1", tmp_len)
		return false
	}

	tmp_scoremap := make(map[int32]bool)
	this.tongchestcfg = make([]*TongArenaLvlChests, 0, tmp_len)
	var tmp_chests *TongArenaLvlChests
	for idx, val := range tmp_cfg.Items {
		if !tmp_scoremap[val.TotalCrowns] {
			if nil != tmp_chests {
				tmp_chests.end_score = val.TotalCrowns - 1
				this.tongchestcfg = append(this.tongchestcfg, tmp_chests)
			}
			tmp_chests = &TongArenaLvlChests{}
			tmp_chests.start_score = val.TotalCrowns
			tmp_chests.Lvl2Items = make(map[int32]*XmlTongChestItem)
			tmp_scoremap[val.TotalCrowns] = true
		}

		tmp_chests.Lvl2Items[val.ArenaRating] = &tmp_cfg.Items[idx]
	}

	tmp_chests.end_score = MAX_MATCH_SCORE

	log.Info("部落宝箱配置加载完成！")
	for _, val := range this.tongchestcfg {
		if nil == val {
			continue
		}
		log.Info("部落宝箱[%d,%d]", val.start_score, val.end_score)
		for _, item := range val.Lvl2Items {
			log.Info("	具体条目：%v", *item)
		}
	}

	return true
}

// 初始化帮会排行榜 未加锁 在初始化的时候调用
func (this *TongMgr) InitRankWithDb(c *server_conn.ServerConn) {
	this.tong_score_rank = NewSmallRankService(200, SMALL_RANK_TYPE_TONG_SCORE, SMALL_RANK_SORT_TYPE_B)
	for tong_id, tong := range this.id2tong {
		if nil == tong {
			continue
		}

		log.Info("初始化帮会排行榜，处理帮会[%d]积分[%d]", tong_id, tong.db.TongMembers.GetTotalScore())
		this.tong_score_rank.SetUpdateRank(tong_id, tong.db.TongMembers.GetTotalScore())
	}

	this.PrintCurTongRank()

	all_rds := this.tong_score_rank.GetTopN(200)
	cur_count := int32(0)
	res2co := &msg_server_message.MultiTongScoreChg{}
	res2co.ChgList = make([]*msg_server_message.TongScoreChg, 0, 50)
	var tmp_t *Tong
	for _, val := range all_rds {
		if nil == val {
			continue
		}

		tmp_t = this.GetTongById(val.id)
		if nil == tmp_t {
			continue
		}

		tmp_chg := &msg_server_message.TongScoreChg{}
		tmp_chg.TongId = proto.Int32(val.id)
		tmp_chg.TongIcon = proto.Int32(tmp_t.db.TongData.GetIcon())
		tmp_chg.TongName = proto.String(tmp_t.db.TongData.GetName())
		tmp_chg.Score = proto.Int32(val.val)
		tmp_chg.Pos = proto.Int32(tmp_t.db.TongData.GetPos())

		res2co.ChgList = append(res2co.ChgList, tmp_chg)
		cur_count++
		if cur_count >= 50 {
			c.Send(res2co, true)
			res2co.ChgList = make([]*msg_server_message.TongScoreChg, 0, 50)
			cur_count = 1
		}
	}

	if cur_count > 0 {
		c.Send(res2co, true)
	}

	//this.PrintCurTongRank()
}

func (this *TongMgr) PrintCurTongRank() {
	log.Info("TongMgr 打印排行榜 ============ start !")

	cur_top := this.tong_score_rank.GetTopN(200)
	for _, val := range cur_top {
		if nil == val {
			continue
		}

		log.Info("	rank_item: 名次[%d] Id[%d] 积分[%d] ",
			val.rank, val.id, val.val)
	}

	log.Info("TongMgr 打印排行榜 ============ end !")
}

func (this *TongMgr) CheckTongChestActState() {

	cur_unix := int32(time.Now().Unix())
	if cur_unix-this.last_act_chk_unix < 2 {
		return
	}

	week_d := int32(time.Now().Weekday())
	if 0 == week_d {
		week_d = 7
	}

	this.last_act_chk_unix = cur_unix
	cur_week_sec := week_d*86400 + int32(time.Now().Hour())*3600 + int32(time.Now().Minute())*60 + int32(time.Now().Second())
	tmp_end_sec := int32(0)
	log.Info("TongMgr CheckTongChestActState ", len(global_config.TongChestOpenTimes))
	for _, val := range global_config.TongChestOpenTimes {
		log.Info("TongMgr CheckTongChestActState %v", val)
		tmp_end_sec = val.ActEndTime.WeekDay*86400 + val.ActEndTime.Hour*3600 + val.ActEndTime.Minute*60 + val.ActEndTime.Second
		if cur_week_sec >= val.StartTime.WeekDay*86400+val.StartTime.Hour*3600+val.StartTime.Minute*60+val.StartTime.Second &&
			cur_week_sec <= tmp_end_sec {
			this.cur_tong_chest_state = TONG_CHEST_OPEN
			this.cur_act_left_sec = tmp_end_sec - cur_week_sec
			break
		} else if cur_week_sec > val.ActEndTime.WeekDay*86400+val.ActEndTime.Hour*3600+val.ActEndTime.Minute*60+val.ActEndTime.Second &&
			cur_week_sec <= val.ActEndTime.WeekDay*86400+val.ActEndTime.Hour*3600+val.ActEndTime.Minute*60+val.ActEndTime.Second {
			this.cur_tong_chest_state = TONG_CHEST_REWARD
			break
		} else {
			this.cur_tong_chest_state = TONG_CHEST_CLOSE
		}
	}
}

func (this *TongMgr) AddTongNoLock(tong *Tong) {
	if nil == tong {
		log.Error("TongMgr AddTongNoLock tong nil !")
		return
	}

	this.id2tong[tong.db.GetTongId()] = tong
	return
}

func (this *TongMgr) AddTong(tong *Tong) {
	if nil == tong {
		log.Error("TongMgr AddTongNoLock Tong nil !")
		return
	}

	tong_id := tong.db.GetTongId()

	this.id2tong_lock.Lock()
	defer this.id2tong_lock.Unlock()

	this.id2tong[tong_id] = tong
}

func (this *TongMgr) GetTongById(tong_id int32) *Tong {
	this.id2tong_lock.RLock()
	defer this.id2tong_lock.RUnlock()

	return this.id2tong[tong_id]
}

func (this *TongMgr) remove_tong_by_id(tong_id int32) {
	this.id2tong_lock.Lock()
	defer this.id2tong_lock.Unlock()

	if nil != this.id2tong[tong_id] {
		delete(this.id2tong, tong_id)
	}

	return
}

func (this *TongMgr) RemoveTongById(player_id, tong_id int32) {
	tong := this.GetTongById(tong_id)
	if nil != tong {
		log.Error("TongMgr RemoveTongById fail to get tong[%d]", tong_id)
		return
	}

	if player_id != tong.db.TongData.GetCaptainId() {
		log.Error("TongMgr RemoveTongById not CaptainId")
		return
	}

	this.remove_tong_by_id(tong_id)
	dbc.Tongs.RemoveRow(tong_id)

	return
}

func (this *TongMgr) FillRecommandTongMsg() *msg_server_message.RetRecommendTong {
	cur_unix := int32(time.Now().Unix())
	cur_count := int32(0)
	var tmp_t *msg_server_message.TongSummaryInfo
	this.id2tong_lock.RLock()
	defer this.id2tong_lock.RUnlock()
	if cur_unix-this.last_recommend_t < TONG_MGR_RECOMMEND_CD_SEC && nil != this.last_recommend {
		return this.last_recommend
	}

	tmp_msg := &msg_server_message.RetRecommendTong{}
	this.last_recommend_t = cur_unix
	tmp_msg.Tongs = make([]*msg_server_message.TongSummaryInfo, 0, DEFAULT_RECOMMEND_TONG_NUM)
	for tong_id, tong := range this.id2tong {
		if nil == tong {
			continue
		}

		tmp_t = &msg_server_message.TongSummaryInfo{}
		tmp_t.Icon = proto.Int32(tong.db.TongData.GetIcon())
		tmp_t.MemCount = proto.Int32(tong.db.TongMembers.GetCurMemberCount())
		tmp_t.Name = proto.String(tong.db.TongData.GetName())
		tmp_t.TongScore = proto.Int32(tong.db.TongMembers.GetCurTongScore())
		tmp_t.TongId = proto.Int32(tong_id)
		tmp_msg.Tongs = append(tmp_msg.Tongs, tmp_t)
		cur_count++
		if cur_count >= DEFAULT_RECOMMEND_TONG_NUM {
			break
		}
	}

	this.last_recommend = tmp_msg
	return this.last_recommend
}

func (this *TongMgr) DoSearch(msg *msg_server_message.TongSearch) *msg_server_message.RetTongSearch {
	if nil == msg {
		log.Error("TongMgr DoSearch msg nil !")
		return nil
	}

	ret_msg := &msg_server_message.RetTongSearch{}
	ret_msg.TongList = make([]*msg_server_message.TongSummaryInfo, 0, DEFAULT_TONG_SEARCH_NUM)
	cur_count := int32(0)
	min_count := msg.GetMinCount()
	max_count := msg.GetMaxCount()
	min_score := msg.GetMinScore()
	only_can_join := msg.GetOnlyCanJoin()
	pos := msg.GetPos()
	tong_name := msg.GetName()
	var tmp_t *msg_server_message.TongSummaryInfo

	this.id2tong_lock.RLock()
	defer this.id2tong_lock.RUnlock()

	for tong_id, tong := range this.id2tong {
		if nil == tong {
			continue
		}

		if tong.tong_score < min_score {
			log.Info("帮会 %s tong_score not match(%d < %d) !", tong.db.TongData.GetName(), tong.tong_score < min_score)
			continue
		}

		if tong.db.TongMembers.GetCurMemberCount() < min_count || tong.db.TongMembers.GetCurMemberCount() > max_count {
			log.Info("帮会 %s membercount not match(%d , %d, %d) !", tong.db.TongData.GetName(), min_count, tong.db.TongMembers.GetCurMemberCount(), max_count)
			continue
		}

		if pos > 0 && tong.db.TongData.GetPos() != pos {
			log.Info("帮会 %s pos not match(%d, %d) !", tong.db.TongData.GetName(), tong.db.TongData.GetPos(), pos)
			continue
		}

		if 1 == only_can_join && TONG_JOIN_TYPE_EVERYONE != tong.db.TongData.GetJoinType() {
			log.Info("帮会 %s join_type not match(%d, %d) !", tong.db.TongData.GetName(), only_can_join, tong.db.TongData.GetJoinType())
			continue
		}

		if tong_name != tong.db.TongData.GetName() {
			log.Info("帮会 %s name not match %s !", tong.db.TongData.GetName(), tong_name)
			continue
		}

		tmp_t = &msg_server_message.TongSummaryInfo{}
		tmp_t.TongId = proto.Int32(tong_id)
		tmp_t.Icon = proto.Int32(tong.db.TongData.GetIcon())
		tmp_t.MemCount = proto.Int32(tong.db.TongMembers.GetCurMemberCount())
		tmp_t.Name = proto.String(tong.db.TongData.GetName())
		tmp_t.TongScore = proto.Int32(tong.db.TongMembers.GetCurTongScore())

		ret_msg.TongList = append(ret_msg.TongList, tmp_t)

		cur_count++
		if cur_count >= DEFAULT_TONG_SEARCH_NUM {
			break
		}
	}

	ret_msg.PlayerId = proto.Int32(msg.GetPlayerId())
	return ret_msg
}

func (this *TongMgr) AddScoreChgTongId(tong_id int32) {
	this.score_chg_tongids_lock.Lock()
	defer this.score_chg_tongids_lock.Unlock()

	this.score_chg_tongids[tong_id] = tong_id
}

func (this *TongMgr) PopTongScoreChgs() map[int32]int32 {
	this.score_chg_tongids_lock.Lock()
	defer this.score_chg_tongids_lock.Unlock()
	if len(this.score_chg_tongids) < 1 {
		return nil
	}

	ret_ids := this.score_chg_tongids

	this.score_chg_tongids = make(map[int32]int32)

	return ret_ids
}

func (this *TongMgr) OnTick() {

	if this.score_chg_chk_frame < TONG_SCORE_CHG_CHK_FRAME {
		this.score_chg_chk_frame++
		return
	}

	this.score_chg_chk_frame = 0

	score_chg_tong_ids := this.PopTongScoreChgs()
	req2co := &msg_server_message.MultiTongScoreChg{}
	req2co.ChgList = make([]*msg_server_message.TongScoreChg, 0, 50)
	var tmp_tong *Tong
	var tmp_chg *msg_server_message.TongScoreChg
	cur_count := int32(0)
	for _, tong_id := range score_chg_tong_ids {
		tmp_tong = this.GetTongById(tong_id)
		if nil == tmp_tong {
			continue
		}

		tmp_chg = &msg_server_message.TongScoreChg{}
		tmp_chg.TongId = proto.Int32(tong_id)
		tmp_chg.TongIcon = proto.Int32(tmp_tong.db.TongData.GetIcon())
		tmp_chg.TongName = proto.String(tmp_tong.db.TongData.GetName())
		tmp_chg.Score = proto.Int32(tmp_tong.db.TongMembers.GetTotalScore())
		tmp_chg.Pos = proto.Int32(tmp_tong.db.TongData.GetPos())

		req2co.ChgList = append(req2co.ChgList, tmp_chg)
		cur_count++
		if cur_count >= 50 {
			center_conn.Send(req2co)
			cur_count = 0
			req2co.ChgList = make([]*msg_server_message.TongScoreChg, 0, 50)
		}

		this.tong_score_rank.SetUpdateRank(tong_id, *tmp_chg.Score)
	}

	if cur_count > 0 {
		center_conn.Send(req2co)
	}
}

// ==================================================================

func (this *TongMgr) RegTongMsg() {
	center_conn.SetMessageHandler(msg_server_message.ID_CreateTong, this.C2TCreateTongHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_GetTongInfo, this.C2TGetTongInfoHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongSearch, this.C2TTongSearchHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_GetRecommendTong, this.C2TGetRecommondTongHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_EnterTong, this.C2TEnterTongHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_EnterTongAgree, this.C2TEnterTongAgreeHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongLeave, this.C2TTongLeaveHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_SetPlayerTongInfoOk, this.C2TSetPlayerTongInfoOkHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_SetTongMemberOnOffline, this.C2TSetTongMemberOnOfflineHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongSetChg, this.C2TTongSetChgHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongPubChg, this.C2TTongPubChgHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongChatSend, this.C2TTongChatSendHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongCardReq, this.C2TTongCardReqHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongDonateCard, this.C2TTongDonateCardHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongMemberFightEnd, this.C2TTongMemberFightEndHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongChestOpen, this.C2TTongChestOpenHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongFriendMatch, this.C2TTongFriendMatchHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongFriendCancel, this.C2TTongFriendCancelHandler)
	center_conn.SetMessageHandler(msg_server_message.ID_TongFriendEnter, this.C2TTongFriendEnterHandler)
}

func (this *TongMgr) C2TCreateTongHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.CreateTong)
	if nil == req || nil == c {
		log.Error("TongMgr C2TCreateTongHandler param error !")
		return
	}

	new_tong := CreateTong(req)
	if nil == new_tong {
		return
	}

	this.AddTong(new_tong)
	this.AddScoreChgTongId(new_tong.tong_id)

	res2co := &msg_server_message.CreateTongOk{}
	res2co.TongId = proto.Int32(req.GetTongId())
	res2co.CreatorId = proto.Int32(req.GetCreatorId())
	res2co.Icon = proto.Int32(req.GetIcon())
	res2co.JoinScore = proto.Int32(req.GetJoinScore())
	res2co.JoinType = proto.Int32(req.GetJoinType())
	res2co.Pos = proto.Int32(req.GetPos())
	res2co.TongName = proto.String(req.GetTongName())
	res2co.TongPub = proto.String(req.GetTongPub())

	c.Send(res2co)
}

func (this *TongMgr) C2TGetTongInfoHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.GetTongInfo)
	if nil == c || nil == req {
		log.Error("TongMgr C2TGetTongInfoHandler c or req nil [%v]!", nil == c)
		return
	}

	tong_id := req.GetTongId()
	tong := this.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TGetTongInfoHandler Failed to get tong by Id[%d]", tong_id)
		return
	}

	res2co := tong.GetRetTongInfoMsg(req.GetPlayerId(), req.GetIfOwnTong())
	this.CheckTongChestActState()
	if TONG_CHEST_CLOSE == this.cur_tong_chest_state && 1 != tong.db.TongData.GetIfTongChestClear() {
		tong.db.TongChestOpens.Clear()
		tong.db.TongData.SetIfTongChestClear(1)
	}

	res2co.TongChestState = proto.Int32(this.cur_tong_chest_state)
	if this.cur_act_left_sec > 0 {
		res2co.TongChestLeftSec = proto.Int32(this.cur_act_left_sec)
	}

	if nil != tong.db.TongChestOpens.Get(req.GetPlayerId()) {
		res2co.IfGetTongChest = proto.Int32(1)
	}
	res2co.TongChestScore = proto.Int32(tong.db.TongData.GetTongChestScore())

	c.Send(res2co)
}

func (this *TongMgr) C2TGetRecommondTongHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.GetRecommendTong)
	if nil == req || nil == c {
		log.Error("TongMgr C2TGetRecommondTongHandler")
		return
	}

	ret_msg := this.FillRecommandTongMsg()
	if nil != ret_msg {
		ret_msg.PlayerId = proto.Int32(req.GetPlayerId())
		c.Send(ret_msg)
	} else {
		log.Error("TongMgr C2TGetRecommondTongHandler FillRecommandTongMsg nil")
	}

	return
}

func (this *TongMgr) C2TTongSearchHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongSearch)
	if nil == req || nil == c {
		log.Error("TongMgr C2TTongSearchHandler param error")
		return
	}

	res2co := this.DoSearch(req)
	if nil != res2co {
		c.Send(res2co)
	}

	return
}

func (this *TongMgr) C2TEnterTongHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.EnterTong)
	if nil == c || nil == req {
		log.Error("TongMgr C2TEnterTongHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TEnterTongHandler tong[%d] nil", tong_id)
		return
	}

	if tong.EnterTong(c, req) {
		pid := req.GetPlayerId()
		res2co := tong.GetRetTongInfoMsg(pid, 1)
		res2co.IfEnter = proto.Int32(1)
		c.Send(res2co)

		notify := &msg_server_message.NotifyPlayerEnter{}
		notify.OnlinePlayers = tong.GetOnlinePlayerIds(pid)
		if len(notify.OnlinePlayers) > 0 {
			notify.PlayerId = proto.Int32(pid)
			notify.PlayerName = proto.String(req.GetPlayerName())
			notify.PlayerScore = proto.Int32(req.GetScore())
			notify.IfOnline = proto.Int32(1)
			c.Send(notify)
		}

		this.AddScoreChgTongId(tong_id)

	}

	return
}

func (this *TongMgr) C2TEnterTongAgreeHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.EnterTongAgree)
	if nil == c || nil == req {
		log.Error("TongMgr C2TEnterTongAgreeHandler c or req nil [%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TEnterTongAgreeHandler failed to get tong by id[%d]", tong_id)
		return
	}

	op_mem := tong.db.TongMembers.GetByPlayerId(req.GetOpPlayerId())
	if nil == op_mem {
		log.Error("TongMgr C2TEnterTongAgreeHandler failed to get op_mem[%d]", req.GetOpPlayerId())
		return
	}

	if TONG_MEMBER_CAPTAIN != op_mem.MemberType {
		log.Error("TongMgr C2TEnterTongAgreeHandler op_mem[%d] type[%d] error", req.GetOpPlayerId(), op_mem.MemberType)
		return
	}

	tong.EnterAgree(c, req, op_mem)

	return
}

func (this *TongMgr) C2TTongEnterRefuseHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.EnterTongRefuse)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongEnterRefuseHandler c or req nil [%v]", nil == req)
		return
	}

	return
}

func (this *TongMgr) C2TSetPlayerTongInfoOkHandler(c *CenterConnection, msg proto.Message) {
	res := msg.(*msg_server_message.SetPlayerTongInfoOk)
	if nil == c || nil == res {
		log.Error("TongMgr C2TSetPlayerTongInfoOkHandler c or res nil [%v]", nil == res)
		return
	}

	tong_id := res.GetTongId()
	tong := this.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TSetPlayerTongInfoOkHandler c or res nil [%v]", nil == res)
		return
	}

	if tong.OnSetPlayerTongInfoOk(c, res) {
		this.AddScoreChgTongId(tong_id)
	}

	return
}

func (this *TongMgr) C2TTongLeaveHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongLeave)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongLeaveHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongLeaveHandler failed to find tong[%d]", tong_id)
		return
	}

	tong.ChkMemberLeave(c, req)
	this.AddScoreChgTongId(tong_id)

	return
}

func (this *TongMgr) C2TClearTongPlayerByIdHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.ClearPlayerTongInfo)
	if nil == c || nil == req {
		log.Error("TongMgr C2TClearTongPlayerByIdHandler c or req nil[%v]", nil == req)
		return
	}

	return
}

func (this *TongMgr) C2TSetTongMemberOnOfflineHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.SetTongMemberOnOffline)
	if nil == c || nil == req {
		log.Error("TongMgr C2TSetTongMemberOnOfflineHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TSetTongMemberOnOfflineHandler failed to find tong[%d]", tong_id)
		return
	}

	if 1 == req.GetOnOffLine() {
		tong.SetMemberOnline(req.GetPlayerId())
	} else {
		tong.SetMemberOffline(req.GetPlayerId())
	}

	res2co := &msg_server_message.NotifyTongMemberOnOffline{}
	res2co.OnlinePlayers = tong.GetOnlinePlayerIds(req.GetPlayerId())
	if len(res2co.OnlinePlayers) > 0 {
		res2co.OnOffLine = proto.Int32(req.GetOnOffLine())
		res2co.PlayerId = proto.Int32(req.GetPlayerId())

		c.Send(res2co)
	}

	return
}

func (this *TongMgr) C2TTongSetChgHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongSetChg)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongSetChgHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongSetChgHandler failed to find tong[%d]", tong_id)
		return
	}

	tong.TongSetChg(req)
	res2co := &msg_server_message.NotifyTongSetChg{}
	res2co.OnlinePlayers = tong.GetOnlinePlayerIds(0)
	if len(res2co.OnlinePlayers) > 0 {
		res2co.Icon = proto.Int32(req.GetIcon())
		res2co.JoinScore = proto.Int32(req.GetJoinScore())
		res2co.JoinType = proto.Int32(req.GetJoinType())
		res2co.Pos = proto.Int32(req.GetPos())
		res2co.TongId = proto.Int32(req.GetTongId())
		res2co.TongName = proto.String(req.GetTongName())

		c.Send(res2co)
	}

	return
}

func (this *TongMgr) C2TTongPubChgHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongPubChg)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongSetChgHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongSetChgHandler failed to find tong[%d]", tong_id)
		return
	}

	tong.db.TongData.SetPubContent(req.GetTongPub())
	res2co := &msg_server_message.NotifyTongPubChg{}
	res2co.OnlinePlayers = tong.GetOnlinePlayerIds(0)
	if len(res2co.OnlinePlayers) > 0 {
		res2co.TongPub = proto.String(req.GetTongPub())
		res2co.TongId = proto.Int32(req.GetTongId())

		c.Send(res2co)
	}

	return
}

func (this *TongMgr) C2TTongChatSendHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongChatSend)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongSetChgHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongSetChgHandler failed to find tong[%d]", tong_id)
		return
	}

	tong.db.TongChatRecords.AddNewChatRdByMsg(req)
	res2co := &msg_server_message.NotifyTongChatSend{}
	res2co.OnlinePlayers = tong.GetOnlinePlayerIds(0)
	if len(res2co.OnlinePlayers) > 0 {
		res2co.PlayerId = proto.Int32(req.GetPlayerId())
		res2co.PlayerName = proto.String(req.GetPlayerName())
		res2co.Content = proto.String(req.GetContent())
		res2co.TongId = proto.Int32(req.GetTongId())
		res2co.SendUnix = proto.Int32(int32(time.Now().Unix()))
		c.Send(res2co)
	}

	return
}

func (this *TongMgr) C2TTongCardReqHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongCardReq)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongCardReqHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongCardReqHandler failed to find tong[%d]", tong_id)
		return
	}

	tong.db.TongCardReqs.AddNewCardReqBymsg(req)
	res2co := &msg_server_message.NotifyTongCardReq{}
	res2co.OnlinePlayers = tong.GetOnlinePlayerIds(0)
	if len(res2co.OnlinePlayers) > 0 {
		res2co.PlayerId = proto.Int32(req.GetPlayerId())
		res2co.PlayerName = proto.String(req.GetPlayerName())
		res2co.CardCfgId = proto.Int32(req.GetCardCfgId())
		res2co.MaxGetNum = proto.Int32(req.GetMaxGetNum())
		res2co.ReqUnix = proto.Int32(int32(time.Now().Unix()))
		c.Send(res2co)
	}

	return
}

func (this *TongMgr) C2TTongDonateCardHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongDonateCard)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongDonateCardHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongDonateCardHandler failed to find tong[%d]", tong_id)
		return
	}

	pid := req.GetPlayerId()
	tong_mem_id := tong.db.TongMembers.GetMemberIdByPlayerId(pid)
	if -1 == tong_mem_id {
		log.Error("TongMgr C2TTongDonateCardHandler failed to find mem_id [%d]", pid)
		return
	}

	if tong.db.TongCardReqs.ChkDoDonate(req) {
		tong.db.TongMembers.IncbyDonate(tong_mem_id, 1)
		res2co := &msg_server_message.NotifyTongDonateCard{}
		res2co.OnlinePlayers = tong.GetOnlinePlayerIds(0)
		if len(res2co.OnlinePlayers) > 0 {
			res2co.PlayerId = proto.Int32(pid)
			res2co.PlayerName = proto.String(req.GetPlayerName())
			res2co.CardCfgId = proto.Int32(req.GetCardCfgId())
			res2co.TgtPlayerId = proto.Int32(req.GetTgtPlayerId())
			c.Send(res2co)
		}
	} else {
		res2co := &msg_server_message.TongDonateCardFailed{}
		res2co.PlayerId = proto.Int32(req.GetPlayerId())
	}

	return
}

func (this *TongMgr) C2TTongMemberFightEndHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongMemberFightEnd)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongMemberFightEndHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongMemberFightEndHandler failed to find tong[%d]", tong_id)
		return
	}

	this.CheckTongChestActState()
	if TONG_CHEST_CLOSE == this.cur_tong_chest_state && 1 != tong.db.TongData.GetIfTongChestClear() {
		tong.db.TongChestOpens.Clear()
		tong.db.TongData.SetIfTongChestClear(1)
	}
	win_score := req.GetScore()
	if TONG_CHEST_OPEN == this.cur_tong_chest_state && win_score > 0 {
		cur_score := tong.db.TongData.IncbyTongChestScore(req.GetScore())
		res2co := &msg_server_message.NotifyTongChestScoreChg{}
		res2co.OnlinePlayers = tong.GetOnlinePlayerIds(0)
		if len(res2co.OnlinePlayers) > 0 {
			res2co.CurScore = proto.Int32(cur_score)
			c.Send(res2co)
		}
	} else {
		log.Info("TongMgr C2TTongMemberFightEndHandler state[%d] or win_score[%d] not ok", this.cur_tong_chest_state, win_score)
	}

	pid := req.GetPlayerId()
	cur_score := req.GetCurScore()
	tmp_memid := tong.db.TongMembers.GetMemberIdByPlayerId(pid)
	if 0 < tmp_memid {
		tong.db.TongMembers.SetScore(tmp_memid, cur_score)
		res2co := &msg_server_message.NotifyTongMemberScoreChg{}
		res2co.OnlinePlayers = tong.GetOnlinePlayerIds(0)
		if len(res2co.OnlinePlayers) > 0 {
			res2co.PlayerId = proto.Int32(pid)
			res2co.CurScore = proto.Int32(cur_score)
			c.Send(res2co)
		}
		tong.db.TongMembers.SetScore(tmp_memid, cur_score)
		this.AddScoreChgTongId(tong_id)
	} else {
		log.Info("TongMgr C2TTongMemberFightEndHandler failed to get memberid[%d] by pid[%d]", tmp_memid, pid)
	}

	return
}

func (this *TongMgr) C2TTongChestOpenHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongChestOpen)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongChestOpenHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongChestOpenHandler failed to find tong[%d]", tong_id)
		return
	}

	this.CheckTongChestActState()

	if TONG_CHEST_REWARD != this.cur_tong_chest_state {
		log.Error("TongMgr C2TTongChestOpenHandler not in reward state[%d]", this.cur_tong_chest_state)
		return
	}

	pid := req.GetPlayerId()
	if nil != tong.db.TongChestOpens.Get(pid) {
		log.Error("TongMgr C2TTongChestOpenHandler[%d] already Get", pid)
		return
	}

	cur_score := tong.db.TongData.GetTongChestScore()
	arena_lvl := req.GetArenaLvl()
	for _, val := range this.tongchestcfg {
		if nil == val {
			continue
		}

		if val.start_score <= cur_score && cur_score <= val.end_score {
			tmp_item := val.Lvl2Items[arena_lvl]
			if nil != tmp_item {
				tong.db.TongChestOpens.ForceAddChestOpen(pid, int32(time.Now().Unix()))

				res2co := &msg_server_message.RetTongChestOpen{}
				res2co.PlayerId = proto.Int32(req.GetPlayerId())
				res2co.ChestId = proto.Int32(tmp_item.ChestID)
				c.Send(res2co)
			} else {
				log.Error("TongMgr C2TTongChestOpenHandler failed to find xml item [%d:%d]", cur_score, arena_lvl)
			}
			break
		}
	}

	return
}

func (this *TongMgr) C2TTongFriendMatchHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongFriendMatch)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongFriendMatchHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongFriendMatchHandler failed to find tong[%d]", tong_id)
		return
	}

	pid := req.GetPlayerId()
	pname := req.GetName()
	if tong.AddFriendMatch(req) {
		res2co := &msg_server_message.NotifyTongFriendMatch{}
		res2co.PlayerId = proto.Int32(pid)
		res2co.PlayerName = proto.String(pname)
		res2co.OnlinePlayers = tong.GetOnlinePlayerIds(0)
		center_conn.Send(res2co)
	}

	return
}

func (this *TongMgr) C2TTongFriendCancelHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongFriendCancel)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongFriendCancelHandler c or req nil[%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongFriendCancelHandler failed to find tong[%d]", tong_id)
		return
	}

	pid := req.GetPlayerId()
	if tong.CancelFriendMatch(pid) {
		res2co := &msg_server_message.NotifyTongFriendCancel{}
		res2co.PlayerId = proto.Int32(pid)
		res2co.OnlinePlayers = tong.GetOnlinePlayerIds(0)
		center_conn.Send(res2co)
	}

	return
}

func (this *TongMgr) C2TTongFriendEnterHandler(c *CenterConnection, msg proto.Message) {
	req := msg.(*msg_server_message.TongFriendEnter)
	if nil == c || nil == req {
		log.Error("TongMgr C2TTongFriendEnterHandler c or req nil [%v]", nil == req)
		return
	}

	tong_id := req.GetTongId()
	tong := tong_mgr.GetTongById(tong_id)
	if nil == tong {
		log.Error("TongMgr C2TTongFriendEnterHandler failed to find tong[%d]", tong_id)
		return
	}

	pid := req.GetPlayerId()
	tgt_id := req.GetTgtPlayerId()
	cur_match := tong.PopTongFriendMatch(tgt_id)
	if nil == cur_match {
		log.Error("TongMgr C2TTongFriendEnterHandler failed to pop match[%d]", tgt_id)
		return
	}

	cur_unix := int32(time.Now().Unix())
	req2m := &msg_server_message.GetRoomReq{}
	req2m.MatchPlayers = make([]*msg_server_message.MatchPlayer, 2)
	tmp_mp := &msg_server_message.MatchPlayer{}
	tmp_mp.Id = proto.Int64(int64(cur_match.pid))
	tmp_mp.Name = proto.String(cur_match.name)
	tmp_mp.Score = proto.Int32(cur_match.score)
	tmp_mp.CardCfgIds = cur_match.card_ids
	tmp_mp.CardLvls = cur_match.card_lvls
	tmp_mp.Token = proto.Int32(cur_unix)
	tmp_mp.TongIcon = proto.Int32(tong.db.TongData.GetIcon())
	tmp_mp.TongName = proto.String(tong.db.TongData.GetName())
	tmp_mp.HallId = proto.Int32(cur_match.hall_id)
	req2m.MatchPlayers[0] = tmp_mp

	tmp_mp = &msg_server_message.MatchPlayer{}
	tmp_mp.Id = proto.Int64(int64(req.GetPlayerId()))
	tmp_mp.Name = proto.String(req.GetPlayerName())
	tmp_mp.Score = proto.Int32(req.GetScore())
	tmp_mp.CardCfgIds = req.GetCardIds()
	tmp_mp.CardLvls = req.GetCardLvls()
	tmp_mp.Token = proto.Int32(cur_unix)
	tmp_mp.TongIcon = proto.Int32(tong.db.TongData.GetIcon())
	tmp_mp.TongName = proto.String(tong.db.TongData.GetName())
	tmp_mp.HallId = proto.Int32(req.GetHallId())
	req2m.MatchPlayers[1] = tmp_mp

	req2m.ResultId = proto.Int32(tong_id)
	req2m.MatchType = proto.Int32(MATCH_TYPE_TONG_FRIEND)

	res2co := &msg_server_message.NotifyTongFriendCancel{}
	res2co.PlayerId = proto.Int32(pid)
	res2co.OnlinePlayers = tong.GetOnlinePlayerIds(0)
	center_conn.Send(res2co)

	match_conn.Send(req2m)

	return
}

func (this *TongMgr) PrintCurTongs() {
	log.Info("当前拥有的帮会！！！！！")
	for tong_id, _ := range this.id2tong {
		log.Info("	帮会[%d]", tong_id)
	}
	log.Info("===========================")
}
