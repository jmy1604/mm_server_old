package main

import (
	"libs/log"
	"libs/socket"
	"public_message/gen_go/client_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

func (this *Player) ChkPlayerSignInfo() {
	cur_month := int32(time.Now().Month())
	if cur_month != this.db.SignInfo.GetCurSignSumMonth() {
		this.db.SignInfo.SetCurSignSumMonth(cur_month)
		this.db.SignInfo.SetCurSignSum(0)
		this.db.SignInfo.SetRewardSignSum(nil)
	}
}

func (this *Player) SyncPlayerSignInfo() {
	this.ChkPlayerSignInfo()
	res2cli := &msg_client_message.S2CSyncSignInfo{}
	this.db.SignInfo.FillSyncMsg(res2cli)
	this.Send(res2cli)
}

// --------------------------------------------

func reg_player_sign_msg() {
	hall_server.SetMessageHandler(msg_client_message.ID_C2SDaySign, C2SDaySignHandler)
	hall_server.SetMessageHandler(msg_client_message.ID_C2SGetDaySignSumReward, C2SGetDaySignSumRewardHandler)
}

func C2SDaySignHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SDaySign)
	if nil == c || nil == req {
		log.Error("C2SDaySignHandler c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SDaySignHandler not login [%d]", c.T)
		return
	}

	p.ChkPlayerSignInfo()

	cur_sign_key := int32(time.Now().Year()*10000 + int(time.Now().Month())*100 + time.Now().Day())
	sign_cfg := cfg_day_sign_mgr.Map[cur_sign_key]
	if nil == sign_cfg {
		log.Error("Failed to find Day sign cfg [%d]", cur_sign_key)
		return
	}

	cur_signs := p.db.SignInfo.GetCurSignDays()
	for _, val := range cur_signs {
		if val == cur_sign_key {
			log.Error("C2SDaySignHandler already signed !!")
			return
		}
	}

	tmp_len := int32(len(cur_signs))
	new_signs := make([]int32, tmp_len+1)
	for idx, val := range cur_signs {
		new_signs[idx] = val
	}

	new_signs[tmp_len] = cur_sign_key
	p.db.SignInfo.SetCurSignDays(new_signs)
	p.db.SignInfo.IncbyCurSignSum(1)

	res2cli := &msg_client_message.S2CDaySign{}
	if PLAYER_CAMP_1 == p.db.Info.GetCamp() {
		if sign_cfg.Camp1CardID > 0 {
			p.AddCard(sign_cfg.Camp1CardID, sign_cfg.Camp1CardCount, "DaySign", "DaySign", true, false)
			res2cli.CardCfgId = proto.Int32(sign_cfg.Camp1CardID)
			cur_num, _ := p.db.Cards.GetCardCount(sign_cfg.Camp1CardID)
			res2cli.CurCardNum = proto.Int32(cur_num)
		}
	} else {
		if sign_cfg.Camp2CardID > 0 {
			p.AddCard(sign_cfg.Camp2CardID, sign_cfg.Camp2CardCount, "DaySign", "DaySign", true, false)
			res2cli.CardCfgId = proto.Int32(sign_cfg.Camp2CardID)
			cur_num, _ := p.db.Cards.GetCardCount(sign_cfg.Camp2CardID)
			res2cli.CurCardNum = proto.Int32(cur_num)
		}
	}

	if sign_cfg.GoldCount > 0 {
		res2cli.CurCoin = proto.Int32(p.AddCoin(sign_cfg.GoldCount, "DaySign", "DaySign"))
	}

	if sign_cfg.GemCount > 0 {
		res2cli.CurDiamond = proto.Int32(p.AddDiamond(sign_cfg.GemCount, "DaySign", "DaySign"))
	}

	if sign_cfg.CardToken1Count > 0 {
		res2cli.CurCardToken1 = proto.Int32(p.AddCardToken1(sign_cfg.CardToken1Count, "DaySign", "DaySign"))
	}

	if sign_cfg.CardToken2Count > 0 {
		res2cli.CurCardToken2 = proto.Int32(p.AddCardToken2(sign_cfg.CardToken2Count, "DaySign", "DaySign"))
	}

	if sign_cfg.CardToken3Count > 0 {
		res2cli.CurCardToken3 = proto.Int32(p.AddCardToken3(sign_cfg.CardToken3Count, "DaySign", "DaySign"))
	}

	if sign_cfg.CardToken4Count > 0 {
		res2cli.CurCardToken4 = proto.Int32(p.AddCardToken4(sign_cfg.CardToken4Count, "DaySign", "DaySign"))
	}

	p.Send(res2cli)

	return
}

func C2SGetDaySignSumRewardHandler(c *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SGetDaySignSumReward)
	if nil == c || nil == req {
		log.Error("C2SGetDaySignSumRewardHandler c or req nil [%v]", nil == req)
		return
	}

	p := player_mgr.GetPlayerById(int32(c.T))
	if nil == p {
		log.Error("C2SGetDaySignSumRewardHandler not login[%d]", c.T)
		return
	}

	p.ChkPlayerSignInfo()
	sign_sum := req.GetSumNum()

	if sign_sum > p.db.SignInfo.GetCurSignSum() {
		log.Error("C2SGetDaySignSumRewardHandler sign_sum not enough !")
		return
	}

	reward := cfg_day_sign_mgr.SunNum2Reward[sign_sum]
	if nil == reward {
		log.Error("C2SGetDaySignSumRewardHandler can not find sign_sum[%d] for cfg !", sign_sum)
		return
	}

	res2cli := &msg_client_message.S2CRetDaySignSumReward{}
	res2cli.Rewards = p.OpenChest(reward.ChestId, "Sign_sum_Reward", "DaySign", 0, -1, true)

	p.Send(res2cli)

	return
}
