package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"libs/log"
	"libs/timer"
	"net/http"
	"net/url"
	"public_message/gen_go/client_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	TONG_MEMBER_MENBER  = 0 // 帮会成员
	TONG_MEMBER_CAPTAIN = 1 // 帮会帮主

	TONG_JOIN_TYPE_EVERYONE = 0 // 任何人都可以加入
	TONG_JOIN_TYPE_NOONE    = 1 // 不允许任何人加入
	TONG_JOIN_TYPE_NEED_CHK = 2 // 需要确认

	TONG_AGREE_AVI_SEC = 5 // 同意占位有效时间
)

type TestClient struct {
	start_time         time.Time
	quit               bool
	shutdown_lock      *sync.Mutex
	shutdown_completed bool
	ticker             *timer.TickTimer
	initialized        bool
}

var test_client TestClient

func (this *TestClient) Init() (ok bool) {
	this.start_time = time.Now()
	this.shutdown_lock = &sync.Mutex{}
	this.initialized = true

	return true
}

func (this *TestClient) Start() (err error) {

	log.Event("客户端已启动", nil)
	log.Trace("**************************************************")

	this.Run()

	return
}

func (this *TestClient) Run() {
	defer func() {
		if err := recover(); err != nil {
			log.Stack(err)
		}

		this.shutdown_completed = true
	}()

	this.ticker = timer.NewTickTimer(1000)
	this.ticker.Start()
	defer this.ticker.Stop()

	for {
		select {
		case d, ok := <-this.ticker.Chan:
			{
				if !ok {
					return
				}

				this.OnTick(d)
			}
		}
	}
}

func (this *TestClient) Shutdown() {
	if !this.initialized {
		return
	}

	this.shutdown_lock.Lock()
	defer this.shutdown_lock.Unlock()

	if this.quit {
		return
	}
	this.quit = true

	log.Trace("关闭游戏主循环")

	begin := time.Now()

	if this.ticker != nil {
		this.ticker.Stop()
	}

	for {
		if this.shutdown_completed {
			break
		}

		time.Sleep(time.Millisecond * 100)
	}

	log.Trace("关闭游戏主循环耗时 %v 秒", time.Now().Sub(begin).Seconds())
}

const (
	CMD_TYPE_LOGIN = 1 // 登录命令
)

type JsonLoginRes struct {
	Code    int32
	Account string
	Token   string
	HallIP  string
}

var cur_hall_conn *HallConnection

func (this *TestClient) OnTick(t timer.TickTime) {

	fmt.Printf("请输入命令:1为登录 3为用卡\n")
	var cmd_str string
	fmt.Scanf("%s\n", &cmd_str)
	switch cmd_str {
	case "1":
		{
			var acc string
			fmt.Printf("请输入账号：")
			fmt.Scanf("%s\n", &acc)
			cur_hall_conn = hall_conn_mgr.GetHallConnByAcc(acc)
			if nil != cur_hall_conn && cur_hall_conn.blogin {
				log.Info("[%s] already login", acc)
				break
			}
			url_str := fmt.Sprintf("http://192.168.2.111:15000/login?account=%s&token=0000", acc)
			//url_str := fmt.Sprintf("http://123.207.182.67:15000/login?account=%s&token=0000", acc)
			//url_str := fmt.Sprintf("http://192.168.10.113:15000/login?account=%s&token=0000", acc)
			fmt.Println("Url str %s", url_str)
			resp, err := http.Get(url_str)
			if nil != err {
				log.Error("login http get err (%s)", err.Error())
				break
			}

			data, err := ioutil.ReadAll(resp.Body)
			if nil != err {
				log.Error("login ioutil readall failed err(%s) !", err.Error())
				break
			}

			res := &JsonLoginRes{}
			err = json.Unmarshal(data, res)
			if nil != err {
				log.Error("login ummarshal failed err(%s)", err.Error())
				break
			}

			log.Info("login before connect hall")

			cur_hall_conn = hall_conn_mgr.GetHallConnByAcc(acc)
			if nil == cur_hall_conn {
				cur_hall_conn = new_hall_connect(res.HallIP, acc)
				hall_conn_mgr.AddHallConn(cur_hall_conn)
				go cur_hall_conn.Start()
				cur_hall_conn.WaitConnectOk()
			}

			req := &msg_client_message.C2SLoginRequest{}
			req.Acc = proto.String(res.Account)
			req.Token = proto.String(res.Token)
			cur_hall_conn.Send(req)
		}
	case "0":
		{
			var camp int32
			fmt.Printf("请选择阵营：")
			fmt.Scanf("%d\n", &camp)
			if 1 != camp && 2 != camp {
				log.Error("=============================")
				break
			}
			req := &msg_client_message.C2SSetCamp{}
			req.Camp = proto.Int32(camp)

			cur_hall_conn.Send(req)
		}
	case "2":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				log.Info("发送匹配消息")
				req := &msg_client_message.C2SMatchReq{}
				req.MatchType = proto.Int32(0)
				cur_hall_conn.Send(req)
			}
		}
	case "match":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				log.Info("发送匹配消息")
				req := &msg_client_message.C2SMatchReq{}
				req.MatchType = proto.Int32(0)
				cur_hall_conn.Send(req)
			}
		}
	case "3":
		{
			if nil == cur_hall_conn.room_conn {
				log.Error("未连接房间，还不能发送卡片使用信息！")
				break
			}

			if !cur_hall_conn.room_conn.blogin {
				log.Error("房间服务器未登录成功！还不能发送卡片使用信息！")
			}

			var card_idx int32
			fmt.Printf("请输入卡片序号：")
			fmt.Scanf("%d\n", &card_idx)

			req := &msg_client_message.C2SUseCard{}
			req.Idx = proto.Int32(card_idx)
			req.X = proto.Float32(24.0)
			req.Y = proto.Float32(24.0)

			cur_hall_conn.room_conn.Send(req)
		}
	case "c_match":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				log.Info("发送取消匹配消息")
				req := &msg_client_message.C2SMatchCancel{}
				cur_hall_conn.Send(req)
			}
		}
	case "buy_card":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				var card_idx int32
				fmt.Printf("请输入购买卡片的序号(1或者2或者3):")
				fmt.Scanf("%d\n", &card_idx)
				var buy_count int32
				fmt.Printf("请输入购买卡片的数目:")
				fmt.Scanf("%d\n", &buy_count)

				req := &msg_client_message.C2SBuyCard{}
				req.CardPos = proto.Int32(card_idx)
				req.BuyNum = proto.Int32(buy_count)

				cur_hall_conn.Send(req)
			}
		}
	case "open_chest":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				var chest_idx int32
				fmt.Printf("请输入需要打开的宝箱的序号(1或者2或者3或者4):")
				fmt.Scanf("%d\n", &chest_idx)
				var if_force int32
				fmt.Printf("是否强制打开:")
				fmt.Scanf("%d\n", &if_force)
				if 1 == if_force {
					req := &msg_client_message.C2SOpenChestDiamond{}
					req.ChestPos = proto.Int32(chest_idx)
					cur_hall_conn.Send(req)
				} else {
					req := &msg_client_message.C2SOpenChest{}
					req.ChestPos = proto.Int32(chest_idx)

					cur_hall_conn.Send(req)
				}

			}
		}
	case "c_tong":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				var tong_name string
				fmt.Printf("创建帮会，请输入帮会名称:")
				fmt.Scanf("%s\n", &tong_name)

				var join_type int32
				fmt.Printf("请输入帮会加入模式0(任何)/1(关闭)/2(确认):")
				fmt.Scanf("%d\n", &join_type)
				if join_type < 0 || join_type > 2 {
					join_type = 0
				}

				var join_score int32
				fmt.Printf("请输入帮会加入积分:")
				fmt.Scanf("%d\n", &join_score)

				req := &msg_client_message.C2SCreateTong{}
				req.TongName = proto.String(tong_name)
				req.Icon = proto.Int32(1)
				req.JoinScore = proto.Int32(join_score)
				req.JoinType = proto.Int32(join_type)
				log.Info("创建帮会 [%v]", req)
				cur_hall_conn.Send(req)
			}
		}
	case "l_tong":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				req := &msg_client_message.C2SLeaveTong{}
				log.Info("离开帮会 [%v]", req)
				cur_hall_conn.Send(req)
			}
		}
	case "get_tong":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				var tong_id int32
				fmt.Printf("请输入帮会Id:")
				fmt.Scanf("%d\n", &tong_id)

				req := &msg_client_message.C2SGetTongInfo{}
				req.TongId = proto.Int32(tong_id)
				log.Info("获取帮会信息 [%v]", req)
				cur_hall_conn.Send(req)
			}
		}
	case "req_tong":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				var tong_id int32
				fmt.Printf("申请加入帮会，请输入帮会Id:")
				fmt.Scanf("%d\n", &tong_id)

				req := &msg_client_message.C2STongEnter{}
				req.TongId = proto.Int32(tong_id)
				log.Info("申请加入帮会 [%v]", req)
				cur_hall_conn.Send(req)
			}
		}
	case "re_tong":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				log.Info("获取推荐帮会:")
				req := &msg_client_message.C2SGetRecommendTong{}
				cur_hall_conn.Send(req)
			}
		}
	case "agree_tong":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				var player_id int32
				fmt.Printf("同意入帮会，请输入玩家Id:")
				fmt.Scanf("%d\n", &player_id)

				req := &msg_client_message.C2SEnterTongAgree{}
				req.PlayerId = proto.Int32(player_id)
				log.Info("同意入帮会 [%v]", req)
				cur_hall_conn.Send(req)
			}
		}
	case "gm":
		{
			var param1, param2, param3, param4 string
			fmt.Printf("Gm命令，请输入:")
			fmt.Scanf("%s %s %s %s", &param1, &param2, &param3, &param4)
			url.QueryEscape(" ")
			//url_str := "http://123.207.182.67:10002/send_mail?pids=583|1&mail_id=2&last_sec=30000"
			url_str := "http://192.168.1.221:10002/send_mail?pids=1|2&coin=20&diamond=20&last_sec=30000&chests=6005|6006"
			//url_str := "http://192.168.1.221:10002/gm_cmd?cmd_str=" + param1 + url.QueryEscape(" ") + param2 + url.QueryEscape(" ") + param3 + url.QueryEscape(" ") + param4
			log.Info("发送命令%s", url_str)
			_, err := http.Get(url_str)
			if nil != err {
				log.Error("http err(%s)", err.Error())
			}
		}
	case "get_mails":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("获取邮件列表:")

				req := &msg_client_message.C2SGetMailList{}
				log.Info("获取邮件列表 [%v]", req)
				cur_hall_conn.Send(req)
			}
		}
	case "open_free":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("打开免费宝箱:")

				req := &msg_client_message.C2SOpenFreeChest{}
				log.Info("打开免费宝箱 [%v]", req)
				cur_hall_conn.Send(req)
			}
		}
	case "tong_chat":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				var chat_content string
				fmt.Printf("帮会聊天，请输入聊天内容Id:")
				fmt.Scanf("%s\n", &chat_content)
				req := &msg_client_message.C2STongChat{}
				req.Content = proto.String(chat_content)
				cur_hall_conn.Send(req)
			}
		}
	case "get_rank":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("请求排行榜，是否本地榜:")
				var if_local int32
				fmt.Scanf("%d\n", &if_local)
				fmt.Printf("排行榜类型1玩家2帮会:")
				var tong_type int32
				fmt.Scanf("%d\n", &tong_type)
				fmt.Printf("是否上一期:")
				var if_last int32
				fmt.Scanf("%d\n", &if_last)
				req := &msg_client_message.C2SRankInfo{}
				req.RankType = proto.Int32(tong_type)
				req.IfLocal = proto.Int32(if_local)
				req.IfGetLast = proto.Int32(if_last)
				cur_hall_conn.Send(req)
			}
		}
	case "get_player":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("请求玩家信息，输入玩家Id:")
				var player_id int32
				fmt.Scanf("%d\n", &player_id)
				req := &msg_client_message.C2SGetPlayerInfo{}
				req.PlayerId = proto.Int32(player_id)
				cur_hall_conn.Send(req)
			}
		}
	case "tong_friend_req":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("帮会友谊战请求:")
				req := &msg_client_message.C2STongFriendMatch{}
				cur_hall_conn.Send(req)
			}
		}
	case "tong_friend_cancel":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("帮会友谊战取消:")
				req := &msg_client_message.C2STongFriendCancel{}
				cur_hall_conn.Send(req)
			}
		}
	case "tong_friend_enter":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("帮会友谊战加入,输入对方玩家Id:")
				var player_id int32
				fmt.Scanf("%d\n", &player_id)
				req := &msg_client_message.C2STongFriendEnter{}
				req.TgtPlayerId = proto.Int32(player_id)

				cur_hall_conn.Send(req)
			}
		}
	case "get_mail_list":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("获取邮件列表:")
				req := &msg_client_message.C2SGetMailList{}

				cur_hall_conn.Send(req)
			}
		}
	case "tong_search":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("搜索帮会:")
				req := &msg_client_message.C2STongSearch{}
				req.Name = proto.String("TAT")
				req.MaxCount = proto.Int32(50)
				req.MinCount = proto.Int32(1)
				req.MinScore = proto.Int32(0)
				req.Pos = proto.Int32(0)

				cur_hall_conn.Send(req)
			}
		}
	case "camp_fight":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("阵营战:")
				req := &msg_client_message.C2SMatchReq{}
				req.MatchType = proto.Int32(2)

				cur_hall_conn.Send(req)
			}
		}
	case "camp_rank":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("获取阵营战排行榜请输入排行榜类型（3全，4阵营1，5阵营2）:")
				var rank_type int32
				fmt.Scanf("%d\n", &rank_type)
				req := &msg_client_message.C2SGetCampFightRank{}
				req.RankType = proto.Int32(rank_type)

				cur_hall_conn.Send(req)
			}
		}
	case "sign":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("签到:")
				req := &msg_client_message.C2SDaySign{}

				cur_hall_conn.Send(req)
			}
		}
	case "sum_sign":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("领取累计签到奖励,输入累计天数:")
				var sum_num int32
				fmt.Scanf("%d\n", &sum_num)
				req := &msg_client_message.C2SGetDaySignSumReward{}
				req.SumNum = proto.Int32(sum_num)

				cur_hall_conn.Send(req)
			}
		}
	case "card_up":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("卡片升级:")
				var card_id int32
				fmt.Scanf("%d\n", &card_id)
				req := &msg_client_message.C2SCardLvlUp{}
				req.CardCfgId = proto.Int32(card_id)

				cur_hall_conn.Send(req)
			}
		}
	case "add_friend":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("Id添加好友:")
				var player_id int32
				fmt.Scanf("%d\n", &player_id)
				req := &msg_client_message.C2SAddFriendByPId{}
				req.PlayerId = proto.Int32(player_id)

				cur_hall_conn.Send(req)
			}
		}
	case "agree_friend":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("同意加好友:")
				var player_id int32
				fmt.Scanf("%d\n", &player_id)
				req := &msg_client_message.C2SAddFriendAgree{}
				req.PlayerId = proto.Int32(player_id)

				cur_hall_conn.Send(req)
			}
		}
	case "friend_search":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("搜索好友, 输入关键字:")
				var key string
				fmt.Scanf("%s\n", &key)
				req := &msg_client_message.C2SFriendSearch{}
				req.Key = proto.String(key)

				cur_hall_conn.Send(req)
			}
		}
	case "get_friend":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("获取好友列表，选择类型（1好友2关注3粉丝）:")
				var tmp_type int32
				fmt.Scanf("%d\n", &tmp_type)
				req := &msg_client_message.C2SGetFriendList{}
				req.FriendType = proto.Int32(tmp_type)

				cur_hall_conn.Send(req)
			}
		}
	case "rm_friend":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("删除好友 好友Id:")
				var player_id int32
				fmt.Scanf("%d\n", &player_id)
				req := &msg_client_message.C2SFriendRemove{}
				req.PlayerId = proto.Int32(player_id)

				cur_hall_conn.Send(req)
			}
		}
	case "add_focus":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("添加关注 好友Id:")
				var player_id int32
				fmt.Scanf("%d\n", &player_id)
				req := &msg_client_message.C2SAddFocusByPId{}
				req.PlayerId = proto.Int32(player_id)

				cur_hall_conn.Send(req)
			}
		}
	case "get_friend_online":
		{
			if nil == cur_hall_conn || !cur_hall_conn.blogin {
				log.Error("当前连接未登陆", cur_hall_conn)
			} else {
				fmt.Printf("获取在线好友Id：\n")
				req := &msg_client_message.C2SGetOnlineFriends{}

				cur_hall_conn.Send(req)
			}
		}
	}
}

//=================================================================================
