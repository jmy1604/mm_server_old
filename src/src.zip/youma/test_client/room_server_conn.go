package main

import (
	"libs/log"
	"libs/socket_cli"
	"libs/timer"
	"public_message/gen_go/client_message"
	"sync/atomic"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	ROOM_CONN_STATE_DISCONNECT  = 0
	ROOM_CONN_STATE_CONNECTED   = 1
	ROOM_CONN_STATE_FORCE_CLOSE = 2
)

type RoomConnection struct {
	client_node    *socket.Node
	state          int32
	last_conn_time int32
	playerid       int64
	token          int32
	room_ip        string
	room_id        int32

	blogin bool

	last_send_time int64
}

var room_conn RoomConnection

func new_room_connect(room_ip string, room_id, token int32, playerid int64) *RoomConnection {
	ret_conn := &RoomConnection{}
	ret_conn.playerid = playerid
	ret_conn.room_ip = room_ip
	ret_conn.room_id = room_id
	ret_conn.token = token

	return ret_conn
}

func (this *RoomConnection) Start() {
	this.client_node = socket.NewNode(this, 300000, 300000, 1000, msg_client_message.MessageNames)
	this.state = ROOM_CONN_STATE_DISCONNECT
	this.RegisterMsgHandler()

	if this.Connect(ROOM_CONN_STATE_DISCONNECT) {
		log.Event("连接RoomServer成功", nil, log.Property{"IP", this.room_ip})
	}
	for {
		state := atomic.LoadInt32(&this.state)
		if state == ROOM_CONN_STATE_CONNECTED {
			time.Sleep(time.Second * 2)
			continue
		}

		if state == ROOM_CONN_STATE_FORCE_CLOSE {
			this.client_node.Shutdown()
			log.Event("与RoomServer的连接被强制关闭", nil)
			break
		}
		if this.Connect(state) {
			log.Event("连接RoomServer成功", nil, log.Property{"IP", this.room_ip})
		}
	}
}

func (this *RoomConnection) Connect(state int32) (ok bool) {
	if ROOM_CONN_STATE_DISCONNECT == state {
		var err error
		for {
			log.Trace("连接RoomServer %v", this.room_ip)
			err = this.client_node.Connect(this.room_ip, time.Second*10)
			if nil == err {
				break
			}

			// 每隔30秒输出一次连接信息
			now := time.Now().Unix()
			if int32(now)-this.last_conn_time >= 30 {
				log.Trace("RoomServer连接中...")
				this.last_conn_time = int32(now)
			}
			time.Sleep(time.Second * 5)
		}
	}

	if atomic.CompareAndSwapInt32(&this.state, state, ROOM_CONN_STATE_CONNECTED) {
		this.state = ROOM_CONN_STATE_CONNECTED
		ok = true
	}
	return
}

func (this *RoomConnection) OnAccept(c *socket.TcpConn) {
	log.Error("Impossible accept")
}

func (this *RoomConnection) OnConnect(c *socket.TcpConn) {
	log.Trace("on RoomServer connect", this.room_ip)
	c.T = this.playerid
	this.blogin = true

	req_2s := &msg_client_message.C2SEnterRoomReq{}
	req_2s.Id = proto.Int64(this.playerid)
	req_2s.Token = proto.Int32(this.token)
	c.Send(req_2s)
}

func (this *RoomConnection) OnUpdate(c *socket.TcpConn, t timer.TickTime) {
	if time.Now().Unix()-this.last_send_time > 180 {
		this.Send(&msg_client_message.HeartBeat{})
	}
}

func (this *RoomConnection) WaitConnectOk() {
	for {
		if ROOM_CONN_STATE_CONNECTED == this.state {
			break
		}
		time.Sleep(time.Millisecond)
	}

	return
}

func (this *RoomConnection) OnDisconnect(c *socket.TcpConn, reason socket.E_DISCONNECT_REASON) {
	if reason == socket.E_DISCONNECT_REASON_FORCE_CLOSED_CLIENT {
		this.state = ROOM_CONN_STATE_FORCE_CLOSE
	} else {
		this.state = ROOM_CONN_STATE_DISCONNECT
	}
	log.Event("与RoomServer连接断开", nil)
	this.blogin = false
}

func (this *RoomConnection) Send(msg proto.Message) {
	if ROOM_CONN_STATE_CONNECTED != this.state {
		log.Info("RoomServer未连接!!!")
		return
	}
	if nil == this.client_node {
		return
	}

	this.last_send_time = time.Now().Unix()
	this.client_node.GetClient().Send(msg)
}

func (this *RoomConnection) set_ih(type_id uint16, h socket.Handler) {
	t := msg_client_message.MessageTypes[type_id]
	if t == nil {
		log.Error("设置消息句柄失败，不存在的消息类型 %v", type_id)
		return
	}

	this.client_node.SetHandler(type_id, t, h)
}

type RoomMessageHandler func(a *RoomConnection, m proto.Message)

func (this *RoomConnection) SetMessageHandler(type_id uint16, h RoomMessageHandler) {
	if h == nil {
		this.set_ih(type_id, nil)
		return
	}

	this.set_ih(type_id, func(c *socket.TcpConn, m proto.Message) {
		h(this, m)
	})
}

//========================================================================

func (this *RoomConnection) RegisterMsgHandler() {
	this.SetMessageHandler(msg_client_message.ID_S2CEnterRoomRes, S2CEnterRoomResHanlder)
	this.SetMessageHandler(msg_client_message.ID_S2CFightEnd, S2CFightEndHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CPointChg, S2CPointChgHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNpcSync, S2CNpcSyncHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNpcAdd, S2CNpcAddHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CCastSkill, S2CCastSkillHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CSkillEffect, S2CSkillEffectHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNpcRemove, S2CNpcRemoveHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNpcHpChg, S2CNpcHpChgHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CMultiNpcHpChg, S2CMultiNpcHpChgHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CUseCardRes, S2CUseCardResHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CAddBuff, S2CAddBuffHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CMultiNpcBuffAdd, S2CMultiNpcBuffAddHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CCardLoadEnd, S2CCardLoadEndHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CMultiNpcAdd, S2CMultiNpcAddHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CMultiNpcBuffRemove, S2CMultiNpcBuffRemove)
	this.SetMessageHandler(msg_client_message.ID_S2CRemoveBuff, S2CRemoveBuffHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CMultiNpcRelocate, S2CMultiNpcRelocateHandler)
}

func S2CEnterRoomResHanlder(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CEnterRoomRes)
	if nil == res || nil == c {
		log.Error("S2CEnterRoomResHanlder param error !")
		return
	}

	log.Info("S2CEnterRoomResHanlder 房间服务器登录返回 %v")

	c.Send(&msg_client_message.C2SEnterRoomReady{})
	return
}

func S2CFightEndHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CFightEnd)
	if nil == res || nil == c {
		log.Error("S2CFightEndHandler param error !")
		return
	}

	log.Info("S2CFightEndHandler 比赛结束返回 %v", *res)
	return
}

func S2CPointChgHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CPointChg)
	if nil == res || nil == c {
		log.Error("S2CPointChgHandler param error !")
		return
	}

	//log.Info("玩家[%d] 圣水变化 %v", c.playerid, res.GetPoint())
	return
}

func S2CNpcSyncHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CNpcSync)
	if nil == res || nil == c {
		log.Error("S2CNpcSyncHandler param error !")
		return
	}

	//log.Info("服务器发来Npc同步信息 %v", *res)

	return
}

func S2CNpcAddHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CNpcAdd)
	if nil == res || nil == c {
		log.Error("S2CNpcAddHandler param error !")
		return
	}

	log.Info("服务器添加了Npc[%d:%d]", res.GetId(), res.GetCfgId())
	return
}

func S2CMultiNpcAddHandler(c *RoomConnection, m proto.Message) {
	return
}

func S2CCardLoadEndHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CCardLoadEnd)
	if nil == res || nil == c {
		log.Error("S2CCardLoadEndHandler param error !")
		return
	}

	log.Info("服务器随机卡片 %v", *res)
}

func S2CCastSkillHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CCastSkill)
	if nil == res || nil == c {
		log.Error("S2CCastSkillHandler param error !")
		return
	}

	//log.Info("服务器释放技能 %v", *res)
}

func S2CSkillEffectHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CSkillEffect)
	if nil == res || nil == c {
		log.Error("S2CSkillEffectHandler param error !")
		return
	}

	//log.Info("服务器创建子弹 %v", *res)
}

func S2CNpcRemoveHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CNpcRemove)
	if nil == res || nil == c {
		log.Error("S2CNpcRemoveHandler param error !")
		return
	}

	log.Info("服务器删除Npc %v", *res)
}

func S2CNpcHpChgHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CNpcHpChg)
	if nil == res || nil == c {
		log.Error("S2CNpcHpChgHandler param error !")
		return
	}

	//log.Info("Npc血量变化 %v", *res)
}

func S2CMultiNpcHpChgHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CMultiNpcHpChg)
	if nil == res || nil == c {
		log.Error("S2CMultiNpcHpChgHandler param error !")
		return
	}

	//log.Info("多个Npc血量变化 %v", *res)
}

func S2CUseCardResHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CUseCardRes)
	if nil == res || nil == c {
		log.Error("S2CUseCardResHandler param error !")
		return
	}

	//log.Info("服务器发来卡片使用信息 用了%v", *res)
}

func S2CAddBuffHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CAddBuff)
	if nil == res || nil == c {
		log.Error("S2CAddBuffHandler param error !")
		return
	}

	log.Info("服务器发来了Buff增加信息 %v", res)
}

func S2CMultiNpcBuffAddHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CMultiNpcBuffAdd)
	if nil == res || nil == c {
		log.Error("S2CMultiNpcBuffAddHandler param error !")
		return
	}

	log.Info("服务器发来了多个BUff的增加信息 %v", res)
}

func S2CRemoveBuffHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CRemoveBuff)
	if nil == res || nil == c {
		log.Error("S2CRemoveBuffHandler param error !")
		return
	}

	log.Info("服务器发来了buff的删除信息 %v", res)
}

func S2CMultiNpcBuffRemove(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CMultiNpcBuffRemove)
	if nil == res || nil == c {
		log.Error("S2CMultiNpcBuffRemove param error !")
		return
	}

	log.Info("服务器发来了多个buff的删除信息 %v", res)
}

func S2CMultiNpcRelocateHandler(c *RoomConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CMultiNpcRelocate)
	if nil == c || nil == res {
		log.Error("S2CMultiNpcRelocateHandler res or c nil %v !", nil == c)
		return
	}

	return
}
