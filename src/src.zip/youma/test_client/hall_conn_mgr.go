package main

import (
	"libs/log"
	"sync"
)

type HallConnMgr struct {
	acc2hconn      map[string]*HallConnection
	acc2hconn_lock *sync.RWMutex
}

var hall_conn_mgr HallConnMgr

func (this *HallConnMgr) Init() bool {
	this.acc2hconn = make(map[string]*HallConnection)
	this.acc2hconn_lock = &sync.RWMutex{}
	return true
}

func (this *HallConnMgr) AddHallConn(conn *HallConnection) {
	if nil == conn {
		log.Error("HallConnMgr AddHallConn param error !")
		return
	}

	this.acc2hconn_lock.Lock()
	defer this.acc2hconn_lock.Unlock()

	this.acc2hconn[conn.acc] = conn
}

func (this *HallConnMgr) RemoveHallConnByAcc(acc string) {
	this.acc2hconn_lock.Lock()
	defer this.acc2hconn_lock.Unlock()

	delete(this.acc2hconn, acc)
}

func (this *HallConnMgr) GetHallConnByAcc(acc string) *HallConnection {
	this.acc2hconn_lock.RLock()
	defer this.acc2hconn_lock.RUnlock()

	return this.acc2hconn[acc]
}
