package main

import (
	"libs/log"
	"libs/socket_cli"
	"libs/timer"
	"public_message/gen_go/client_message"
	"sync/atomic"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	HALL_CONN_STATE_DISCONNECT  = 0
	HALL_CONN_STATE_CONNECTED   = 1
	HALL_CONN_STATE_FORCE_CLOSE = 2
)

type HallConnection struct {
	client_node    *socket.Node
	state          int32
	last_conn_time int32
	acc            string
	hall_ip        string
	playerid       int64

	room_conn *RoomConnection

	blogin bool

	last_send_time int64
}

var hall_conn HallConnection

func new_hall_connect(hall_ip, acc string) *HallConnection {
	ret_conn := &HallConnection{}
	ret_conn.acc = acc
	ret_conn.hall_ip = hall_ip

	return ret_conn
}

func (this *HallConnection) Start() {
	this.client_node = socket.NewNode(this, 3, 3000, 1000, msg_client_message.MessageNames)
	this.state = HALL_CONN_STATE_DISCONNECT
	this.RegisterMsgHandler()

	if this.Connect(HALL_CONN_STATE_DISCONNECT) {
		log.Event("连接HallServer成功", nil, log.Property{"IP", this.hall_ip})
	}
	for {
		state := atomic.LoadInt32(&this.state)
		if state == HALL_CONN_STATE_CONNECTED {
			time.Sleep(time.Second * 2)
			continue
		}

		if state == HALL_CONN_STATE_FORCE_CLOSE {
			this.client_node.Shutdown()
			log.Event("与HallServer的连接被强制关闭", nil)
			break
		}
		if this.Connect(state) {
			log.Event("连接HallServer成功", nil, log.Property{"IP", this.hall_ip})
		}
	}
}

func (this *HallConnection) Connect(state int32) (ok bool) {
	if HALL_CONN_STATE_DISCONNECT == state {
		var err error
		for {
			log.Trace("连接HallServer %v", this.hall_ip)
			err = this.client_node.Connect(this.hall_ip, time.Second*10)
			if nil == err {
				break
			}

			// 每隔30秒输出一次连接信息
			now := time.Now().Unix()
			if int32(now)-this.last_conn_time >= 30 {
				log.Trace("HallServer连接中...")
				this.last_conn_time = int32(now)
			}
			time.Sleep(time.Second * 5)
		}
	}

	if atomic.CompareAndSwapInt32(&this.state, state, HALL_CONN_STATE_CONNECTED) {
		this.state = HALL_CONN_STATE_CONNECTED
		ok = true
	}
	return
}

func (this *HallConnection) OnAccept(c *socket.TcpConn) {
	log.Error("Impossible accept")
}

func (this *HallConnection) OnConnect(c *socket.TcpConn) {
	log.Trace("on HallServer connect", this.hall_ip)
	c.I = &this.acc
	this.blogin = true
}

func (this *HallConnection) OnUpdate(c *socket.TcpConn, t timer.TickTime) {
	if time.Now().Unix()-this.last_send_time > 180 {
		this.Send(&msg_client_message.HeartBeat{})
	}
}

func (this *HallConnection) WaitConnectOk() {
	for {
		if HALL_CONN_STATE_CONNECTED == this.state {
			break
		}
		time.Sleep(time.Millisecond)
	}

	return
}

func (this *HallConnection) OnDisconnect(c *socket.TcpConn, reason socket.E_DISCONNECT_REASON) {
	if reason == socket.E_DISCONNECT_REASON_FORCE_CLOSED_CLIENT {
		this.state = HALL_CONN_STATE_FORCE_CLOSE
	} else {
		this.state = HALL_CONN_STATE_DISCONNECT
	}
	log.Event("与HallServer连接断开", nil)
	this.blogin = false
}

func (this *HallConnection) Send(msg proto.Message) {
	if HALL_CONN_STATE_CONNECTED != this.state {
		log.Info("HallServer未连接!!!")
		go this.Start()
		return
	}
	if nil == this.client_node {
		return
	}

	this.last_send_time = time.Now().Unix()
	this.client_node.GetClient().Send(msg)
}

func (this *HallConnection) set_ih(type_id uint16, h socket.Handler) {
	t := msg_client_message.MessageTypes[type_id]
	if t == nil {
		log.Error("设置消息句柄失败，不存在的消息类型 %v", type_id)
		return
	}

	this.client_node.SetHandler(type_id, t, h)
}

type MatchMessageHandler func(a *HallConnection, m proto.Message)

func (this *HallConnection) SetMessageHandler(type_id uint16, h MatchMessageHandler) {
	if h == nil {
		this.set_ih(type_id, nil)
		return
	}

	this.set_ih(type_id, func(c *socket.TcpConn, m proto.Message) {
		h(this, m)
	})
}

//========================================================================

func (this *HallConnection) RegisterMsgHandler() {
	this.SetMessageHandler(msg_client_message.ID_S2CLoginResponse, S2CLoginResponseHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CMatchRes, S2CMatchResHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CMatchCancel, S2CMatchCancelHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CFightResult, S2CFightResultHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CChgCurTeam, S2CChgCurTeamHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CPlayerLvlUp, S2CPlayerLvlUpHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CPlayerExpUp, S2CPlayerExpUpHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CArenaLvl, S2CAreanLvlUpHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CBuyChest, S2CBuyChestHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CSellingCards, S2CSellingCardsHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CBuyCard, S2CBuyCardHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CChestsSync, S2CChestSyncHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CStartOpenChest, S2CStartOpenChestHandler)
	this.SetMessageHandler(msg_client_message.ID_S2COpenChest, S2COpenChestHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CCreateTongOk, S2CCreateTongOkHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CLeaveTongOk, S2CTongLeaveHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CRetTongInfo, S2CTongInfoHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CRetRecommendTong, S2CRetRecommendTongHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CEnterTongRequest, S2CEnterTongRequestHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CMailList, S2CMailListHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CMailAdd, S2CMailAddHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CSyncDialyTask, S2CSyncDialyTaskHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNotifyTongChat, S2CNotifyTongChatHanlder)
	this.SetMessageHandler(msg_client_message.ID_S2CNotifyPlayerEnter, S2CNotifyPlayerEnterHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CRankItems, S2CRankItemsHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNotifyTongChestScoreChg, S2CNotifyTongChestScoreChgHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNotifyTongMemberScoreChg, S2CNotifyTongMemberScoreChgHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNotifyTaskValueChg, S2CNotifyTaskValueChgHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNotifyAchieveValueChg, S2CNotifyAchieveValueChgHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CSyncAchieveData, S2CSyncAchieveDataHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNotifyMemberOnOff, S2CNotifyTongMemberOnOffHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CRetPlayerInfo, S2CRetPlayerInfoHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNotifyTongFriendMatch, S2CNotifyTongFriendMatchHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNotifyTongFriendCancel, S2CNotifyTongFriendCancelHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CRetTongSearch, S2CRetTongSearchHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CSyncCardCompound, S2CSyncCardCompoundHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CRetCampFightRank, S2CCampFightRankHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CSyncSignInfo, S2CSyncSignInfoHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CDaySign, S2CDaySignHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CRetDaySignSumReward, S2CRetDaySignSumRewardHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CSyncFirstPayState, S2CSyncFirstPayStateHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CCardLvlUp, S2CSyncCardLvlUpHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CNeedSetCamp, S2CNeedSetCampHandler)
	this.SetMessageHandler(msg_client_message.ID_S2CCurCamp, S2CCurCampHandler)
}

func S2CLoginResponseHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CLoginResponse)

	log.Info("player[%s]收到服务器登录返回 %v", c.acc, res)
	c.playerid = res.GetPlayerId()
	return
}

func S2CMatchResHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CMatchRes)

	log.Info("Player[%s]收到服务器的匹配返回 %v", c.acc, res)
	if 2 == res.GetState() {
		room_conn := new_room_connect(res.GetRoomIP(), res.GetRoomId(), res.GetToken(), c.playerid)
		go room_conn.Start()
		c.room_conn = room_conn
	}
	return
}

func S2CMatchCancelHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CMatchCancel)

	log.Info("服务器发来匹配取消消息 %v", res)
}

func S2CFightResultHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CFightResult)
	log.Info("服务器发来战斗结果 %v", *res)
}

func S2CChgCurTeamHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CChgCurTeam)

	log.Info("服务器发来 卡组改变[%d]", res.GetTeamId())
}

func S2CPlayerLvlUpHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CPlayerLvlUp)
	log.Info("服务器发来升级信息 %v", *res)
}

func S2CPlayerExpUpHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CPlayerExpUp)
	log.Info("服务器发来经验变化信息 %v", *res)
}

func S2CAreanLvlUpHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CArenaLvl)
	log.Info("服务器发来竞技场等级变化 %d", res.GetArenaLvl())
}

func S2CBuyChestHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CBuyChest)
	log.Info("服务器发来宝箱购买回复%v", *res)
}

func S2CSellingCardsHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CSellingCards)
	log.Info("服务同步过来了售卖的卡片信息 %v", *res)
	return
}

func S2CBuyCardHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CBuyCard)
	log.Info("服务器发来了购买卡片的回复 当前金币%d 购买的位置%d 当前累计购买次数%d", res.GetCurCoin(), res.GetCardPos(), res.GetBuyNum())

	return
}

func S2CChestSyncHandler(c *HallConnection, m proto.Message) {
	res := m.(*msg_client_message.S2CChestsSync)
	log.Info("服务器发来宝箱同步信息：")

	for _, chest := range res.GetChests() {
		if nil == chest {
			continue
		}

		log.Info("	宝箱[位置:%d][Id:%d][剩余开启秒数:%d] ", chest.GetChestPos(), chest.GetChestCfgId(), chest.GetLeftOpenTime())
	}

	return
}

func S2CStartOpenChestHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CStartOpenChest)
	log.Info("服务器发来了宝箱开始开启的消息 %v", res)

	return
}

func S2COpenChestHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2COpenChest)
	log.Info("服务器发来了宝箱开启结果 %v", res)

	return
}

func S2CCreateTongOkHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CCreateTongOk)
	log.Info("服务器发来了帮会创建结果：%v", *res)

	return
}

func S2CTongLeaveHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CLeaveTongOk)

	log.Info("服务器发来了帮会退出信息：%v", *res)

	return
}

func S2CTongInfoHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CRetTongInfo)

	log.Info("服务器发来了帮会信息 %v", *res)
}

func S2CNotifyTongEnterHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CNotifyPlayerEnter)

	log.Info("服务器通知有玩家进入帮会 %v", *res)
}

func S2CRetRecommendTongHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CRetRecommendTong)
	log.Info("服务器返回推荐帮会信息 %v", *res)
}

func S2CEnterTongRequestHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CEnterTongRequest)
	log.Info("服务器发来入帮会请求 %v", *res)
}

func S2CMailListHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CMailList)
	log.Info("服务器发来了邮件列表:")
	for _, val := range res.GetMailList() {
		log.Info("	[%d:%s]", val.GetMailId(), val.GetTitle())
	}
}

func S2CMailAddHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CMailAdd)
	log.Info("服务器发来了邮件添加[%d:%s]", res.GetMailId(), res.GetTitle())
}

func S2CSyncDialyTaskHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CSyncDialyTask)
	log.Info("服务器发来了每日任务数据:")
	for _, val := range res.GetTaskList() {
		if nil == val {
			continue
		}

		log.Info("	[%d:%d]", val.GetTaskId(), val.GetTaskValue())
	}
}

func S2CNotifyTongChatHanlder(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CNotifyTongChat)
	log.Info("[%d]服务器发来了帮会聊天消息 [%s:%s %d]", c.playerid, res.GetSendName(), res.GetContent(), res.GetSendUnix())
}

func S2CNotifyPlayerEnterHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CNotifyPlayerEnter)
	log.Info("[%d]服务器发来了成员[%s]加入信息", c.playerid, res.GetPlayerName())
}

func S2CRankItemsHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CRankItems)
	log.Info("[%d]服务器发来了排行榜信息", c.playerid)
	for _, val := range res.GetRankList() {
		log.Info("	榜条目", val.GetId(), val.GetName(), val.GetRank(), val.GetScore())
	}
}

func S2CNotifyTongChestScoreChgHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CNotifyTongChestScoreChg)
	log.Info("[%d]服务器发来了帮会宝箱经验[%d]", c.playerid, res.GetTongChestScore())

}

func S2CNotifyTongMemberScoreChgHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CNotifyTongMemberScoreChg)
	log.Info("[%d]服务器发来了成员[%d]积分变化[%d]", c.playerid, res.GetPlayerId(), res.GetPlayerScore())

}

func S2CNotifyTaskValueChgHandler(c *HallConnection, msg proto.Message) {
	//res := msg.(*msg_client_message.S2CNotifyTaskValueChg)
	//log.Info("服务器发来了任务[%d]值[%d]的变化", res.GetTaskId(), res.GetTaskValue())
}

func S2CNotifyAchieveValueChgHandler(c *HallConnection, msg proto.Message) {
	//res := msg.(*msg_client_message.S2CNotifyAchieveValueChg)
	//log.Info("服务器发来了成就[%d]值[%d]的变化", res.GetAchieveId(), res.GetAchieveValue())
}

func S2CSyncAchieveDataHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CSyncAchieveData)
	log.Info("服务器同步来了成就信息%v", *res)
}

func S2CNotifyTongMemberOnOffHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CNotifyMemberOnOff)
	log.Info("服务器通知帮会成员[%d]上下线[%d]", res.GetPlayerId(), res.GetOnOffLine())
}

func S2CRetPlayerInfoHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CRetPlayerInfo)
	log.Info("服务器回复玩家信息 %v", *res)
}

func S2CNotifyTongFriendMatchHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CNotifyTongFriendMatch)
	log.Info("服务器通知帮会友谊战 %v", res)
}

func S2CNotifyTongFriendCancelHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CNotifyTongFriendCancel)
	log.Info("服务器通知帮会友谊战取消 %v", res)
}

func S2CRetTongSearchHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CRetTongSearch)
	log.Info("服务器发来帮会搜索结果 %v", res)
}

func S2CSyncCardCompoundHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CSyncCardCompound)
	log.Info("服务器发来当天卡片合成次数 %v", res)
}

func S2CCampFightRankHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CRetCampFightRank)
	log.Info("服务器发来阵营战排行帮会信息 %v", res)
}

func S2CSyncSignInfoHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CSyncSignInfo)
	log.Info("服务器发来了签到信息 %v", res)
}

func S2CDaySignHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CDaySign)
	log.Info("服务器发来了签到结果 %v", res)
}

func S2CRetDaySignSumRewardHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CRetDaySignSumReward)
	log.Info("服务器发来了领取累计奖励结果 %v", res)
}

func S2CSyncSevenActivityHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CSyncSevenActivity)
	log.Info("服务器发来了七天活动相关信息 %v", res)
}

func S2CSyncFirstPayStateHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CSyncFirstPayState)
	log.Info("服务器发来了首充相关信息 %v", res)
}

func S2CSyncCardLvlUpHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CCardLvlUp)
	log.Info("服务器发来了卡片升级相关信息 %v", res)
}

func S2CNeedSetCampHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CNeedSetCamp)
	log.Info("需要设置阵营 ，输入命令0进行设置", res)
}

func S2CCurCampHandler(c *HallConnection, msg proto.Message) {
	res := msg.(*msg_client_message.S2CCurCamp)
	log.Info("设置阵营 成功", res)
}
