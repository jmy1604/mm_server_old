package main

import (
	_ "3p/mysql"
	"database/sql"
	"encoding/json"
	"io/ioutil"
	"libs/log"
	"time"
)

type Config struct {
	IP             string
	MaxConnections int
	MaxPlayers     int32

	MYSQL_NAME    string
	MYSQL_IP      string
	MYSQL_ACCOUNT string
	MYSQL_PWD     string

	DBCST_MIN int
	DBCST_MAX int
}

var config Config

func main() {
	defer func() {
		if err := recover(); err != nil {
			log.Stack(err)
			time.Sleep(time.Second * 5)
		}
	}()

	// 加载日志配置
	log.Init("../conf/log/server_logger.json", "../conf/log/server_tracer.json", true)

	data, err := ioutil.ReadFile("../conf/game_server.cfg")
	if err != nil {
		log.Error("读取配置文件失败 %v", err)
		time.Sleep(time.Second * 5)
		return
	}
	err = json.Unmarshal(data, &config)
	if err != nil {
		log.Error("解析配置文件失败 %v", err)
		time.Sleep(time.Second * 5)
		return
	}
	log.Trace(config)

	source := config.MYSQL_ACCOUNT + ":" + config.MYSQL_PWD + "@tcp(" + config.MYSQL_IP + ")/" + config.MYSQL_NAME + "?charset=utf8"
	db, err := sql.Open("mysql", source)
	if err != nil {
		log.Error("open data source failed %v", err)
		time.Sleep(time.Second * 5)
		return
	}

	log.Info("重置数据库...")

	rows, err := db.Query("SELECT TABLE_NAME FROM information_schema.`TABLES` WHERE TABLE_SCHEMA=?", config.MYSQL_NAME)
	if err != nil {
		log.Error("SELECT information_schema.TABLES failed %v", err)
		time.Sleep(time.Second * 5)
		return
	}

	for rows.Next() {
		var table_name string
		err = rows.Scan(&table_name)
		if err != nil {
			log.Error("scan table_name failed %v", err)
			time.Sleep(time.Second * 5)
			return
		}

		_, err = db.Exec("DROP TABLE IF EXISTS " + table_name)
		if err != nil {
			log.Error("DROP table %v failed %v", table_name, err)
			time.Sleep(time.Second * 5)
			return
		}
	}

	log.Info("重置数据库成功")

	time.Sleep(time.Second * 5)

	log.Close()
}
