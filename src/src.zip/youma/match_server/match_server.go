package main

import (
	"errors"
	"libs/log"
	"libs/timer"
	"sync"
	"time"
)

type MatchServer struct {
	start_time         time.Time
	quit               bool
	shutdown_lock      *sync.Mutex
	shutdown_completed bool
	ticker             *timer.TickTimer
	initialized        bool
	last_gc_time       int32
}

var match_server MatchServer

func (this *MatchServer) Init() (ok bool) {
	this.start_time = time.Now()
	this.shutdown_lock = &sync.Mutex{}

	err := this.OnInit()
	if err != nil {
		log.Error("登陆服务器初始化失败")
		return
	}

	this.initialized = true

	ok = true
	return
}

func (this *MatchServer) Start() (err error) {
	log.Event("服务器已启动", nil)
	log.Trace("**************************************************")

	this.Run()

	return
}

func (this *MatchServer) Run() {
	defer func() {
		if err := recover(); err != nil {
			log.Stack(err)
		}

		this.shutdown_completed = true
	}()

	this.ticker = timer.NewTickTimer(1000)
	this.ticker.Start()
	defer this.ticker.Stop()

	for {
		select {
		case d, ok := <-this.ticker.Chan:
			{
				if !ok {
					return
				}

				begin := time.Now()
				this.OnTick(d)
				match_mgr.OnTick()
				time_cost := time.Now().Sub(begin).Seconds()
				if time_cost > 1 {
					log.Trace("耗时 %v", time_cost)
					if time_cost > 30 {
						log.Error("耗时 %v", time_cost)
					}
				}
			}
		}
	}
}

func (this *MatchServer) Shutdown() {
	if !this.initialized {
		return
	}

	this.shutdown_lock.Lock()
	defer this.shutdown_lock.Unlock()

	if this.quit {
		return
	}
	this.quit = true

	log.Trace("关闭游戏主循环")

	begin := time.Now()

	if this.ticker != nil {
		this.ticker.Stop()
	}

	for {
		if this.shutdown_completed {
			break
		}

		time.Sleep(time.Millisecond * 100)
	}

	hall_agent_mgr.server_node.Shutdown()
	room_server_agent_mgr.net.Shutdown()

	log.Trace("关闭游戏主循环耗时 %v 秒", time.Now().Sub(begin).Seconds())
}

func (this *MatchServer) OnInit() (err error) {

	if !match_mgr.Init() {
		return errors.New("match_mgr init failed !!")
	} else {
		log.Event("MatchServer match_mgr init succeed !!", nil)
	}

	return
}

func (this *MatchServer) OnTick(t timer.TickTime) {

}
