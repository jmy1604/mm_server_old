package main

import (
	"libs/log"
	"public_message/gen_go/server_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	MATCH_2V2_STEP_ROOM_MATCH = 0
	MATCH_2V2_STEP_TEAM_MATCH = 1
)

type Match2v2Room struct {
	master_id  int32          // 房主Id
	score      int32          // 最小积分
	mps        []*MatchPlayer // 匹配的玩家
	p1_ready   bool           // 玩家1准备好
	p2_ready   bool           // 玩家2准备好
	full_sec   int32          // 人数满的时间
	match_step int32          // 匹配阶段
}

func NewMatch2v2Room(match_score int32) *Match2v2Room {
	ret_room := &Match2v2Room{}
	ret_room.score = match_score
	ret_room.mps = make([]*MatchPlayer, 2)

	return ret_room
}

func (this *Match2v2Room) IfIdInRoom(pid int32) bool {
	for _, tmp_mp := range this.mps {
		if nil != tmp_mp && tmp_mp.Id == pid {
			return true
		}
	}

	return false
}

func (this *Match2v2Room) ReSendEnterMsg(pid int32) {
	for idx, tmp_mp := range this.mps {
		if nil == tmp_mp || tmp_mp.Id != pid {
			continue
		}

		switch idx {
		case 0:
			{
				res2h := &msg_server_message.Match2V2EnterRoom{}
				res2h.MyPId = proto.Int32(pid)
				res2h.MatchRoomId = proto.Int32(this.master_id)
				mp1 := this.mps[1]
				if nil != mp1 {
					tmp_parter := &msg_server_message.Match2V2ParterInfo{}
					tmp_parter.Id = proto.Int32(mp1.Id)
					tmp_parter.Name = proto.String(mp1.Name)
					tmp_parter.Score = proto.Int32(mp1.MatchScore)
					tmp_parter.CardCfgIds = mp1.CardCfgIds
					tmp_parter.CardLvls = mp1.CardLvls
					res2h.Pater = tmp_parter
				}

			}
		case 1:
			{
				res2h := &msg_server_message.Match2V2EnterRoom{}
				res2h.MyPId = proto.Int32(pid)
				res2h.MatchRoomId = proto.Int32(this.master_id)
				mp0 := this.mps[0]
				if nil != mp0 {
					tmp_parter := &msg_server_message.Match2V2ParterInfo{}
					tmp_parter.Id = proto.Int32(mp0.Id)
					tmp_parter.Name = proto.String(mp0.Name)
					tmp_parter.Score = proto.Int32(mp0.MatchScore)
					tmp_parter.CardCfgIds = mp0.CardCfgIds
					tmp_parter.CardLvls = mp0.CardLvls
					res2h.Pater = tmp_parter
				}
			}
		}
	}

	return
}

func (this *Match2v2Room) TryMatchPlayerEnter(mp *MatchPlayer) bool {
	if nil == mp {
		log.Error("Match2v2Room OnMatchPlayerEnter mp nil !")
		return false
	}

	for idx, tmp_mp := range this.mps {
		if nil == tmp_mp {
			res2h := &msg_server_message.Match2V2EnterRoom{}
			this.mps[idx] = mp
			switch idx {
			case 0:
				{
					log.Info("pos 1 player enter [%d] !", mp.Id)
					this.master_id = mp.Id

					res2h.MyPId = proto.Int32(mp.Id)
					res2h.MatchRoomId = proto.Int32(this.master_id)
				}
			case 1:
				{
					log.Info("pos 2 player enter [%d] !", mp.Id)

					res2h.MyPId = proto.Int32(mp.Id)
					res2h.MatchRoomId = proto.Int32(this.master_id)
					mp0 := this.mps[0]
					if nil != mp0 {
						tmp_parter := &msg_server_message.Match2V2ParterInfo{}
						tmp_parter.Id = proto.Int32(mp0.Id)
						tmp_parter.Name = proto.String(mp0.Name)
						tmp_parter.Score = proto.Int32(mp0.MatchScore)
						tmp_parter.CardCfgIds = mp0.CardCfgIds
						tmp_parter.CardLvls = mp0.CardLvls
						mp0.Send(res2h)
						res2h.Pater = tmp_parter
					}
				}
			}

			mp.Send(res2h)
			return true
		}
	}

	return false
}

func (this *Match2v2Room) MatchPlayerReady(pid int32) bool {

	for idx, tmp_mp := range this.mps {
		if nil != tmp_mp || tmp_mp.Id == pid {
			switch idx {
			case 0:
				{
					log.Info("pos 1 player ready [%d] !", tmp_mp.Id)
					this.p1_ready = true
					res2h_my := &msg_server_message.Match2V2Ready{}
					res2h_my.MyId = proto.Int32(pid)
					tmp_mp.Send(res2h_my)
					mp1 := this.mps[1]
					if nil != mp1 {
						res2h_parter := &msg_server_message.Match2V2ParterReady{}
						res2h_parter.MyId = proto.Int32(mp1.Id)
						res2h_parter.ParterId = proto.Int32(pid)
						mp1.Send(res2h_parter)
					}
				}
			case 1:
				{
					log.Info("pos 2 player enter [%d] !", tmp_mp.Id)
					this.p2_ready = true
					res2h_my := &msg_server_message.Match2V2Ready{}
					res2h_my.MyId = proto.Int32(pid)
					tmp_mp.Send(res2h_my)
					mp0 := this.mps[0]
					if nil != mp0 {
						res2h_parter := &msg_server_message.Match2V2ParterReady{}
						res2h_parter.MyId = proto.Int32(mp0.Id)
						res2h_parter.ParterId = proto.Int32(pid)
						mp0.Send(res2h_parter)
					}
				}
			}

			return true
		}
	}

	return false
}

func (this *Match2v2Room) OnMatchPlayerLeave() {

}

func (this *Match2v2Room) OnMatchCardChg(msg *msg_server_message.Match2V2CardsChg) {
	if nil == msg {
		log.Error("Match2v2Room OnMatchCardChg msg nil !")
		return
	}

	var parter *MatchPlayer
	for idx, tmp_mp := range this.mps {
		if nil == tmp_mp || tmp_mp.Id != msg.GetPlayerId() {
			continue
		}

		tmp_mp.CardCfgIds = msg.GetCardCfgIds()
		tmp_mp.CardLvls = msg.GetCardlvls()

		switch idx {
		case 0:
			{
				parter = this.mps[1]
			}
		case 1:
			{
				parter = this.mps[0]
			}
		}

		if nil != parter {
			msg.ParterId = proto.Int32(parter.Id)
			parter.Send(msg)
		}
	}
}

// -------------------------------------------------------------------------------

// 2v2队友匹配 ========================================================================

func (this *MatchManager) select_start_2v2_rooms() map[int32]*Match2v2Room {
	var tmp_room *Match2v2Room
	this.m2v2_rooms_lock.Lock()
	defer this.m2v2_rooms_lock.Unlock()
	cur_sec := int32(time.Now().Unix())
	start_rooms := make(map[int32]*Match2v2Room)

	for idx := int32(0); idx < this.cur_m2v2_room_num; idx++ {
		tmp_room = this.m2v2_rooms[idx]
		if nil == tmp_room || 0 >= tmp_room.full_sec {
			continue
		}

		if cur_sec-tmp_room.full_sec > global_config.Match2V2StartTime || (tmp_room.p1_ready && tmp_room.p2_ready) {
			start_rooms[tmp_room.master_id] = tmp_room
			tmp_room.match_step = MATCH_2V2_STEP_TEAM_MATCH
			if idx != this.cur_m2v2_room_num-1 {
				this.m2v2_rooms[idx] = this.m2v2_rooms[this.cur_m2v2_room_num-1]
			}
			this.cur_m2v2_room_num--
		}
	}

	return start_rooms
}

func (this *MatchManager) check_2v2_room_start() {
	start_rooms := this.select_start_2v2_rooms()
	var msg_p *msg_server_message.MatchPlayer
	cur_unix := int32(time.Now().Unix())
	for _, room := range start_rooms {
		_, new_result := this.Do2v2TeamMatch(room)
		if nil != new_result {
			new_result.resultid = match_mgr.GetNextMatchResultId()
			room_agent := room_server_agent_mgr.GetSuitableAgent()
			if nil == room_agent {
				log.Error("H2MPlayerMatchHandler GetSuitableAgent failed !")
				match_mgr.PopCurMatchInfo(new_result.player2.Id)
				return
			}
			new_result.room_server_id = room_agent.id
			req_2r := &msg_server_message.GetRoomReq{}
			req_2r.MatchType = proto.Int32(MATCH_TYPE_2V2_MATCH)
			req_2r.ResultId = proto.Int32(new_result.resultid)
			req_2r.MatchPlayers = make([]*msg_server_message.MatchPlayer, 4)
			for idx, tmp_mp := range new_result.players {
				msg_p = &msg_server_message.MatchPlayer{}
				msg_p.Id = proto.Int64(int64(tmp_mp.Id))
				msg_p.Name = proto.String(tmp_mp.Name)
				msg_p.Score = proto.Int32(tmp_mp.MatchScore)
				msg_p.CardCfgIds = tmp_mp.CardCfgIds
				msg_p.CardLvls = tmp_mp.CardLvls
				msg_p.Token = proto.Int32(cur_unix)
				msg_p.TongIcon = proto.Int32(tmp_mp.TongIcon)
				msg_p.TongName = proto.String(tmp_mp.TongName)
				msg_p.HallId = proto.Int32(tmp_mp.HallId)
				req_2r.MatchPlayers[idx] = msg_p
			}

			room_agent.Send(req_2r)
			match_mgr.AddToMatching(new_result)
			match_mgr.PopCurMatchInfo(new_result.player2.Id)
		}
	}
}

func (this *MatchManager) add_2v2_room_no_lock(room *Match2v2Room) {
	if this.cur_m2v2_room_num >= this.max_m2v2_room_num {
		log.Info("MatchManager 2v2 match need grow (%d  %d)", this.cur_m2v2_room_num, this.max_m2v2_room_num)
		this.max_m2v2_room_num = this.max_m2v2_room_num * 2
		new_2v2_rooms := make([]*Match2v2Room, this.max_m2v2_room_num)
		for idx := int32(0); idx < this.cur_m2v2_room_num; idx++ {
			new_2v2_rooms[idx] = this.m2v2_rooms[idx]
		}
		this.m2v2_rooms = new_2v2_rooms
	}

	log.Info("MatchManager 2v2 match after grow (%d  %d)", this.cur_m2v2_room_num, this.max_m2v2_room_num)
	this.m2v2_rooms[this.cur_m2v2_room_num] = room
	this.cur_m2v2_room_num++
}

func (this *MatchManager) Do2v2RoomMatch(p *MatchPlayer) (int32, *Match2v2Room) {
	if nil == p {
		log.Error("MatchManager Do2v2Match param error !")
		return -1, nil
	}

	score := p.MatchScore
	bfind := false
	min_score := int32(-1)
	max_score := int32(-1)
	for _, val := range this.match_config.Items {
		//log.Error("Do Match compare (%d - %d)", val.TrophyLowerLimit, val.TrophyUpperLimit)
		if score >= val.TrophyLowerLimit && score <= val.TrophyUpperLimit {
			bfind = true
			min_score = val.BasictrophyLowert
			max_score = val.BasictrophyUpper
		}
	}

	if !bfind {
		log.Error("MatchManager player[%d] Do2v2Match not find scope for score[%d]", p.Id, score)
		return -1, nil
	}

	this.m2v2_rooms_lock.Lock()
	defer this.m2v2_rooms_lock.Unlock()
	var tmp_room *Match2v2Room
	for idx := int32(0); idx <= this.cur_m2v2_room_num; idx++ {
		tmp_room := this.m2v2_rooms[idx]
		if nil == tmp_room {
			continue
		}

		if tmp_room.IfIdInRoom(p.Id) {
			return 0, tmp_room
		}
	}

	var tmp_r_score int32

	for idx := int32(0); idx <= this.cur_m2v2_room_num; idx++ {
		tmp_room = this.m2v2_rooms[idx]
		if nil == tmp_room {
			log.Error("MatchManager Do2v2Match matchplayer have nil !")
			continue
		}

		tmp_r_score = tmp_room.score
		if tmp_r_score < min_score || tmp_r_score > max_score {
			continue
		}

		if tmp_room.TryMatchPlayerEnter(p) {
			return 0, tmp_room
		}
	}

	new_room := NewMatch2v2Room(score)

	if !new_room.TryMatchPlayerEnter(p) {
		log.Error("MatchManager Do2v2Match Do2v2Match matchplayer have nil !")
		return -1, nil
	}
	this.add_2v2_room_no_lock(new_room)
	return 0, new_room
}

// 2v2队伍匹配 ========================================================================

func (this *MatchManager) add_2v2_team_no_lock(room *Match2v2Room) {
	if this.cur_m2v2_team_num >= this.max_m2v2_team_num {
		log.Info("MatchManager 2v2 match need grow (%d  %d)", this.cur_m2v2_team_num, this.max_m2v2_team_num)
		this.max_m2v2_team_num = this.max_m2v2_team_num * 2
		new_2v2_teams := make([]*Match2v2Room, this.max_m2v2_team_num)
		for idx := int32(0); idx < this.cur_m2v2_team_num; idx++ {
			new_2v2_teams[idx] = this.m2v2_teams[idx]
		}
		this.m2v2_teams = new_2v2_teams
	}

	log.Info("MatchManager 2v2 match team after grow (%d  %d)", this.cur_m2v2_team_num, this.max_m2v2_team_num)
	this.m2v2_rooms[this.cur_m2v2_team_num] = room
	this.cur_m2v2_team_num++
}

func (this *MatchManager) Do2v2TeamMatch(room *Match2v2Room) (int32, *MatchResult) {
	if nil == room || nil == room.mps[0] || nil == room.mps[1] {
		log.Error("MatchManager Do2v2teamMatch param error !")
		return -1, nil
	}

	score := room.score
	bfind := false
	min_score := int32(-1)
	max_score := int32(-1)
	for _, val := range this.match_config.Items {
		//log.Error("Do Match compare (%d - %d)", val.TrophyLowerLimit, val.TrophyUpperLimit)
		if score >= val.TrophyLowerLimit && score <= val.TrophyUpperLimit {
			bfind = true
			min_score = val.BasictrophyLowert
			max_score = val.BasictrophyUpper
		}
	}

	if !bfind {
		log.Error("MatchManager room[%d] Do2v2Match not find scope for score[%d]", room.master_id, score)
		return -1, nil
	}

	bfind = false
	this.m2v2_teams_lock.Lock()
	defer this.m2v2_teams_lock.Unlock()
	var tmp_team *Match2v2Room
	for idx := int32(0); idx <= this.cur_m2v2_team_num; idx++ {
		tmp_team = this.m2v2_teams[idx]
		if nil == tmp_team {
			continue
		}

		if tmp_team.score >= min_score || tmp_team.score <= max_score {
			bfind = true
			break
		}
	}

	if !bfind {
		this.add_2v2_team_no_lock(room)
		return 0, nil
	}

	new_result := &MatchResult{}
	new_result.players = make([]*MatchPlayer, 4)
	for idx := int32(0); idx < 4; idx++ {
		new_result.players[idx] = room.mps[idx]
	}

	return 0, new_result
}
