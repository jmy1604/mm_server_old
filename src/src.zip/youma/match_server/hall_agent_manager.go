package main

import (
	"libs/log"
	"libs/server_conn"
	"libs/timer"
	"public_message/gen_go/server_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

type HallAgent struct {
	conn             *server_conn.ServerConn
	id               int32
	name             string
	listen_room_ip   string
	listen_client_ip string
}

func new_match_agent(conn *server_conn.ServerConn, id int32, name, listen_room_ip, listen_client_ip string) *HallAgent {
	if nil == conn || id < 0 {
		log.Error("NewHallAgent param error !", id)
		return nil
	}

	retagent := &HallAgent{}
	retagent.conn = conn
	retagent.id = id
	retagent.name = name
	retagent.listen_room_ip = listen_room_ip
	retagent.listen_client_ip = listen_client_ip
	return retagent
}

func (this *HallAgent) Send(msg proto.Message) {
	this.conn.Send(msg, true)
}

var hall_agent_mgr HallAgentManager

type HallAgentManager struct {
	start_time      time.Time
	server_node     *server_conn.Node
	id2agent        map[int32]*HallAgent
	conn2agent      map[*server_conn.ServerConn]*HallAgent
	conn2agent_lock *RWMutex
	initialized     bool
	listen_err_chan chan error
}

func (this *HallAgentManager) Init() (ok bool) {
	this.start_time = time.Now()
	this.id2agent = make(map[int32]*HallAgent)
	this.conn2agent = make(map[*server_conn.ServerConn]*HallAgent)
	this.conn2agent_lock = NewRWMutex()
	this.server_node = server_conn.NewNode(this, 0, 0, 5000, 0, 0, 0, 0, 0)
	this.server_node.SetDesc("HallAgent", "大厅服务器")
	this.listen_err_chan = make(chan error)

	this.RegisterMsgHandler()
	this.initialized = true
	ok = true
	return
}

func (this *HallAgentManager) Listen() {
	err := this.server_node.Listen(config.ListenHallIP, config.MaxHallConnections)
	if err != nil {
		log.Error("启动HallAgentManager(%v)失败 %v", config.ListenHallIP, err)
		this.listen_err_chan <- err
		return
	}

	return
}

func (this *HallAgentManager) Start() (err error) {

	// log.Event("HallAgentManager已启动", nil, log.Property{"IP", config.ListenHallIP})
	// log.Trace("**************************************************")
	go this.Listen()

	err = this.wait_listen_res()

	return
}

// 等1秒中，如果没出错就认为成功
func (this *HallAgentManager) wait_listen_res() (err error) {
	timeout := make(chan bool, 1)
	go func() {
		time.Sleep(1 * time.Second)
		timeout <- true
	}()

	var o bool
	select {
	case err, o = <-this.listen_err_chan:
		{
			if !o {
				log.Trace("wait listen_err_chan failed")
				return
			}
		}
	case <-timeout:
		{
		}
	}

	return
}

func (this *HallAgentManager) OnTick() {
}

func (this *HallAgentManager) OnAccept(conn *server_conn.ServerConn) {
	log.Info("新的Hall连接[%v]", conn.GetAddr())
}

func (this *HallAgentManager) OnConnect(conn *server_conn.ServerConn) {

}

func (this *HallAgentManager) OnUpdate(conn *server_conn.ServerConn, t timer.TickTime) {

}

func (this *HallAgentManager) OnDisconnect(conn *server_conn.ServerConn, reason server_conn.E_DISCONNECT_REASON) {
	log.Info("断开Hall连接[%v]", conn.GetAddr())
	this.RemoveAgent(conn)
}

func (this *HallAgentManager) CloseConnection(conn *server_conn.ServerConn, reason server_conn.E_DISCONNECT_REASON) {
	if nil == conn {
		log.Error("参数为空")
		return
	}

	conn.Close(reason)
}

func (this *HallAgentManager) SendToAllMatch(msg proto.Message) {
	this.server_node.Broadcast(msg)
}

func (this *HallAgentManager) HasAgentByConn(conn *server_conn.ServerConn) bool {
	if nil == conn {
		return false
	}
	this.conn2agent_lock.UnSafeRLock("HallAgentManager HasAgentByConn")
	defer this.conn2agent_lock.UnSafeRUnlock()
	if nil != this.conn2agent[conn] {
		return true
	}

	return false
}

func (this *HallAgentManager) GetAgentByConn(conn *server_conn.ServerConn) *HallAgent {
	if nil == conn {
		log.Error("HallAgentManager GetAgentByConn conn nil !")
		return nil
	}

	this.conn2agent_lock.UnSafeRLock("HallAgentManager GetAgentByConn")
	defer this.conn2agent_lock.UnSafeRUnlock()

	return this.conn2agent[conn]
}

func (this *HallAgentManager) GetAgentById(id int32) *HallAgent {
	this.conn2agent_lock.UnSafeRLock("HallAgentMananger GetAgentById")
	defer this.conn2agent_lock.UnSafeRUnlock()

	return this.id2agent[id]
}

func (this *HallAgentManager) AddAgent(conn *server_conn.ServerConn, id int32, name, listen_room_ip, listen_client_ip string) {
	new_agent := new_match_agent(conn, id, name, listen_room_ip, listen_client_ip)
	if nil == new_agent {
		log.Error("HallAgentManager AddAgent new_agent nil ", conn, id, name, listen_room_ip, listen_client_ip)
		return
	}

	this.conn2agent_lock.UnSafeLock("HallAgentManager AddAgent")
	defer this.conn2agent_lock.UnSafeUnlock()
	this.conn2agent[conn] = new_agent
	conn.T = id
	this.id2agent[id] = new_agent
	return
}

func (this *HallAgentManager) RemoveAgent(conn *server_conn.ServerConn) {
	this.conn2agent_lock.UnSafeLock("HallAgent RemoveAgent")
	defer this.conn2agent_lock.UnSafeUnlock()
	if nil != this.conn2agent[conn] {
		delete(this.conn2agent, conn)
	}
	if nil != this.id2agent[conn.T] {
		delete(this.id2agent, conn.T)
	}
	return
}

func (this *HallAgentManager) Broadcast(msg proto.Message) {
	this.server_node.Broadcast(msg)
}

//==========================================================================================================

func (this *HallAgentManager) RegisterMsgHandler() {
	this.SetMessageHandler(msg_server_message.ID_H2MHallServerRegister, H2MHallServerRegisterHandler)
	this.SetMessageHandler(msg_server_message.ID_H2MHallServerUnRegister, H2MHallServerUnRegisterHandler)
}

func (this *HallAgentManager) set_ih(type_id uint16, h server_conn.Handler) {
	t := msg_server_message.MessageTypes[type_id]
	if t == nil {
		log.Error("设置消息句柄失败，不存在的消息类型 %v", type_id)
		return
	}

	this.server_node.SetHandler(type_id, t, h)
}

type HallMessageHandler func(conn *server_conn.ServerConn, m proto.Message)

func (this *HallAgentManager) SetMessageHandler(type_id uint16, h HallMessageHandler) {
	if h == nil {
		this.set_ih(type_id, nil)
		return
	}

	this.set_ih(type_id, func(c *server_conn.ServerConn, m proto.Message) {
		h(c, m)
	})
}

func H2MHallServerRegisterHandler(conn *server_conn.ServerConn, m proto.Message) {
	req := m.(*msg_server_message.H2MHallServerRegister)
	if nil == conn || nil == req {
		log.Error("H2MHallServerRegisterHandler param error !")
		return
	}

	cur_agent := hall_agent_mgr.GetAgentById(req.GetServerId())
	if nil != cur_agent {
		log.Error("H2MHallServerRegisterHandler cur_agent not nil [%d]", req.GetServerId())
		conn.Close(server_conn.E_DISCONNECT_REASON_FORCE_CLOSED)
		return
	}

	/*
		cur_agent := hall_agent_mgr.GetAgentByConn(conn)
		if nil != cur_agent {
			log.Error("H2MHallServerRegisterHandler already have agent(%d:%s)", cur_agent.id, cur_agent.name)
			return
		}
	*/

	hall_agent_mgr.AddAgent(conn, req.GetServerId(), req.GetServerName(), req.GetListenRoomIP(), req.GetListenClientIP())
	log.Info("H2M New HallServer(Id:%d Name:%s) Register", req.GetServerId(), req.GetServerName(), req.GetListenClientIP())

	return
}

func H2MHallServerUnRegisterHandler(conn *server_conn.ServerConn, m proto.Message) {
	req := m.(*msg_server_message.H2MHallServerRegister)
	if nil == conn || nil == req {
		log.Error("H2MHallServerUnRegisterHandler param error !")
		return
	}
	if !hall_agent_mgr.HasAgentByConn(conn) {
		log.Error("H2MHallServerUnRegisterHandler no agent")
		return
	}

	hall_agent_mgr.RemoveAgent(conn)

	log.Info("H2M New HallServer(Id:%d Name:%s) UnRegister", req.GetServerId(), req.GetServerName())

	return
}
