package main

import (
	"encoding/json"
	"io/ioutil"
	"libs/log"
)

type GlobalConfig struct {
	MatchAiSec        int32 // 匹配Ai的时间
	Match2V2StartTime int32 // 2v2比赛房间满后的准备时间
}

var global_config GlobalConfig

func global_config_load() bool {
	data, err := ioutil.ReadFile("../game_data/global.json")
	if nil != err {
		log.Error("global_config_load failed to readfile err(%s)!", err.Error())
		return false
	}

	err = json.Unmarshal(data, &global_config)
	if nil != err {
		log.Error("global_config_load json unmarshal failed err(%s)!", err.Error())
		return false
	}

	if global_config.MatchAiSec <= 0 {
		log.Error("global_config_load json unmarshal TimeExchangeRate < 0")
		return false
	}

	return true
}
