package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"libs/server_conn"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	DEFAULT_MATCH_PLAYERS_LEN = 1

	ROOM_CREATE_STATE_NONE = 0 // 未创建房间
	ROOM_CREATE_STATE_ING  = 1 // 已经请求创建房间
	ROOM_CREATE_STATE_DOWN = 2 // 创建房间完成

	FIGHT_RESULT_ERROR  = -1 // 异常结束
	FIGHT_RESULT_EQUAL  = 0  // 平局
	FIGHT_RESULT_P1_WIN = 1  // 玩家1获胜
	FIGHT_RESULT_P2_WIN = 2  // 玩家2获胜

	FIGHT_RESULT_2_HALL_EQUAL = 0 // 平局
	FIGHT_RESULT_2_HALL_WIN   = 1 // 赢局
	FIGHT_RESULT_2_HALL_FAIL  = 2 // 输局

	MATCH_MGR_AI_CHECK_FRAME = 10

	MATCH_TYPE_NORMAL      = 0 // 普通匹配赛
	MATCH_TYPE_TONG_FRIEND = 1 // 帮会友谊赛
	MATCH_TYPE_CAMP_MATCH  = 2 // 阵营战
	MATCH_TYPE_2V2_MATCH   = 3 // 2v2比赛

	PLAYER_CAMP_1 = 1 // 阵营1
	PLAYER_CAMP_2 = 2 // 阵营2
)

type XmlMatchItem struct {
	Index             int32 `xml:"index,attr"`
	TrophyLowerLimit  int32 `xml:"trophyLowerLimit,attr"`
	TrophyUpperLimit  int32 `xml:"trophyUpperLimit,attr"`
	BasictrophyLowert int32 `xml:"basictrophyLowert,attr"`
	BasictrophyUpper  int32 `xml:"basictrophyUpper,attr"`
}

type XmlMatchConfig struct {
	Items []XmlMatchItem `xml:"item"`
}

type MatchPlayer struct {
	Id         int32
	HallId     int32
	Name       string
	MatchScore int32
	CardCfgIds []int32
	CardLvls   []int32
	match_type int32
	TongId     int32
	TongIcon   int32
	TongName   string
	BAi        bool
	StartUnix  int32 // 开始匹配的秒数
	Token      int32
}

func (this *MatchPlayer) Send(msg proto.Message) {
	hall_svr := hall_agent_mgr.GetAgentById(this.HallId)
	if nil == hall_svr {
		log.Error("MatchPlayer send hall nil [%d]", this.HallId)
		return
	}

	hall_svr.Send(msg)
	return
}

func new_match_player(id, hallid int32, req *msg_server_message.H2MPlayerMatch) *MatchPlayer {
	ret_mp := &MatchPlayer{}
	ret_mp.Id = id
	ret_mp.HallId = hallid
	ret_mp.Name = req.GetName()
	ret_mp.MatchScore = req.GetScore()
	ret_mp.CardCfgIds = req.GetCardCfgIds()
	ret_mp.CardLvls = req.GetCardLvls()
	ret_mp.TongId = req.GetTongId()
	ret_mp.TongIcon = req.GetTongIcon()
	ret_mp.TongName = req.GetTongName()
	ret_mp.StartUnix = int32(time.Now().Unix())
	ret_mp.match_type = req.GetMatchType()

	return ret_mp
}

type MatchInfo struct {
	match_type     int32
	match_2v2_room *Match2v2Room
}

type MatchResult struct {
	resultid       int32
	players        []*MatchPlayer
	player2        *MatchPlayer
	player3        *MatchPlayer
	player4        *MatchPlayer
	room_server_id int32  // 房间服务器Id
	room_id        int32  // 房间Id
	room_server_ip string // 房间服务器监听客户端IP
}

type MatchManager struct {
	match_config *XmlMatchConfig

	cur_camp1_mp_num        int32          // 阵营1匹配库有多少人
	max_camp1_mp_num        int32          // 阵营1匹配库的容量
	camp1_matchplayers      []*MatchPlayer // 阵营1匹配库
	camp1_matchplayers_lock *sync.Mutex

	cur_camp2_mp_num        int32          // 阵营2匹配库有多少人
	max_camp2_mp_num        int32          // 阵营2匹配库的容量
	camp2_matchplayers      []*MatchPlayer // 阵营2匹配库
	camp2_matchplayers_lock *sync.Mutex

	cur_normal_mp_num        int32          // 普通匹配库有多少人
	max_normal_mp_num        int32          // 普通匹配库的容量
	normal_matchplayers      []*MatchPlayer // 普通匹配库
	normal_matchplayers_lock *sync.Mutex

	cur_m2v2_room_num int32           // 2v2队友匹配库有多少人
	max_m2v2_room_num int32           // 2v2队友匹配库的容量
	m2v2_rooms        []*Match2v2Room // 2v2队友匹配库
	m2v2_rooms_lock   *sync.Mutex

	cur_m2v2_team_num int32           // 2v2组匹配库有多少人
	max_m2v2_team_num int32           // 2v2组匹配库的容量
	m2v2_teams        []*Match2v2Room // 2v2组匹配库
	m2v2_teams_lock   *sync.Mutex

	rid2mingresult  map[int32]*MatchResult // 正在申请房间的匹配 索引为resultid
	pid2mingresult  map[int32]*MatchResult // 正在申请房间的匹配 索引为pid
	mingresult_lock *sync.RWMutex

	rid2mresult    map[int32]*MatchResult // 正在比赛的匹配 索引为resultid
	pid2mresult    map[int32]*MatchResult // 正在比赛的匹配 索引为pid
	medresult_lock *sync.RWMutex

	next_result_id      int32
	next_result_id_lock *sync.Mutex

	pid2matchinfo      map[int32]*MatchInfo // 玩家id到匹配类型+1
	pid2matchinfo_lock *sync.RWMutex

	binit bool

	ai_chk_frame int32
}

var match_mgr MatchManager

func (this *MatchManager) Init() bool {

	this.cur_camp1_mp_num = -1
	this.max_camp1_mp_num = DEFAULT_MATCH_PLAYERS_LEN
	this.camp1_matchplayers = make([]*MatchPlayer, DEFAULT_MATCH_PLAYERS_LEN)
	this.camp1_matchplayers_lock = &sync.Mutex{}

	this.cur_camp2_mp_num = -1
	this.max_camp2_mp_num = DEFAULT_MATCH_PLAYERS_LEN
	this.camp2_matchplayers = make([]*MatchPlayer, DEFAULT_MATCH_PLAYERS_LEN)
	this.camp2_matchplayers_lock = &sync.Mutex{}

	this.cur_normal_mp_num = -1
	this.max_normal_mp_num = DEFAULT_MATCH_PLAYERS_LEN
	this.normal_matchplayers = make([]*MatchPlayer, DEFAULT_MATCH_PLAYERS_LEN)
	this.normal_matchplayers_lock = &sync.Mutex{}

	this.rid2mingresult = make(map[int32]*MatchResult)
	this.pid2mingresult = make(map[int32]*MatchResult)
	this.mingresult_lock = &sync.RWMutex{}

	this.rid2mresult = make(map[int32]*MatchResult)
	this.pid2mresult = make(map[int32]*MatchResult)
	this.medresult_lock = &sync.RWMutex{}

	this.next_result_id = 0
	this.next_result_id_lock = &sync.Mutex{}

	this.pid2matchinfo = make(map[int32]*MatchInfo)
	this.pid2matchinfo_lock = &sync.RWMutex{}

	this.LoadMatchConfig()
	this.RegMsgHandler()

	this.binit = true

	return true
}

func (this *MatchManager) LoadMatchConfig() bool {
	content, err := ioutil.ReadFile("../game_data/arenaMatching.xml")

	if nil != err {
		log.Error("LoadMatchSectorCfg failed err(%s)", err.Error())
		return false
	}

	this.match_config = &XmlMatchConfig{}
	err = xml.Unmarshal(content, this.match_config)
	if nil != err {
		log.Error("LoadMatchSectorCfg Unmarshal failed err(%s)", err.Error())
		return false
	}

	/*
		log.Info("============================ MatchConfig ============================")

		for _, val := range this.match_config.Items {
			log.Info("item: %v", val)
		}

		log.Info("================================ End ================================")
	*/

	return true
}

/// 当前的匹配的类型 =============================================================

func (this *MatchManager) GetCurMathType(pid int32) int32 {
	this.pid2matchinfo_lock.RLock()
	defer this.pid2matchinfo_lock.RUnlock()
	cur_info := this.pid2matchinfo[pid]
	if nil != cur_info {
		return cur_info.match_type
	}

	return -1
}

func (this *MatchManager) SetCurMatchType(pid int32, match_type int32) {
	this.pid2matchinfo_lock.Lock()
	defer this.pid2matchinfo_lock.Unlock()
	cur_info := this.pid2matchinfo[pid]
	if nil == cur_info {
		cur_info = &MatchInfo{}
		this.pid2matchinfo[pid] = cur_info
	}
	cur_info.match_type = match_type
	return
}

func (this *MatchManager) SetCur2v2RoomMatch(pid int32, room *Match2v2Room, match_type int32) {
	this.pid2matchinfo_lock.Lock()
	defer this.pid2matchinfo_lock.Unlock()
	cur_info := this.pid2matchinfo[pid]
	if nil == cur_info {
		cur_info = &MatchInfo{}
		this.pid2matchinfo[pid] = cur_info
	}
	cur_info.match_type = match_type
	cur_info.match_2v2_room = room
	return
}

func (this *MatchManager) PopCurMatchInfo(pid int32) *MatchInfo {
	this.pid2matchinfo_lock.Lock()
	defer this.pid2matchinfo_lock.Unlock()
	cur_info := this.pid2matchinfo[pid]
	if nil != cur_info {
		delete(this.pid2matchinfo, pid)
	}

	return cur_info
}

/// 未申请好房间的匹配结果 ========================================================

func (this *MatchManager) GetMatchingByPId(pid int32) *MatchResult {
	this.mingresult_lock.RLock()
	defer this.mingresult_lock.RUnlock()

	return this.pid2mingresult[pid]
}

func (this *MatchManager) GetMatchingByResultId(rid int32) *MatchResult {
	this.mingresult_lock.RLock()
	defer this.mingresult_lock.RUnlock()

	return this.rid2mingresult[rid]
}

func (this *MatchManager) AddToMatching(result *MatchResult) {
	if nil == result {
		log.Error("MatchManager AddToMatchingResult param error!")
		return
	}

	this.mingresult_lock.Lock()
	defer this.mingresult_lock.Unlock()
	for _, tmp_mp := range result.players {
		this.pid2mingresult[tmp_mp.Id] = result
	}

	this.rid2mingresult[result.resultid] = result

	return
}

func (this *MatchManager) PopMatchingByRId(rid int32) (ret_m *MatchResult) {
	this.mingresult_lock.Lock()
	defer this.mingresult_lock.Unlock()

	ret_m = this.rid2mingresult[rid]
	if nil == ret_m {
		return
	}

	delete(this.rid2mingresult, rid)
	for _, tmp_mp := range ret_m.players {
		if nil != tmp_mp {
			delete(this.pid2mingresult, tmp_mp.Id)
		}
	}

	return
}

func (this *MatchManager) RemoveMatchingByRoomServerId(room_svr_id int32) {
	rdelmap := make(map[int32]bool)
	pdelmap := make(map[int32]bool)
	this.mingresult_lock.Lock()
	defer this.mingresult_lock.Unlock()
	for rid, val := range this.rid2mingresult {
		if nil == val {
			continue
		}

		if val.room_server_id == room_svr_id {
			rdelmap[rid] = true
		}
	}

	for rid, _ := range rdelmap {
		delete(this.rid2mingresult, rid)
	}

	for pid, val := range this.pid2mingresult {
		if nil == val {
			continue
		}

		if val.room_server_id == room_svr_id {
			pdelmap[pid] = true
		}
	}

	for pid, _ := range rdelmap {
		delete(this.pid2mingresult, pid)
	}

	return
}

/// 已经申请好房间的匹配结果=======================================================

func (this *MatchManager) GetMatchedByPId(pid int32) *MatchResult {
	this.medresult_lock.RLock()
	defer this.medresult_lock.RUnlock()

	return this.pid2mresult[pid]
}

func (this *MatchManager) AddToMatchedResult(result *MatchResult) {
	if nil == result {
		log.Error("MatchManager AddToMatchResult param error !")
		return
	}

	this.medresult_lock.Lock()
	defer this.medresult_lock.Unlock()

	this.rid2mresult[result.resultid] = result
	for _, tmp_mp := range result.players {
		this.pid2mresult[tmp_mp.Id] = result
	}

	return
}

func (this *MatchManager) PopMatchedByRId(resultid int32) (ret_agent *MatchResult) {
	if resultid <= 0 {
		log.Error("MatchManager PopMatchedByRId resultid[%d] <= 0 !", resultid)
		return nil
	}

	this.medresult_lock.Lock()
	defer this.medresult_lock.Unlock()

	ret_agent = this.rid2mresult[resultid]
	if nil == ret_agent {
		return
	}

	for _, tmp_mp := range ret_agent.players {
		if nil != tmp_mp {
			delete(this.pid2mresult, tmp_mp.Id)
		}
	}

	return
}

func (this *MatchManager) RemoveMatchedByRoomServerId(room_svr_id int32) (pdelmap map[int32]int32) {
	rdelmap := make(map[int32]bool)
	pdelmap = make(map[int32]int32)
	this.medresult_lock.Lock()
	defer this.medresult_lock.Unlock()

	for rid, val := range this.rid2mresult {
		if nil == val {
			continue
		}

		if val.room_server_id == room_svr_id {
			rdelmap[rid] = true
		}
	}

	for rid, _ := range rdelmap {
		delete(this.rid2mresult, rid)
	}

	for pid, val := range this.pid2mresult {
		if nil == val {
			continue
		}

		if val.room_server_id == room_svr_id {
			for _, tmp_mp := range val.players {
				if pid == tmp_mp.Id {
					pdelmap[pid] = tmp_mp.HallId
				}
			}
		}
	}

	for pid, _ := range pdelmap {
		delete(this.pid2mresult, pid)
	}

	return
}

func (this *MatchManager) AddToTongFriendMatch(msg *msg_server_message.GetRoomReq, room_agent *RoomServerAgent) {
	if nil == msg || nil == room_agent {
		log.Error("MatchManager AddToTongFriend msg or hall_agent nil !")
		return
	}

	cur_unix := int32(time.Now().Unix())

	tmp_mr := &MatchResult{}
	tmp_mr.players = make([]*MatchPlayer, 2)
	var tmp_p *MatchPlayer
	for idx, msg_p := range msg.GetMatchPlayers() {
		tmp_p = &MatchPlayer{}
		tmp_p.Id = int32(msg_p.GetId())
		tmp_p.HallId = msg_p.GetHallId()
		tmp_p.Name = msg_p.GetName()
		tmp_p.MatchScore = msg_p.GetScore()
		tmp_p.CardCfgIds = msg_p.GetCardCfgIds()
		tmp_p.CardLvls = msg_p.GetCardLvls()
		tmp_p.TongId = msg.GetResultId()
		tmp_p.TongIcon = msg_p.GetTongIcon()
		tmp_p.TongName = msg_p.GetTongName()
		tmp_p.StartUnix = cur_unix
		tmp_p.Token = msg_p.GetToken()
		tmp_mr.players[idx] = tmp_p

	}

	tmp_mr.room_server_id = room_agent.id
	tmp_mr.room_server_ip = room_agent.listen_client_ip
	tmp_mr.resultid = match_mgr.GetNextMatchResultId()
	log.Info("ResultId is %d", tmp_mr.resultid)
	msg.ResultId = proto.Int32(tmp_mr.resultid)

	match_mgr.AddToMatching(tmp_mr)

	return
}

// 阵营匹配 ========================================================================

func (this *MatchManager) add_camp1_mp_no_lock(p *MatchPlayer) {
	this.cur_camp1_mp_num++
	if this.cur_camp1_mp_num >= this.max_camp1_mp_num {
		log.Info("MatchManager camp1_mp need grow (%d %d) !", this.cur_camp1_mp_num, this.max_camp1_mp_num)
		this.max_camp1_mp_num = this.max_camp1_mp_num * 2
		new_match_items := make([]*MatchPlayer, this.max_camp1_mp_num)
		for idx := int32(0); idx < this.cur_camp1_mp_num; idx++ {
			new_match_items[idx] = this.camp1_matchplayers[idx]
		}
		this.camp1_matchplayers = new_match_items
	}
	this.camp1_matchplayers[this.cur_camp1_mp_num] = p
	log.Info("MatchManager camp1_mp after grow (%d, %d) !", this.cur_camp1_mp_num, this.max_camp1_mp_num)
}

func (this *MatchManager) AddCamp1Mp(p *MatchPlayer) {
	this.camp1_matchplayers_lock.Lock()
	defer this.camp1_matchplayers_lock.Unlock()

	this.cur_camp1_mp_num++
	if this.cur_camp1_mp_num >= this.max_camp1_mp_num {
		log.Info("MatchManager camp1_mp need grow (%d %d) !", this.cur_camp1_mp_num, this.max_camp1_mp_num)
		this.max_camp1_mp_num = this.max_camp1_mp_num * 2
		new_match_items := make([]*MatchPlayer, this.max_camp1_mp_num)
		for idx := int32(0); idx < this.cur_camp1_mp_num; idx++ {
			new_match_items[idx] = this.camp1_matchplayers[idx]
		}
		this.camp1_matchplayers = new_match_items
	}
	this.camp1_matchplayers[this.cur_camp1_mp_num] = p
	log.Info("MatchManager camp1_mp after grow (%d, %d) !", this.cur_camp1_mp_num, this.max_camp1_mp_num)
}

func (this *MatchManager) DoCamp1Match(p *MatchPlayer, match_type int32) (*MatchResult, int32) {
	if nil == p {
		log.Error("MatchManager DoCamp1Match param error !")
		return nil, -1
	}

	score := p.MatchScore
	bfind := false
	min_score := int32(-1)
	max_score := int32(-1)
	for _, val := range this.match_config.Items {
		//log.Error("Do Match compare (%d - %d)", val.TrophyLowerLimit, val.TrophyUpperLimit)
		if score >= val.TrophyLowerLimit && score <= val.TrophyUpperLimit {
			bfind = true
			min_score = val.BasictrophyLowert
			max_score = val.BasictrophyUpper
		}
	}

	if !bfind {
		log.Error("MatchManager player[%d] DoCamp1Match not find scope for score[%d]", p.Id, score)
		return nil, -1
	}

	this.camp1_matchplayers_lock.Lock()
	defer this.camp1_matchplayers_lock.Unlock()
	var tmp_p *MatchPlayer
	for idx := int32(0); idx <= this.cur_camp1_mp_num; idx++ {
		tmp_p := this.camp1_matchplayers[idx]
		if nil == tmp_p {
			continue
		}

		if tmp_p.Id == p.Id {
			return nil, 1
		}
	}

	var tmp_p_score int32
	find_idx := int32(-1)

	for idx := int32(0); idx <= this.cur_camp1_mp_num; idx++ {
		tmp_p = this.camp1_matchplayers[idx]
		if nil == tmp_p {
			log.Error("MatchManager DoCamp1Match matchplayer have nil")
			continue
		}

		tmp_p_score = tmp_p.MatchScore
		if tmp_p_score >= min_score && tmp_p_score <= max_score {
			find_idx = int32(idx)
			break
		}
	}

	if -1 == find_idx {
		//this.add_camp1_mp_no_lock(p)
		return nil, 0
	}

	new_m_result := &MatchResult{}
	new_m_result.players = make([]*MatchPlayer, 2)
	new_m_result.players[0] = p
	new_m_result.players[0].Token = int32(time.Now().Unix())
	new_m_result.players[1] = tmp_p
	new_m_result.players[1].Token = int32(time.Now().Unix())
	new_m_result.resultid = this.GetNextMatchResultId()

	if 0 == this.cur_camp1_mp_num {
		this.cur_camp1_mp_num = -1
	} else {
		this.camp1_matchplayers[find_idx] = this.camp1_matchplayers[this.cur_camp1_mp_num]
		this.cur_camp1_mp_num--
	}

	return new_m_result, 0

}

func (this *MatchManager) CancelCamp1Match(pid int32) {
	var tmp_p *MatchPlayer
	this.camp1_matchplayers_lock.Lock()
	defer this.camp1_matchplayers_lock.Unlock()
	for idx := int32(0); idx <= this.cur_camp1_mp_num; idx++ {
		tmp_p = this.camp1_matchplayers[idx]
		if nil == tmp_p || tmp_p.Id != pid {
			continue
		}

		if 0 == this.cur_camp1_mp_num {
			this.cur_camp1_mp_num = -1
		} else {
			this.camp1_matchplayers[idx] = this.camp1_matchplayers[this.cur_camp1_mp_num]
			this.cur_camp1_mp_num--
		}
		return
	}
}

func (this *MatchManager) add_camp2_mp_no_lock(p *MatchPlayer) {
	this.cur_camp2_mp_num++
	if this.cur_camp2_mp_num >= this.max_camp2_mp_num {
		log.Info("MatchManager camp2_mp need grow (%d %d) !", this.cur_camp2_mp_num, this.max_camp2_mp_num)
		this.max_camp2_mp_num = this.max_camp2_mp_num * 2
		new_match_items := make([]*MatchPlayer, this.max_camp2_mp_num)
		for idx := int32(0); idx < this.cur_camp2_mp_num; idx++ {
			new_match_items[idx] = this.camp2_matchplayers[idx]
		}
		this.camp2_matchplayers = new_match_items
	}
	this.camp2_matchplayers[this.cur_camp2_mp_num] = p
	log.Info("MatchManager camp2_mp after grow (%d, %d) !", this.cur_camp2_mp_num, this.max_camp2_mp_num)
}

func (this *MatchManager) AddCamp2Mp(p *MatchPlayer) {
	this.camp2_matchplayers_lock.Lock()
	defer this.camp2_matchplayers_lock.Unlock()
	this.cur_camp2_mp_num++
	if this.cur_camp2_mp_num >= this.max_camp2_mp_num {
		log.Info("MatchManager camp2_mp need grow (%d %d) !", this.cur_camp2_mp_num, this.max_camp2_mp_num)
		this.max_camp2_mp_num = this.max_camp2_mp_num * 2
		new_match_items := make([]*MatchPlayer, this.max_camp2_mp_num)
		for idx := int32(0); idx < this.cur_camp2_mp_num; idx++ {
			new_match_items[idx] = this.camp2_matchplayers[idx]
		}
		this.camp2_matchplayers = new_match_items
	}
	this.camp2_matchplayers[this.cur_camp2_mp_num] = p
	log.Info("MatchManager camp2_mp after grow (%d, %d) !", this.cur_camp2_mp_num, this.max_camp2_mp_num)
}

func (this *MatchManager) DoCamp2Match(p *MatchPlayer, match_type int32) (*MatchResult, int32) {
	if nil == p {
		log.Error("MatchManager DoCamp2Match param error !")
		return nil, -1
	}

	score := p.MatchScore
	bfind := false
	min_score := int32(-1)
	max_score := int32(-1)
	for _, val := range this.match_config.Items {
		//log.Error("Do Match compare (%d - %d)", val.TrophyLowerLimit, val.TrophyUpperLimit)
		if score >= val.TrophyLowerLimit && score <= val.TrophyUpperLimit {
			bfind = true
			min_score = val.BasictrophyLowert
			max_score = val.BasictrophyUpper
		}
	}

	if !bfind {
		log.Error("MatchManager player[%d] DoCamp2Match not find scope for score[%d]", p.Id, score)
		return nil, -1
	}

	this.camp2_matchplayers_lock.Lock()
	defer this.camp2_matchplayers_lock.Unlock()
	var tmp_p *MatchPlayer
	for idx := int32(0); idx <= this.cur_camp2_mp_num; idx++ {
		tmp_p := this.camp2_matchplayers[idx]
		if nil == tmp_p {
			continue
		}

		if tmp_p.Id == p.Id {
			return nil, 1
		}
	}

	var tmp_p_score int32
	find_idx := int32(-1)

	for idx := int32(0); idx <= this.cur_camp2_mp_num; idx++ {
		tmp_p = this.camp2_matchplayers[idx]
		if nil == tmp_p {
			log.Error("MatchManager DoCamp2Match matchplayer have nil")
			continue
		}

		tmp_p_score = tmp_p.MatchScore
		if tmp_p_score >= min_score && tmp_p_score <= max_score {
			find_idx = int32(idx)
			break
		}
	}

	if -1 == find_idx {
		//this.add_camp2_mp_no_lock(p)
		return nil, 0
	}

	new_m_result := &MatchResult{}
	new_m_result.players = make([]*MatchPlayer, 2)
	new_m_result.players[0] = p
	new_m_result.players[0].Token = int32(time.Now().Unix())
	new_m_result.players[1] = tmp_p
	new_m_result.players[1].Token = int32(time.Now().Unix())
	new_m_result.resultid = this.GetNextMatchResultId()

	if 0 == this.cur_camp2_mp_num {
		this.cur_camp2_mp_num = -1
	} else {
		this.camp2_matchplayers[find_idx] = this.camp2_matchplayers[this.cur_camp2_mp_num]
		this.cur_camp2_mp_num--
	}

	return new_m_result, 0

}

func (this *MatchManager) CancelCamp2Match(pid int32) {
	var tmp_p *MatchPlayer
	this.camp2_matchplayers_lock.Lock()
	defer this.camp2_matchplayers_lock.Unlock()
	for idx := int32(0); idx <= this.cur_camp2_mp_num; idx++ {
		tmp_p = this.camp2_matchplayers[idx]
		if nil == tmp_p || tmp_p.Id != pid {
			continue
		}

		if 0 == this.cur_camp2_mp_num {
			this.cur_camp2_mp_num = -1
		} else {
			this.camp2_matchplayers[idx] = this.camp2_matchplayers[this.cur_camp2_mp_num]
			this.cur_camp2_mp_num--
		}
		return
	}
}

// 普通匹配 ========================================================================

func (this *MatchManager) add_match_p_no_lock(p *MatchPlayer) {
	this.cur_normal_mp_num++
	if this.cur_normal_mp_num >= this.max_normal_mp_num {
		log.Info("MatchManager normal match need grow (%d  %d)", this.cur_normal_mp_num, this.max_normal_mp_num)
		this.max_normal_mp_num = this.max_normal_mp_num * 2
		new_match_items := make([]*MatchPlayer, this.max_normal_mp_num)
		for idx := int32(0); idx < this.cur_normal_mp_num; idx++ {
			new_match_items[idx] = this.normal_matchplayers[idx]
		}
		this.normal_matchplayers = new_match_items
	}

	log.Info("MatchManager normal match after grow (%d  %d)", this.cur_normal_mp_num, this.max_normal_mp_num)
	this.normal_matchplayers[this.cur_normal_mp_num] = p
}

func (this *MatchManager) DoNormalMatch(p *MatchPlayer, match_type int32) (*MatchResult, int32) {
	if nil == p {
		log.Error("MatchManager DoNormalMatch param error !")
		return nil, -1
	}

	score := p.MatchScore
	bfind := false
	min_score := int32(-1)
	max_score := int32(-1)
	for _, val := range this.match_config.Items {
		//log.Error("Do Match compare (%d - %d)", val.TrophyLowerLimit, val.TrophyUpperLimit)
		if score >= val.TrophyLowerLimit && score <= val.TrophyUpperLimit {
			bfind = true
			min_score = val.BasictrophyLowert
			max_score = val.BasictrophyUpper
		}
	}

	if !bfind {
		log.Error("MatchManager player[%d] DoNormalMatch not find scope for score[%d]", p.Id, score)
		return nil, -1
	}

	this.normal_matchplayers_lock.Lock()
	defer this.normal_matchplayers_lock.Unlock()
	var tmp_p *MatchPlayer
	for idx := int32(0); idx <= this.cur_normal_mp_num; idx++ {
		tmp_p := this.normal_matchplayers[idx]
		if nil == tmp_p {
			continue
		}

		if tmp_p.Id == p.Id {
			return nil, 1
		}
	}

	var tmp_p_score int32
	find_idx := int32(-1)

	for idx := int32(0); idx <= this.cur_normal_mp_num; idx++ {
		tmp_p = this.normal_matchplayers[idx]
		if nil == tmp_p {
			log.Error("MatchManager DoMatch matchplayer have nil")
			continue
		}

		tmp_p_score = tmp_p.MatchScore
		if tmp_p_score >= min_score && tmp_p_score <= max_score {
			find_idx = int32(idx)
			break
		}
	}

	if -1 == find_idx {
		this.add_match_p_no_lock(p)
		return nil, 0
	}

	new_m_result := &MatchResult{}
	new_m_result.players = make([]*MatchPlayer, 2)
	new_m_result.players[0] = p
	new_m_result.players[0].Token = int32(time.Now().Unix())
	new_m_result.players[1] = tmp_p
	new_m_result.players[1].Token = int32(time.Now().Unix())
	new_m_result.resultid = this.GetNextMatchResultId()

	if 0 == this.cur_normal_mp_num {
		this.cur_normal_mp_num = -1
	} else {
		this.normal_matchplayers[find_idx] = this.normal_matchplayers[this.cur_normal_mp_num]
		this.cur_normal_mp_num--
	}

	return new_m_result, 0

}

func (this *MatchManager) DoAiMatch(p *MatchPlayer, match_type int32) *MatchResult {
	ai_match_p := &MatchPlayer{}
	ai_match_p.Id = -1
	ai_match_p.Name = "CrazyMaster"
	ai_match_p.MatchScore = p.MatchScore + this.ai_chk_frame%5 - 2
	if ai_match_p.MatchScore < 0 {
		ai_match_p.MatchScore = 0
	}
	ai_match_p.CardCfgIds = p.CardCfgIds
	ai_match_p.CardLvls = p.CardLvls

	new_m_result := &MatchResult{}
	new_m_result.players = make([]*MatchPlayer, 2)
	new_m_result.players[0] = p
	new_m_result.players[0].Token = int32(time.Now().Unix())
	new_m_result.players[1] = ai_match_p
	new_m_result.players[1].Token = int32(time.Now().Unix())
	new_m_result.resultid = this.GetNextMatchResultId()

	return new_m_result
}

func (this *MatchManager) CancelNormalMatch(pid int32) {
	var tmp_p *MatchPlayer
	this.normal_matchplayers_lock.Lock()
	defer this.normal_matchplayers_lock.Unlock()

	for idx := int32(0); idx <= this.cur_normal_mp_num; idx++ {
		tmp_p = this.normal_matchplayers[idx]
		if nil == tmp_p || tmp_p.Id != pid {
			continue
		}

		if 0 == this.cur_normal_mp_num {
			this.cur_normal_mp_num = -1
		} else {
			this.normal_matchplayers[idx] = this.normal_matchplayers[this.cur_normal_mp_num]
			this.cur_normal_mp_num--
		}

		return
	}
}

// ===============================================================================

func (this *MatchManager) CancelMatch(pid, match_type int32) {

	switch match_type {
	case MATCH_TYPE_NORMAL:
		{
			match_mgr.print_match_players_nolock()
			this.CancelNormalMatch(pid)
			match_mgr.print_match_players_nolock()
		}
	case MATCH_TYPE_CAMP_MATCH:
		{
			match_mgr.print_camp1_match_players_nolock()
			this.CancelCamp1Match(pid)
			match_mgr.print_camp1_match_players_nolock()
			match_mgr.print_camp2_match_players_nolock()
			this.CancelCamp2Match(pid)
			match_mgr.print_camp2_match_players_nolock()
		}
	case MATCH_TYPE_2V2_MATCH:
		{

		}
	default:
		{
			log.Error("MatchManager CancelMatch match_type error %d %d", pid, match_type)
		}
	}

}

func (this *MatchManager) GetNextMatchResultId() int32 {
	this.next_result_id_lock.Lock()
	defer this.next_result_id_lock.Unlock()

	this.next_result_id++
	if this.next_result_id <= 0 {
		this.next_result_id = 1
	}

	return this.next_result_id
}

func (this *MatchManager) OnRoomServerClose(room_server_id int32) {
	log.Trace("MatchManager OnRoomServerClose 1")
	if !this.binit {
		return
	}

	this.RemoveMatchingByRoomServerId(room_server_id)
	pdelmap := this.RemoveMatchedByRoomServerId(room_server_id)
	log.Trace("MatchManager OnRoomServerClose 2 %v", pdelmap)
	res_2h := &msg_server_message.M2HClearMatchInfo{}
	res_2h.PlayerIds = make([]int64, 1)
	for pid, hallid := range pdelmap {
		hall_agent := hall_agent_mgr.GetAgentById(hallid)
		if nil == hall_agent {
			continue
		}

		res_2h.PlayerIds[0] = int64(pid)
		hall_agent.Send(res_2h)
	}
}

func (this *MatchManager) print_match_players_nolock() {
	log.Info("当前有%d名玩家在匹配:", this.cur_normal_mp_num)
	for idx := int32(0); idx <= this.cur_normal_mp_num; idx++ {
		val := this.normal_matchplayers[idx]
		log.Info("	玩家信息：%d,%s,%d", val.Id, val.Name, val.MatchScore)
	}
}

func (this *MatchManager) print_camp1_match_players_nolock() {
	log.Info("当前有%d名阵营1玩家在匹配:", this.cur_camp1_mp_num)
	for idx := int32(0); idx <= this.cur_camp1_mp_num; idx++ {
		val := this.camp1_matchplayers[idx]
		log.Info("	玩家信息：%d,%s,%d", val.Id, val.Name, val.MatchScore)
	}
}

func (this *MatchManager) print_camp2_match_players_nolock() {
	log.Info("当前有%d名阵营2玩家在匹配:", this.cur_camp2_mp_num)
	for idx := int32(0); idx <= this.cur_camp2_mp_num; idx++ {
		val := this.camp2_matchplayers[idx]
		log.Info("	玩家信息：%d,%s,%d", val.Id, val.Name, val.MatchScore)
	}
}

// 时钟处理=======================================================================================

func (this *MatchManager) PopTimeOverMatchNeed() map[int32]*MatchPlayer {
	ret_matchs := make(map[int32]*MatchPlayer)
	var tmp_p *MatchPlayer
	this.normal_matchplayers_lock.Lock()
	defer this.normal_matchplayers_lock.Unlock()
	cur_unix := int32(time.Now().Unix())
	for idx := int32(0); idx <= this.cur_normal_mp_num; idx++ {
		tmp_p = this.normal_matchplayers[idx]
		if nil == tmp_p || cur_unix-tmp_p.StartUnix <= global_config.MatchAiSec {
			continue
		}

		ret_matchs[tmp_p.Id] = tmp_p

		if 0 == this.cur_normal_mp_num {
			this.cur_normal_mp_num = -1
		} else {
			this.normal_matchplayers[idx] = this.normal_matchplayers[this.cur_normal_mp_num]
			this.cur_normal_mp_num--
		}
	}

	return ret_matchs
}

func (this *MatchManager) OnTick() {
	this.ai_chk_frame++
	if this.ai_chk_frame < MATCH_MGR_AI_CHECK_FRAME {
		return
	}

	this.ai_chk_frame = 0

	t_over_matchs := this.PopTimeOverMatchNeed()
	var new_result *MatchResult
	var msg_p *msg_server_message.MatchPlayer
	for _, val := range t_over_matchs {
		new_result = match_mgr.DoAiMatch(val, 0)
		new_result.resultid = match_mgr.GetNextMatchResultId()
		room_agent := room_server_agent_mgr.GetSuitableAgent()
		if nil == room_agent {
			log.Error("MatchManager OnTick failed !")
			this.PopCurMatchInfo(val.Id)
			return
		}
		new_result.room_server_id = room_agent.id
		req_2r := &msg_server_message.GetRoomReq{}
		req_2r.MatchPlayers = make([]*msg_server_message.MatchPlayer, 2)
		for idx, tmp_mp := range new_result.players {
			msg_p = &msg_server_message.MatchPlayer{}
			msg_p.Id = proto.Int64(int64(tmp_mp.Id))
			msg_p.Name = proto.String(tmp_mp.Name)
			msg_p.Score = proto.Int32(tmp_mp.MatchScore)
			msg_p.CardCfgIds = tmp_mp.CardCfgIds
			msg_p.CardLvls = tmp_mp.CardLvls
			msg_p.TongIcon = proto.Int32(tmp_mp.TongIcon)
			msg_p.TongName = proto.String(tmp_mp.TongName)
			msg_p.Token = proto.Int32(tmp_mp.Token)
			req_2r.MatchPlayers[idx] = msg_p
		}
		req_2r.ResultId = proto.Int32(new_result.resultid)

		room_agent.Send(req_2r)
		match_mgr.AddToMatching(new_result)

		this.PopCurMatchInfo(val.Id)

	}
}

// 消息处理=======================================================================================

func (this *MatchManager) RegMsgHandler() {
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_H2MPlayerMatch, H2MPlayerMatchHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_H2MCancelMatchReq, H2MCancelMatchReqHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_H2MCheckMatchInfo, H2MCheckMatchInfoHandler)
	hall_agent_mgr.SetMessageHandler(msg_server_message.ID_GetRoomReq, T2MGetRoomReqHandler)

	room_server_agent_mgr.SetMessageHandler(msg_server_message.ID_R2MGetRoomResponse, R2MGetRoomResponseHandler)
	room_server_agent_mgr.SetMessageHandler(msg_server_message.ID_R2MFightResult, R2MFightResultHandler)
}

func H2MPlayerMatchHandler(conn *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.H2MPlayerMatch)
	if nil == conn || nil == req {
		log.Error("H2MPlayerMatchHandler param error !")
		return
	}

	playerid := int32(req.GetId())
	hallid := conn.T
	if playerid <= 0 || hallid <= 0 || len(req.GetCardCfgIds()) < 0 {
		log.Error("H2MPlayerMatchHandler playerid(%d) or hallid(%d) <=0", playerid, hallid)
		return
	}

	if len(req.GetCardCfgIds()) != len(req.GetCardLvls()) {
		log.Error("H2MPlayerMatchHandler idlen(%d) != lvllen(%d)", len(req.GetCardCfgIds()), len(req.GetCardLvls()))
		return
	}

	// 是否在队列中
	if match_mgr.GetCurMathType(playerid) >= 0 {
		res_2h := &msg_server_message.M2HMatchingState{}
		res_2h.Id = proto.Int64(int64(playerid))
		res_2h.State = proto.Int32(1)
		res_2h.MatchType = proto.Int32(req.GetMatchType())
		conn.Send(res_2h, true)
		return
	}

	// 是否已经在比赛中
	cur_result := match_mgr.GetMatchedByPId(playerid)
	if nil != cur_result {
		res_2h := &msg_server_message.M2HMatchResult{}
		res_2h.Id = proto.Int64(int64(playerid))
		res_2h.ResultId = proto.Int32(cur_result.resultid)
		res_2h.RoomServerIP = proto.String(cur_result.room_server_ip)
		res_2h.RoomId = proto.Int32(cur_result.room_id)
		for _, tmp_mp := range cur_result.players {
			if playerid == tmp_mp.Id {
				res_2h.Token = proto.Int32(tmp_mp.Token)
			}
		}

		conn.Send(res_2h, true)
		log.Trace("H2MPlayerMatchHandler player[%d] is in Fighting ")
		return
	}

	// 是否在分配房间中
	cur_result = match_mgr.GetMatchingByPId(playerid)
	if nil != cur_result {
		res_2h := &msg_server_message.M2HMatchingState{}
		res_2h.Id = proto.Int64(int64(playerid))
		res_2h.State = proto.Int32(1)
		res_2h.MatchType = proto.Int32(req.GetMatchType())
		conn.Send(res_2h, true)
		log.Trace("H2MPlayerMatchHandler player[%d] is in Matching ")
		return
	}

	new_mp := new_match_player(playerid, hallid, req)
	match_type := req.GetMatchType()
	var new_result *MatchResult
	var iret int32
	switch match_type {
	case MATCH_TYPE_NORMAL:
		{
			match_mgr.print_match_players_nolock()
			defer match_mgr.print_match_players_nolock()
			new_result, iret = match_mgr.DoNormalMatch(new_mp, 0)
			if nil == new_result && 0 == iret {
				match_mgr.SetCurMatchType(playerid, match_type)
			}
		}
	case MATCH_TYPE_CAMP_MATCH:
		{
			camp := req.GetPlayerCamp()
			if PLAYER_CAMP_1 == camp {
				match_mgr.print_camp1_match_players_nolock()
				defer match_mgr.print_camp1_match_players_nolock()
				new_result, iret = match_mgr.DoCamp2Match(new_mp, 0)
				if nil == new_result && 0 == iret {
					match_mgr.SetCurMatchType(playerid, match_type)
					match_mgr.AddCamp1Mp(new_mp)
				}
			} else {
				match_mgr.print_camp2_match_players_nolock()
				defer match_mgr.print_camp2_match_players_nolock()
				new_result, iret = match_mgr.DoCamp1Match(new_mp, 0)
				if nil == new_result && 0 == iret {
					match_mgr.SetCurMatchType(playerid, match_type)
					match_mgr.AddCamp2Mp(new_mp)
				}
			}
		}
	case MATCH_TYPE_2V2_MATCH:
		{
			iret, new_room := match_mgr.Do2v2RoomMatch(new_mp)
			if iret < 0 || nil == new_room {
				log.Error("2v2 match failed !")
				return
			}

			match_mgr.SetCur2v2RoomMatch(playerid, new_room, MATCH_TYPE_2V2_MATCH)
			return
		}
	}

	if 0 > iret {
		res_2h := &msg_server_message.M2HMatchingState{}
		res_2h.Id = proto.Int64(int64(playerid))
		res_2h.State = proto.Int32(0)
		res_2h.MatchType = proto.Int32(req.GetMatchType())
		conn.Send(res_2h, true)
	} else {
		if nil == new_result {
			res_2h := &msg_server_message.M2HMatchingState{}
			res_2h.Id = proto.Int64(int64(playerid))
			res_2h.State = proto.Int32(1)
			res_2h.MatchType = proto.Int32(req.GetMatchType())
			conn.Send(res_2h, true)
			return
		}

		new_result.resultid = match_mgr.GetNextMatchResultId()
		room_agent := room_server_agent_mgr.GetSuitableAgent()
		if nil == room_agent {
			log.Error("H2MPlayerMatchHandler GetSuitableAgent failed !")
			match_mgr.PopCurMatchInfo(new_result.player2.Id)
			return
		}
		new_result.room_server_id = room_agent.id
		req_2r := &msg_server_message.GetRoomReq{}
		req_2r.MatchPlayers = make([]*msg_server_message.MatchPlayer, 0, len(new_result.players))
		var msg_p *msg_server_message.MatchPlayer
		for _, tmp_mp := range new_result.players {
			msg_p.Id = proto.Int64(int64(tmp_mp.Id))
			msg_p.Name = proto.String(tmp_mp.Name)
			msg_p.Score = proto.Int32(tmp_mp.MatchScore)
			msg_p.CardCfgIds = tmp_mp.CardCfgIds
			msg_p.CardLvls = tmp_mp.CardLvls
			msg_p.TongIcon = proto.Int32(tmp_mp.TongIcon)
			msg_p.TongName = proto.String(tmp_mp.TongName)
			msg_p.Token = proto.Int32(tmp_mp.Token)
			req_2r.MatchPlayers = append(req_2r.MatchPlayers, msg_p)
		}

		req_2r.ResultId = proto.Int32(new_result.resultid)

		room_agent.Send(req_2r)
		match_mgr.AddToMatching(new_result)
		match_mgr.PopCurMatchInfo(new_result.player2.Id)
	}
}

func H2MCancelMatchReqHandler(conn *server_conn.ServerConn, msg proto.Message) {

	req := msg.(*msg_server_message.H2MCancelMatchReq)
	if nil == conn || nil == req {
		log.Error("H2MCancelMatchReqHandler param error !")
		return
	}

	playerid := int32(req.GetId())
	// 是否已经在比赛中
	cur_result := match_mgr.GetMatchedByPId(playerid)
	if nil != cur_result {
		log.Trace("H2MCancelMatchReqHandler player(%d) in matched ", playerid)
		return
	}

	// 是否在分配房间中
	cur_result = match_mgr.GetMatchingByPId(playerid)
	if nil != cur_result {
		log.Trace("H2MCancelMatchReqHandler player(%d) in matching ", playerid)
		return
	}

	cur_match_info := match_mgr.PopCurMatchInfo(playerid)
	if nil == cur_match_info {
		log.Trace("H2MCancelMatchReqHandler player[%d] no match info", playerid)
		return
	}

	if MATCH_TYPE_2V2_MATCH == cur_match_info.match_type &&
		(nil == cur_match_info.match_2v2_room || MATCH_2V2_STEP_TEAM_MATCH == cur_match_info.match_2v2_room.match_step) {
		log.Trace("H2MCancelMatchReqHandler player[%d] 2v2 match can not stop now [%v]", playerid, nil == cur_match_info.match_2v2_room)
		return
	}

	match_mgr.CancelMatch(playerid, cur_match_info.match_type)
	res_2h := &msg_server_message.M2HCancelMatchRes{}
	res_2h.Id = proto.Int64(int64(playerid))
	res_2h.State = proto.Int32(0)

	conn.Send(res_2h, true)
}

func H2MCheckMatchInfoHandler(conn *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.H2MCheckMatchInfo)
	if nil == conn || nil == req {
		log.Error("H2MCheckMatchInfoHandler param error !")
		return
	}

	playerid := int32(req.GetId())
	// 如果不在比赛，则取消掉
	cur_result := match_mgr.GetMatchedByPId(playerid)
	if nil == cur_result {
		res_2h := &msg_server_message.M2HClearMatchInfo{}
		res_2h.PlayerIds = make([]int64, 1)
		res_2h.PlayerIds[0] = req.GetId()
		conn.Send(res_2h, true)
	}

	return
}

// ---------------------------------------------------------------------

func T2MGetRoomReqHandler(conn *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.GetRoomReq)
	if nil == conn || nil == req {
		log.Error("T2MGetRoomReqHandler conn or req nil [%v]", nil == req)
		return
	}

	room_svr := room_server_agent_mgr.GetSuitableAgent()
	if nil == room_svr {
		log.Error("T2MGetRoomReqHandler failed to get suitable agent !")
		return
	}

	match_mgr.AddToTongFriendMatch(req, room_svr)

	room_svr.Send(req)
}

// ---------------------------------------------------------------------

func R2MGetRoomResponseHandler(agent *RoomServerAgent, msg proto.Message) {
	res := msg.(*msg_server_message.R2MGetRoomResponse)
	if nil == agent || nil == msg {
		log.Error("R2MGetRoomResponseHandler param error !")
		return
	}

	resultid := res.GetResultId()
	cur_matching := match_mgr.PopMatchingByRId(resultid)
	if nil == cur_matching {
		log.Error("R2MGetRoomResponseHandler cur_matching[%d] nil", resultid)
		return
	}

	roomid := res.GetRoomId()
	cur_matching.room_id = roomid
	cur_matching.room_server_ip = agent.listen_client_ip
	log.Info("R2MGetRoomResponseHandler =================add to matched", cur_matching.resultid)
	match_mgr.AddToMatchedResult(cur_matching)

	res_2h := &msg_server_message.M2HMatchResult{}
	res_2h.RoomServerIP = proto.String(cur_matching.room_server_ip)

	for _, tmp_mp := range cur_matching.players {
		if tmp_mp.Id <= 0 {
			continue
		}

		hall := hall_agent_mgr.GetAgentById(tmp_mp.HallId)
		if nil != hall {
			res_2h.ResultId = proto.Int32(resultid)
			res_2h.Id = proto.Int64(int64(tmp_mp.Id))
			res_2h.RoomId = proto.Int32(roomid)
			res_2h.Token = proto.Int32(tmp_mp.Token)
			res_2h.MathType = proto.Int32(tmp_mp.match_type)
			hall.Send(res_2h)
		} else {
			log.Error("R2MGetRoomResponseHandler get hall [%d] failed !", tmp_mp.HallId)
		}

	}

	return
}

func R2MFightResultHandler(agent *RoomServerAgent, msg proto.Message) {
	res := msg.(*msg_server_message.R2MFightResult)
	if nil == agent || nil == res {
		log.Error("R2MFightResultHandler param error !")
		return
	}

	resultid := res.GetResultId()
	matched := match_mgr.PopMatchedByRId(resultid)
	if nil == matched {
		log.Error("R2MFightResultHandler can not find matched", resultid)
		return
	}

	res_2h := &msg_server_message.M2HFightResult{}
	res_2h.MatchType = proto.Int32(res.GetMatchType())
	hall1 := hall_agent_mgr.GetAgentById(matched.players[0].HallId)
	hall2 := hall_agent_mgr.GetAgentById(matched.players[1].HallId)
	player1 := matched.players[0]
	player2 := matched.players[1]
	result := res.GetResult()
	switch result {
	case FIGHT_RESULT_EQUAL:
		fallthrough
	case FIGHT_RESULT_ERROR:
		{
			if nil != hall1 {
				res_2h.Id = proto.Int64(int64(player1.Id))
				res_2h.Result = proto.Int32(FIGHT_RESULT_2_HALL_EQUAL)
				res_2h.MyTowers = proto.Int32(res.GetP1Towers())
				res_2h.OpTowers = proto.Int32(res.GetP2Towers())
				res_2h.OpScores = proto.Int32(player2.MatchScore)
				res_2h.OptId = proto.Int32(player2.Id)
				res_2h.OptName = proto.String(player2.Name)
				res_2h.OptCards = player2.CardCfgIds
				res_2h.OptCardLvls = player2.CardLvls
				res_2h.OptTongId = proto.Int32(player2.TongId)
				res_2h.OpTongIcon = proto.Int32(player2.TongIcon)
				res_2h.OptTongName = proto.String(player2.TongName)
				res_2h.OpMatchScore = proto.Int32(player2.MatchScore)
				hall1.Send(res_2h)
			}
			if nil != hall2 {
				res_2h.Id = proto.Int64(int64(player2.Id))
				res_2h.Result = proto.Int32(FIGHT_RESULT_2_HALL_EQUAL)
				res_2h.MyTowers = proto.Int32(res.GetP2Towers())
				res_2h.OpTowers = proto.Int32(res.GetP1Towers())
				res_2h.OpScores = proto.Int32(player1.MatchScore)
				res_2h.OptId = proto.Int32(player1.Id)
				res_2h.OptName = proto.String(player1.Name)
				res_2h.OptCards = player1.CardCfgIds
				res_2h.OptCardLvls = player1.CardLvls
				res_2h.OptTongId = proto.Int32(player1.TongId)
				res_2h.OpTongIcon = proto.Int32(player1.TongIcon)
				res_2h.OptTongName = proto.String(player1.TongName)
				res_2h.OpMatchScore = proto.Int32(player2.MatchScore)
				hall2.Send(res_2h)
			}
		}
	case FIGHT_RESULT_P1_WIN:
		{
			if nil != hall1 {
				res_2h.Id = proto.Int64(int64(player1.Id))
				res_2h.Result = proto.Int32(FIGHT_RESULT_2_HALL_WIN)
				res_2h.MyTowers = proto.Int32(res.GetP1Towers())
				res_2h.OpTowers = proto.Int32(res.GetP2Towers())
				res_2h.OpScores = proto.Int32(player2.MatchScore)
				res_2h.OptId = proto.Int32(player2.Id)
				res_2h.OptName = proto.String(player2.Name)
				res_2h.OptCards = player2.CardCfgIds
				res_2h.OptCardLvls = player2.CardLvls
				res_2h.OptTongId = proto.Int32(player2.TongId)
				res_2h.OpTongIcon = proto.Int32(player2.TongIcon)
				res_2h.OptTongName = proto.String(player2.TongName)
				res_2h.OpMatchScore = proto.Int32(player2.MatchScore)
				hall1.Send(res_2h)
			}
			if nil != hall2 {
				res_2h.Id = proto.Int64(int64(matched.player2.Id))
				res_2h.Result = proto.Int32(FIGHT_RESULT_2_HALL_FAIL)
				res_2h.MyTowers = proto.Int32(res.GetP2Towers())
				res_2h.OpTowers = proto.Int32(res.GetP1Towers())
				res_2h.OpScores = proto.Int32(player1.MatchScore)
				res_2h.OptId = proto.Int32(player1.Id)
				res_2h.OptName = proto.String(player1.Name)
				res_2h.OptCards = player1.CardCfgIds
				res_2h.OptCardLvls = player1.CardLvls
				res_2h.OptTongId = proto.Int32(player1.TongId)
				res_2h.OpTongIcon = proto.Int32(player1.TongIcon)
				res_2h.OptTongName = proto.String(player1.TongName)
				res_2h.OpMatchScore = proto.Int32(player1.MatchScore)
				hall2.Send(res_2h)
			}
		}
	case FIGHT_RESULT_P2_WIN:
		{
			if nil != hall1 {
				res_2h.Id = proto.Int64(int64(player1.Id))
				res_2h.Result = proto.Int32(FIGHT_RESULT_2_HALL_FAIL)
				res_2h.MyTowers = proto.Int32(res.GetP1Towers())
				res_2h.OpTowers = proto.Int32(res.GetP2Towers())
				res_2h.OpScores = proto.Int32(player2.MatchScore)
				res_2h.OptId = proto.Int32(player2.Id)
				res_2h.OptName = proto.String(player2.Name)
				res_2h.OptCards = player2.CardCfgIds
				res_2h.OptCardLvls = player2.CardLvls
				res_2h.OptTongId = proto.Int32(player2.TongId)
				res_2h.OpTongIcon = proto.Int32(player2.TongIcon)
				res_2h.OptTongName = proto.String(player2.TongName)
				res_2h.OpMatchScore = proto.Int32(player2.MatchScore)
				hall1.Send(res_2h)
			}
			if nil != hall2 {
				res_2h.Id = proto.Int64(int64(matched.player2.Id))
				res_2h.Result = proto.Int32(FIGHT_RESULT_2_HALL_WIN)
				res_2h.MyTowers = proto.Int32(res.GetP2Towers())
				res_2h.OpTowers = proto.Int32(res.GetP1Towers())
				res_2h.OpScores = proto.Int32(player1.MatchScore)
				res_2h.OptId = proto.Int32(player1.Id)
				res_2h.OptName = proto.String(player1.Name)
				res_2h.OptCards = player1.CardCfgIds
				res_2h.OptCardLvls = player1.CardLvls
				res_2h.OptTongId = proto.Int32(player1.TongId)
				res_2h.OpTongIcon = proto.Int32(player1.TongIcon)
				res_2h.OptTongName = proto.String(player1.TongName)
				res_2h.OpMatchScore = proto.Int32(player1.MatchScore)
				hall2.Send(res_2h)
			}
		}
	}

	return
}
