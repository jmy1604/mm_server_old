package main

import (
	//"encoding/json"
	//"io/ioutil"
	"libs/log"
	"libs/server_conn"
	"libs/timer"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	AGENT_ACCOUNT_STATE_DISCONNECTED = iota
	AGENT_ACCOUNT_STATE_CONNECTED    = 1
	AGENT_ACCOUNT_STATE_IN_LOGIN     = 2
	AGENT_ACCOUNT_STATE_IN_GAME      = 3
)

const (
	ROOM_SERVER_AGENT_DISCONNECT = iota
	ROOM_SERVER_AGENT_CONNECTED  = 1
	ROOM_SERVER_AGENT_CREATED    = 2

	MIN_ROOM_MATCH_P_NUM = 2000
)

type RoomServerAgent struct {
	conn             *server_conn.ServerConn // 连接
	state            int32                   // agent状态
	name             string                  // room_server name
	id               int32                   // room_server ID
	listen_client_ip string                  // 监听客户端IP
	curr_player_num  int32                   // 当前在线人数
	aids             map[string]int32        // 已有的账号
	aids_lock        *sync.RWMutex
}

func new_agent(c *server_conn.ServerConn, state int32) (agent *RoomServerAgent) {
	agent = &RoomServerAgent{}
	agent.conn = c
	agent.state = state
	agent.aids = make(map[string]int32)
	agent.aids_lock = &sync.RWMutex{}
	return
}

func (this *RoomServerAgent) HasAid(aid string) (ok bool) {
	this.aids_lock.RLock()
	defer this.aids_lock.RUnlock()

	state, o := this.aids[aid]
	if !o {
		return
	}
	if state <= 0 {
		return
	}
	ok = true
	return
}

func (this *RoomServerAgent) AddAid(aid string) (ok bool) {
	this.aids_lock.Lock()
	defer this.aids_lock.Unlock()

	_, o := this.aids[aid]
	if o {
		return
	}
	this.aids[aid] = 1
	ok = true
	return
}

func (this *RoomServerAgent) RemoveAid(aid string) (ok bool) {
	this.aids_lock.Lock()
	defer this.aids_lock.Unlock()

	_, o := this.aids[aid]
	if !o {
		return
	}

	delete(this.aids, aid)
	ok = true
	return
}

func (this *RoomServerAgent) UpdatePlayersNum(curr_num int32) {
	this.curr_player_num = curr_num
	return
}

func (this *RoomServerAgent) GetPlayersNum() (curr_num int32) {
	curr_num = this.curr_player_num
	return
}

func (this *RoomServerAgent) Send(msg proto.Message) {
	this.conn.Send(msg, false)
}

func (this *RoomServerAgent) Close(force bool) {
	this.aids_lock.Lock()
	defer this.aids_lock.Unlock()
	if force {
		this.conn.Close(server_conn.E_DISCONNECT_REASON_FORCE_CLOSED)
	} else {
		this.conn.Close(server_conn.E_DISCONNECT_REASON_LOGGIN_FAILED)
	}
}

//=================================================================================================

type RoomServerAgentManager struct {
	net                *server_conn.Node
	id2agents          map[int32]*RoomServerAgent
	conn2agents        map[*server_conn.ServerConn]*RoomServerAgent
	agents_lock        *sync.RWMutex
	inited             bool
	quit               bool
	shutdown_lock      *sync.Mutex
	shutdown_completed bool
	ticker             *timer.TickTimer
	listen_err_chan    chan error
}

var room_server_agent_mgr RoomServerAgentManager

func (this *RoomServerAgentManager) Init() {
	this.id2agents = make(map[int32]*RoomServerAgent)
	this.conn2agents = make(map[*server_conn.ServerConn]*RoomServerAgent)
	this.agents_lock = &sync.RWMutex{}
	this.net = server_conn.NewNode(this, 0, 0, 5000, 0, 0, 0, 0, 0)
	this.net.SetDesc("", "房间服务器")

	this.shutdown_lock = &sync.Mutex{}
	this.listen_err_chan = make(chan error)
	this.init_message_handle()
	this.inited = true
	return
}

func (this *RoomServerAgentManager) Start() (err error) {

	go this.Run()

	go this.Listen()

	err = this.wait_listen_res()

	// log.Event("RoomServerAgentManager已启动", nil, log.Property{"IP", config.ListenRoomServerIP})
	// log.Trace("**************************************************")

	return
}

func (this *RoomServerAgentManager) Listen() {
	err := this.net.Listen(config.ListenRoomServerIP, config.MaxRoomConnections)
	if err != nil {
		this.listen_err_chan <- err
		log.Error("启动RoomServerAgentManager失败 %v", err)
	} else {
		close(this.listen_err_chan)
	}
	return
}

func (this *RoomServerAgentManager) Run() {
	defer func() {
		if err := recover(); err != nil {
			log.Stack(err)
		}
		this.shutdown_completed = true
	}()

	this.ticker = timer.NewTickTimer(1000)
	this.ticker.Start()
	defer this.ticker.Stop()

	for {
		select {
		case d, ok := <-this.ticker.Chan:
			{
				if !ok {
					return
				}

				begin := time.Now()
				this.OnTick(d)
				time_cost := time.Now().Sub(begin).Seconds()
				if time_cost > 1 {
					log.Trace("耗时 %v", time_cost)
					if time_cost > 30 {
						log.Error("耗时 %v", time_cost)
					}
				}
			}
		}
	}
}

// 等5秒中，如果没出错就认为成功
func (this *RoomServerAgentManager) wait_listen_res() (err error) {
	timeout := make(chan bool, 1)
	go func() {
		time.Sleep(1 * time.Second)
		timeout <- true
	}()

	var o bool
	select {
	case err, o = <-this.listen_err_chan:
		{
			if !o {
				log.Trace("wait listen_err_chan failed")
				return
			}
		}
	case <-timeout:
		{
		}
	}

	return
}

func (this *RoomServerAgentManager) OnAccept(c *server_conn.ServerConn) {
	this.AddAgent(c, ROOM_SERVER_AGENT_CONNECTED)
	log.Trace("新的RoomServerAgent连接")
}

func (this *RoomServerAgentManager) OnConnect(c *server_conn.ServerConn) {
}

func (this *RoomServerAgentManager) OnUpdate(c *server_conn.ServerConn, t timer.TickTime) {
}

func (this *RoomServerAgentManager) OnDisconnect(c *server_conn.ServerConn, reason server_conn.E_DISCONNECT_REASON) {
	this.DisconnectAgent(c, reason)
	log.Trace("断开RoomServerAgent连接", reason)
}

func (this *RoomServerAgentManager) OnTick(t timer.TickTime) {
}

func (this *RoomServerAgentManager) set_ih(type_id uint16, h server_conn.Handler) {
	t := msg_server_message.MessageTypes[type_id]
	if t == nil {
		log.Error("设置消息句柄失败，不存在的消息类型 %v", type_id)
		return
	}

	this.net.SetHandler(type_id, t, h)
}

func (this *RoomServerAgentManager) HasAgent(server_id int32) (ok bool) {
	this.agents_lock.RLock()
	defer this.agents_lock.RUnlock()
	_, o := this.id2agents[server_id]
	if !o {
		return
	}
	ok = true
	return
}

func (this *RoomServerAgentManager) GetAgent(c *server_conn.ServerConn) (agent *RoomServerAgent) {
	this.agents_lock.RLock()
	defer this.agents_lock.RUnlock()
	a, o := this.conn2agents[c]
	if !o {
		return
	}
	agent = a
	return
}

func (this *RoomServerAgentManager) GetAgentByID(server_id int32) (agent *RoomServerAgent) {
	this.agents_lock.RLock()
	defer this.agents_lock.RUnlock()
	a, o := this.id2agents[server_id]
	if !o {
		return
	}
	agent = a
	return
}

func (this *RoomServerAgentManager) AddAgent(c *server_conn.ServerConn, state int32) (agent *RoomServerAgent) {
	this.agents_lock.Lock()
	defer this.agents_lock.Unlock()

	_, o := this.conn2agents[c]
	if o {
		return
	}

	agent = new_agent(c, state)
	this.conn2agents[c] = agent
	return
}

func (this *RoomServerAgentManager) SetAgentByID(id int32, agent *RoomServerAgent) (ok bool) {
	this.agents_lock.Lock()
	defer this.agents_lock.Unlock()

	agent.id = id

	this.id2agents[id] = agent
	ok = true
	return
}

func (this *RoomServerAgentManager) RemoveAgent(c *server_conn.ServerConn, lock bool) (ok bool, agent_id int32) {
	if lock {
		this.agents_lock.Lock()
		defer this.agents_lock.Unlock()
	}

	agent, o := this.conn2agents[c]
	if !o {
		return
	}

	delete(this.conn2agents, c)
	delete(this.id2agents, agent.id)

	agent.aids = nil

	ok = true
	agent_id = agent.id

	return
}

func (this *RoomServerAgentManager) DisconnectAgent(c *server_conn.ServerConn, reason server_conn.E_DISCONNECT_REASON) (ok bool, agent_id int32) {
	if c == nil {
		return
	}

	if server_conn.E_DISCONNECT_REASON_FORCE_CLOSED != reason {
		res := &msg_server_message.M2RDissconnectNotify{}
		res.Reason = proto.Int32(int32(reason))
		c.Send(res, true)
	}

	ok, agent_id = this.RemoveAgent(c, true)
	if ok {
		match_mgr.OnRoomServerClose(agent_id)
	}

	return
}

func (this *RoomServerAgentManager) UpdatePlayersNum(server_id int32, curr_num int32) {
	this.agents_lock.RLock()
	defer this.agents_lock.RUnlock()

	agent := this.id2agents[server_id]
	if agent == nil {
		return
	}

	agent.UpdatePlayersNum(curr_num)
}

func (this *RoomServerAgentManager) GetPlayersNum(server_id int32) (agent *RoomServerAgent, curr_num int32) {
	this.agents_lock.RLock()
	defer this.agents_lock.RUnlock()

	agent = this.id2agents[server_id]
	if agent == nil {
		return
	}

	curr_num = agent.GetPlayersNum()
	return
}

func (this *RoomServerAgentManager) GetSuitableAgent() *RoomServerAgent {
	min_num := int32(-1)
	var ret_agent *RoomServerAgent
	this.agents_lock.RLock()
	defer this.agents_lock.RUnlock()
	for _, agent := range this.conn2agents {
		if nil == agent {
			continue
		}

		if agent.curr_player_num < MIN_ROOM_MATCH_P_NUM {
			ret_agent = agent
			break
		}

		if -1 == min_num || agent.curr_player_num < min_num {
			min_num = agent.curr_player_num
			ret_agent = agent
		}
	}

	return ret_agent
}

//==============================================================================================

func (this *RoomServerAgentManager) init_message_handle() {
	this.SetMessageHandler(msg_server_message.ID_R2MRoomServerRegister, R2MRoomServerRegisterHandler)
	this.SetMessageHandler(msg_server_message.ID_R2MPlayerNumUpdate, R2MPlayerNumUpdateHandler)
}

type GameMessageHandler func(a *RoomServerAgent, m proto.Message)

func (this *RoomServerAgentManager) SetMessageHandler(type_id uint16, h GameMessageHandler) {
	if h == nil {
		this.set_ih(type_id, nil)
		return
	}

	this.set_ih(type_id, func(c *server_conn.ServerConn, m proto.Message) {
		a := this.GetAgent(c)
		if a == nil {
			log.Trace("game_server尚未成功连接 %v", c.GetAddr())
			//this.CloseConnection(c, server_conn.E_DISCONNECT_REASON_PLAYER_NOT_LOGGED)
			return
		}

		h(a, m)
	})
}

func R2MRoomServerRegisterHandler(a *RoomServerAgent, m proto.Message) {
	req := m.(*msg_server_message.R2MRoomServerRegister)
	if nil == req {
		log.Error("RoomServerRegisterHandler")
		return
	}
	server_id := req.GetServerId()

	if room_server_agent_mgr.HasAgent(server_id) {
		room_server_agent_mgr.DisconnectAgent(a.conn, server_conn.E_DISCONNECT_REASON_FORCE_CLOSED)
		log.Warn("房间服务器[%v]已有，不能有重复的ID", server_id)
		return
	}

	a.id = server_id
	a.name = req.GetServerName()
	a.state = ROOM_SERVER_AGENT_CONNECTED
	a.listen_client_ip = req.GetListenClientIP()

	room_server_agent_mgr.SetAgentByID(server_id, a)

	log.Trace("房间服务器[%d %s]已连接", server_id, a.name)
}

func R2MPlayerNumUpdateHandler(agent *RoomServerAgent, msg proto.Message) {
	res := msg.(*msg_server_message.R2MPlayerNumUpdate)
	curr_num := res.GetCurPlayerNum()
	room_server_agent_mgr.UpdatePlayersNum(agent.id, curr_num)
	log.Info("房间服务器[%d]人数[%d]", agent.id, curr_num)
}
