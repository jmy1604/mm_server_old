package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"libs/log"
	"os"
	"public_message/gen_go/server_message"
	"time"
)

type ServerConfig struct {
	ServerId           int32
	InnerVersion       string
	ServerName         string
	ListenRoomServerIP string
	ListenHallIP       string
	MaxHallConnections int32
	MaxRoomConnections int32

	LogConfigDir   string // 日志配置文件路径
	CenterServerIP string // 连接AssistServer
	DbServerCfgDir string // Db服务器地址配置
	SAuthIP        string // 计费登陆地址
}

var config ServerConfig
var shutingdown bool

func main() {
	defer func() {
		log.Event("关闭服务器", nil)
		if err := recover(); err != nil {
			log.Stack(err)
		}
		match_server.Shutdown()
		time.Sleep(3 * time.Second)
	}()

	var temp_i int32

	config_file := "../conf/match_server.cfg"
	if len(os.Args) > 1 {
		arg_config_file := flag.String("f", "", "config file path")
		if arg_config_file != nil && *arg_config_file == "" {
			flag.Parse()
			fmt.Printf("配置参数 %s", *arg_config_file)
			config_file = *arg_config_file
		}
	}

	data, err := ioutil.ReadFile(config_file)
	if err != nil {
		fmt.Printf("读取配置文件失败 %v", err)
		return
	}
	err = json.Unmarshal(data, &config)
	if err != nil {
		fmt.Printf("解析配置文件失败 %v", err.Error())
		fmt.Scanln(&temp_i)
		return
	}

	// 加载日志配置
	log.Init("", config.LogConfigDir, true)
	log.Event("配置:网络协议版本", int32(msg_server_message.E_VERSION_NUMBER))
	log.Event("配置:服务器监听房间地址", config.ListenRoomServerIP)
	log.Event("配置:最大大厅连接数)", config.MaxHallConnections)
	log.Event("配置:最大房间连接数)", config.MaxRoomConnections)

	if !global_config_load() {
		log.Error("global_config_load failed !")
		return
	}

	// 启动房间服务管理器
	room_server_agent_mgr.Init()
	err = room_server_agent_mgr.Start()
	if nil != err {
		log.Error("启动room_server_agent_mgr失败", err.Error())
		return
	}

	// 启动房间服务器管理器
	hall_agent_mgr.Init()
	err = hall_agent_mgr.Start()
	if nil != err {
		log.Error("启动hall_agent_mgr失败", err.Error())
		return
	}

	if !match_server.Init() {
		return
	}

	match_server.Start()
}
