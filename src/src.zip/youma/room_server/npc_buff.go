package main

import (
	"libs/log"
	"time"
)

const (
	MAX_BUFF_LAST_NSEC = 900000000000

	BUFF_AURA_EFFECT_ENEMY  = 1
	BUFF_AURA_EFFECT_FRIEND = 2
)

const (
	BUFF_EFFECT_DEATH_CAST       = 1  // 死亡技能
	BUFF_EFFECT_ADD_MOVE_SPEED   = 2  // 加运动速度
	BUFF_EFFECT_ADD_ATTACK_SPEED = 3  // 加攻击速度
	BUFF_EFFECT_SUB_MOVE_SPEED   = 4  // 减少运动速度
	BUFF_EFFECT_SUB_ATTACK_SPEED = 5  // 减少攻击速度
	BUFF_EFFECT_CIRCLE_SKILL     = 6  // 循环技能
	BUFF_EFFECT_FORWARD          = 7  // 冲锋
	BUFF_EFFECT_CAST_WHEN_BLOCK  = 8  // 遇到阻挡后释放技能
	BUFF_EFFECT_FREEZE           = 9  // 冰冻
	BUFF_EFFECT_LASTING_DAMAGE   = 12 // 持续伤害
	BUFF_EFFECT_DIZZY            = 13 // 眩晕
	BUFF_EFFECT_AURA             = 18 // 光环
)

type NpcBuff struct {
	cfgid        int32           // buffid
	create_nsec  int64           // buff创建时间 单位 纳秒
	end_nsec     int64           // buff的结束时间 单位 纳秒
	buff_lvl     int32           // buff等级
	cur_act_nsec int64           // 上一次生效时间单位 纳秒
	buff_cfg     *XmlBuff        // buff配置
	sub_dis2     float32         // 光环类buff有效距离平方
	effect_npcs  map[int32]int32 // buff影响的npc，需要的时候使用
}

func NewNpcBuff(buffid, lvl int32, lastnsec int64) *NpcBuff {
	buff_cfg := cfg_buff_mgr.Map[buffid]
	if nil == buff_cfg {
		log.Error("NewNpcBuff param error [%d]!", buffid)
		return nil
	}
	new_buff := &NpcBuff{}
	new_buff.cfgid = buffid
	new_buff.create_nsec = time.Now().UnixNano()
	if lastnsec > 0 {
		new_buff.end_nsec = time.Now().UnixNano() + lastnsec
	}
	new_buff.buff_cfg = buff_cfg
	new_buff.buff_lvl = lvl
	return new_buff
}

func (this *Npc) OnBuffAdd(buff *NpcBuff) {
	if nil == buff || nil == buff.buff_cfg {
		log.Error("Npc OnBuffAdd buff nil !")
		return
	}

	if nil != buff.buff_cfg.EffectInfos1 {
		this.DoBuffOnEffect(buff, buff.buff_cfg.EffectInfos1)
	}

	if nil != buff.buff_cfg.EffectInfos2 {
		this.DoBuffOnEffect(buff, buff.buff_cfg.EffectInfos2)
	}

	if nil != buff.buff_cfg.EffectInfos3 {
		this.DoBuffOnEffect(buff, buff.buff_cfg.EffectInfos3)
	}
}

func (this *Npc) DoBuffOnEffect(buff *NpcBuff, eff_param *EffectModeParam) {
	switch eff_param.EffectType {
	case BUFF_EFFECT_DEATH_CAST:
		{
			break
		}
	case BUFF_EFFECT_ADD_MOVE_SPEED:
		{
			if len(eff_param.Params) < 1 {
				log.Error("Npc[%d] DoBuffOnEffect[%d] BUFF_EFFECT_ADD_MOVE_SPEED param error !", this.Id, buff.cfgid)
				return
			}

			this.buff_add_m_speed = this.buff_add_m_speed + eff_param.Params[0]
			log.Trace("npc[%d] DoBuffOnEffect buff[%d]加移动速[%d] cur_val[%d]", this.Id, buff.cfgid, eff_param.Params[0], this.buff_add_m_speed)
		}
	case BUFF_EFFECT_ADD_ATTACK_SPEED:
		{
			if len(eff_param.Params) < 1 {
				log.Error("Npc[%d] DoBuffOnEffect[%d] Add AttackSpeed param error !", this.Id, buff.cfgid)
				return
			}

			this.buff_add_a_speed = this.buff_add_a_speed + eff_param.Params[0]
			log.Trace("npc[%d] DoBuffOnEffect buff[%d]加攻击速[%d] cur_val[%d]", this.Id, buff.cfgid, eff_param.Params[0], this.buff_add_a_speed)
		}
	case BUFF_EFFECT_SUB_MOVE_SPEED:
		{
			if len(eff_param.Params) < 1 {
				log.Error("Npc[%d] DoBuffOnEffect[%d] sub MoveSpeed param error !", this.Id, buff.cfgid)
				return
			}

			this.buff_sub_m_speed = this.buff_sub_m_speed + eff_param.Params[0]
			log.Trace("npc[%d] DoBuffOnEffect buff[%d]减移动速度[%d] cur_val[%d]", this.Id, buff.cfgid, eff_param.Params[0], this.buff_sub_m_speed)
		}
	case BUFF_EFFECT_SUB_ATTACK_SPEED:
		{
			if len(eff_param.Params) < 1 {
				log.Error("Npc[%d] DoBuffOnEffect[%d] sub attack speed param error !", this.Id, buff.cfgid)
				return
			}

			this.buff_sub_a_speed = this.buff_sub_a_speed + eff_param.Params[0]
			log.Trace("npc[%d] DoBuffOnEffect buff[%d]减攻击速度[%d] cur_val[%d]", this.Id, buff.cfgid, eff_param.Params[0], this.buff_sub_a_speed)
		}
	case BUFF_EFFECT_FORWARD:
		{
			if len(eff_param.Params) < 2 {
				log.Error("Npc[%d] DoBuffOnEffect[%d] forward param error !", this.Id, buff.cfgid)
				return
			}

			if this.isforward <= 0 {
				this.isforward = 1
				this.forwarddmgadd = eff_param.Params[0]
				this.forwardspeed = eff_param.Params[1]
			}

			log.Trace("npc[%d] DoBuffOnEffect buff[%d]冲锋 attack[%d] speed[%d]", this.Id, buff.cfgid, eff_param.Params[0], eff_param.Params[1])
		}
	case BUFF_EFFECT_CAST_WHEN_BLOCK:
		{
			//log.Error("Npc[%d] DoBuffOnEffect[%d] 未实现！！！", this.Id, buff.cfgid)
		}
	case BUFF_EFFECT_FREEZE:
		{
			this.isfreeze = 1
			log.Trace("npc[%d] DoBuffOnEffect buff[%d] 冰冻", this.Id, buff.cfgid)
		}
	case BUFF_EFFECT_DIZZY:
		{
			this.isdizzy = 1
			log.Info("npc[%d] DoBuffOnEffect buff[%d] 眩晕", this.Id, buff.cfgid)
		}
	case BUFF_EFFECT_AURA:
		{
			if len(eff_param.Params) < 3 {
				log.Error("Npc[%d] DoBuffOnEffect[%d] BUFF_EFFECT_AURA param error !", this.Id, buff.cfgid)
				return
			}
			buff.sub_dis2 = float32(eff_param.Params[1]*eff_param.Params[1]) / 4
			buff.effect_npcs = make(map[int32]int32)
		}
	default:
		//log.Error("Npc[%d] DoBuffOnEffect[%d] buff 效果值[%d]错误", this.Id, buff.cfgid, eff_param.EffectType)
	}
}

func (this *Npc) DoBuffOffEffect(room *FightRoom, buff *NpcBuff, eff_param *EffectModeParam) {
	switch eff_param.EffectType {
	case BUFF_EFFECT_DEATH_CAST:
		{
			break
		}
	case BUFF_EFFECT_ADD_MOVE_SPEED:
		{
			if len(eff_param.Params) < 1 {
				log.Error("Npc[%d] DoBuffOffEffect[%d] BUFF_EFFECT_ADD_MOVE_SPEED param error !", this.Id, buff.cfgid)
				return
			}

			this.buff_add_m_speed = this.buff_add_m_speed - eff_param.Params[0]
			log.Trace("npc[%d] DoBuffOffEffect [%d]加移动速[%d] cur_buff_m_speed[%d]", this.Id, buff.cfgid, eff_param.Params[0], this.buff_add_m_speed)
		}
	case BUFF_EFFECT_ADD_ATTACK_SPEED:
		{
			if len(eff_param.Params) < 1 {
				log.Error("Npc[%d] DoBuffOffEffect[%d] Add AttackSpeed param error !", this.Id, buff.cfgid)
				return
			}

			this.buff_add_a_speed = this.buff_add_a_speed - eff_param.Params[0]
			log.Trace("npc[%d] DoBuffOffEffect[%d]加攻击速[%d] cur_buff_a_speed", this.Id, buff.cfgid, eff_param.Params[0], this.buff_add_a_speed)
		}
	case BUFF_EFFECT_SUB_MOVE_SPEED:
		{
			if len(eff_param.Params) < 1 {
				log.Error("Npc[%d] DoBuffOffEffect[%d] sub MoveSpeed param error !", this.Id, buff.cfgid)
				return
			}

			this.buff_sub_m_speed = this.buff_sub_m_speed - eff_param.Params[0]

			log.Info("npc[%d] DoBuffOffEffect[%d]减移动速度[%d] buff_sub_m_speed[%d]", this.Id, buff.cfgid, eff_param.Params[0], this.buff_sub_m_speed)
		}
	case BUFF_EFFECT_SUB_ATTACK_SPEED:
		{
			if len(eff_param.Params) < 1 {
				log.Error("Npc[%d] DoBuffOffEffect[%d] sub attack speed param error !", this.Id, buff.cfgid)
				return
			}

			this.buff_sub_a_speed = this.buff_sub_a_speed - eff_param.Params[0]
			log.Trace("npc[%d] DoBuffOffEffect[%d]减攻击速度[%d] cur_buff_a_speed", this.Id, buff.cfgid, eff_param.Params[0], this.buff_sub_a_speed)
		}
	case BUFF_EFFECT_FORWARD:
		{
			if 2 == this.isforward {
				this.isforward = 1
			} else if 1 == this.isforward {
				this.isforward = 0
				this.forwarddmgadd = 0
				this.forwardspeed = 0
			}

			this.RemvoeBuff(room, global_config.FowardBuffCfgId, false)
			log.Trace("npc[%d] DoBuffOffEffect[%d]冲锋 ", this.Id, buff.cfgid)
		}
	case BUFF_EFFECT_CAST_WHEN_BLOCK:
		{
			log.Error("Npc[%d] DoBuffOffEffect[%d] 未实现！！！", this.Id, buff.cfgid)
		}
	case BUFF_EFFECT_FREEZE:
		{
			this.isfreeze = 0
			log.Trace("npc[%d] DoBuffOffEffect[%d]冰冻 ", this.Id, buff.cfgid)
		}
	case BUFF_EFFECT_DIZZY:
		{
			this.isdizzy = 0
			log.Info("npc[%d] DoBuffOffEffect[%d]眩晕 ", this.Id, buff.cfgid)
		}
	}
}

func (this *Npc) _do_buff_check(room *FightRoom, buff *NpcBuff, eff *EffectModeParam) {
	switch eff.EffectType {
	case BUFF_EFFECT_CIRCLE_SKILL:
		{
			if len(eff.Params) < 3 {
				log.Error("Npc _do_buff_check param error !")
				return
			}

			if buff.cur_act_nsec <= 0 {
				log.Info("Buff第一次生效 ！！！")
				buff.cur_act_nsec = time.Now().UnixNano()
			} else {
				if time.Now().UnixNano()-buff.cur_act_nsec < int64(eff.Params[1])*1000000 {
					return
				}
			}

			buff.cur_act_nsec = time.Now().UnixNano()

			this.DirectCastSkill(room, eff.Params[0], this.Id, this.x, this.y)

			log.Info("Npc[%d] buff释放循环技能[%d]", this.Id, eff.Params[0])
		}
	case BUFF_EFFECT_AURA:
		{
			if len(eff.Params) < 3 {
				log.Error("Npc[%d] _do_buff_check[%d] BUFF_EFFECT_AURA param error !", this.Id, buff.cfgid)
				return
			}

			if nil == buff.effect_npcs {
				log.Error("Npc[%d] _do_buff_check[%d] BUFF_EFFECT_AURA map nil !", this.Id, buff.cfgid)
				return
			}

			var tmp_npc *Npc
			tmp_dis2 := float32(0.0)
			remove_npcs := make(map[int32]bool)

			for npc_id, _ := range buff.effect_npcs {
				tmp_npc = room.id2npc[npc_id]
				if nil == tmp_npc {
					remove_npcs[npc_id] = true
					continue
				}

				if BUFF_AURA_EFFECT_ENEMY == eff.Params[2] && tmp_npc.player_side == this.player_side {
					continue
				}

				if BUFF_AURA_EFFECT_FRIEND == eff.Params[2] && tmp_npc.player_side != this.player_side {
					continue
				}

				tmp_dis2 = (tmp_npc.x-this.x)*(tmp_npc.x-this.x) + (tmp_npc.y-this.y)*(tmp_npc.y-this.y)
				if tmp_dis2 > buff.sub_dis2 {
					remove_npcs[npc_id] = true
					tmp_npc.RemvoeBuff(room, eff.Params[0], true)
				}
			}

			for npc_id, _ := range remove_npcs {
				delete(buff.effect_npcs, npc_id)
			}

			for _, tmp_npc = range room.id2npc {
				if nil == tmp_npc {
					continue
				}

				if 1 == buff.effect_npcs[tmp_npc.Id] {
					continue
				}

				tmp_dis2 = (tmp_npc.x-this.x)*(tmp_npc.x-this.x) + (tmp_npc.y-this.y)*(tmp_npc.y-this.y)
				if tmp_dis2 > buff.sub_dis2 {
					continue
				}

				buff.effect_npcs[tmp_npc.Id] = 1
				tmp_npc.AddBuff(room, eff.Params[0], MAX_BUFF_LAST_NSEC)
			}
		}
	}
}

func (this *Npc) _buff_death_check(room *FightRoom) {
	if nil == room {
		log.Error("Npc _buff_check param error !")
		return
	}

	if len(this.id2buff) < 1 {
		return
	}

	overbuf := make(map[int32]*NpcBuff)
	for buffid, tmp_buff := range this.id2buff {
		if nil == tmp_buff {
			overbuf[buffid] = tmp_buff
			continue
		}

		if nil != tmp_buff.buff_cfg.EffectInfos1 {
			this._do_buff_death_check(room, tmp_buff, tmp_buff.buff_cfg.EffectInfos1)
		}

		if nil != tmp_buff.buff_cfg.EffectInfos2 {
			this._do_buff_death_check(room, tmp_buff, tmp_buff.buff_cfg.EffectInfos2)
		}

		if nil != tmp_buff.buff_cfg.EffectInfos3 {
			this._do_buff_death_check(room, tmp_buff, tmp_buff.buff_cfg.EffectInfos3)
		}
	}
}

func (this *Npc) _do_buff_death_check(room *FightRoom, buff *NpcBuff, eff *EffectModeParam) {
	switch eff.EffectType {
	case BUFF_EFFECT_DEATH_CAST:
		{
			if len(eff.Params) < 1 {
				log.Error("Npc _do_buff_death_check param error !")
				return
			}

			this.DirectCastSkill(room, eff.Params[0], this.Id, this.x, this.y)
		}
	}
}
