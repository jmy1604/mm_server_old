package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"strconv"
	"strings"
)

type EffectModeParam struct {
	EffectType int32   // 技能效果类型
	Params     []int32 // 技能效果参数
}

type EffectLastParam struct {
	LastType int32   // 持续类型
	Params   []int32 // 持续类型参数
}

type EffectRangeParam struct {
	RangeType int32   // 技能目标区域类型
	Params    []int32 // 技能目标区域参数
}

type XmlSkill struct {
	SkillId         int32   `xml:"SkillID,attr"`
	TargetType      int32   `xml:"TargetType,attr"`
	TargetStrategy  int32   `xml:"TargetStrategy,attr"`
	SkillRange      float32 `xml:"SkillRange,attr"`
	DamageDelay     int32   `xml:"DamageDelay,attr"`
	DamageSpan      int32   `xml:"DamageSpan,attr"`
	FlySpeed        int32   `xml:"FlySpeed,attr"`
	EffectType      string  `xml:"EffectType,attr"`
	EffectRange     string  `xml:"EffectRange,attr"`
	EffectModel1    string  `xml:"EffectModel1,attr"`
	EffectModel2    string  `xml:"EffectModel2,attr"`
	EffectModel3    string  `xml:"EffectModel3,attr"`
	EffectLParam    *EffectLastParam
	EffectRParam    *EffectRangeParam
	EffectInfos1    *EffectModeParam
	EffectInfos2    *EffectModeParam
	EffectInfos3    *EffectModeParam
	DamageDelayNSec int64
	DamageSpanNSec  int64
}

type XmlSkillConfig struct {
	Skills []XmlSkill `xml:"item"`
}

type SkillConfigMgr struct {
	Array []*XmlSkill
	Map   map[int32]*XmlSkill
}

var cfg_skill_mgr SkillConfigMgr

func (this *SkillConfigMgr) Init() bool {
	if !this.Load() {
		return false
	}
	return true
}

func (this *SkillConfigMgr) Load() bool {
	content, err := ioutil.ReadFile("../game_data/SkillConfig.xml")
	if nil != err {
		log.Error("SkillConfigMgr load ReadFile error(%s) !", err.Error())
		return false
	}

	xmlskillcfg := &XmlSkillConfig{}
	err = xml.Unmarshal(content, &xmlskillcfg)
	if nil != err {
		log.Error("SkillConfigMgr load Unmarshal failed error(%s) !", err.Error())
		return false
	}

	this.Array = make([]*XmlSkill, 0, len(xmlskillcfg.Skills))
	this.Map = make(map[int32]*XmlSkill)
	var tmp_skill *XmlSkill
	int_val := int(0)
	for _, val := range xmlskillcfg.Skills {
		tmp_skill = &XmlSkill{}
		*tmp_skill = val

		if "" != tmp_skill.EffectType {
			str_vals := strings.Split(tmp_skill.EffectType, "|")
			len_vals := int32(len(str_vals))
			if len_vals > 0 {
				lastinfo := &EffectLastParam{}
				int_val, err = strconv.Atoi(str_vals[0])
				if nil != err {
					log.Error("SkillConfigMgr EffectType(%s) 配置错误(%s)不能转化出类型", tmp_skill.EffectType, err.Error())
					return false
				} else {
					lastinfo.LastType = int32(int_val)
				}
				if len_vals > 1 {
					lastinfo.Params = make([]int32, len_vals-1)
					for i := int32(1); i < len_vals; i++ {
						int_val, err = strconv.Atoi(str_vals[i])
						if nil != err {
							log.Error("SkillConfigMgr EffectType(%s) 配置错误(%s)参数错误", tmp_skill.EffectType, err.Error())
							return false
						} else {
							lastinfo.Params[i-1] = int32(int_val)
						}
					}
				}
				tmp_skill.EffectLParam = lastinfo
			} else {
				log.Error("SkillConfigMgr EffectType(%s) 配置错误", tmp_skill.EffectType)
				return true
			}
		} else {
			tmp_skill.EffectLParam = &EffectLastParam{}
			tmp_skill.EffectLParam.LastType = 1
		}

		if "" != tmp_skill.EffectRange {
			str_vals := strings.Split(tmp_skill.EffectRange, "|")
			len_vals := int32(len(str_vals))
			if len_vals > 0 {
				rangeinfo := &EffectRangeParam{}
				int_val, err = strconv.Atoi(str_vals[0])
				if nil != err {
					log.Error("SkillConfigMgr EffectRange(%s) 配置错误(%s)不能转化出类型", tmp_skill.EffectRange, err.Error())
					return false
				} else {
					rangeinfo.RangeType = int32(int_val)
				}
				if len_vals > 1 {
					rangeinfo.Params = make([]int32, len_vals-1)
					for i := int32(1); i < len_vals; i++ {
						int_val, err = strconv.Atoi(str_vals[i])
						if nil != err {
							log.Error("SkillConfigMgr EffectRange(%s) 配置错误(%s)参数错误", tmp_skill.EffectRange, err.Error())
							return false
						} else {
							rangeinfo.Params[i-1] = int32(int_val)
						}
					}
				}
				tmp_skill.EffectRParam = rangeinfo
			} else {
				log.Error("SkillConfigMgr EffectRange(%s) 配置错误", tmp_skill.EffectRange)
				return false
			}
		} else {
			tmp_skill.EffectRParam = &EffectRangeParam{}
			tmp_skill.EffectRParam.RangeType = 1
		}

		if "" != tmp_skill.EffectModel1 {
			str_vals := strings.Split(tmp_skill.EffectModel1, "|")
			len_vals := int32(len(str_vals))
			if len_vals > 0 {
				effectinfo := &EffectModeParam{}
				int_val, err = strconv.Atoi(str_vals[0])
				if nil != err {
					log.Error("SkillConfigMgr effectmodel1(%s) 配置错误(%s)不能转化出类型", tmp_skill.EffectModel1, err.Error())
					return false
				} else {
					effectinfo.EffectType = int32(int_val)
				}

				if len_vals > 1 {
					effectinfo.Params = make([]int32, len_vals-1)
					for i := int32(1); i < len_vals; i++ {
						int_val, err = strconv.Atoi(str_vals[i])
						if nil != err {
							log.Error("SkillConfigMgr effectmodel1(%s) 配置错误(%s)参数错误", tmp_skill.EffectModel1, err.Error())
							return false
						} else {
							effectinfo.Params[i-1] = int32(int_val)
						}
					}
				}
				tmp_skill.EffectInfos1 = effectinfo
			} else {
				log.Error("SkillConfigMgr effectmodel1(%s) 配置错误", tmp_skill.EffectModel1)
				return false
			}
		}

		if "" != tmp_skill.EffectModel2 {
			str_vals := strings.Split(tmp_skill.EffectModel2, "|")
			len_vals := int32(len(str_vals))
			if len_vals > 0 {
				effectinfo := &EffectModeParam{}
				int_val, err = strconv.Atoi(str_vals[0])
				if nil != err {
					log.Error("SkillConfigMgr effectmodel2(%s) 配置错误(%s)不能转化出类型", tmp_skill.EffectModel2, err.Error())
					return false
				} else {
					effectinfo.EffectType = int32(int_val)
				}
				if len_vals > 1 {
					effectinfo.Params = make([]int32, len_vals-1)
					for i := int32(1); i < len_vals; i++ {
						int_val, err = strconv.Atoi(str_vals[i])
						if nil != err {
							log.Error("SkillConfigMgr effectmodel2(%s) 配置错误(%s)参数错误", tmp_skill.EffectModel2, err.Error())
							return false
						} else {
							effectinfo.Params[i-1] = int32(int_val)
						}
					}
				}
				tmp_skill.EffectInfos2 = effectinfo
			} else {
				log.Error("SkillConfigMgr effectmodel2(%s) 配置错误", tmp_skill.EffectModel2)
				return false
			}
		}

		if "" != tmp_skill.EffectModel3 {
			str_vals := strings.Split(tmp_skill.EffectModel3, "|")
			len_vals := int32(len(str_vals))
			if len_vals > 0 {
				effectinfo := &EffectModeParam{}
				int_val, err = strconv.Atoi(str_vals[0])
				if nil != err {
					log.Error("SkillConfigMgr effectmodel3(%s) 配置错误(%s)不能转化出类型", tmp_skill.EffectModel3, err.Error())
					return false
				} else {
					effectinfo.EffectType = int32(int_val)
				}
				if len_vals > 1 {
					effectinfo.Params = make([]int32, len_vals-1)
					for i := int32(1); i < len_vals; i++ {
						int_val, err = strconv.Atoi(str_vals[i])
						if nil != err {
							log.Error("SkillConfigMgr effectmodel3(%s) 配置错误(%s)参数错误", tmp_skill.EffectModel3, err.Error())
							return false
						} else {
							effectinfo.Params[i-1] = int32(int_val)
						}
					}
				}
				tmp_skill.EffectInfos3 = effectinfo
			} else {
				log.Error("SkillConfigMgr effectmodel3(%s) 配置错误", tmp_skill.EffectModel3)
				return false
			}
		}

		tmp_skill.DamageDelayNSec = int64(tmp_skill.DamageDelay) * 1000000
		tmp_skill.DamageSpanNSec = int64(tmp_skill.DamageSpan) * 1000000

		this.Array = append(this.Array, tmp_skill)
		this.Map[tmp_skill.SkillId] = tmp_skill
	}

	log.Info("206101111   %v", this.Map, this.Map[206101])

	return true
}
