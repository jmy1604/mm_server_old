package main

import (
	"libs/log"
	"libs/server_conn"
	"libs/timer"
	"public_message/gen_go/server_message"
	"sync/atomic"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	MATCH_CONN_STATE_DISCONNECT  = 0
	MATCH_CONN_STATE_CONNECTED   = 1
	MATCH_CONN_STATE_FORCE_CLOSE = 2
)

type MatchConnection struct {
	client_node    *server_conn.Node
	state          int32
	last_conn_time int32
}

var match_conn MatchConnection

func (this *MatchConnection) Init() bool {
	this.client_node = server_conn.NewNode(this, 0, 0, 100, 0, 0, 0, 0, 0)
	this.client_node.SetDesc("匹配服务器", "")
	this.state = MATCH_CONN_STATE_DISCONNECT
	this.RegisterMsgHandler()

	return true
}

func (this *MatchConnection) Start() {
	if this.Connect(MATCH_CONN_STATE_DISCONNECT) {
		log.Event("连接MatchServer成功 ", nil, log.Property{"IP", config.MatchServerIP}, log.Property{"this.state", this.state})
	}

	for MATCH_CONN_STATE_FORCE_CLOSE != this.state {
		state := atomic.LoadInt32(&this.state)
		if state == MATCH_CONN_STATE_CONNECTED {
			time.Sleep(time.Second * 2)
			continue
		}

		if state == MATCH_CONN_STATE_FORCE_CLOSE {
			this.client_node.ClientDisconnect()
			log.Event("与MatchServer的连接被强制关闭", nil)
			break
		}
		if this.Connect(state) {
			log.Event("连接MatchServer成功", nil, log.Property{"IP", config.MatchServerIP})
		}
	}
}

func (this *MatchConnection) Connect(state int32) (ok bool) {
	if MATCH_CONN_STATE_DISCONNECT == state {
		var err error
		for MATCH_CONN_STATE_FORCE_CLOSE != this.state {
			log.Trace("连接MatchServer %v", config.MatchServerIP)
			err = this.client_node.ClientConnect(config.MatchServerIP, time.Second*10)
			if nil == err {
				break
			}

			// 每隔30秒输出一次连接信息
			now := time.Now().Unix()
			if int32(now)-this.last_conn_time >= 30 {
				log.Trace("MatchServer连接中...")
				this.last_conn_time = int32(now)
			}
			time.Sleep(time.Second * 5)
		}
	}

	if MATCH_CONN_STATE_FORCE_CLOSE != this.state && atomic.CompareAndSwapInt32(&this.state, state, MATCH_CONN_STATE_CONNECTED) {
		go this.client_node.ClientRun()
		ok = true
	}
	return
}

func (this *MatchConnection) OnAccept(c *server_conn.ServerConn) {
	log.Error("Impossible accept")
}

func (this *MatchConnection) OnConnect(c *server_conn.ServerConn) {
	if MATCH_CONN_STATE_FORCE_CLOSE != this.state {
		log.Trace("MatchServer[%v][%v] on CenterServer connect", config.ServerId, config.ServerName, config.ListenClientInIP)

		notify := &msg_server_message.R2MRoomServerRegister{}
		notify.ServerId = proto.Int32(config.ServerId)
		notify.ServerName = proto.String(config.ServerName)
		notify.ListenClientIP = proto.String(config.ListenClientOutIP)
		c.Send(notify, true)
	} else {
		log.Trace("MatchServer[%v][%v] force close on CenterServer connect", config.ServerId, config.ServerName, config.ListenClientInIP)
	}

}

func (this *MatchConnection) OnUpdate(c *server_conn.ServerConn, t timer.TickTime) {

}

func (this *MatchConnection) OnDisconnect(c *server_conn.ServerConn, reason server_conn.E_DISCONNECT_REASON) {
	if reason == server_conn.E_DISCONNECT_REASON_FORCE_CLOSED {
		this.state = MATCH_CONN_STATE_FORCE_CLOSE
	} else {
		this.state = MATCH_CONN_STATE_DISCONNECT
	}
	log.Event("与MatchServer连接断开", nil)
}

func (this *MatchConnection) ShutDown() {
	log.Info("MatchConnection ShutDown !!")

	this.state = MATCH_CONN_STATE_FORCE_CLOSE
	if nil != this.client_node {
		this.client_node.Shutdown()
	}
}

func (this *MatchConnection) set_ih(type_id uint16, h server_conn.Handler) {
	t := msg_server_message.MessageTypes[type_id]
	if t == nil {
		log.Error("设置消息句柄失败，不存在的消息类型 %v", type_id)
		return
	}

	this.client_node.SetHandler(type_id, t, h)
}

type MatchMessageHandler func(a *MatchConnection, m proto.Message)

func (this *MatchConnection) SetMessageHandler(type_id uint16, h MatchMessageHandler) {
	if h == nil {
		this.set_ih(type_id, nil)
		return
	}

	this.set_ih(type_id, func(c *server_conn.ServerConn, m proto.Message) {
		h(this, m)
	})
}

func (this *MatchConnection) Send(msg proto.Message) {
	if MATCH_CONN_STATE_CONNECTED != this.state {
		log.Info("AssistServer未连接!!!")
		return
	}
	if nil == this.client_node {
		return
	}
	this.client_node.GetClient().Send(msg, false)
}

//========================================================================

func (this *MatchConnection) RegisterMsgHandler() {
	//this.SetMessageHandler(msg_youma.ID_MsgA2LGameServerListNotify, handle_game_server_list)
}
