package main

const (
	NORMAL_BTM_KING_NPC_ID  = 1
	NORMAL_BTM_PRINESS_L_ID = 2
	NORMAL_BTM_PRINESS_R_ID = 3
	NORMAL_P2_KING_NPC_ID   = 4
	NORMAL_P2_PRINESS_L_ID  = 5
	NORMAL_P2_PRINESS_R_ID  = 6
)

type FightRoomNpcDeathIF interface {
	on_npc_dead(room *FightRoom, npc_id int32)
}
