package main

import (
	"libs/log"
	"math"
	"public_message/gen_go/client_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	TARGET_STRATEGY_BUILDING = 1 // 只有建筑
	TARGET_STRATEGY_GROUND   = 2 // 地面单位 包含建筑
	TARGET_STRATEGY_ALL      = 3 // 所有单位
	TARGET_STRATEGY_SELF_DO  = 4 // 被动技能

	NPC_MAX_SKILL_COUNT = 4 // NPC最多4个技能

	NPC_JUMP_DIS = 2
)

// 循环释放的技能
type LoopingSkill struct {
	cfgid      int32     // 技能Id
	skill_cfg  *XmlSkill // 技能配置
	cast_nsec  int64     // 技能当前开始时间 单位 纳秒
	is_cooling int32     // 是否已经过了前摇
}

type DamageObj struct {
	tgt_npc *Npc    // 如果为空，表示定点坐标
	tgt_x   float32 // 定点的X坐标
	tgt_y   float32 // 定点的Y坐标
}

type Npc struct {
	Id      int32 // npc唯一Id
	cfgid   int32 // npc配置Id
	npctype int32 // npc类型
	cardid  int32 // npc对应的卡片Id
	npc_lvl int32 // npc等级

	load_end_nsec int64

	curhp int32 // 当前血量
	def   int32 // 当前护盾
	dmg   int32 // 基础伤害

	dead_about_npcs []int32 // 死亡之后唤醒/击杀的NPCId

	player_side int32 // 属于哪一方
	player_idx  int32 // 玩家序号

	move_check_frame int32
	ai_check_frame   int32
	stop_frame       int32
	cur_move_dis     float32
	path_points      *A_PATH_POINT // 当前移动路径点
	cur_target       *Npc          // 当前目标
	blast_path       bool          // 上一次是否用的A*
	last_def_tgx     float32       // 上一次默认目标x
	last_def_tgy     float32       // 上一次默认目标y
	last_path_x      float32       // 上一次寻路用的目标点x
	last_path_y      float32       // 上一次寻路用的目标点y
	def_move_action  int32         // 当前默认移动
	x                float32       // npc x 坐标
	y                float32       // npc y 坐标
	push_x           float32       // 被推到的x坐标
	push_y           float32       // 被推到的y坐标
	searchradius     float32       // 搜索敌人的半径
	targetstrategy   int32         // 搜索敌人策略
	attackradius     float32       // 攻击半径
	hitradius        float32       // 碰撞半径
	buidradius       float32       // 建造半径
	speed            float32       // 像素每秒
	isfly            int32         // 是否飞行单位

	cur_tgt_atk_count int32 // 当前目标攻击次数

	x_move_adjust float32 // 移动的X平移

	b_near_y_base bool

	loopskills []*LoopingSkill    // npc拥有技能表（不包含buff技能,包含技能当前状态，在哪个阶段，起始时间等等)
	id2buff    map[int32]*NpcBuff // npc拥有buff表

	buff_add_m_speed int32 // buff增加的移动速度比（万分比）
	buff_sub_m_speed int32 // buff减少的移动速度比（万分比）
	buff_add_a_speed int32 // buff增加的攻击速度比（万分比）
	buff_sub_a_speed int32 // buff极少的攻击速度比（万分比）

	cur_c_move_nsec int64 // 当前累计移动纳秒
	isforward       uint8 // 是否冲锋
	forwarddmgadd   int32 // 冲锋伤害加成(万分比)
	forwardspeed    int32 // 冲锋速度加成(万分比）

	isjump      uint8 // 是否能跳河道
	isfreeze    uint8 // 是否冰冻
	isdizzy     uint8 // 是否眩晕
	isattacking bool  // 是否在攻击敌人中
}

func NewNpc(npcid int32, npc_cfg *ConfigNpc, x, y float32, npctype, player_side, player_idx, npc_lvl int32) (ret_npc *Npc) {
	ret_npc = &Npc{}
	ret_npc.Id = npcid
	ret_npc.cfgid = npc_cfg.ConfigId
	ret_npc.npctype = npctype
	ret_npc.npc_lvl = npc_lvl

	ret_npc.curhp = npc_cfg.HP
	ret_npc.def = npc_cfg.DEF
	ret_npc.x = x
	ret_npc.y = y

	ret_npc.speed = npc_cfg.MSpeed
	ret_npc.isfly = npc_cfg.IsFly
	ret_npc.searchradius = npc_cfg.SearchRange
	ret_npc.buidradius = npc_cfg.PlaceSize
	ret_npc.hitradius = npc_cfg.Radius
	ret_npc.player_side = player_side
	ret_npc.player_idx = player_idx
	ret_npc.id2buff = make(map[int32]*NpcBuff, 6)
	ret_npc.loopskills = make([]*LoopingSkill, 0, NPC_MAX_SKILL_COUNT)
	ret_npc.cardid = npc_cfg.ConfigId / 100

	log.Info("New Npc dmg [%d]", ret_npc.dmg)
	return
}

func (this *Npc) LoadSkill(room *FightRoom, skillid, skilllvl int32) {
	skill_cfg := cfg_skill_mgr.Map[skillid]
	if nil == skill_cfg {
		log.Error("Npc LoadSkill param error !")
		return
	}

	var tmp_effect *SkillEffect
	switch skill_cfg.TargetStrategy {
	case TARGET_STRATEGY_SELF_DO:
		{
			log.Info("被动技能直接对自己释放[%d]", this.Id)
			if nil != skill_cfg.EffectInfos1 {
				tmp_effect = NewSkillEffect(this, this.Id, this.x, this.y,
					skillid, skilllvl, skill_cfg, skill_cfg.EffectInfos1)
				if !tmp_effect.DoEffect(room) {
					room.add_skill_effect(tmp_effect)
				}
			}
			if nil != skill_cfg.EffectInfos2 {
				tmp_effect = NewSkillEffect(this, this.Id, this.x, this.y,
					skillid, skilllvl, skill_cfg, skill_cfg.EffectInfos2)
				if !tmp_effect.DoEffect(room) {
					room.add_skill_effect(tmp_effect)
				}
			}
			if nil != skill_cfg.EffectInfos3 {
				tmp_effect = NewSkillEffect(this, this.Id, this.x, this.y,
					skillid, skilllvl, skill_cfg, skill_cfg.EffectInfos3)
				if !tmp_effect.DoEffect(room) {
					room.add_skill_effect(tmp_effect)
				}
			}
		}
	default:
		tmp_loop_skill := &LoopingSkill{}
		tmp_loop_skill.cast_nsec = 0
		tmp_loop_skill.cfgid = skill_cfg.SkillId
		tmp_loop_skill.skill_cfg = skill_cfg
		this.loopskills = append(this.loopskills, tmp_loop_skill)
	}
}

func (this *Npc) DirectCastSkill(room *FightRoom, skillid, tgt_id int32, tgt_x, tgt_y float32) {
	skill_cfg := cfg_skill_mgr.Map[skillid]
	if nil == skill_cfg {
		log.Error("Npc DirectCastSkill[%d] not found !", skillid)
		return
	}

	ext_nsec := int64(0)
	if skill_cfg.FlySpeed > 0 {
		cur_dis := float32(math.Sqrt(float64((tgt_x-this.x)*(tgt_x-this.x) + (tgt_y-this.y)*(tgt_y-this.y))))
		ext_nsec = int64(float64(cur_dis/float32(skill_cfg.FlySpeed)) * 1000000000)
	}

	var tmp_effect *SkillEffect
	if nil != skill_cfg.EffectInfos1 {
		tmp_effect = NewSkillEffect(this, tgt_id, tgt_x, tgt_y,
			skillid, this.npc_lvl, skill_cfg, skill_cfg.EffectInfos1)

		if skill_cfg.DamageDelayNSec > 0 || ext_nsec > 0 {
			tmp_effect.active_nsec = time.Now().UnixNano() + skill_cfg.DamageDelayNSec + ext_nsec
			room.add_skill_effect(tmp_effect)
		} else {
			if !tmp_effect.DoEffect(room) {
				room.add_skill_effect(tmp_effect)
			}
		}
	}
	if nil != skill_cfg.EffectInfos2 {
		tmp_effect = NewSkillEffect(this, tgt_id, tgt_x, tgt_y,
			skillid, this.npc_lvl, skill_cfg, skill_cfg.EffectInfos2)

		if skill_cfg.DamageDelayNSec > 0 || ext_nsec > 0 {
			tmp_effect.active_nsec = time.Now().UnixNano() + skill_cfg.DamageDelayNSec + ext_nsec
			room.add_skill_effect(tmp_effect)
		} else {
			if !tmp_effect.DoEffect(room) {
				room.add_skill_effect(tmp_effect)
			}
		}
	}
	if nil != skill_cfg.EffectInfos3 {
		tmp_effect = NewSkillEffect(this, tgt_id, tgt_x, tgt_y,
			skillid, this.npc_lvl, skill_cfg, skill_cfg.EffectInfos3)

		if skill_cfg.DamageDelayNSec > 0 || ext_nsec > 0 {
			tmp_effect.active_nsec = time.Now().UnixNano() + skill_cfg.DamageDelayNSec + ext_nsec
			room.add_skill_effect(tmp_effect)
		} else {
			if !tmp_effect.DoEffect(room) {
				room.add_skill_effect(tmp_effect)
			}
		}
	}

	res_2cli := &msg_client_message.S2CCastSkill{}
	res_2cli.NpcId = proto.Int32(this.Id)
	res_2cli.SkillId = proto.Int32(skillid)
	if nil != this.cur_target {
		res_2cli.TgtId = proto.Int32(this.cur_target.Id)
		res_2cli.TgtX = proto.Float32(this.cur_target.x)
		res_2cli.TgtY = proto.Float32(this.cur_target.y)
	} else {
		res_2cli.TgtX = proto.Float32(tgt_x)
		res_2cli.TgtY = proto.Float32(tgt_y)
	}
	res_2cli.SelfX = proto.Float32(this.x)
	res_2cli.SelfY = proto.Float32(this.y)

	if skill_cfg.FlySpeed > 0 {
		res_2cli := &msg_client_message.S2CSkillEffect{}
		res_2cli.SkillId = proto.Int32(skillid)
		res_2cli.SrcNpcId = proto.Int32(this.Id)
		res_2cli.TgtNpcId = proto.Int32(-1)
		res_2cli.TgtX = proto.Float32(tgt_x)
		res_2cli.TgtY = proto.Float32(tgt_y)
		res_2cli.CardId = proto.Int32(this.cardid)
		room.SendToAll(res_2cli)
	}

	log.Info("直接释放技能===========  %v", res_2cli)
	room.SendToAll(res_2cli)
}

func (this *Npc) SkillCheck(room *FightRoom) {
	this.path_points = nil
	this.blast_path = false
	this.def_move_action = -1
	this.cur_c_move_nsec = 0
	this.cur_move_dis = 0
	this.isattacking = true

	if len(this.loopskills) < 1 {
		return
	}

	cur_nsec := time.Now().UnixNano()
	var skill_cfg *XmlSkill
	var skillid int32
	var tmp_effect *SkillEffect
	//log.Info("Npc[%d] 技能(个数%d)检查", this.Id, len(this.loopskills))
	for _, tmp_loop_skill := range this.loopskills {
		if nil == tmp_loop_skill {
			continue
		}

		skill_cfg = tmp_loop_skill.skill_cfg
		skillid = tmp_loop_skill.cfgid
		if SKILL_TARGET_SELF == skill_cfg.TargetType {
			if tmp_loop_skill.cast_nsec <= 0 {
				// 这里开始释放技能
				tmp_loop_skill.cast_nsec = time.Now().UnixNano()
				res_2cli := &msg_client_message.S2CCastSkill{}
				res_2cli.NpcId = proto.Int32(this.Id)
				res_2cli.SkillId = proto.Int32(skillid)
				res_2cli.TgtId = proto.Int32(this.Id)
				res_2cli.TgtX = proto.Float32(this.x)
				res_2cli.TgtY = proto.Float32(this.y)
				res_2cli.SelfX = proto.Float32(this.x)
				res_2cli.SelfY = proto.Float32(this.y)
				room.SendToAll(res_2cli)
			} else {
				if 0 == tmp_loop_skill.is_cooling && cur_nsec-tmp_loop_skill.cast_nsec >= skill_cfg.DamageDelayNSec { //
					tmp_loop_skill.is_cooling = 1
					// 由于目标是自己，效果不需要延迟触发
					if nil != skill_cfg.EffectInfos1 {
						tmp_effect = NewSkillEffect(this, this.Id, this.x, this.y,
							skillid, this.npc_lvl, skill_cfg, skill_cfg.EffectInfos1)
						if !tmp_effect.DoEffect(room) {
							room.add_skill_effect(tmp_effect)
						}
					}
					if nil != skill_cfg.EffectInfos2 {
						tmp_effect = NewSkillEffect(this, this.Id, this.x, this.y,
							skillid, this.npc_lvl, skill_cfg, skill_cfg.EffectInfos2)
						if !tmp_effect.DoEffect(room) {
							room.add_skill_effect(tmp_effect)
						}
					}
					if nil != skill_cfg.EffectInfos3 {
						tmp_effect = NewSkillEffect(this, this.Id, this.x, this.y,
							skillid, this.npc_lvl, skill_cfg, skill_cfg.EffectInfos3)
						if !tmp_effect.DoEffect(room) {
							room.add_skill_effect(tmp_effect)
						}
					}
				}

				if 1 == tmp_loop_skill.is_cooling && cur_nsec-tmp_loop_skill.cast_nsec >= skill_cfg.DamageSpanNSec*int64(10000-this.buff_add_a_speed+this.buff_sub_a_speed)/10000 {
					tmp_loop_skill.cast_nsec = 0
					tmp_loop_skill.is_cooling = 0
				}
			}
		} else if SKILL_TARGET_ENEMY == skill_cfg.TargetType {
			//log.Info("============================1")
			if nil == this.cur_target {
				//log.Info("============================2")
				continue
			}

			if TARGET_STRATEGY_BUILDING == skill_cfg.TargetStrategy && NPC_TYPE_BUILDING != this.cur_target.npctype {
				//log.Info("============================3")
				continue
			}

			if TARGET_STRATEGY_GROUND == skill_cfg.TargetStrategy && 1 == this.cur_target.isfly {
				//log.Info("============================4")
				continue
			}

			if !room.if_near(this.x-this.attackradius, this.y+this.attackradius, 2*this.attackradius, this.cur_target.x-this.cur_target.buidradius/2, this.cur_target.y+this.cur_target.buidradius/2, this.cur_target.buidradius) {
				//log.Info("============================5")
				continue
			}

			if tmp_loop_skill.cast_nsec <= 0 {
				// 这里开始释放技能
				log.Trace("npc[%d]对敌人读技能[%d] 需要纳秒%d, ", this.Id, tmp_loop_skill.cfgid, skill_cfg.DamageDelayNSec)
				tmp_loop_skill.cast_nsec = time.Now().UnixNano()
				res_2cli := &msg_client_message.S2CCastSkill{}
				res_2cli.NpcId = proto.Int32(this.Id)
				res_2cli.SkillId = proto.Int32(skillid)
				res_2cli.TgtId = proto.Int32(this.cur_target.Id)
				res_2cli.TgtX = proto.Float32(this.cur_target.x)
				res_2cli.TgtY = proto.Float32(this.cur_target.y)
				res_2cli.SelfX = proto.Float32(this.x)
				res_2cli.SelfY = proto.Float32(this.y)
				room.SendToAll(res_2cli)
			} else {
				if 0 == tmp_loop_skill.is_cooling && cur_nsec-tmp_loop_skill.cast_nsec >= skill_cfg.DamageDelayNSec { //
					tmp_loop_skill.is_cooling = 1
					log.Trace("npc[%d]对敌人读技能[%d]完毕 cur_nsec[%d] cast_nsec[%d] need[%d] sub_val[%d] is_forward[%d]", this.Id, tmp_loop_skill.cfgid, cur_nsec, tmp_loop_skill.cast_nsec, skill_cfg.DamageDelayNSec, cur_nsec-tmp_loop_skill.cast_nsec, this.isforward)
					if nil != skill_cfg.EffectInfos1 && skill_cfg.EffectInfos1.EffectType > 0 {
						for tmp_idx := int32(0); tmp_idx < 1; tmp_idx++ {
							if NPC_TYPE_BUILDING == this.cur_target.npctype && SKILL_EFFECT_TYPE_NORMAL_DAMAGE == skill_cfg.EffectInfos1.EffectType {
								continue
							}

							if NPC_TYPE_ARMY == this.cur_target.npctype && SKILL_EFFECT_TYPE_BUILDING_DAMAGE == skill_cfg.EffectInfos1.EffectType {
								continue
							}

							tmp_effect = NewSkillEffect(this, this.cur_target.Id, this.cur_target.x, this.cur_target.y,
								skillid, this.npc_lvl, skill_cfg, skill_cfg.EffectInfos1)

							if skill_cfg.FlySpeed <= 0 {
								if !tmp_effect.DoEffect(room) {
									room.add_skill_effect(tmp_effect)
								}
							} else {
								cur_dis := float32(math.Sqrt(float64((this.cur_target.x-this.x)*(this.cur_target.x-this.x) + (this.cur_target.y-this.y)*(this.cur_target.y-this.y))))
								tmp_effect.active_nsec = cur_nsec + int64(float64(cur_dis/float32(skill_cfg.FlySpeed))*1000000000)
								room.add_skill_effect(tmp_effect)
							}
						}
					}

					if nil != skill_cfg.EffectInfos2 && skill_cfg.EffectInfos2.EffectType > 0 {
						for tmp_idx := int32(0); tmp_idx < 1; tmp_idx++ {
							if NPC_TYPE_BUILDING == this.cur_target.npctype && SKILL_EFFECT_TYPE_NORMAL_DAMAGE == skill_cfg.EffectInfos2.EffectType {
								continue
							}

							if NPC_TYPE_ARMY == this.cur_target.npctype && SKILL_EFFECT_TYPE_BUILDING_DAMAGE == skill_cfg.EffectInfos2.EffectType {
								continue
							}

							tmp_effect = NewSkillEffect(this, this.cur_target.Id, this.cur_target.x, this.cur_target.y,
								skillid, this.npc_lvl, skill_cfg, skill_cfg.EffectInfos2)

							if skill_cfg.FlySpeed <= 0 {
								if !tmp_effect.DoEffect(room) {
									room.add_skill_effect(tmp_effect)
								}
							} else {
								cur_dis := float32(math.Sqrt(float64((this.cur_target.x-this.x)*(this.cur_target.x-this.x) + (this.cur_target.y-this.y)*(this.cur_target.y-this.y))))
								tmp_effect.active_nsec = cur_nsec + int64(float64(cur_dis/float32(skill_cfg.FlySpeed))*1000000000)
								room.add_skill_effect(tmp_effect)
							}
						}
					}

					if nil != skill_cfg.EffectInfos3 && skill_cfg.EffectInfos3.EffectType > 0 {
						for tmp_idx := int32(0); tmp_idx < 1; tmp_idx++ {
							if NPC_TYPE_BUILDING == this.cur_target.npctype && SKILL_EFFECT_TYPE_NORMAL_DAMAGE == skill_cfg.EffectInfos3.EffectType {
								continue
							}

							if NPC_TYPE_ARMY == this.cur_target.npctype && SKILL_EFFECT_TYPE_BUILDING_DAMAGE == skill_cfg.EffectInfos3.EffectType {
								continue
							}

							tmp_effect = NewSkillEffect(this, this.cur_target.Id, this.cur_target.x, this.cur_target.y,
								skillid, this.npc_lvl, skill_cfg, skill_cfg.EffectInfos3)

							if skill_cfg.FlySpeed <= 0 {
								if !tmp_effect.DoEffect(room) {
									room.add_skill_effect(tmp_effect)
								}
							} else {
								cur_dis := float32(math.Sqrt(float64((this.cur_target.x-this.x)*(this.cur_target.x-this.x) + (this.cur_target.y-this.y)*(this.cur_target.y-this.y))))
								tmp_effect.active_nsec = cur_nsec + int64(float64(cur_dis/float32(skill_cfg.FlySpeed))*1000000000)
								room.add_skill_effect(tmp_effect)
							}
						}
					}

					if 2 == this.isforward {
						this.isforward = 1
						this.RemvoeBuff(room, global_config.FowardBuffCfgId, false)
					}

					if skill_cfg.FlySpeed > 0 {
						res_2cli := &msg_client_message.S2CSkillEffect{}
						res_2cli.SkillId = proto.Int32(skillid)
						res_2cli.SrcNpcId = proto.Int32(this.Id)
						res_2cli.TgtNpcId = proto.Int32(this.cur_target.Id)
						res_2cli.TgtX = proto.Float32(this.cur_target.x)
						res_2cli.TgtY = proto.Float32(this.cur_target.y)
						res_2cli.CardId = proto.Int32(this.cardid)
						room.SendToAll(res_2cli)
					}
				}

				if 1 == tmp_loop_skill.is_cooling && cur_nsec-tmp_loop_skill.cast_nsec >= skill_cfg.DamageSpanNSec*int64(10000-this.buff_add_a_speed+this.buff_sub_a_speed)/10000 {
					log.Trace("npc[%d]对敌人冷却[%d]完毕 cur_nsec[%d] cast_nsec[%d] need[%d] sub_val[%d]", this.Id, tmp_loop_skill.cfgid, cur_nsec, tmp_loop_skill.cast_nsec, skill_cfg.DamageDelayNSec, cur_nsec-tmp_loop_skill.cast_nsec)
					tmp_loop_skill.cast_nsec = 0
					tmp_loop_skill.is_cooling = 0
				}
			}
		} else {
			log.Info("npc技能效果错误")
		}
	}
}

func (this *Npc) AddBuff(room *FightRoom, buffid int32, lastnsec int64) {
	cur_buff := this.id2buff[buffid]
	if nil != cur_buff {
		cur_buff.end_nsec = time.Now().UnixNano() + lastnsec
	} else {
		new_buff := NewNpcBuff(buffid, this.npc_lvl, lastnsec)
		if nil == new_buff {
			log.Error("Npc AddBuff %d %d failed !", buffid, lastnsec)
			return
		}
		this.id2buff[new_buff.cfgid] = new_buff
		this.OnBuffAdd(new_buff)

		res_2cli := &msg_client_message.S2CAddBuff{}
		res_2cli.BuffId = proto.Int32(buffid)
		res_2cli.NpcId = proto.Int32(this.Id)
		room.SendToAll(res_2cli)
	}

	log.Info("Npc[%d] AddBuff[%d] last_sec[%d]", this.Id, buffid, lastnsec)
}

func (this *Npc) RemvoeBuff(room *FightRoom, buffid int32, bdoff bool) {
	cur_buff := this.id2buff[buffid]
	if nil == cur_buff {
		return
	}

	res_2cli := &msg_client_message.S2CRemoveBuff{}
	res_2cli.BuffId = proto.Int32(buffid)
	res_2cli.NpcId = proto.Int32(this.Id)
	room.SendToAll(res_2cli)

	log.Trace("Npc[%d] RemoveBuff[%d]", this.Id, buffid)

	if bdoff {
		if nil != cur_buff.buff_cfg.EffectInfos1 {
			this.DoBuffOffEffect(room, cur_buff, cur_buff.buff_cfg.EffectInfos1)
		}
		if nil != cur_buff.buff_cfg.EffectInfos2 {
			this.DoBuffOffEffect(room, cur_buff, cur_buff.buff_cfg.EffectInfos2)
		}
		if nil != cur_buff.buff_cfg.EffectInfos3 {
			this.DoBuffOffEffect(room, cur_buff, cur_buff.buff_cfg.EffectInfos3)
		}
	}

	return
}

func (this *Npc) DoEnemySearch(room *FightRoom, TargetStrategy int32, blog bool) {
	if nil == room {
		log.Error("Npc DoEnemySearch param error !")
		return
	}

	if blog {
		log.Info("npc[%d]寻找敌人", this.Id, this.searchradius, this.player_side)
	}

	inleft := this.x - this.searchradius
	intop := this.y + this.searchradius
	min_des := float32(100000)
	for _, tmp_npc := range room.id2npc {
		if nil == tmp_npc || this.Id == tmp_npc.Id || this.player_side == tmp_npc.player_side {
			if blog {
				log.Info("敌人[%d]不满足要求 player_side %d %v", tmp_npc.Id, tmp_npc.player_side, this.searchradius)
			}
			continue
		}

		if NPC_TYPE_MAGIC == tmp_npc.npctype {
			continue
		}

		if TARGET_STRATEGY_BUILDING == TargetStrategy && NPC_TYPE_BUILDING != tmp_npc.npctype {
			if blog {
				log.Info("只打建筑 敌人[%d]不满足要求 player_side %d %v", tmp_npc.Id, tmp_npc.player_side, this.searchradius)
			}
			continue
		}

		if TARGET_STRATEGY_GROUND == TargetStrategy && 1 == tmp_npc.isfly {
			if blog {
				log.Info("只打地面 敌人[%d]不满足要求 player_side %d %v", tmp_npc.Id, tmp_npc.player_side, this.searchradius)
			}
			continue
		}

		if !room.if_near(tmp_npc.x-tmp_npc.buidradius/2, tmp_npc.y+tmp_npc.buidradius/2, tmp_npc.buidradius,
			inleft, intop, this.searchradius*2) {
			if blog {
				log.Info("敌人[%d,%f,%f] buildradius[%f] 太远了, 自己[%f,%f,%f]", tmp_npc.Id, tmp_npc.x, tmp_npc.y, tmp_npc.buidradius, this.searchradius, this.x, this.y)
			}
			//log.Info("hit npc(%d,%d) pos(x:%f,y:%f,r:%f)", npc.Id, npc.cfgid, npc.x, npc.y, npc.buidradius)
			continue
		} else {

		}
		/*
			if !if_area_hit(tmp_npc.x-tmp_npc.buidradius/2, tmp_npc.y+tmp_npc.buidradius/2, tmp_npc.buidradius, tmp_npc.buidradius,
				inleft, intop, this.searchradius*2, this.searchradius*2) {
				if blog {
					log.Info("敌人[%d,%f,%f] buildradius[%f] 太远了, 自己[%f,%f,%f]", tmp_npc.Id, tmp_npc.x, tmp_npc.y, tmp_npc.buidradius, this.searchradius, this.x, this.y)
				}
				//log.Info("hit npc(%d,%d) pos(x:%f,y:%f,r:%f)", npc.Id, npc.cfgid, npc.x, npc.y, npc.buidradius)
				continue
			} else {

			}
		*/

		new_dis := (tmp_npc.x-this.x)*(tmp_npc.x-this.x) + (tmp_npc.y-this.y)*(tmp_npc.y-this.y)
		if min_des > new_dis {
			this.cur_target = tmp_npc
			min_des = new_dis
		}
	}

	return
}

func (this *Npc) _do_fly_move(room *FightRoom, sec float32) {
	move_dis := this.speed * sec
	//log.Info("Npc(id:%d,x:%f,y:%f) _domove1 ", this.Id, this.x, this.y, move_dis, this.speed)

	if nil == this.path_points {
		log.Error("Npc(id:%d,x:%f,y:%f) _domove2 no path points ", this.Id, this.x, this.y, move_dis, this.speed)
	}

	//log.Info("Npc(id:%d,x:%f,y:%f) _domove21 ", this.Id, this.x, this.y)
	enemy_id := int32(0)
	for nil != this.path_points {
		if nil != this.cur_target {
			enemy_id = this.cur_target.Id
		}

		if !room.IfPosCanMoveToNear(this.path_points.fx, this.path_points.fy, this.hitradius, this.isfly, this.Id, enemy_id, false) {
			if (nil == this.cur_target && this.stop_frame > 1) || (nil != this.cur_target && this.stop_frame > 20) {
				log.Info("npc[%d, %f,%f] 前面已经等过一次 需要重新获取路点", this.Id, this.x, this.y)
				this.path_points = nil
				this.blast_path = false
				this.def_move_action = -1
				this.last_def_tgx = -1
				this.last_def_tgy = -1
			} else {
				log.Info("npc[%d, %f,%f]前面路点被挡，前前点没有，停止加1", this.Id, this.x, this.y)
			}
			break

		}

		this.stop_frame = 0
		cur_dis := float32(math.Sqrt(float64((this.path_points.fx-this.x)*(this.path_points.fx-this.x) + (this.path_points.fy-this.y)*(this.path_points.fy-this.y))))
		if move_dis > cur_dis {
			move_dis -= cur_dis
			this.x = this.path_points.fx
			this.y = this.path_points.fy
			this.path_points = this.path_points.next_point
			//log.Info("NPC[%d]移动到 %d %d", this.Id, this.x, this.y)
		} else {
			this.x += move_dis * (this.path_points.fx - this.x) / cur_dis
			this.y += move_dis * (this.path_points.fy - this.y) / cur_dis
			//log.Info("NPC[%d]移动到 %d %d", this.Id, this.x, this.y)
			if nil != room.cur_npc_info {
				tmp_move_info := &msg_client_message.NpcMoveInfo{}
				tmp_move_info.Id = proto.Int32(this.Id)
				tmp_move_info.CurX = proto.Float32(this.x)
				tmp_move_info.CurY = proto.Float32(this.y)
				if nil != this.path_points {
					tmp_move_info.TargetX = proto.Float32(this.path_points.fx)
					tmp_move_info.TargetY = proto.Float32(this.path_points.fy)
				} else {
					tmp_move_info.TargetX = proto.Float32(-1.0)
					tmp_move_info.TargetY = proto.Float32(-1.0)
				}
				room.cur_npc_info.NpcMoves = append(room.cur_npc_info.NpcMoves, tmp_move_info)
			}

			break
		}
	}
}

func (this *Npc) _do_ground_move(room *FightRoom) {
	//log.Info("Npc(id:%d,x:%f,y:%f) _domove1 ", this.Id, this.x, this.y, move_dis, this.speed)
	//跳跃判断
	if 1 == this.isdizzy || 1 == this.isfreeze {
		return
	}

	if this.speed <= 0.001 && this.speed >= -0.001 {
		return
	} else {
		this.move_check_frame++
		if this.move_check_frame < 4 {
			return
		}
		this.move_check_frame = 0
	}

	if 1 == this.isjump && !(this.x >= 8 && this.x <= 12) && !(this.x >= 52 && this.x <= 64) {
		log.Info("Npc[%d] 有跳跃属性 进行跳跃检测", this.Id)
		if PLAYER_SIDE_BTM == this.player_side {
			dis_y := this.y - MAP_REVIER_DOWN_Y
			if dis_y < 0 {
				dis_y = -dis_y
			}

			if dis_y < NPC_JUMP_DIS {
				in_npcs := room.GetInAreaLandArmy(this.x, MAP_REVIER_UP_JUMP_Y, this.hitradius)
				res_2cli := &msg_client_message.S2CMultiNpcRelocate{}
				res_2cli.NpcMoves = make([]*msg_client_message.S2CNpcRelocate, 0, 0+int32(len(in_npcs)))
				room.chang_npc_pos(this, this.x, MAP_REVIER_UP_JUMP_Y, NPC_RELOCATE_JUMP, res_2cli)
				room.reloadnpcs(in_npcs, this.x, MAP_REVIER_UP_JUMP_Y, NPC_RELOCATE_JUMP, res_2cli)

				room.SendToAll(res_2cli)
			}
		} else if PLAYER_SIDE_TOP == this.player_side {
			dis_y := this.y - MAP_REVIER_UP_Y
			if dis_y < 0 {
				dis_y = -dis_y
			}

			if dis_y < NPC_JUMP_DIS {
				in_npcs := room.GetInAreaLandArmy(this.x, MAP_REVIER_DOWN_JUMP_Y, this.hitradius)
				res_2cli := &msg_client_message.S2CMultiNpcRelocate{}
				res_2cli.NpcMoves = make([]*msg_client_message.S2CNpcRelocate, 0, 0+int32(len(in_npcs)))
				room.chang_npc_pos(this, this.x, MAP_REVIER_DOWN_JUMP_Y, NPC_RELOCATE_JUMP, res_2cli)
				room.reloadnpcs(in_npcs, this.x, MAP_REVIER_DOWN_JUMP_Y, NPC_RELOCATE_JUMP, res_2cli)
				room.SendToAll(res_2cli)
			}
		} else {
			log.Error("Npc[%d] 跳跃检测 player_side[%d] 有问题", this.Id, this.player_side)
		}
	}

	if nil == this.path_points && !this.isattacking {
		log.Info("NPC [%d] 没有路点", this.Id)
		return
	}

	sec := float32(0.2)
	move_dis := this.speed*float32(10000+this.buff_add_m_speed-this.buff_sub_m_speed+this.forwardspeed)/10000*sec + this.cur_move_dis
	/*
		if move_dis > 2*this.speed*float32(10000+this.buff_add_m_speed-this.buff_sub_m_speed)/10000*sec {
			log.Error("npc[%d:%d]_do_ground_move 当前移动距离异常 %v  speed %v", this.Id, this.cfgid, move_dis, this.speed)
		}
	*/
	this.cur_move_dis = 0

	// 冲锋判断
	if 1 == this.isforward {
		this.cur_c_move_nsec = this.cur_c_move_nsec + int64(sec*1000000000)
		log.Info("当前累计移动时间 %d", this.cur_c_move_nsec)

		if this.cur_c_move_nsec > global_config.FowardNSec {
			log.Trace("npc[%d] 加冲锋buff[%d] isforward[%d] neednsec(%d)", this.Id, global_config.FowardBuffCfgId, this.isforward, global_config.FowardNSec)
			this.isforward = 2
			this.AddBuff(room, global_config.FowardBuffCfgId, MAX_BUFF_LAST_NSEC)
			this.cur_c_move_nsec = 0
		}
	}

	//log.Info("Npc(id:%d,x:%f,y:%f) _domove21 ", this.Id, this.x, this.y)
	tmp_move_info := &msg_client_message.NpcMoveInfo{}
	tmp_move_info.Id = proto.Int32(this.Id)
	b_move := false
	enemy_id := int32(0)
	cur_dis := float32(0.0)
	//bsub := false
	for nil != this.path_points {
		if nil != this.cur_target {
			enemy_id = this.cur_target.Id
		}
		if !room.IfPosCanMoveToNear(this.path_points.fx, this.path_points.fy, this.hitradius, this.isfly, this.Id, enemy_id, false) {
			//log.Info("Npc[%d] 下一个点[%f,%f]有障碍，且没有下下点，停止帧+1, 当前目标ID[%d]", this.Id, this.path_points.fx, this.path_points.fy, enemy_id)
			if TARGET_STRATEGY_BUILDING == this.targetstrategy {
				pushed_nps := make(map[int32]*Npc)
				res_2cli_r := &msg_client_message.S2CMultiNpcRelocate{}

				var tmp_re *msg_client_message.S2CNpcRelocate
				if room._push_npc(this, this.path_points.fx, this.path_points.fy, pushed_nps, false) {
					log.Info("移动逻辑push成功")
					res_2cli_r.NpcMoves = make([]*msg_client_message.S2CNpcRelocate, 0, len(pushed_nps))
					for _, tmp_npc := range pushed_nps {
						if nil == tmp_npc {
							continue
						}
						tmp_npc.x = tmp_npc.push_x
						tmp_npc.y = tmp_npc.push_y
						tmp_npc.blast_path = false
						tmp_re = &msg_client_message.S2CNpcRelocate{}
						tmp_re.CurX = proto.Float32(tmp_npc.x)
						tmp_re.CurY = proto.Float32(tmp_npc.y)
						tmp_re.Id = proto.Int32(tmp_npc.Id)
						tmp_re.Type = proto.Int32(NPC_RELOCATE_PUSH)
						if nil != tmp_npc.path_points {
							tmp_re.TargetX = proto.Float32(tmp_npc.path_points.fx)
							tmp_re.TargetY = proto.Float32(tmp_npc.path_points.fy)
						} else {
							tmp_re.TargetX = proto.Float32(tmp_npc.x)
							tmp_re.TargetY = proto.Float32(tmp_npc.y)
						}
						res_2cli_r.NpcMoves = append(res_2cli_r.NpcMoves, tmp_re)

						tmp_npc.path_points = nil
						tmp_npc.def_move_action = -1
					}

					if len(res_2cli_r.NpcMoves) > 0 {
						room.SendToAll(res_2cli_r)
					}
					this.stop_frame = 0
				} else {
					this.stop_frame++
					if this.stop_frame > 8 {
						this.path_points = nil
						this.blast_path = false
						this.def_move_action = -1
						this.last_def_tgx = -1
						this.last_def_tgy = -1
						this.cur_move_dis = 0
					}
					break
				}
			} else {
				this.stop_frame++
				if this.stop_frame > 1 {
					if this.stop_frame > 2 {
						log.Error("npc[%d,%d]停止===========================%d", this.Id, this.cfgid, this.stop_frame)
					}
					this.path_points = nil
					this.blast_path = false
					this.def_move_action = -1
					this.last_def_tgx = -1
					this.last_def_tgy = -1
					this.cur_move_dis = 0
				}
				break
			}
		}

		this.stop_frame = 0
		cur_dis = float32(math.Sqrt(float64((this.path_points.fx-this.x)*(this.path_points.fx-this.x) + (this.path_points.fy-this.y)*(this.path_points.fy-this.y))))
		if move_dis >= cur_dis && move_dis > 0 {
			//bsub = true
			move_dis -= cur_dis
			this.x = this.path_points.fx
			this.y = this.path_points.fy
			this.path_points = this.path_points.next_point
			//log.Info("NPC[%d]移动到 %d %d", this.Id, this.x, this.y)
			tmp_move_info.CurX = proto.Float32(this.x)
			tmp_move_info.CurY = proto.Float32(this.y)
			if nil != this.path_points {
				tmp_move_info.TargetX = proto.Float32(this.path_points.fx)
				tmp_move_info.TargetY = proto.Float32(this.path_points.fy)
			} else {
				tmp_move_info.TargetX = proto.Float32(this.x)
				tmp_move_info.TargetY = proto.Float32(this.y)
			}
			b_move = true
		} else {
			this.cur_move_dis = move_dis
			break
		}
	}

	if b_move {
		if move_dis > 0.1 && nil != this.path_points {
			tmp_move_info.TargetX = proto.Float32(this.path_points.fx + move_dis*(this.path_points.fx-this.x)/cur_dis)
			tmp_move_info.TargetY = proto.Float32(this.path_points.fy + move_dis*(this.path_points.fy-this.y)/cur_dis)
		}

		room.cur_npc_info.NpcMoves = append(room.cur_npc_info.NpcMoves, tmp_move_info)
	}
}

func (this *Npc) _ground_ai_check(room *FightRoom) {
	blog := false

	if 1 == this.isdizzy || 1 == this.isfreeze {
		if blog {
			log.Info("Npc[%d] isdizzy or isfreeze ============================1", this.Id)
		}
		return
	}

	if this.speed <= 0.001 && this.speed >= -0.001 {
		this.ai_check_frame++
		if this.ai_check_frame < 4 {
			return
		}
		this.ai_check_frame = 0
		if blog {
			log.Info("Npc[%d] no speed _move_check ============================1", this.Id)
		}
		if nil != this.cur_target && nil == room.id2npc[this.cur_target.Id] {
			this.cur_target = nil
			this.cur_tgt_atk_count = 0
		}
		if nil != this.cur_target {
			if blog {
				log.Info("Npc  no speed _move_check  ============================21 myid:%d targetid:%d", this.Id, this.cur_target.Id)
			}

			if !room.if_near(this.x-this.searchradius, this.y+this.searchradius, 2*this.searchradius, this.cur_target.x-this.cur_target.buidradius/2, this.cur_target.y+2*this.cur_target.buidradius, this.cur_target.buidradius) {
				this.cur_target = nil
				this.path_points = nil
				this.blast_path = false
				this.cur_tgt_atk_count = 0
				return
			} else {
				// 是否跑出攻击范围
				if room.if_near(this.x-this.attackradius, this.y+this.attackradius, 2*this.attackradius, this.cur_target.x-this.cur_target.buidradius/2, this.cur_target.y-this.cur_target.buidradius/2, this.cur_target.buidradius) {
					if blog {
						log.Info("原来敌人[%d,%f,%f]还没死HP(%d)，在范围内，接着打", this.cur_target.Id, this.cur_target.x, this.cur_target.y, this.cur_target.curhp)
					}
					this.SkillCheck(room)
					return
				}
			}
		}

		if blog {
			log.Info("Npc[id:%d,x:%f,y:%f]  no speed _move_check  ======31 player_side:", this.Id, this.x, this.y, this.player_side)
		}
		this.DoEnemySearch(room, this.targetstrategy, false)

		if nil != this.cur_target {
			// 是否跑出攻击范围
			if room.if_near(this.x-this.attackradius, this.y+this.attackradius, 2*this.attackradius, this.cur_target.x-this.cur_target.buidradius/2, this.cur_target.y+this.cur_target.buidradius/2, this.cur_target.buidradius) {
				if blog {
					log.Info("找到新敌人[%d,%f,%f]，且在攻击范围，打", this.cur_target.Id, this.cur_target.x, this.cur_target.y)
				}
				this.SkillCheck(room)
				return
			} else {
				if blog {
					log.Info("npc[%d] [%f,%f]找到新敌人[%d,%f,%f]，但是不在攻击范围[%f] 等", this.Id, this.x, this.y, this.cur_target.Id, this.cur_target.x, this.cur_target.y, this.attackradius)
				}
			}
		} else {
			// 检查类似召唤类技能
			this.SkillCheck(room)
		}

	} else {
		this.ai_check_frame++
		if this.ai_check_frame < 4 {
			return
		}
		this.ai_check_frame = 0

		//log.Info("Npc _move_check ============================1")

		if nil != this.cur_target && nil == room.id2npc[this.cur_target.Id] {
			this.cur_target = nil
			this.cur_tgt_atk_count = 0
		}

		bret := false
		if nil != this.cur_target {
			//log.Info("Npc  _move_check ============================21 myid:%d targetid:%d", this.Id, this.cur_target.Id)
			// 是否跑出发现范围

			if NPC_TYPE_BUILDING != this.cur_target.npctype && !room.if_near(this.x-this.searchradius, this.y+this.searchradius, 2*this.searchradius, this.cur_target.x-this.cur_target.buidradius/2, this.cur_target.y+this.cur_target.buidradius/2, this.cur_target.buidradius) {
				//log.Info("npc[%d] 原来敌人[%d,%f,%f]跑出发现范围了！！！", this.Id, this.cur_target.Id, this.cur_target.x, this.cur_target.y)
				this.cur_target = nil
				this.path_points = nil
				this.blast_path = false
				this.cur_tgt_atk_count = 0
				return
			} else {
				// 是否跑出攻击范围
				if room.if_near(this.x-this.attackradius, this.y+this.attackradius, 2*this.attackradius, this.cur_target.x-this.cur_target.buidradius/2, this.cur_target.y+this.cur_target.buidradius/2, this.cur_target.buidradius) {
					// 如果还在 停原地继续打
					//log.Info("npc[%d] 原来敌人[%d,%f,%f]还没死HP(%d)，在范围内，接着打", this.Id, this.cur_target.Id, this.cur_target.x, this.cur_target.y, this.cur_target.curhp)
					this.SkillCheck(room)
					return
				}
			}
		}
		//log.Info("Npc[id:%d,x:%f,y:%f]  _move_check ======31 player_side:", this.Id, this.x, this.y, this.player_side)
		this.DoEnemySearch(room, this.targetstrategy, false)
		if nil == this.cur_target {
			area_idx := room.map_data.getxy_army_area_idx(this.x, this.y, 0)
			//log.Info("Npc[id:%d,x:%f,y:%f]  _move_check ======32 player_side:", this.Id, this.x, this.y, this.player_side, area_idx)
			def_action := room.map_data.get_def_move_action(area_idx, this.player_side)
			if -1 != def_action {
				this.def_move_action = def_action
				berr, tgt_x, tgt_y, ptgt_x, ptgt_y := cfg_move_act_mgr.GetMovetargetByAction(this.x, this.y, this.def_move_action)
				if berr {
					log.Error("默认动作返回目标点失败%d", this.def_move_action)
					return
				}

				if nil != this.path_points && def_action == this.def_move_action && int32(tgt_x) == int32(this.last_def_tgx) && int32(tgt_y) == int32(this.last_def_tgy) && this.blast_path {
					//log.Info("默认动作%d 不用重新找路", this.def_move_action)
				} else {
					this.last_def_tgx = tgt_x
					this.last_def_tgy = tgt_y
					//log.Trace("默认动作%d != %d 需要重新找路", this.def_move_action, def_action)
					this.def_move_action = def_action

					if berr {
						log.Error("默认动作返回目标点失败%d", this.def_move_action)
					} else {
						this.path_points, bret = room.PatchFindInRoom(this.x, this.y, this.hitradius, this.hitradius, ptgt_x, ptgt_y, 2, this.isfly, this.Id, nil)
						if !bret {
							this.path_points, bret = room.PatchFindInRoomNoBlock(this.x, this.y, this.hitradius, this.hitradius, ptgt_x, ptgt_y, 2, this.isfly, this.Id, nil)
							if !bret {
								this.path_points = nil
								this.blast_path = false
								log.Info("默认动作%d 找路失败 %v,%v,%v,%v,%v,%v,%v,%v,%v,%v", this.def_move_action, this.x, this.y, this.hitradius, ptgt_x, ptgt_y, 4, this.isfly, this.Id)
								return
							} else {
								this.x_move_adjust = 0
								this.blast_path = true
								this.last_path_x = tgt_x
								this.last_path_y = tgt_y
							}
						} else {
							this.x_move_adjust = 0
							this.blast_path = true
							this.last_path_x = tgt_x
							this.last_path_y = tgt_y
						}
					}
				}

			} else {
				log.Error("Npc _move_check def_move_action -1")
			}

		} else {
			// 是否跑出攻击范围
			if room.if_near(this.x-this.attackradius, this.y+this.attackradius, 2*this.attackradius, this.cur_target.x-this.cur_target.buidradius/2, this.cur_target.y+this.cur_target.buidradius/2, this.cur_target.buidradius) {
				//log.Info("找到新敌人[%d,%f,%f]，且在攻击范围，打", this.cur_target.Id, this.cur_target.x, this.cur_target.y)
				this.SkillCheck(room)
				return
			}

			if nil != this.path_points && this.blast_path &&
				this.last_path_x-this.cur_target.x < 0.1 &&
				this.last_path_x-this.cur_target.x > -0.1 &&
				this.last_path_y-this.cur_target.y < 0.1 &&
				this.last_path_y-this.cur_target.y > -0.1 {
				//log.Info("npc[%d]原来敌人[%d,%f,%f]没死也没动，不在范围，跑过去", this.Id, this.cur_target.Id, this.cur_target.x, this.cur_target.y)

			} else {
				//log.Info("npc[%d,%f,%f]敌人[%d,%f,%f] 没路点，找路先", this.Id, this.x, this.y, this.cur_target.Id, this.cur_target.x, this.cur_target.y)
				tgt_x := this.cur_target.x
				if this.x >= tgt_x-this.cur_target.buidradius/2 && this.x <= tgt_x+this.cur_target.buidradius/2 {
					tgt_x = this.x
				}
				this.path_points, bret = room.PatchFindInRoom(this.x, this.y, this.hitradius, 2*this.attackradius, tgt_x, this.cur_target.y, this.cur_target.buidradius, this.isfly, this.Id, this.cur_target)
				if !bret {
					this.path_points, bret = room.PatchFindInRoomNoBlock(this.x, this.y, this.hitradius, 2*this.attackradius, tgt_x, this.cur_target.y, this.cur_target.buidradius, this.isfly, this.Id, this.cur_target)
					if !bret {
						this.path_points = nil
						this.blast_path = false
						//log.Info("找到新敌人[%d,%f,%f]，太远了，没路 ！！！！", this.cur_target.Id, this.cur_target.x, this.cur_target.y, this.x, this.y, this.attackradius, this.cur_target.x, this.cur_target.y, this.cur_target.hitradius, this.attackradius, 2*this.searchradius, this.isfly, this.Id)
						return
					} else {
						this.x_move_adjust = 0
						this.blast_path = true
						this.last_path_x = this.cur_target.x
						this.last_path_y = this.cur_target.y
						this.def_move_action = -1
						this.last_def_tgx = -1
						this.last_def_tgy = -1
						this.cur_move_dis = 0
					}
				} else {
					this.x_move_adjust = 0
					this.blast_path = true
					this.last_path_x = this.cur_target.x
					this.last_path_y = this.cur_target.y
					this.def_move_action = -1
					this.last_def_tgx = -1
					this.last_def_tgy = -1
					this.cur_move_dis = 0
					//log.Info("找到新敌人[%d,%f,%f]，太远了，跑过去，打", this.cur_target.Id, this.cur_target.x, this.cur_target.y)
				}
			}
		}

		//this._do_ground_move(room, sec)
	}
}

func (this *Npc) _buff_check(room *FightRoom, remove_buffs map[int32]int32) {
	if nil == room {
		log.Error("Npc _buff_check param error !")
		return
	}

	if len(this.id2buff) < 1 {
		return
	}

	cur_nsec := time.Now().UnixNano()

	overbuf := make(map[int32]*NpcBuff)
	for buffid, tmp_buff := range this.id2buff {
		if nil == tmp_buff {
			overbuf[buffid] = tmp_buff
			continue
		}

		if tmp_buff.end_nsec > 0 && cur_nsec >= tmp_buff.end_nsec {
			overbuf[buffid] = tmp_buff
			remove_buffs[buffid] = this.Id
			continue
		}

		if nil != tmp_buff.buff_cfg.EffectInfos1 {
			this._do_buff_check(room, tmp_buff, tmp_buff.buff_cfg.EffectInfos1)
		}

		if nil != tmp_buff.buff_cfg.EffectInfos2 {
			this._do_buff_check(room, tmp_buff, tmp_buff.buff_cfg.EffectInfos2)

		}

		if nil != tmp_buff.buff_cfg.EffectInfos3 {
			this._do_buff_check(room, tmp_buff, tmp_buff.buff_cfg.EffectInfos3)
		}
	}

	for buffid, tmp_buff := range overbuf {
		delete(this.id2buff, buffid)
		if nil == tmp_buff {
			continue
		}

		if nil != tmp_buff.buff_cfg.EffectInfos1 {
			this.DoBuffOffEffect(room, tmp_buff, tmp_buff.buff_cfg.EffectInfos1)
		}

		if nil != tmp_buff.buff_cfg.EffectInfos2 {
			this.DoBuffOffEffect(room, tmp_buff, tmp_buff.buff_cfg.EffectInfos2)

		}

		if nil != tmp_buff.buff_cfg.EffectInfos3 {
			this.DoBuffOffEffect(room, tmp_buff, tmp_buff.buff_cfg.EffectInfos3)
		}
	}
}
