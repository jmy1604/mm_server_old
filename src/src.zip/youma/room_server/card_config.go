package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
)

const (
	CARD_TYPE_ARMY     = 1 // 军队
	CARD_TYPE_BUILDING = 2 // 建筑
	CARD_TYPE_MAGIC    = 3 // 法术
)

type XmlPlayerCard struct {
	ConfigId     int32   `xml:"ID,attr"`
	Type         int32   `xml:"Type,attr"`
	Placesize    float32 `xml:"Placesize,attr"`
	NpcCount     int32   `xml:"NpcCount,attr"`
	LoadTime     int32   `xml:"LoadTime,attr"`
	LoadNSec     int64
	SkillId1     int32 `xml:"SkillId1,attr"`
	SkillId2     int32 `xml:"SkillId2,attr"`
	SkillId3     int32 `xml:"SkillId3,attr"`
	SkillId4     int32 `xml:"SkillId4,attr"`
	LoadCost     int32 `xml:"PlaceCost,attr"`
	Trait        int32 `xml:"Trait,attr"`
	IsMirror     bool
	MirrorParams []int32
}

type XmlPlayerCards struct {
	Cards []XmlPlayerCard `xml:"item"`
}

var cfg_player_cards CfgPlayerCards

type CfgPlayerCards struct {
	Array []*XmlPlayerCard         // 数组结构
	Map   map[int32]*XmlPlayerCard // 映射结构
}

func (this *CfgPlayerCards) Load() bool {

	content, err := ioutil.ReadFile("../game_data/cardDataConfig.xml")

	if nil != err {
		log.Error("CfgPlayerCards load failed err(%s)", err.Error())
		return false
	}

	var xml_cards XmlPlayerCards
	err = xml.Unmarshal(content, &xml_cards)
	if nil != err {
		log.Error("CfgPlayerCards load Unmarshal failed err(%s)", err.Error())
		return false
	}

	this.Array = make([]*XmlPlayerCard, len(xml_cards.Cards))
	this.Map = make(map[int32]*XmlPlayerCard)

	for idx := int32(0); idx < int32(len(xml_cards.Cards)); idx++ {
		val := &xml_cards.Cards[idx]
		val.LoadNSec = int64(val.LoadTime) * 1000000
		for _, cfg_id := range global_config.MirrorCardCfgIds {
			if cfg_id == val.ConfigId {
				val.IsMirror = true
				if val.SkillId1 <= 0 {
					log.Error("CfgPlayerCards load mirror less skill1[%d]", val.SkillId1)
					return false
				}

				skill_cfg := cfg_skill_mgr.Map[val.SkillId1]
				if nil == skill_cfg {
					log.Error("CfgPlayerCards load mirror can not find skill1[%d] cfg", val.SkillId1)
					return false
				}

				if nil == skill_cfg.EffectInfos1 {
					log.Error("CfgPlayerCards load mirror effectinfos1 nil !")
					return false
				}

				if SKILL_EFFECT_TYPE_MIRROR != skill_cfg.EffectInfos1.EffectType {
					log.Error("CfgPlayerCards load mirror effectinfos1 effectype[%d] eror !", skill_cfg.EffectInfos1.EffectType)
					return false
				}

				if len(skill_cfg.EffectInfos1.Params) < 4 {
					log.Error("CfgPlayerCards load mirror effectinfos1 len params[%d] eror !", len(skill_cfg.EffectInfos1.Params))
					return false
				}

				val.MirrorParams = make([]int32, 4)
				for tmp_idx := int32(0); tmp_idx < 4; tmp_idx++ {
					val.MirrorParams[tmp_idx] = skill_cfg.EffectInfos1.Params[tmp_idx]
				}

				break
			}
		}

		if val.Trait < 1 || val.Trait > 4 {
			log.Error("CfgPlayerCards load Trait[%d] error !", val.Trait)
			return false
		}
		val.LoadCost = val.LoadCost

		this.Array = append(this.Array, val)
		this.Map[val.ConfigId] = val

		//log.Info("CfgPlayerCards load cfg(%d) %v", val.ConfigId, *val)
	}

	return true
}
