package main

import (
	"fmt"
	"libs/log"
	"libs/timer"
	"math"
	"math/rand"
	"os"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	ROOM_STATE_CREATE     = 0 // 创建状态
	ROOM_STATE_FIRST_CONN = 1 // 第一个玩家连接状态
	ROOM_STATE_START      = 2 // 比赛开始状态
	ROOM_STATE_END        = 3 // 房间结束状态

	//ROOM_TOWER_COUNT = 6 // 房间里面的塔数目

	FIGHT_RESULT_ERROR  = -1 // 异常结束
	FIGHT_RESULT_EQUAL  = 0  // 平局
	FIGHT_RESULT_P1_WIN = 1  // 玩家1获胜
	FIGHT_RESULT_P2_WIN = 2  // 玩家2获胜

	PLAYER_STATE_NOT_ENTER_ROOM = 0 // 玩家未进入房间
	PLAYER_STATE_ENTERED_ROOM   = 1 // 玩家已经进入房间

	MAX_LOAD_EXTRA = 30

	ROOM_TIME_OVER_CHECK_FRAME = 20

	NPC_RELOCATE_PUSH = 1
	NPC_RELOCATE_JUMP = 2
	NPC_RELOCATE_COPY = 3

	AREA_IDX_LEFT_BRIDGE  = 5
	AREA_IDX_RIGHT_BRIDGE = 6

	MAX_INIT_NPC_COUNT = 1

	PLAYER_LOGIN_OUT_READY_IN    = 0 // 登录
	PLAYER_LOGIN_OUT_READY_OUT   = 1 // 登出
	PLAYER_LOGIN_OUT_READY_READY = 2 // 准备好

	DEF_SKILL_TARGET_COUNT = 40
)

type PlayerLoginoutReady struct {
	p     *Player
	inout int32 // 0为in 1为out 2为ready
}

type PlayerCardUse struct {
	idx         int32   // 在接收消息的时候，需要检查值范围 0 ~ 3
	p           *Player // 使用卡片的玩家对象
	x           float32 // x坐标 可以考虑 在传入房间前检查范围
	y           float32 // y坐标 可以考虑 在传入房间前检查范围
	create_nsec int64   // 开始加载时间，在房间里面填写
	need_nsec   int64   // 需要加载的时间，在房间外面填写
	cardid      int32   // 卡片配置id
	cardlvl     int32   // 卡片的等级
}

type FightRoom struct {
	room_id          int32    // 房间Id
	result_id        int32    // 结果Id
	room_type        int32    // 房间类型
	map_id           int32    // 房间地图Id
	map_data         *MapData // 地图数据
	max_tower_npc_id int32
	end_fight_score  uint8

	players       []*Player // 玩家1
	players_state []uint8   // 玩家1状态
	players_ready []bool    // 玩家1是否准备好

	btm_npcs        []*Npc // 下方的npc数组
	btm_npc_num     uint16 // 下方的npc数目
	btm_npc_cur_max uint16 // 下方当前npc容量
	btm_score       uint8  // 下方得分

	top_npcs        []*Npc // 上方的Npc数组
	top_npc_num     uint16 // 上方的npc数目
	top_npc_cur_max uint16 // 上方当前的npc容量
	top_score       uint8  // 上分得分

	loginout_chan chan *PlayerLoginoutReady // 玩家登陆退出chan
	use_card_chan chan *PlayerCardUse       // 玩家使用卡片操作列表

	room_state      uint8 // 房间状态
	time_over_frame uint8 // 超时检查帧
	create_time     int32 // 房间创建时间
	first_conn_time int32 // 第一个玩家进入的时间
	start_time      int32 // 开始时间

	next_npc_id int32          // 下一个NpcId
	id2npc      map[int32]*Npc // 当前场景Npc列表

	next_skill_effect_id int32                  // 下一个技能效果Id
	id2skilleffet        map[int32]*SkillEffect // 下一个技能效果

	close_chan chan int32 // 关闭管道

	ticker *timer.TickTimer // 房间时钟

	cur_npc_info *msg_client_message.S2CNpcSync

	room_end_lock *sync.RWMutex

	skill_target_cache []*Npc
	skill_target_count int32
	skill_target_max   int32

	ai_wait_sec        int32
	last_ai_check_unix int32
}

func NewFightRoom(room_id int32, req *msg_server_message.GetRoomReq) *FightRoom {
	rand.Seed(time.Now().Unix())
	if nil == req || room_id <= 0 {
		log.Error("NewFightRoom param error !")
		return nil
	}

	ret_room := &FightRoom{}
	ret_room.room_id = room_id
	ret_room.result_id = req.GetResultId()
	ret_room.room_type = req.GetMatchType()
	ret_room.map_id = cfg_map_mgr.type2mapid[ret_room.room_type]
	ret_room.map_data = cfg_map_mgr.mapid2mapdata[ret_room.map_id]
	if nil == ret_room.map_data {
		log.Error("NewFightRoom map_data error !")
		return nil
	}

	if MATCH_TYPE_2V2_MATCH == ret_room.room_type {
		ret_room.max_tower_npc_id = 10
		ret_room.end_fight_score = 5
	} else {
		ret_room.max_tower_npc_id = 6
		ret_room.end_fight_score = 3
	}

	NewPlayerFromMsg(ret_room, req)
	ret_room.loginout_chan = make(chan *PlayerLoginoutReady, 4)

	ret_room.create_time = int32(time.Now().Unix())
	ret_room.first_conn_time = 0
	ret_room.start_time = 0
	ret_room.room_state = ROOM_STATE_CREATE
	ret_room.time_over_frame = 0
	ret_room.use_card_chan = make(chan *PlayerCardUse, 10)
	ret_room.close_chan = make(chan int32)

	ret_room.next_npc_id = 6
	ret_room.id2npc = make(map[int32]*Npc)

	ret_room.btm_npc_cur_max = MAX_INIT_NPC_COUNT
	ret_room.btm_npcs = make([]*Npc, MAX_INIT_NPC_COUNT)

	ret_room.top_npc_cur_max = MAX_INIT_NPC_COUNT
	ret_room.top_npcs = make([]*Npc, MAX_INIT_NPC_COUNT)

	ret_room.next_skill_effect_id = 0
	ret_room.id2skilleffet = make(map[int32]*SkillEffect)

	ret_room.room_end_lock = &sync.RWMutex{}
	ret_room.skill_target_cache = make([]*Npc, DEF_SKILL_TARGET_COUNT)
	ret_room.skill_target_max = DEF_SKILL_TARGET_COUNT

	return ret_room
}

func (this *FightRoom) get_next_npc_id() int32 {
	this.next_npc_id++
	if this.next_npc_id <= 0 {
		this.next_npc_id = 7
	}

	return this.next_npc_id
}

func (this *FightRoom) get_skill_effect_id() int32 {
	this.next_skill_effect_id++
	if this.next_skill_effect_id <= 0 {
		this.next_skill_effect_id = 1
	}

	return this.next_skill_effect_id
}

func (this *FightRoom) SendToAll(msg proto.Message) {
	for idx, p := range this.players {
		if this.players_ready[idx] {
			p.Send(msg)
		}
	}
}

func (this *FightRoom) IfPosCanLoadArmy(x, y, inradius float32, isfly int32) bool {
	//log.Info("FightRoom IfPosCanBuild", x, y, inradius)
	if -1 == this.map_data.getxy_army_area_idx(x-inradius/2, y, 0) || -1 == this.map_data.getxy_army_area_idx(x+inradius/2, y, 0) { // 空中单位的放置范围和地面单位一致
		log.Trace("FightRoom IfPosCanBuild pox(%f,%f) not in map", this.map_id, x-inradius/2, y, 0)
		return false
	}
	inleft := x - inradius/2
	intop := y + inradius/2
	for _, npc := range this.id2npc {
		if nil == npc || npc.isfly != isfly || NPC_TYPE_MAGIC == npc.npctype {
			continue
		}

		if if_area_hit(npc.x-npc.buidradius/2, npc.y+npc.buidradius/2, npc.buidradius, npc.buidradius,
			inleft, intop, inradius, inradius) {
			//log.Info("hit npc(%d,%d) pos(x:%f,y:%f,r:%f)", npc.Id, npc.cfgid, npc.x, npc.y, npc.buidradius)
			return false
		}
	}

	return true
}

func (this *FightRoom) IfPosCanLoadBuilding(x, y, inradius float32) bool {
	//log.Info("FightRoom IfPosCanBuild", x, y, inradius)
	area_idx1 := this.map_data.getxy_build_area_idx(x-inradius/2, y, inradius/2, 0)
	area_idx2 := this.map_data.getxy_build_area_idx(x+inradius/2, y, inradius/2, 0)
	if -1 == area_idx1 || -1 == area_idx2 ||
		AREA_IDX_LEFT_BRIDGE == area_idx1 ||
		AREA_IDX_RIGHT_BRIDGE == area_idx1 ||
		AREA_IDX_LEFT_BRIDGE == area_idx2 ||
		AREA_IDX_RIGHT_BRIDGE == area_idx2 {
		log.Trace("FightRoom IfPosCanBuild pox(%f,%f) not in map or on bridge area_idx[%d:%d]", x, y, area_idx1, area_idx2)
		return false
	}
	inleft := x - inradius/2
	intop := y + inradius/2
	for _, npc := range this.id2npc {
		if nil == npc || npc.npctype != NPC_TYPE_BUILDING {
			continue
		}

		if if_area_hit(npc.x-npc.buidradius/2, npc.y+npc.buidradius/2, npc.buidradius, npc.buidradius,
			inleft, intop, inradius, inradius) {
			//log.Info("hit npc(%d,%d) pos(x:%f,y:%f,r:%f)", npc.Id, npc.cfgid, npc.x, npc.y, npc.buidradius)
			return false
		}
	}

	return true
}

func (this *FightRoom) IfPosCanMoveToNear(x, y, inradius float32, isfly, extra_npcid, enemy_id int32, blog bool) bool {
	if -1 == this.map_data.getxy_army_area_idx(x-inradius/2, y, isfly) || -1 == this.map_data.getxy_army_area_idx(x+inradius/2, y, isfly) {
		//log.Trace("FightRoom getxy_area_idx pox(%f,%f) not in map", x, y)
		return false
	}
	inleft := x - inradius/2
	intop := y + inradius/2

	if blog {
		//log.Info("FightRoom  IfPosCanMoveToNear  ", x, y, inradius, isfly, extra_npcid)
	}

	for _, npc := range this.id2npc {
		if nil == npc || npc.Id == extra_npcid || npc.Id == enemy_id || npc.isfly != isfly || NPC_TYPE_MAGIC == npc.npctype {
			continue
		}

		if if_area_hit_move(npc.x-npc.hitradius/2, npc.y+npc.hitradius/2, npc.hitradius, npc.hitradius,
			inleft, intop, inradius, inradius) {
			if blog {
				log.Info("FightRoom IfPosCanMoveToNear hit npc(%d,%d) pos(x:%f,y:%f,r:%f) ", npc.Id, npc.cfgid, npc.x, npc.y, npc.hitradius)
			}
			return false
		}
	}

	return true
}

func (this *FightRoom) IfPosCanMoveToNearExt(x, y, inradius float32, isfly, extra_npcid, enemy_id int32, blog bool) (bret bool, hitnpcs map[int32]*Npc) {
	bret = true
	if -1 == this.map_data.getxy_army_area_idx(x, y, isfly) {
		log.Trace("FightRoom getxy_area_idx pox(%f,%f) not in map", x, y)
		return false, nil
	}
	inleft := x - inradius/2
	intop := y + inradius/2

	if blog {
		//log.Info("FightRoom  IfPosCanMoveToNear  ", x, y, inradius, isfly, extra_npcid)
	}

	hitnpcs = make(map[int32]*Npc)

	for _, npc := range this.id2npc {
		if nil == npc || npc.Id == extra_npcid || npc.Id == enemy_id || npc.isfly != isfly || NPC_TYPE_MAGIC == npc.npctype {
			continue
		}

		if if_area_hit_move(npc.x-npc.hitradius/2, npc.y+npc.hitradius/2, npc.hitradius, npc.hitradius,
			inleft, intop, inradius, inradius) {
			if blog {
				log.Info("FightRoom IfPosCanMoveToNear hit npc(%d,%d) pos(x:%f,y:%f,r:%f) ", npc.Id, npc.cfgid, npc.x, npc.y, npc.hitradius)
			}
			bret = false
			hitnpcs[npc.Id] = npc
		}
	}

	return
}

func (this *FightRoom) _try_push_out_way(src_npc *Npc, des_x, des_y float32, push_npcs map[int32]*Npc, isfly int32, blog bool) bool {
	if -1 == this.map_data.getxy_army_area_idx(des_x-src_npc.hitradius/2, des_y, isfly) || -1 == this.map_data.getxy_army_area_idx(des_x+src_npc.hitradius/2, des_y, isfly) {
		log.Error("FightRoom _try_push_out_way pox(%f,%f) not in map", des_x, des_y)
		return false
	}

	if nil == src_npc || nil == push_npcs {
		log.Error("FightRoom _try_push_out_way src npc nil")
		return false
	}

	inleft := des_x - src_npc.hitradius/2
	inright := des_x + src_npc.hitradius/2
	intop := des_y + src_npc.hitradius/2

	for _, npc := range this.id2npc {
		if nil == npc || npc.Id == src_npc.Id || npc.isfly != src_npc.isfly {
			continue
		}

		if nil != push_npcs[npc.Id] {
			if if_area_hit_move(npc.push_x-npc.hitradius/2, npc.push_y+npc.hitradius/2, npc.hitradius, npc.hitradius,
				inleft, intop, src_npc.hitradius, src_npc.hitradius) {
				log.Info("FightRoom _push_npcs Npc[%d:%d]碰到了移动过的Npc[%d:%d]", src_npc.Id, src_npc.cfgid, npc.Id, npc.cfgid)
				return false
			}
		} else {
			if if_area_hit_move(npc.x-npc.hitradius/2, npc.y+npc.hitradius/2, npc.hitradius, npc.hitradius,
				inleft, intop, src_npc.hitradius, src_npc.hitradius) {
				if blog {
					log.Info("FightRoom _push_npcs hit npc(%d,%d) pos(x:%f,y:%f,r:%f) ", npc.Id, npc.cfgid, npc.x, npc.y, npc.hitradius)
				}

				sub_pushed_nps := make(map[int32]*Npc)
				res_2cli_r := &msg_client_message.S2CMultiNpcRelocate{}
				var tmp_re *msg_client_message.S2CNpcRelocate
				if npc.x <= des_x {
					npc.push_x = inleft - npc.hitradius/2 - 1
					npc.push_y = npc.y
					log.Info("npc[%d]推npc[%d]到左边", src_npc.cardid, npc.cardid)
				} else {
					npc.push_x = inright + npc.hitradius/2 + 1
					npc.push_y = npc.y
					log.Info("npc[%d]推npc[%d]到右边", src_npc.cardid, npc.cardid)
				}

				if NPC_TYPE_BUILDING == npc.npctype || -1 == this.map_data.getxy_army_area_idx(npc.push_x-npc.hitradius/2, npc.push_y, npc.isfly) || -1 == this.map_data.getxy_army_area_idx(npc.push_x+npc.hitradius/2, npc.push_y, npc.isfly) {
					log.Error("_try_push_out_way 推npc[%d, %d]失败", npc.Id, npc.cfgid)
					return false
				}

				if this._push_npc(npc, npc.push_x, npc.push_y, sub_pushed_nps, false) {
					res_2cli_r.NpcMoves = make([]*msg_client_message.S2CNpcRelocate, 0, len(sub_pushed_nps)+1)
					for _, tmp_npc := range sub_pushed_nps {
						if nil == tmp_npc {
							continue
						}
						tmp_npc.x = tmp_npc.push_x
						tmp_npc.y = tmp_npc.push_y
						tmp_npc.blast_path = false
						tmp_re = &msg_client_message.S2CNpcRelocate{}
						tmp_re.CurX = proto.Float32(tmp_npc.x)
						tmp_re.CurY = proto.Float32(tmp_npc.y)
						tmp_re.Id = proto.Int32(tmp_npc.Id)
						tmp_re.Type = proto.Int32(NPC_RELOCATE_PUSH)
						if nil != tmp_npc.path_points {
							tmp_re.TargetX = proto.Float32(tmp_npc.path_points.fx)
							tmp_re.TargetY = proto.Float32(tmp_npc.path_points.fy)
						} else {
							tmp_re.TargetX = proto.Float32(tmp_npc.x)
							tmp_re.TargetY = proto.Float32(tmp_npc.y)
						}
						res_2cli_r.NpcMoves = append(res_2cli_r.NpcMoves, tmp_re)

						tmp_npc.path_points = nil
						tmp_npc.blast_path = false
						tmp_npc.def_move_action = -1
					}

					if len(res_2cli_r.NpcMoves) > 0 {
						this.SendToAll(res_2cli_r)
					}
				} else {
					log.Info("npc[%d]推npc[%d]失败了", src_npc.cardid, npc.cardid)
					return false
				}
			}
		}
	}

	return true
}

func (this *FightRoom) _push_npc(src_npc *Npc, des_x, des_y float32, push_npcs map[int32]*Npc, blog bool) bool {
	if nil == src_npc || nil == push_npcs {
		log.Error("FightRoom _push_npcs src npc nil")
		return false
	}

	push_x := des_x - src_npc.x
	push_y := des_y - src_npc.y
	des_left := des_x - src_npc.hitradius/2
	des_top := des_y + src_npc.hitradius/2

	for _, npc := range this.id2npc {
		if nil == npc || npc.Id == src_npc.Id || npc.isfly != src_npc.isfly {
			continue
		}

		if nil != push_npcs[npc.Id] {
			if if_area_hit_move(npc.push_x-npc.hitradius/2, npc.push_y+npc.hitradius/2, npc.hitradius, npc.hitradius,
				des_left, des_top, src_npc.hitradius, src_npc.hitradius) {
				log.Info("FightRoom _push_npcs Npc[%d:%d]碰到了移动过的Npc[%d:%d]", src_npc.Id, src_npc.cfgid, npc.Id, npc.cfgid)
				return false
			}
		} else {
			if if_area_hit_move(npc.x-npc.hitradius/2, npc.y+npc.hitradius/2, npc.hitradius, npc.hitradius,
				des_left, des_top, src_npc.hitradius, src_npc.hitradius) {
				if blog {
					log.Info("FightRoom _push_npcs hit npc(%d,%d) pos(x:%f,y:%f,r:%f) ", npc.Id, npc.cfgid, npc.x, npc.y, npc.hitradius)
				}

				npc.push_x = npc.x + push_x
				npc.push_y = npc.y + push_y

				// || TARGET_STRATEGY_BUILDING == npc.targetstrategy
				if NPC_TYPE_BUILDING == npc.npctype || -1 == this.map_data.getxy_army_area_idx(npc.push_x+npc.hitradius/2, npc.push_y, src_npc.isfly) || -1 == this.map_data.getxy_army_area_idx(npc.push_x-npc.hitradius/2, npc.push_y, src_npc.isfly) {
					log.Error("============================== 推npc[%d, %d] 目标位置不合法", npc.Id, npc.cfgid)
					return false
				}

				if !this._push_npc(npc, npc.push_x, npc.push_y, push_npcs, false) {
					log.Error("============================== 推npc[%d, %d] 失败", npc.Id, npc.cfgid)
					return false
				}

				npc.path_points = nil
				push_npcs[npc.Id] = npc
			}
		}
	}

	return true
}

func (this *FightRoom) IfPosCanMoveToFar(x, y, inradius float32, isfly, extra_npcid, enemy_id int32, blog bool) bool {
	if -1 == this.map_data.getxy_army_area_idx(x-inradius/2, y, isfly) || -1 == this.map_data.getxy_army_area_idx(x+inradius/2, y, isfly) {
		//log.Trace("FightRoom getxy_area_idx pox(%f,%f) not in map", x, y)
		return false
	}
	inleft := x - inradius/2
	intop := y + inradius/2

	if blog {
		//log.Info("FightRoom  IfPosCanMoveToFar  ", x, y, inradius, isfly, extra_npcid)
	}

	for _, npc := range this.id2npc {
		if nil == npc || npc.Id == extra_npcid || npc.Id == enemy_id || npc.isfly != isfly || NPC_TYPE_MAGIC == npc.npctype {
			continue
		}

		if NPC_TYPE_BUILDING == npc.npctype {
			if if_area_hit_move(npc.x-npc.hitradius/2, npc.y+npc.hitradius/2, npc.hitradius, npc.hitradius,
				inleft, intop, inradius, inradius) {
				if blog {
					log.Info("FightRoom IfPosCanMoveToFar hit building(%d,%d) pos(x:%f,y:%f,r:%f) ", npc.Id, npc.cfgid, npc.x, npc.y, npc.hitradius)
				}
				return false
			}
		}

		if NPC_TYPE_ARMY == npc.npctype && nil == npc.path_points {
			if if_area_hit_move(npc.x-npc.hitradius/2, npc.y+npc.hitradius/2, npc.hitradius, npc.hitradius,
				inleft, intop, inradius, inradius) {
				if blog {
					log.Info("FightRoom IfPosCanMoveToFar hit stopnpc(%d,%d) pos(x:%f,y:%f,r:%f) ", npc.Id, npc.cfgid, npc.x, npc.y, npc.hitradius)
				}
				return false
			}
		}
	}

	return true
}

func (this *FightRoom) if_near(src_x, src_y, src_radius, des_x, des_y, des_radius float32) bool {
	/*
		if (src_x+src_radius) < des_x || (des_x+des_radius) < src_x || (src_y-src_radius) > des_y || (des_y-des_radius) > src_y {
			return false
		}
	*/
	src_c_x := src_x + src_radius/2
	src_c_y := src_y - src_radius/2
	des_c_x := des_x + des_radius/2
	des_c_y := des_y - des_radius/2

	dis_c2 := (des_c_x-src_c_x)*(des_c_x-src_c_x) + (des_c_y-src_c_y)*(des_c_y-src_c_y)
	chk_dis2 := (src_radius/2 + des_radius/2) * (src_radius/2 + des_radius/2)
	if chk_dis2 > dis_c2 {
		return true
	}

	return false
}

func (this *FightRoom) if_in_area(center_x, center_y, radius, x, y float32) bool {
	if (center_x+radius/2) < x || x < center_x-radius/2 || (center_y-radius/2) > y || y > center_y+radius/2 {
		return false
	}

	return true
}

type A_PATH_POINT struct {
	x          int32 // 相对于起始点的x坐标
	y          int32 // 相对于起始点的Y坐标
	fx         float32
	fy         float32
	pre_point  *A_PATH_POINT
	next_point *A_PATH_POINT
}

func (this *FightRoom) PatchFindInRoom(src_x, src_y, src_radius, near_radius, des_x, des_y, des_radius float32, isfly, extra_npc_id int32, tgt_npc *Npc) (startpoint *A_PATH_POINT, bret bool) {
	bret = false
	enemy_id := int32(0)
	if nil != tgt_npc {
		enemy_id = tgt_npc.Id
	}

	log.Info("npc[%d] 寻路 当前目标Id %d", extra_npc_id, enemy_id)

	min_step := float32(1.0)

	bnear := false
	closepoints := make(map[int32]bool)
	in_way_points := make(map[int32]bool)
	startpoint = &A_PATH_POINT{x: int32(src_x + 1), y: int32(src_y + 1), fx: src_x, fy: src_y}
	cur_point := startpoint
	count := int32(0)

	x_start, x_end, x_step := int32(-1), int32(1), int32(1)
	des_left := des_x - des_radius/2
	des_top := des_y + des_radius/2
	if nil != tgt_npc {
		des_left = tgt_npc.x - des_radius/2
		des_top = tgt_npc.y + des_radius/2
		if des_x >= tgt_npc.x {
			x_start, x_end, x_step = 1, -1, -1
		}
	}
	for {
		count++
		if count > 100 {
			log.Error("PatchFindInRoom over count 500 !!!")
			return nil, false
		}

		if this.if_near(cur_point.fx-near_radius/2, cur_point.fy+near_radius/2, near_radius, des_left, des_top, des_radius) {
			bret = true
			startpoint = startpoint.next_point
			//log.Trace("near 寻路成功！！", cur_point.fx, cur_point.fy, near_radius, des_x, des_y, des_radius)
			return
		}

		min_des := float32(1000000.0)
		min_ix := int32(-1)
		min_iy := int32(-1)
		bfind := false
		//log.Info("try point %d , %d", cur_point.x, cur_point.y)
		if nil != cur_point.pre_point {
			//log.Info("====pre point %d , %d", cur_point.pre_point.x, cur_point.pre_point.y)
		}
		broll_back := false
		for ix := x_start; ; ix = ix + x_step {
			if (x_end > 0 && ix > x_end) || (x_end < 0 && ix < x_end) {
				break
			}
			for iy := int32(-1); iy <= 1; iy++ {
				if ix == 0 && iy == 0 {
					continue
				}
				new_idx := (cur_point.x+ix)*1000 + cur_point.y + iy
				if closepoints[new_idx] {
					//log.Info("FightRoom fasle continue closepoints [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
					continue
				}

				if nil != cur_point.pre_point {

					prex_dis := cur_point.x + ix - cur_point.pre_point.x
					prey_dis := cur_point.y + iy - cur_point.pre_point.y
					if (0 == prey_dis && prex_dis >= -1 && prex_dis <= 1) ||
						(0 == prex_dis && prey_dis >= -1 && prey_dis <= 1) {
						//log.Info("FightRoom false continue way back [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
						broll_back = true
						continue
					}
				}

				new_x := cur_point.fx + float32(ix)*min_step
				new_y := cur_point.fy + float32(iy)*min_step
				if enemy_id <= 0 {
					if (src_x < MAP_CENTER_X && new_x >= MAP_CENTER_X) || (src_x > MAP_CENTER_X && new_x <= MAP_CENTER_X) {
						log.Error("=============================================cross")
						return nil, false
					}
				}

				bnear = false
				if nil != tgt_npc && this.if_in_area(tgt_npc.x, tgt_npc.y, tgt_npc.buidradius+src_radius+1, new_x, new_y) {
					bnear = true

				} else if this.if_in_area(src_x, src_y, 2, new_x, new_y) || this.if_in_area(des_x, des_y, des_radius+src_radius/2, new_x, new_y) {
					bnear = true
				}

				if bnear {
					if !this.IfPosCanMoveToNear(new_x, new_y, src_radius, isfly, extra_npc_id, enemy_id, false) {
						tmp_idx := (cur_point.x+ix)*1000 + cur_point.y + iy
						closepoints[tmp_idx] = true
						//log.Info("FightRoom fasle continue IfPosCanMoveToNear [ix:%d, iy:%d] [fx:%f, fy:%f]", cur_point.x+ix, cur_point.y+iy, cur_point.fx, cur_point.fy)
						continue
					}
				} else {
					/*
						if -1 == cfg_map_mgr.getxy_area_idx(new_x, new_y, isfly) {
							continue
						}
					*/
					if !this.IfPosCanMoveToFar(new_x, new_y, src_radius, isfly, extra_npc_id, enemy_id, false) {
						tmp_idx := (cur_point.x+ix)*1000 + cur_point.y + iy
						closepoints[tmp_idx] = true
						//log.Info("FightRoom fasle continue IfPosCanMoveToNear [ix:%d, iy:%d] [fx:%f, fy:%f]", cur_point.x+ix, cur_point.y+iy, cur_point.fx, cur_point.fy)
						continue
					}
				}

				new_dis := (new_x-des_x)*(new_x-des_x) + (new_y-des_y)*(new_y-des_y)
				//log.Info("try point %d , %d", cur_point.x+ix, cur_point.y+iy, new_dis, new_x, new_y, des_x, des_y)
				if new_dis < min_des {
					min_des = new_dis
					min_ix = ix
					min_iy = iy
					if in_way_points[new_idx] {
						//log.Info("FightRoom fasle continue in_way_points [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
						bfind = false
						continue
					} else {
						bfind = true
					}
				}
			}
		}

		if !bfind {
			if nil == cur_point.pre_point {
				log.Info("FightRoom fasle 寻路失败（%d）", count)
				return
			} else {
				//log.Info("FightRoom not find (%d, %d) ", cur_point.x, cur_point.y)
				closepoints[cur_point.x*1000+cur_point.y] = true
				cur_point = cur_point.pre_point
				cur_point.next_point = nil
				in_way_points[cur_point.x*1000+cur_point.y] = false
			}
		} else {
			broll_back = false
			tmp_pre := cur_point.pre_point
			var rool_back_point *A_PATH_POINT
			for nil != tmp_pre {
				prex_dis := cur_point.x + min_ix - tmp_pre.x
				prey_dis := cur_point.y + min_iy - tmp_pre.y
				if prex_dis >= -1 && prex_dis <= 1 && prey_dis >= -1 && prey_dis <= 1 {
					//log.Info("FightRoom false continue way back [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
					broll_back = true
					rool_back_point = tmp_pre
					//log.Info("=================寻路回溯！！！到点[%v]", *rool_back_point)
					break
				}
				tmp_pre = tmp_pre.pre_point
			}

			new_point := &A_PATH_POINT{x: cur_point.x + min_ix, y: cur_point.y + min_iy,
				fx: cur_point.fx + float32(min_ix)*min_step, fy: cur_point.fy + float32(min_iy)*min_step,
				pre_point: cur_point}

			if !broll_back {
				in_way_points[cur_point.x*1000+cur_point.y] = true

				cur_point.next_point = new_point
				cur_point = new_point
			} else {
				for nil != cur_point && (rool_back_point != cur_point) {
					closepoints[cur_point.x*1000+cur_point.y] = true
					cur_point = cur_point.pre_point
				}

				if nil == cur_point {
					log.Error("!!!!!!!!!!回溯处理失败！！！！！！！！！！！！！！")
					return nil, false
				}

				cur_point.next_point = new_point
				cur_point = new_point
			}

			//log.Info("best point (%d, %d) (%f,%f)", new_point.x, new_point.y, new_point.fx, new_point.fy)
		}
	}

	log.Error("寻路不可能的返回位置 ！")
	return nil, false
}

func (this *FightRoom) PatchFindInRoomNoBlock(src_x, src_y, src_radius, near_radius, des_x, des_y, des_radius float32, isfly, extra_npc_id int32, tgt_npc *Npc) (startpoint *A_PATH_POINT, bret bool) {
	bret = false
	enemy_id := int32(0)
	if nil != tgt_npc {
		enemy_id = tgt_npc.Id
	}

	//log.Info("npc[%d] NoBlock寻路 当前目标Id %d", extra_npc_id, enemy_id)

	min_step := float32(1.0)

	closepoints := make(map[int32]bool)
	in_way_points := make(map[int32]bool)
	startpoint = &A_PATH_POINT{x: int32(src_x + 1), y: int32(src_y + 1), fx: src_x, fy: src_y}
	cur_point := startpoint
	count := int32(0)

	x_start, x_end, x_step := int32(-1), int32(1), int32(1)
	des_left := des_x - des_radius/2
	des_top := des_y + des_radius/2
	if nil != tgt_npc {
		des_left = tgt_npc.x - des_radius/2
		des_top = tgt_npc.y + des_radius/2
		if des_x >= tgt_npc.x {
			x_start, x_end, x_step = 1, -1, -1
		}
	}
	for {
		count++
		if count > 100 {
			log.Error("PatchFindInRoom over count 500 !!!")
			return nil, false
		}

		if this.if_near(cur_point.fx-near_radius/2, cur_point.fy+near_radius/2, near_radius, des_left, des_top, des_radius) {
			bret = true
			startpoint = startpoint.next_point
			//log.Trace("near 寻路成功！！", cur_point.fx, cur_point.fy, near_radius, des_x, des_y, des_radius)
			return
		}

		min_des := float32(1000000.0)
		min_ix := int32(-1)
		min_iy := int32(-1)
		bfind := false
		//log.Info("try point %d , %d", cur_point.x, cur_point.y)
		if nil != cur_point.pre_point {
			//log.Info("====pre point %d , %d", cur_point.pre_point.x, cur_point.pre_point.y)
		}
		broll_back := false
		for ix := x_start; ; ix = ix + x_step {
			if (x_end > 0 && ix > x_end) || (x_end < 0 && ix < x_end) {
				break
			}
			for iy := int32(-1); iy <= 1; iy++ {
				if ix == 0 && iy == 0 {
					continue
				}
				new_idx := (cur_point.x+ix)*1000 + cur_point.y + iy
				if closepoints[new_idx] {
					//log.Info("FightRoom fasle continue closepoints [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
					continue
				}

				if nil != cur_point.pre_point {

					prex_dis := cur_point.x + ix - cur_point.pre_point.x
					prey_dis := cur_point.y + iy - cur_point.pre_point.y
					if (0 == prey_dis && prex_dis >= -1 && prex_dis <= 1) ||
						(0 == prex_dis && prey_dis >= -1 && prey_dis <= 1) {
						//log.Info("FightRoom false continue way back [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
						broll_back = true
						continue
					}
				}

				new_x := cur_point.fx + float32(ix)*min_step
				new_y := cur_point.fy + float32(iy)*min_step
				if enemy_id <= 0 {
					if (src_x < MAP_CENTER_X && new_x > MAP_CENTER_X) || (src_x > MAP_CENTER_X && new_x < MAP_CENTER_X) {
						log.Error("=============================================cross")
						return nil, false
					}
				}

				if -1 == this.map_data.getxy_army_area_idx(new_x-src_radius/2, new_y, isfly) || -1 == this.map_data.getxy_army_area_idx(new_x+src_radius/2, new_y, isfly) {
					continue
				}

				new_dis := (new_x-des_x)*(new_x-des_x) + (new_y-des_y)*(new_y-des_y)
				if new_dis < min_des {
					min_des = new_dis
					min_ix = ix
					min_iy = iy
					if in_way_points[new_idx] {
						//log.Info("FightRoom fasle continue in_way_points [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
						bfind = false
						continue
					} else {
						bfind = true
					}
				}
			}
		}

		if !bfind {
			if nil == cur_point.pre_point {
				log.Info("FightRoom fasle 寻路失败（%d）", count)
				return
			} else {
				//log.Info("FightRoom not find (%d, %d) ", cur_point.x, cur_point.y)
				closepoints[cur_point.x*1000+cur_point.y] = true
				cur_point = cur_point.pre_point
				cur_point.next_point = nil
				in_way_points[cur_point.x*1000+cur_point.y] = false
			}
		} else {
			broll_back = false
			tmp_pre := cur_point.pre_point
			var rool_back_point *A_PATH_POINT
			for nil != tmp_pre {
				prex_dis := cur_point.x + min_ix - tmp_pre.x
				prey_dis := cur_point.y + min_iy - tmp_pre.y
				if prex_dis >= -1 && prex_dis <= 1 && prey_dis >= -1 && prey_dis <= 1 {
					//log.Info("FightRoom false continue way back [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
					broll_back = true
					rool_back_point = tmp_pre
					//log.Info("=================寻路回溯！！！到点[%v]", *rool_back_point)
					break
				}
				tmp_pre = tmp_pre.pre_point
			}

			new_point := &A_PATH_POINT{x: cur_point.x + min_ix, y: cur_point.y + min_iy,
				fx: cur_point.fx + float32(min_ix)*min_step, fy: cur_point.fy + float32(min_iy)*min_step,
				pre_point: cur_point}

			if !broll_back {
				in_way_points[cur_point.x*1000+cur_point.y] = true

				cur_point.next_point = new_point
				cur_point = new_point
			} else {
				for nil != cur_point && (rool_back_point != cur_point) {
					closepoints[cur_point.x*1000+cur_point.y] = true
					cur_point = cur_point.pre_point
				}

				if nil == cur_point {
					log.Error("!!!!!!!!!!回溯处理失败！！！！！！！！！！！！！！")
					return nil, false
				}

				cur_point.next_point = new_point
				cur_point = new_point
			}

			//log.Info("best point (%d, %d) (%f,%f)", new_point.x, new_point.y, new_point.fx, new_point.fy)
		}
	}

	log.Error("寻路不可能的返回位置 ！")
	return nil, false
}

func (this *FightRoom) PatchFindInRoomReal(src_x, src_y, src_radius, des_x, des_y, des_radius, extra, findradius float32, isfly, extra_npcid, enemy_id int32) (startpoint *A_PATH_POINT, bret bool) {
	min_step := float32(5.0)
	dir_x := des_x - src_x
	dir_y := des_y - src_y
	dir_r := float32(math.Sqrt(float64(dir_x*dir_x + dir_y*dir_y)))
	min_step_x := min_step * dir_x / dir_r
	min_step_y := min_step * dir_y / dir_r
	log.Info("==============dir_x %f, dir_y %f, dir_r %f, min_step_x %f, min_set_y %f", dir_x, dir_y, dir_r, min_step_x, min_step_y)
	closepoints := make(map[int32]bool)
	in_way_points := make(map[int32]bool)
	startpoint = &A_PATH_POINT{x: int32(src_x), y: int32(src_y), fx: src_x, fy: src_y}
	cur_point := startpoint
	count := int32(0)
	for {
		count++
		if count > 100 {
			log.Error("PatchFindInRoom over count 500 !!!")
			break
		}
		if cur_point.fx-startpoint.fx > findradius {
			log.Info("FightRoom fasle return 1")
			//return
		}

		dir_x = des_x - cur_point.fx
		dir_y = des_y - cur_point.fy
		dir_r = float32(math.Sqrt(float64(dir_x*dir_x + dir_y*dir_y)))
		min_step_x = min_step * dir_x / dir_r
		min_step_y = min_step * dir_y / dir_r

		if this.if_near(cur_point.fx-src_radius/2, cur_point.fy+src_radius/2, src_radius, des_x-des_radius/2, des_y+des_radius/2, des_radius) {
			bret = true
			return
		}

		min_des := float32(1000000.0)
		min_ix := int32(-1)
		min_iy := int32(-1)
		bfind := false
		log.Info("try point %d , %d", cur_point.x, cur_point.y)
		if nil != cur_point.pre_point {
			//log.Info("====pre point %d , %d", cur_point.pre_point.x, cur_point.pre_point.y)
		}
		var new_x, new_y float32
		for ix := int32(-1); ix <= 1; ix++ {
			for iy := int32(-1); iy <= 1; iy++ {
				if ix == 0 && iy == 0 {
					continue
				}
				new_idx := (cur_point.x+ix)*1000 + cur_point.y + iy
				if closepoints[new_idx] {
					log.Info("FightRoom fasle continue closepoints [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
					continue
				}

				if in_way_points[new_idx] {
					log.Info("FightRoom fasle continue in_way_points [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
					continue
				}

				if nil != cur_point.pre_point {
					prex_dis := cur_point.x + ix - cur_point.pre_point.x
					prey_dis := cur_point.y + iy - cur_point.pre_point.y
					if prex_dis >= -1 && prex_dis <= 1 && prey_dis >= -1 && prey_dis <= 1 {
						log.Info("FightRoom false continue way back [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
						continue
					}
				}

				if 0 == ix {
					new_x = cur_point.fx
					new_y = cur_point.fy + float32(iy)*min_step
				} else if 0 == iy {
					new_x = cur_point.fx + float32(ix)*min_step
					new_y = cur_point.fy
				} else {
					new_x = cur_point.fx + float32(ix)*min_step_x
					new_y = cur_point.fy + float32(iy)*min_step_y
				}

				if !this.IfPosCanMoveToNear(new_x, new_y, src_radius, isfly, extra_npcid, enemy_id, false) {
					tmp_idx := (cur_point.x+ix)*1000 + cur_point.y + iy
					closepoints[tmp_idx] = true
					//log.Info("FightRoom fasle continue IfPosCanMoveTo [ix:%d, iy:%d]", cur_point.x+ix, cur_point.y+iy)
					continue
				}
				new_dis := (new_x-des_x)*(new_x-des_x) + (new_y-des_y)*(new_y-des_y)
				log.Info("try point %d , %d", cur_point.x+ix, cur_point.y+iy, new_dis, new_x, new_y, des_x, des_y)
				if new_dis < min_des {
					min_des = new_dis
					min_ix = ix
					min_iy = iy
					bfind = true
				}
			}
		}

		if !bfind {
			if nil == cur_point.pre_point {
				log.Info("FightRoom fasle return 2")
				return
			} else {
				log.Info("FightRoom not find (%d, %d) ", cur_point.x, cur_point.y)
				closepoints[cur_point.x*1000+cur_point.y] = true
				cur_point = cur_point.pre_point
				cur_point.next_point = nil
				in_way_points[cur_point.x*1000+cur_point.y] = false
			}
		} else {

			in_way_points[cur_point.x*1000+cur_point.y] = true
			if 0 == min_ix {
				new_x = cur_point.fx
				new_y = cur_point.fy + float32(min_iy)*min_step
			} else if 0 == min_iy {
				new_x = cur_point.fx + float32(min_ix)*min_step
				new_y = cur_point.fy
			} else {
				new_x = cur_point.fx + float32(min_ix)*min_step_x
				new_y = cur_point.fy + float32(min_iy)*min_step_y
			}
			new_point := &A_PATH_POINT{x: cur_point.x + min_ix, y: cur_point.y + min_iy,
				fx: new_x, fy: new_y,
				pre_point: cur_point}

			cur_point.next_point = new_point
			cur_point = new_point

			log.Info("best point (%d, %d)", new_point.x, new_point.y)
		}
	}

	return
}

func (this *FightRoom) PathFindInRoomFlyDef(src_x, src_y float32, player_side int32) (startpoint *A_PATH_POINT, bret bool) {

	var tmp_target *Npc
	if PLAYER_SIDE_BTM == player_side {
		if src_x <= MAP_CENTER_X {
			log.Info("玩家1飞行单位在地图左半边 !")
			tmp_target := this.id2npc[NORMAL_P2_PRINESS_L_ID]
			if nil == tmp_target {
				tmp_target = this.id2npc[NORMAL_P2_KING_NPC_ID]
			}

			if nil == tmp_target {
				return
			}
		} else {
			log.Info("玩家1飞行单位在地图右半边 ！")
			tmp_target := this.id2npc[NORMAL_P2_PRINESS_R_ID]
			if nil == tmp_target {
				tmp_target = this.id2npc[NORMAL_P2_KING_NPC_ID]
			}

			if nil == tmp_target {
				return
			}
		}
	} else {
		if src_x <= MAP_CENTER_X {
			log.Info("玩家2飞行单位在地图左半边 !")
			tmp_target := this.id2npc[NORMAL_BTM_PRINESS_L_ID]
			if nil == tmp_target {
				tmp_target = this.id2npc[NORMAL_BTM_KING_NPC_ID]
			}

			if nil == tmp_target {
				return
			}
		} else {
			log.Info("玩家2飞行单位在地图右半边 ！")
			tmp_target := this.id2npc[NORMAL_BTM_PRINESS_R_ID]
			if nil == tmp_target {
				tmp_target = this.id2npc[NORMAL_BTM_KING_NPC_ID]
			}

			if nil == tmp_target {
				return
			}

			startpoint = &A_PATH_POINT{x: int32(tmp_target.x), y: int32(tmp_target.y), fx: tmp_target.x, fy: tmp_target.y}
			bret = true
		}
	}

	if nil != tmp_target {
		startpoint = &A_PATH_POINT{x: int32(tmp_target.x), y: int32(tmp_target.y), fx: tmp_target.x, fy: tmp_target.y}
		bret = true
	}

	return
}

func (this *FightRoom) PathFindInRoomFly(src_x, src_y, tgt_x, tgt_y float32, player_side int32) (startpoint *A_PATH_POINT, bret bool) {

	startpoint = &A_PATH_POINT{x: int32(tgt_x), y: int32(tgt_y), fx: tgt_x, fy: tgt_y}
	bret = true

	return
}

const (
	DEF_INBUILDING_NPC_NUM = 10
)

func (this *FightRoom) GetInAreaLandArmy(x, y, inradius float32) []*Npc {
	ret_npc := make([]*Npc, 0, DEF_INBUILDING_NPC_NUM)
	inleft := x - inradius/2
	intop := y + inradius/2
	for _, npc := range this.id2npc {
		if nil == npc || npc.npctype != NPC_TYPE_ARMY || 1 == npc.isfly {
			continue
		}

		if if_area_hit(npc.x-npc.buidradius/2, npc.y+npc.buidradius/2, npc.buidradius, npc.buidradius,
			inleft, intop, inradius, inradius) {
			ret_npc = append(ret_npc, npc)
		}
	}

	return ret_npc
}

func (this *FightRoom) GetInCircleFriend(x, y, inradius float32, isfly, self_player_side int32) (ret_map map[int32]*Npc) {
	this.skill_target_count = 0
	ret_map = make(map[int32]*Npc)
	inleft := x - inradius/2
	intop := y + inradius/2
	for _, npc := range this.id2npc {
		if nil == npc || npc.npctype == NPC_TYPE_MAGIC || npc.player_side != self_player_side {
			continue
		}

		if 0 == isfly && npc.isfly == 1 {
			continue
		}

		if if_area_hit(npc.x-npc.buidradius/2, npc.y+npc.buidradius/2, npc.buidradius, npc.buidradius,
			inleft, intop, inradius, inradius) {
			ret_map[npc.Id] = npc
			if this.skill_target_count >= this.skill_target_max {
				this.skill_target_max = 2 * this.skill_target_max
				tmp_targets := make([]*Npc, this.skill_target_max)
				for idx := int32(0); idx < int32(len(this.skill_target_cache)); idx++ {
					tmp_targets[idx] = this.skill_target_cache[idx]
				}
				this.skill_target_cache = tmp_targets
			}
			this.skill_target_cache[this.skill_target_count] = npc
			this.skill_target_count++
		}
	}
	return
}

func (this *FightRoom) GetInCircleEnemy(x, y, inradius float32, isfly, self_player_side int32) (ret_map map[int32]*Npc) {
	this.skill_target_count = 0
	log.Trace("GetInCircleEnemy ========", x, y, inradius, isfly, self_player_side)
	ret_map = make(map[int32]*Npc)
	inleft := x - inradius/2
	intop := y + inradius/2
	for _, npc := range this.id2npc {
		if nil == npc || npc.npctype == NPC_TYPE_MAGIC || npc.player_side == self_player_side {
			log.Trace("GetInCircleEnemy npc[%d] continue type ", npc.Id, nil == npc, npc.npctype == NPC_TYPE_MAGIC, npc.player_side == self_player_side)
			continue
		}

		if 0 == isfly && npc.isfly == 1 {
			log.Trace("GetInCircleEnemy npc[%d] continue fly ", npc.Id, isfly, npc.isfly == 1)
			continue
		}

		if if_area_hit(npc.x-npc.buidradius/2, npc.y+npc.buidradius/2, npc.buidradius, npc.buidradius,
			inleft, intop, inradius, inradius) {
			ret_map[npc.Id] = npc
			if this.skill_target_count >= this.skill_target_max {
				this.skill_target_max = 2 * this.skill_target_max
				tmp_targets := make([]*Npc, this.skill_target_max)
				for idx := int32(0); idx < int32(len(this.skill_target_cache)); idx++ {
					tmp_targets[idx] = this.skill_target_cache[idx]
				}
				this.skill_target_cache = tmp_targets
			}
			this.skill_target_cache[this.skill_target_count] = npc
			this.skill_target_count++
			log.Info("增加目标[%d]到缓存中[%d]", npc.Id, this.skill_target_count, this.skill_target_max, len(this.skill_target_cache))
		} else {
			log.Trace("GetInCircleEnemy npc[%d] continue not hit my(%f,%f,%f) npc(%f,%f,%f)", npc.Id, x, y, inradius, npc.x, npc.y, npc.buidradius)
		}
	}
	log.Trace("GetInCircleEnemy ===========end")
	return
}

func (this *FightRoom) _add_npc(npc *Npc) {
	if nil == npc {
		log.Error("FightRoom _add_npc failed !")
		return
	}
	this.id2npc[npc.Id] = npc
	if PLAYER_SIDE_BTM == npc.player_side {
		this.btm_npcs[this.btm_npc_num] = npc
		this.btm_npc_num++
		if this.btm_npc_num >= this.btm_npc_cur_max {
			this.btm_npc_cur_max = this.btm_npc_cur_max * 2
			new_npcs := make([]*Npc, this.btm_npc_cur_max)
			for idx := uint16(0); idx < this.btm_npc_num; idx++ {
				new_npcs[idx] = this.btm_npcs[idx]
			}
			this.btm_npcs = new_npcs
		}
	} else {
		this.top_npcs[this.top_npc_num] = npc
		this.top_npc_num++
		if this.top_npc_num >= this.top_npc_cur_max {
			this.top_npc_cur_max = this.top_npc_cur_max * 2
			new_npcs := make([]*Npc, this.top_npc_cur_max)
			for idx := uint16(0); idx < this.top_npc_num; idx++ {
				new_npcs[idx] = this.top_npcs[idx]
			}
			this.top_npcs = new_npcs
		}
	}
}

func (this *FightRoom) _remove_npc(npc *Npc) {
	delete(this.id2npc, npc.Id)
	var tmp_npc *Npc
	if PLAYER_SIDE_BTM == npc.player_side {
		for idx := uint16(0); idx < this.btm_npc_num; idx++ {
			tmp_npc = this.btm_npcs[idx]
			if tmp_npc == npc {
				if idx != this.btm_npc_num-1 {
					this.btm_npcs[idx] = this.btm_npcs[this.btm_npc_num-1]
				}
				this.btm_npc_num--
				break
			}
		}
	} else {
		for idx := uint16(0); idx < this.top_npc_num; idx++ {
			tmp_npc = this.top_npcs[idx]
			if tmp_npc == npc {
				if idx != this.top_npc_num-1 {
					this.top_npcs[idx] = this.top_npcs[this.top_npc_num-1]
				}
				this.top_npc_num--
				break
			}
		}
	}
}

func (this *FightRoom) call_npc(npc_cfg *ConfigNpc, x, y float32, call_count, npc_type, player_side, player_idx, call_lvl int32) {
	card_cfg := cfg_player_cards.Map[npc_cfg.ConfigId/100]
	if nil == card_cfg {
		log.Error("FightRoom call_npc failed to find card[%d]", npc_cfg.ConfigId/100)
		return
	}

	res_2cli := &msg_client_message.S2CMultiNpcAdd{}
	res_2cli.Npcs = make([]*msg_client_message.S2CNpcAdd, 0, call_count)
	var tmp_npcadd *msg_client_message.S2CNpcAdd
	for idx := int32(0); idx < call_count; idx++ {
		count := int32(0)
		tmp_npc := NewNpc(this.get_next_npc_id(), npc_cfg, -100, -100, npc_type, player_side, player_idx, call_lvl)
		if this.IfPosCanLoadArmy(x, y, tmp_npc.buidradius, tmp_npc.isfly) {
			this.set_npc_pos(tmp_npc, x, y)
			count++
		} else {
			var posx1, posx2, posy1, posy2 float32
			step := float32(1.0)
			for extra := float32(1); extra < MAX_LOAD_EXTRA; extra++ {
				posy1 = y + extra*step
				posy2 = y - extra*step
				log.Info("posy1 %v posy2 %v extra %v y%v", posy1, posy2, extra, y)
				for i := -extra; i <= extra; i++ {
					if this.IfPosCanLoadArmy(x+i*step, posy1, tmp_npc.buidradius, tmp_npc.isfly) {
						this.set_npc_pos(tmp_npc, x+i*step, posy1)
						count++
						break
					}
					if this.IfPosCanLoadArmy(x+i*step, posy2, tmp_npc.buidradius, tmp_npc.isfly) {
						this.set_npc_pos(tmp_npc, x+i*step, posy2)
						count++
						break
					}
				}
				if count >= 1 {
					break
				}

				//log.Info("try changeX===================")
				posx1 = x + extra*step
				posx2 = x - extra*step
				for i := -extra + 1; i <= extra-1; i++ {
					if this.IfPosCanLoadArmy(posx1, y+i*step, tmp_npc.buidradius, tmp_npc.isfly) {
						this.set_npc_pos(tmp_npc, posx1, y+i*step)
						count++
						break
					}

					if this.IfPosCanLoadArmy(posx2, y+i*step, tmp_npc.buidradius, tmp_npc.isfly) {
						this.set_npc_pos(tmp_npc, posx2, y+i*step)
						count++
						break
					}
				}
				if count >= 1 {
					break
				}
			}
		}

		if count >= 1 {
			this._add_npc(tmp_npc)
			if card_cfg.SkillId1 > 0 {
				first_skill_cfg := cfg_skill_mgr.Map[card_cfg.SkillId1]
				if nil != first_skill_cfg {
					tmp_npc.targetstrategy = first_skill_cfg.TargetStrategy
					tmp_npc.attackradius = first_skill_cfg.SkillRange + tmp_npc.hitradius/2
				}

				//log.Info("加载召唤NPC[%d]技能1[%d]", tmp_npc.Id, card_cfg.SkillId1)
				tmp_npc.LoadSkill(this, card_cfg.SkillId1, tmp_npc.npc_lvl)
			}

			if card_cfg.SkillId2 > 0 {
				//log.Info("加载召唤NPC[%d]技能2[%d]", tmp_npc.Id, card_cfg.SkillId2)
				tmp_npc.LoadSkill(this, card_cfg.SkillId2, tmp_npc.npc_lvl)
			}

			if card_cfg.SkillId3 > 0 {
				//log.Info("加载召唤NPC[%d]技能3[%d]", tmp_npc.Id, card_cfg.SkillId3)
				tmp_npc.LoadSkill(this, card_cfg.SkillId3, tmp_npc.npc_lvl)
			}

			if card_cfg.SkillId4 > 0 {
				//log.Info("加载召唤NPC[%d]技能4[%d]", tmp_npc.Id, card_cfg.SkillId4)
				tmp_npc.LoadSkill(this, card_cfg.SkillId4, tmp_npc.npc_lvl)
			}

			tmp_npcadd = &msg_client_message.S2CNpcAdd{}
			tmp_npcadd.CfgId = proto.Int32(tmp_npc.cfgid)
			tmp_npcadd.Id = proto.Int32(tmp_npc.Id)
			tmp_npcadd.CurHP = proto.Int32(tmp_npc.curhp)
			tmp_npcadd.CurX = proto.Float32(tmp_npc.x)
			tmp_npcadd.CurY = proto.Float32(tmp_npc.y)
			tmp_npcadd.PlayerIdx = proto.Int32(tmp_npc.player_side)
			tmp_npcadd.TargetX = proto.Float32(-1)
			tmp_npcadd.TargetY = proto.Float32(-1)
			res_2cli.Npcs = append(res_2cli.Npcs, tmp_npcadd)
		}
	}

	log.Info("召唤了%d个Npc", len(res_2cli.Npcs))
	for _, tmp_npc := range res_2cli.Npcs {
		log.Info("Npc[%d] 位置 (%f, %f)", tmp_npc.Id, tmp_npc.CurX, tmp_npc.CurY)
	}
	this.SendToAll(res_2cli)
}

func (this *FightRoom) reloadnpcs(npcs []*Npc, x, y float32, reason int32, msg *msg_client_message.S2CMultiNpcRelocate) {
	if nil == msg {
		log.Error("FightRoom reloadnpcs msg nil")
		return
	}
	for _, tmp_npc := range npcs {
		if this.IfPosCanLoadArmy(x, y, tmp_npc.buidradius, tmp_npc.isfly) {
			this.chang_npc_pos(tmp_npc, x, y, reason, msg)
			continue
		}

		var posx1, posx2, posy1, posy2 float32
		count := int32(0)
		for extra := float32(1); extra < MAX_LOAD_EXTRA; extra++ {
			posy1 = y + extra*tmp_npc.buidradius
			posy2 = y - extra*tmp_npc.buidradius
			log.Info("posy1 %v posy2 %v extra %v y%v", posy1, posy2, extra, y)
			for i := -extra; i <= extra; i++ {
				if this.IfPosCanLoadArmy(x+i*tmp_npc.buidradius, posy1, tmp_npc.buidradius, tmp_npc.isfly) {
					this.chang_npc_pos(tmp_npc, x+i*tmp_npc.buidradius, posy1, reason, msg)
					count++
					if count >= 1 {
						break
					}
				}
				if this.IfPosCanLoadArmy(x+i*tmp_npc.buidradius, posy2, tmp_npc.buidradius, tmp_npc.isfly) {
					this.chang_npc_pos(tmp_npc, x+i*tmp_npc.buidradius, posy2, reason, msg)
					count++
					if count >= 1 {
						break
					}
				}
			}
			if count >= 1 {
				break
			}

			//log.Info("try changeX===================")
			posx1 = x + extra*tmp_npc.buidradius
			posx2 = x - extra*tmp_npc.buidradius
			for i := -extra + 1; i <= extra-1; i++ {
				if this.IfPosCanLoadArmy(posx1, y+i*tmp_npc.buidradius, tmp_npc.buidradius, tmp_npc.isfly) {
					this.chang_npc_pos(tmp_npc, posx1, y+i*tmp_npc.buidradius, reason, msg)
					count++
					if count >= 1 {
						break
					}
				}

				if this.IfPosCanLoadArmy(posx2, y+i*tmp_npc.buidradius, tmp_npc.buidradius, tmp_npc.isfly) {
					this.chang_npc_pos(tmp_npc, posx2, y+i*tmp_npc.buidradius, reason, msg)
					count++
					if count >= 1 {
						break
					}
				}
			}
			if count >= 1 {
				break
			}
		}
	}
}

func (this *FightRoom) PlayerUseCard(card_use *PlayerCardUse) bool {
	this.room_end_lock.Lock()
	defer this.room_end_lock.Unlock()
	if ROOM_STATE_END == this.room_state {
		return false
	}

	this.use_card_chan <- card_use

	return true
}

func (this *FightRoom) on_player_carduse(card_use *PlayerCardUse) {
	if nil == card_use || nil == card_use.p {
		log.Error("FightRoom OnPlayerCardUse param error !")
		return
	}

	log.Info("房间[%d] 处理玩家[%d:%s]的使用卡片请求%v", this.room_id, card_use.p.Id, card_use.p.name, card_use.idx)

	res_2cli_use := &msg_client_message.S2CUseCardRes{}
	res_2cli_use.Idx = proto.Int32(card_use.idx)

	card := card_use.p.fighting_cards[card_use.idx]
	if nil == card {
		log.Error("FightRoom OnPlayerCardUse card nil")
		card_use.p.Send(res_2cli_use)
		return
	}

	card_cfg := cfg_player_cards.Map[card.CardId]
	if nil == card_cfg {
		log.Error("FightRoom OnPlayerCardUse can not find card cfg[%d]", card.CardId)
		card_use.p.Send(res_2cli_use)
		return
	}

	if card.bloading {
		log.Error("FightRoom OnPlayerCardUse card is loading !")
		card_use.p.Send(res_2cli_use)
		return
	}

	if card_use.p.point < card_cfg.LoadCost {
		log.Error("FightRoom OnPlayerCardUse card cost not enough !")
		card_use.p.Send(res_2cli_use)
		return
	}

	if card_cfg.IsMirror {
		last_card_cfg_id := card_use.p.last_use_card_cfgid
		if last_card_cfg_id <= 0 {
			log.Error("FightRoom OnPlayerCardUse card mirror no last card[%d] !", last_card_cfg_id)
			card_use.p.Send(res_2cli_use)
			return
		}

		last_card_cfg := cfg_player_cards.Map[last_card_cfg_id]
		if nil == last_card_cfg {
			log.Error("FightRoom OnPlayerCardUse card mirror last_card_cfg[%d] nil !", last_card_cfg_id)
			card_use.p.Send(res_2cli_use)
			return
		}

		if CARD_TYPE_MAGIC != last_card_cfg.Type && !cfg_loadarea_mgr.IfInTypeArea(card_use.p.load_area_type, card_use.x, card_use.y) {
			//if !cfg_map_mgr.IfInTypeArea(p.room.map_id, p.player_side, p.load_area_type, x, y) {
			log.Error("playeridx[%d] UseCard (x:%f, y:%f) not in type(%d) area !", card_use.p.player_side, card_use.x, card_use.y, card_use.p.load_area_type)
			card_use.p.Send(res_2cli_use)
			return
		}

		if card_use.p.point < card_cfg.LoadCost+last_card_cfg.LoadCost {
			log.Error("FightRoom OnPlayerCardUse card mirror last_card_cfg[%d] nil !")
			card_use.p.Send(res_2cli_use)
			return
		}

		val_idx := int64(card_cfg.SkillId1)*VAL_IDX_SKILL + int64(card_cfg.MirrorParams[last_card_cfg.Trait-1])*VAL_IDX_INDEX + int64(card.Lvl)
		//log.Info("====镜像卡Idx %d %d %v!", val_idx, last_card_cfg.Trait-1, card_cfg.MirrorParams)
		card_real_lvl := cfg_skillbuff_val_mgr.Idx2Values[val_idx]
		if 0 >= card_real_lvl {
			log.Error("FightRoom OnPlayerCardUse card mirrror real lvl[%d] error ! val_idx[%d]", card_real_lvl, val_idx)
			card_use.p.Send(res_2cli_use)
			return
		}

		card_use.p.point = card_use.p.point - (card_cfg.LoadCost + last_card_cfg.LoadCost)
		card.bloading = true
		card_use.create_nsec = time.Now().UnixNano()
		card_use.need_nsec = last_card_cfg.LoadNSec
		card_use.cardlvl = card_real_lvl
		card_use.cardid = last_card_cfg.ConfigId
		// 坐标需要在外面判断合法性
		// 填充到加载列表中
		for idx, val := range card_use.p.loading_slots {
			if nil == val || -1 == val.idx {
				card_use.p.loading_slots[idx] = card_use
				card_use.p.loading_cards_count++
				log.Info("房间[%d] 添加玩家[%d:%s]的使用卡片请求到预加载列表[%d]位置", this.room_id, card_use.p.Id, card_use.p.name, idx)
				break
			}
		}
	} else {
		if CARD_TYPE_MAGIC != card_cfg.Type && !cfg_loadarea_mgr.IfInTypeArea(card_use.p.load_area_type, card_use.x, card_use.y) {
			//if !cfg_map_mgr.IfInTypeArea(p.room.map_id, p.player_side, p.load_area_type, x, y) {
			log.Error("playeridx[%d] UseCard (x:%f, y:%f) not in type(%d) area !", card_use.p.player_side, card_use.x, card_use.y, card_use.p.load_area_type)
			card_use.p.Send(res_2cli_use)
			return
		}
		card_use.p.point -= card_cfg.LoadCost
		card.bloading = true
		card_use.create_nsec = time.Now().UnixNano()
		card_use.need_nsec = card_cfg.LoadNSec
		card_use.cardid = card_cfg.ConfigId
		card_use.cardlvl = card.Lvl
		card_use.p.last_use_card_cfgid = card_cfg.ConfigId
		// 坐标需要在外面判断合法性
		// 填充到加载列表中
		for idx, val := range card_use.p.loading_slots {
			if nil == val || -1 == val.idx {
				card_use.p.loading_slots[idx] = card_use
				card_use.p.loading_cards_count++
				log.Info("房间[%d] 添加玩家[%d:%s]的使用卡片请求到预加载列表[%d]位置", this.room_id, card_use.p.Id, card_use.p.name, idx)
				break
			}
		}
	}

	res_2cli_use.State = proto.Int32(1)
	res_2cli_use.CurPoint = proto.Int32(card_use.p.point)
	card_use.p.Send(res_2cli_use)
	return
}

func (this *FightRoom) _check_card_use(p *Player) {
	if nil == p {
		log.Error("FightRoom _check_card_use param error !")
		return
	}

	//log.Info("房间[%d]检查是否有卡片预加载时间到", this.roomid)
	cur_nsec := time.Now().UnixNano()
	for idx, val := range p.loading_slots {
		if nil == val || -1 == val.idx {
			continue
		}

		if cur_nsec-val.create_nsec > val.need_nsec {
			log.Info("房间[%d] 玩家[%d:%s]预加载卡片[%d]时间到！", this.room_id, val.p.Id, val.p.name, val.idx)
			this.DoCardUse(val)
			p.loading_slots[idx] = nil
			p.loading_cards_count--
		}
	}
}

// 加载卡片
func (this *FightRoom) DoCardUse(card_use *PlayerCardUse) {
	if nil == card_use || nil == card_use.p {
		log.Error("FightRoom DoCardUse card_use error !", nil == card_use)
		return
	}

	card := card_use.p.fighting_cards[card_use.idx]
	if nil == card {
		log.Trace("FightRoom DoCardUse card[%d] nil !", card_use.idx)
		return
	}

	cardid := card_use.cardid
	lvl := card_use.cardlvl
	card.bloading = false

	// 随机下一张卡
	tmp_p := card_use.p
	if tmp_p.next_fight_c_idx >= 0 && tmp_p.next_fight_c_idx < int32(len(tmp_p.resting_cards)) {
		tmp_p.fighting_cards[card_use.idx] = tmp_p.resting_cards[tmp_p.next_fight_c_idx]
		tmp_p.fighting_cards[card_use.idx].bloading = false
		if tmp_p.resting_lib_len > 0 {
			tmp_p.next_fight_c_idx++
			if tmp_p.next_fight_c_idx > tmp_p.resting_lib_len {
				tmp_p.next_fight_c_idx = 0
			}

			card.bloading = false
			tmp_p.resting_lib_cards[tmp_p.cur_rest_lib_idx] = card
			tmp_p.cur_rest_lib_idx++
			if tmp_p.cur_rest_lib_idx >= tmp_p.resting_lib_len {
				tmp_p.resting_cards[tmp_p.resting_lib_len] = tmp_p.resting_cards[tmp_p.next_fight_c_idx]
				tmp_p.next_fight_c_idx = tmp_p.resting_lib_len
				tmp_len := tmp_p.resting_lib_len
				rand_idx := int32(0)
				for idx := int32(0); idx < tmp_p.resting_lib_len; idx++ {
					rand_idx = rand.Int31n(tmp_len)
					tmp_p.resting_cards[idx] = tmp_p.resting_lib_cards[rand_idx]
					if rand_idx != tmp_len-1 {
						tmp_p.resting_lib_cards[rand_idx] = tmp_p.resting_lib_cards[tmp_len-1]
					}
					tmp_len--
				}
				tmp_p.cur_rest_lib_idx = 0
			}
		} else {
			tmp_p.resting_cards[tmp_p.next_fight_c_idx] = card
			tmp_p.next_fight_c_idx = rand.Int31n(tmp_p.rest_card_count)
		}

		res_2cli := &msg_client_message.S2CCardLoadEnd{}
		res_2cli.Idx = proto.Int32(card_use.idx)
		res_2cli.NextCardid = proto.Int32(tmp_p.resting_cards[tmp_p.next_fight_c_idx].CardId)
		card_use.p.Send(res_2cli)
	} else {
		log.Trace("加载卡片[%d]之后无法随机下一张卡片 next_c_idx(%d) rest_cards_count", card_use.idx, tmp_p.next_fight_c_idx, tmp_p.rest_card_count)
	}

	//log.Info("下一张卡片Id, ")
	card_cfg := cfg_player_cards.Map[cardid]
	if nil == card_cfg {
		log.Error("FightRoom LoadCard can not find card(%d) !", cardid)
		return
	} else {
		log.Info("load card[%d] %v", cardid, *card_cfg)
	}

	x := card_use.x
	y := card_use.y

	npccfgid := cardid*100 + lvl
	npc_cfg := cfg_npcs.Map[npccfgid]
	if nil == npc_cfg {
		log.Error("FightRoom LoadCard can not find npc(%d)", npccfgid)
		return
	}

	var tmp_npc *Npc
	if CARD_TYPE_ARMY == card_cfg.Type {
		count := int32(0)
		if this.IfPosCanLoadArmy(x, y, npc_cfg.PlaceSize, npc_cfg.IsFly) {
			npcid := this.get_next_npc_id()
			this.LoadNpc(npcid, cardid, lvl, x, y, tmp_p.player_side, tmp_p.Idx)
			count++
			if count >= card_cfg.NpcCount {
				return
			}
		}

		var posx1, posx2, posy1, posy2 float32
		for extra := float32(1); extra < MAX_LOAD_EXTRA; extra++ {
			posy1 = y + extra*npc_cfg.PlaceSize
			posy2 = y - extra*npc_cfg.PlaceSize
			log.Info("posy1 %v posy2 %v extra %v y%v", posy1, posy2, extra, y)
			for i := -extra; i <= extra; i++ {
				if this.IfPosCanLoadArmy(x+i*npc_cfg.PlaceSize, posy1, npc_cfg.PlaceSize, npc_cfg.IsFly) {
					npcid := this.get_next_npc_id()
					this.LoadNpc(npcid, cardid, lvl, x+i*npc_cfg.PlaceSize, posy1, tmp_p.player_side, tmp_p.Idx)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
				if this.IfPosCanLoadArmy(x+i*npc_cfg.PlaceSize, posy2, npc_cfg.PlaceSize, npc_cfg.IsFly) {
					npcid := this.get_next_npc_id()
					this.LoadNpc(npcid, cardid, lvl, x+i*npc_cfg.PlaceSize, posy2, tmp_p.player_side, tmp_p.Idx)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
			}
			if count >= card_cfg.NpcCount {
				break
			}

			//log.Info("try changeX===================")
			posx1 = x + extra*npc_cfg.PlaceSize
			posx2 = x - extra*npc_cfg.PlaceSize
			for i := -extra + 1; i <= extra-1; i++ {
				if this.IfPosCanLoadArmy(posx1, y+i*npc_cfg.PlaceSize, npc_cfg.PlaceSize, npc_cfg.IsFly) {
					npcid := this.get_next_npc_id()
					this.LoadNpc(npcid, cardid, lvl, posx1, y+i*npc_cfg.PlaceSize, tmp_p.player_side, tmp_p.Idx)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}

				if this.IfPosCanLoadArmy(posx2, y+i*npc_cfg.PlaceSize, npc_cfg.PlaceSize, npc_cfg.IsFly) {
					npcid := this.get_next_npc_id()
					this.LoadNpc(npcid, cardid, lvl, posx2, y+i*npc_cfg.PlaceSize, tmp_p.player_side, tmp_p.Idx)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
			}
			if count >= card_cfg.NpcCount {
				break
			}
		}
	} else if CARD_TYPE_BUILDING == card_cfg.Type {
		count := int32(0)
		if this.IfPosCanLoadBuilding(x, y, npc_cfg.PlaceSize) {
			npcid := this.get_next_npc_id()
			this.LoadNpc(npcid, cardid, lvl, x, y, tmp_p.player_side, tmp_p.Idx)
			count++
			if count >= card_cfg.NpcCount {
				return
			}
		}

		res_2cli := &msg_client_message.S2CMultiNpcRelocate{}
		res_2cli.NpcMoves = make([]*msg_client_message.S2CNpcRelocate, 0, card_cfg.NpcCount)

		var posx1, posx2, posy1, posy2 float32
		step := float32(1.0)
		for extra := float32(1); extra < MAX_LOAD_EXTRA; extra++ {
			posy1 = y + extra*step
			posy2 = y - extra*step
			log.Info("posy1 %v posy2 %v extra %v y%v", posy1, posy2, extra, y)
			for i := -extra; i <= extra; i++ {
				if this.IfPosCanLoadBuilding(x+i*step, posy1, npc_cfg.PlaceSize) {
					npcid := this.get_next_npc_id()
					tmp_npc = this.LoadNpc(npcid, cardid, lvl, x+i*step, posy1, tmp_p.player_side, tmp_p.Idx)
					in_npcs := this.GetInAreaLandArmy(tmp_npc.x, tmp_npc.y, tmp_npc.buidradius)
					this.reloadnpcs(in_npcs, tmp_npc.x, tmp_npc.y, NPC_RELOCATE_PUSH, res_2cli)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
				if this.IfPosCanLoadBuilding(x+i*step, posy2, npc_cfg.PlaceSize) {
					npcid := this.get_next_npc_id()
					tmp_npc := this.LoadNpc(npcid, cardid, lvl, x+i*step, posy2, tmp_p.player_side, tmp_p.Idx)
					in_npcs := this.GetInAreaLandArmy(tmp_npc.x, tmp_npc.y, tmp_npc.buidradius)
					this.reloadnpcs(in_npcs, tmp_npc.x, tmp_npc.y, NPC_RELOCATE_PUSH, res_2cli)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
			}
			if count >= card_cfg.NpcCount {
				break
			}

			//log.Info("try changeX===================")
			posx1 = x + extra*step
			posx2 = x - extra*step
			for i := -extra + 1; i <= extra-1; i++ {
				if this.IfPosCanLoadBuilding(posx1, y+i*step, npc_cfg.PlaceSize) {
					npcid := this.get_next_npc_id()
					tmp_npc := this.LoadNpc(npcid, cardid, lvl, posx1, y+i*step, tmp_p.player_side, tmp_p.Idx)
					in_npcs := this.GetInAreaLandArmy(tmp_npc.x, tmp_npc.y, tmp_npc.buidradius)
					this.reloadnpcs(in_npcs, tmp_npc.x, tmp_npc.y, NPC_RELOCATE_PUSH, res_2cli)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}

				if this.IfPosCanLoadBuilding(posx2, y+i*step, npc_cfg.PlaceSize) {
					npcid := this.get_next_npc_id()
					tmp_npc := this.LoadNpc(npcid, cardid, lvl, posx2, y+i*step, tmp_p.player_side, tmp_p.Idx)
					in_npcs := this.GetInAreaLandArmy(tmp_npc.x, tmp_npc.y, tmp_npc.buidradius)
					this.reloadnpcs(in_npcs, tmp_npc.x, tmp_npc.y, NPC_RELOCATE_PUSH, res_2cli)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
			}
			if count >= card_cfg.NpcCount {
				break
			}
		}
	} else if CARD_TYPE_MAGIC == card_cfg.Type {
		log.Info("技能卡释放！！！")
		if PLAYER_SIDE_BTM == tmp_p.player_side {
			king := this.id2npc[NORMAL_BTM_KING_NPC_ID]
			if nil == king {
				log.Trace("load mgaic card [%d] king miss", card_cfg.ConfigId)
				return
			}

			king.DirectCastSkill(this, card_cfg.SkillId1, -1, card_use.x, card_use.y)
		} else {
			king := this.id2npc[NORMAL_P2_KING_NPC_ID]
			if nil == king {
				log.Trace("load mgaic card [%d] king miss", card_cfg.ConfigId)
				return
			}

			king.DirectCastSkill(this, card_cfg.SkillId1, -1, card_use.x, card_use.y)
		}
	}

	return
}

func (this *FightRoom) LoadCardByCfgId(cardid, lvl int32, x, y float32, player_side, player_idx int32) {
	if lvl <= 0 {
		lvl = 1
		log.Error("FightRoom LoadCard lvl[%d] < 0", lvl)
	}

	card_cfg := cfg_player_cards.Map[cardid]
	if nil == card_cfg {
		log.Error("FightRoom LoadCard can not find card(%d) !", cardid)
		return
	} else {
		log.Info("load card[%d] %v", cardid, *card_cfg)
	}

	npccfgid := cardid*100 + lvl
	npc_cfg := cfg_npcs.Map[npccfgid]
	if nil == npc_cfg {
		log.Error("FightRoom LoadCard can not find npc(%d)", npccfgid)
		return
	}

	var tmp_npc *Npc
	if CARD_TYPE_ARMY == card_cfg.Type {
		count := int32(0)
		if this.IfPosCanLoadArmy(x, y, npc_cfg.PlaceSize, npc_cfg.IsFly) {
			npcid := this.get_next_npc_id()
			this.LoadNpc(npcid, cardid, lvl, x, y, player_side, player_idx)
			count++
			if count >= card_cfg.NpcCount {
				return
			}
		}

		var posx1, posx2, posy1, posy2 float32
		for extra := float32(1); extra < MAX_LOAD_EXTRA; extra++ {
			posy1 = y + extra*npc_cfg.PlaceSize
			posy2 = y - extra*npc_cfg.PlaceSize
			log.Info("posy1 %v posy2 %v extra %v y%v", posy1, posy2, extra, y)
			for i := -extra; i <= extra; i++ {
				if this.IfPosCanLoadArmy(x+i*npc_cfg.PlaceSize, posy1, npc_cfg.PlaceSize, npc_cfg.IsFly) {
					npcid := this.get_next_npc_id()
					this.LoadNpc(npcid, cardid, lvl, x+i*npc_cfg.PlaceSize, posy1, player_side, player_idx)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
				if this.IfPosCanLoadArmy(x+i*npc_cfg.PlaceSize, posy2, npc_cfg.PlaceSize, npc_cfg.IsFly) {
					npcid := this.get_next_npc_id()
					this.LoadNpc(npcid, cardid, lvl, x+i*npc_cfg.PlaceSize, posy2, player_side, player_idx)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
			}
			if count >= card_cfg.NpcCount {
				break
			}

			//log.Info("try changeX===================")
			posx1 = x + extra*npc_cfg.PlaceSize
			posx2 = x - extra*npc_cfg.PlaceSize
			for i := -extra + 1; i <= extra-1; i++ {
				if this.IfPosCanLoadArmy(posx1, y+i*npc_cfg.PlaceSize, npc_cfg.PlaceSize, npc_cfg.IsFly) {
					npcid := this.get_next_npc_id()
					this.LoadNpc(npcid, cardid, lvl, posx1, y+i*npc_cfg.PlaceSize, player_side, player_idx)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}

				if this.IfPosCanLoadArmy(posx2, y+i*npc_cfg.PlaceSize, npc_cfg.PlaceSize, npc_cfg.IsFly) {
					npcid := this.get_next_npc_id()
					this.LoadNpc(npcid, cardid, lvl, posx2, y+i*npc_cfg.PlaceSize, player_side, player_idx)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
			}
			if count >= card_cfg.NpcCount {
				break
			}
		}
	} else if CARD_TYPE_BUILDING == card_cfg.Type {
		count := int32(0)
		res_2cli := &msg_client_message.S2CMultiNpcRelocate{}
		res_2cli.NpcMoves = make([]*msg_client_message.S2CNpcRelocate, 0, card_cfg.NpcCount)
		if this.IfPosCanLoadBuilding(x, y, npc_cfg.PlaceSize) {
			npcid := this.get_next_npc_id()
			this.LoadNpc(npcid, cardid, lvl, x, y, player_side, player_idx)
			count++
			if count >= card_cfg.NpcCount {
				return
			}
		}

		var posx1, posx2, posy1, posy2 float32
		for extra := float32(1); extra < MAX_LOAD_EXTRA; extra++ {
			posy1 = y + extra*npc_cfg.PlaceSize
			posy2 = y - extra*npc_cfg.PlaceSize
			log.Info("posy1 %v posy2 %v extra %v y%v", posy1, posy2, extra, y)
			for i := -extra; i <= extra; i++ {
				if this.IfPosCanLoadBuilding(x+i*npc_cfg.PlaceSize, posy1, npc_cfg.PlaceSize) {
					npcid := this.get_next_npc_id()
					tmp_npc = this.LoadNpc(npcid, cardid, lvl, x+i*npc_cfg.PlaceSize, posy1, player_side, player_idx)
					in_npcs := this.GetInAreaLandArmy(tmp_npc.x, tmp_npc.y, tmp_npc.buidradius)
					this.reloadnpcs(in_npcs, tmp_npc.x, tmp_npc.y, NPC_RELOCATE_PUSH, res_2cli)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
				if this.IfPosCanLoadBuilding(x+i*npc_cfg.PlaceSize, posy2, npc_cfg.PlaceSize) {
					npcid := this.get_next_npc_id()
					tmp_npc := this.LoadNpc(npcid, cardid, lvl, x+i*npc_cfg.PlaceSize, posy2, player_side, player_idx)
					in_npcs := this.GetInAreaLandArmy(tmp_npc.x, tmp_npc.y, tmp_npc.buidradius)
					this.reloadnpcs(in_npcs, tmp_npc.x, tmp_npc.y, NPC_RELOCATE_PUSH, res_2cli)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
			}
			if count >= card_cfg.NpcCount {
				break
			}

			//log.Info("try changeX===================")
			posx1 = x + extra*npc_cfg.PlaceSize
			posx2 = x - extra*npc_cfg.PlaceSize
			for i := -extra + 1; i <= extra-1; i++ {
				if this.IfPosCanLoadBuilding(posx1, y+i*npc_cfg.PlaceSize, npc_cfg.PlaceSize) {
					npcid := this.get_next_npc_id()
					tmp_npc := this.LoadNpc(npcid, cardid, lvl, posx1, y+i*npc_cfg.PlaceSize, player_side, player_idx)
					in_npcs := this.GetInAreaLandArmy(tmp_npc.x, tmp_npc.y, tmp_npc.buidradius)
					this.reloadnpcs(in_npcs, tmp_npc.x, tmp_npc.y, NPC_RELOCATE_PUSH, res_2cli)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}

				if this.IfPosCanLoadBuilding(posx2, y+i*npc_cfg.PlaceSize, npc_cfg.PlaceSize) {
					npcid := this.get_next_npc_id()
					tmp_npc := this.LoadNpc(npcid, cardid, lvl, posx2, y+i*npc_cfg.PlaceSize, player_side, player_idx)
					in_npcs := this.GetInAreaLandArmy(tmp_npc.x, tmp_npc.y, tmp_npc.buidradius)
					this.reloadnpcs(in_npcs, tmp_npc.x, tmp_npc.y, NPC_RELOCATE_PUSH, res_2cli)
					count++
					if count >= card_cfg.NpcCount {
						break
					}
				}
			}
			if count >= card_cfg.NpcCount {
				break
			}
		}

		if len(res_2cli.NpcMoves) > 0 {
			this.SendToAll(res_2cli)
		}
	} else if CARD_TYPE_MAGIC == card_cfg.Type {
		var caster *Npc
		if PLAYER_SIDE_BTM == player_side {
			caster = this.id2npc[NORMAL_BTM_KING_NPC_ID]
		} else {
			caster = this.id2npc[NORMAL_BTM_KING_NPC_ID]
		}

		if nil == caster {
			log.Error("load magic card caster nil player idx[%d]", player_side)
			return
		}

		skillid := card_cfg.SkillId1
		skill_cfg := cfg_skill_mgr.Map[skillid]
		if nil == skill_cfg {
			log.Error("Npc DirectCastSkill[%d] not found !", skillid)
			return
		}

		var tmp_effect *SkillEffect
		if nil != skill_cfg.EffectInfos1 {
			tmp_effect = NewSkillEffectDirect(caster.Id, player_side, cardid, x, y, 0, x, y,
				skillid, lvl, skill_cfg, skill_cfg.EffectInfos1)
			tmp_effect.active_nsec = time.Now().UnixNano() + skill_cfg.DamageDelayNSec
			if !tmp_effect.DoEffect(this) {
				this.add_skill_effect(tmp_effect)
			}
		}
		if nil != skill_cfg.EffectInfos2 {
			tmp_effect = NewSkillEffectDirect(caster.Id, player_side, cardid, x, y, 0, x, y,
				skillid, lvl, skill_cfg, skill_cfg.EffectInfos2)
			tmp_effect.active_nsec = time.Now().UnixNano() + skill_cfg.DamageDelayNSec
			if !tmp_effect.DoEffect(this) {
				this.add_skill_effect(tmp_effect)
			}
		}
		if nil != skill_cfg.EffectInfos3 {
			tmp_effect = NewSkillEffectDirect(caster.Id, player_side, cardid, x, y, 0, x, y,
				skillid, lvl, skill_cfg, skill_cfg.EffectInfos3)
			tmp_effect.active_nsec = time.Now().UnixNano() + skill_cfg.DamageDelayNSec
			if !tmp_effect.DoEffect(this) {
				this.add_skill_effect(tmp_effect)
			}
		}

		res_2cli := &msg_client_message.S2CCastSkill{}
		res_2cli.NpcId = proto.Int32(caster.Id)
		res_2cli.SkillId = proto.Int32(skillid)
		res_2cli.TgtX = proto.Float32(x)
		res_2cli.TgtY = proto.Float32(y)
		res_2cli.SelfX = proto.Float32(caster.x)
		res_2cli.SelfY = proto.Float32(caster.y)

		this.SendToAll(res_2cli)
	}

	return
}

func (this *FightRoom) LoadNpc(npcid, carid, lvl int32, x, y float32, player_side, player_idx int32) *Npc {
	if lvl <= 0 {
		lvl = 1
		log.Error("FightRoom LoadNpc lvl[%d] < 0", lvl)
	}

	card_cfg := cfg_player_cards.Map[carid]
	if nil == card_cfg {
		log.Error("FightRoom LoadNpc can not find card(%d) !", carid)
		return nil
	}

	npccfgid := carid*100 + lvl
	npc_cfg := cfg_npcs.Map[npccfgid]
	if nil == npc_cfg {
		log.Error("FightRoom LoadNpc can not find npc(%d)", npccfgid)
		return nil
	}

	first_skill_cfg := cfg_skill_mgr.Map[card_cfg.SkillId1]
	if nil == first_skill_cfg && card_cfg.SkillId1 > 0 {
		log.Error("FightRoom LoadNpc can not find Skill1[%d]", card_cfg.SkillId1)
		return nil
	}

	new_npc := NewNpc(npcid, npc_cfg, x, y, card_cfg.Type, player_side, player_idx, lvl)
	if nil != first_skill_cfg {
		new_npc.targetstrategy = first_skill_cfg.TargetStrategy
		new_npc.attackradius = first_skill_cfg.SkillRange + new_npc.hitradius/2
	}

	new_npc.load_end_nsec = time.Now().UnixNano() + card_cfg.LoadNSec
	this._add_npc(new_npc) //this.id2npc[npcid] = new_npc

	res_2cli := &msg_client_message.S2CNpcAdd{}
	res_2cli.Id = proto.Int32(new_npc.Id)
	res_2cli.CfgId = proto.Int32(new_npc.cfgid)
	res_2cli.CurHP = proto.Int32(new_npc.curhp)
	res_2cli.CurX = proto.Float32(new_npc.x)
	res_2cli.CurY = proto.Float32(new_npc.y)
	res_2cli.PlayerIdx = proto.Int32(new_npc.player_side)

	this.SendToAll(res_2cli)

	if card_cfg.SkillId1 > 0 {
		new_npc.LoadSkill(this, card_cfg.SkillId1, lvl)
	}

	if card_cfg.SkillId2 > 0 {
		new_npc.LoadSkill(this, card_cfg.SkillId2, lvl)
	}

	if card_cfg.SkillId3 > 0 {
		new_npc.LoadSkill(this, card_cfg.SkillId3, lvl)
	}

	if card_cfg.SkillId4 > 0 {
		new_npc.LoadSkill(this, card_cfg.SkillId4, lvl)
	}

	return new_npc
}

func (this *FightRoom) set_npc_pos(npc *Npc, x, y float32) {
	npc.x = x
	npc.y = y
}

func (this *FightRoom) chang_npc_pos(npc *Npc, x, y float32, reason int32, msg *msg_client_message.S2CMultiNpcRelocate) {
	npc.x = x
	npc.y = y
	tmp_re := &msg_client_message.S2CNpcRelocate{}
	tmp_re.Id = proto.Int32(npc.Id)
	tmp_re.CurX = proto.Float32(x)
	tmp_re.CurY = proto.Float32(y)
	tmp_re.Type = proto.Int32(reason)
	if nil != npc.cur_target {
		tmp_re.TargetX = proto.Float32(npc.cur_target.x)
		tmp_re.TargetY = proto.Float32(npc.cur_target.y)
	} else if nil != npc.path_points {
		tmp_re.TargetX = proto.Float32(npc.path_points.fx)
		tmp_re.TargetY = proto.Float32(npc.path_points.fy)
	} else {
		tmp_re.TargetX = proto.Float32(npc.x)
		tmp_re.TargetY = proto.Float32(npc.y)
	}

}

func (this *FightRoom) add_skill_effect(effect *SkillEffect) {
	if nil == effect {
		log.Error("add_skill_effect failed effect nil !")
		return
	}

	this.next_skill_effect_id = this.next_skill_effect_id + 1
	if this.next_skill_effect_id <= 0 {
		this.next_skill_effect_id = 1
	}
	effect.idx = this.next_skill_effect_id

	this.id2skilleffet[effect.idx] = effect
	//log.Info("添加技能效果 %v %d", *effect, effect.card_id)

	/*
		if effect.active_nsec > 0 {
			res_2cli := &msg_client_message.S2CSkillEffect{}
			res_2cli.SkillId = proto.Int32(effect.skill_id)
			res_2cli.SrcNpcId = proto.Int32(effect.cast_npc_id)
			res_2cli.TgtNpcId = proto.Int32(effect.tgt_npc_id)
			res_2cli.TgtX = proto.Float32(effect.tgt_x)
			res_2cli.TgtY = proto.Float32(effect.tgt_y)
			res_2cli.CardId = proto.Int32(effect.card_id)
			this.SendToAll(res_2cli)
		}
	*/
}

func (this *FightRoom) on_create() {
	r_cfg := global_config.RoomCfg
	clen := float32(global_config.CellLen)
	k1 := this.LoadNpc(NORMAL_BTM_KING_NPC_ID, r_cfg.KingNpcCardCfgId, 1, r_cfg.P1KingPos.X*clen, r_cfg.P1KingPos.Y*clen, PLAYER_SIDE_BTM, 0)
	p1 := this.LoadNpc(NORMAL_BTM_PRINESS_L_ID, r_cfg.PrinecessCardCfgId, 1, r_cfg.P1PrincessLPos.X*clen, r_cfg.P1PrincessLPos.Y*clen, PLAYER_SIDE_BTM, 0)
	p2 := this.LoadNpc(NORMAL_BTM_PRINESS_R_ID, r_cfg.PrinecessCardCfgId, 1, r_cfg.P1PrincessRPos.X*clen, r_cfg.P1PrincessRPos.Y*clen, PLAYER_SIDE_BTM, 0)
	k1.load_end_nsec = time.Now().UnixNano() + global_config.RoomCfg.CreateOverNSec
	k1.dead_about_npcs = make([]int32, 2)
	k1.dead_about_npcs[0] = p1.Id
	k1.dead_about_npcs[1] = p2.Id
	p1.dead_about_npcs = make([]int32, 1)
	p1.dead_about_npcs[0] = k1.Id
	p1.dead_about_npcs = make([]int32, 1)
	p1.dead_about_npcs[0] = k1.Id

	k1 = this.LoadNpc(NORMAL_P2_KING_NPC_ID, r_cfg.KingNpcCardCfgId, 1, r_cfg.P2KingPos.X*clen, r_cfg.P2KingPos.Y*clen, PLAYER_SIDE_TOP, 1)
	p1 = this.LoadNpc(NORMAL_P2_PRINESS_L_ID, r_cfg.PrinecessCardCfgId, 1, r_cfg.P2PrincessLPos.X*clen, r_cfg.P2PrincessLPos.Y*clen, PLAYER_SIDE_TOP, 1)
	p2 = this.LoadNpc(NORMAL_P2_PRINESS_R_ID, r_cfg.PrinecessCardCfgId, 1, r_cfg.P2PrincessRPos.X*clen, r_cfg.P2PrincessRPos.Y*clen, PLAYER_SIDE_TOP, 1)
	k1.load_end_nsec = time.Now().UnixNano() + global_config.RoomCfg.CreateOverNSec
	k1.dead_about_npcs = make([]int32, 2)
	k1.dead_about_npcs[0] = p1.Id
	k1.dead_about_npcs[1] = p2.Id
	p1.dead_about_npcs = make([]int32, 1)
	p1.dead_about_npcs[0] = k1.Id
	p1.dead_about_npcs = make([]int32, 1)
	p1.dead_about_npcs[0] = k1.Id

	log.Trace("Room[%d] resultid[%d] on create", this.room_id, this.result_id)
}

func (this *FightRoom) on_create_test() {
	this.LoadCardByCfgId(1015, 1, 12, 52, PLAYER_SIDE_BTM, 0)
	this.LoadCardByCfgId(1001, 1, 10, 64, PLAYER_SIDE_TOP, 1)
	this.LoadCardByCfgId(1001, 1, 14, 64, PLAYER_SIDE_TOP, 1)
	this.LoadCardByCfgId(1001, 1, 18, 64, PLAYER_SIDE_TOP, 1)

	log.Trace("Room[%d] resultid[%d] on create", this.room_id, this.result_id)
}

func (this *FightRoom) print_npc_pos() {
	filename := fmt.Sprintf("./%d.xlsx", this.room_id)
	outfile, err := os.Create(filename)
	if nil != err {
		log.Error("FightRoom print_npc_pos create file(%s) failed !", filename)
		return
	}

	for _, npc := range this.id2npc {
		if nil == npc {
			continue
		}

		out_line := fmt.Sprintf("%f,%f\r\n", npc.x, npc.y)
		outfile.WriteString(out_line)
	}

	outfile.Close()
}

func (this *FightRoom) send_enter_res_to_p(p *Player) {
	if nil == p {
		log.Error("FightRoom send_enter_res_to_p p nil !")
		return
	}

	log.Info("FightRoom send_enter_res_to_p[%d:%s]", p.Id, p.name)

	res_2cli := &msg_client_message.S2CEnterRoomRes{}
	res_2cli.LeftSec = proto.Int32(global_config.RoomCfg.FightOverSecond - (int32(time.Now().Unix()) - this.start_time))

	res_2cli.OtherPlayers = make([]*msg_client_message.MatchPlayer, 0, int32(len(this.players)))
	var msg_other *msg_client_message.MatchPlayer
	for _, tmp_p := range this.players {
		if tmp_p == p {
			res_2cli.MyPlayerIdx = proto.Int32(tmp_p.player_side)
			res_2cli.CurPoints = proto.Int32(tmp_p.point)
			res_2cli.SlotCards = make([]int32, DEF_CARD_SLOT_NUM)
			for idx := int32(0); idx < DEF_CARD_SLOT_NUM; idx++ {
				if nil != tmp_p.fighting_cards[idx] {
					res_2cli.SlotCards[idx] = tmp_p.fighting_cards[idx].CardId
				}
			}
			if tmp_p.next_fight_c_idx >= 0 && tmp_p.next_fight_c_idx < int32(len(tmp_p.resting_cards)) && nil != tmp_p.resting_cards[tmp_p.next_fight_c_idx] {
				res_2cli.NextCardid = proto.Int32(tmp_p.resting_cards[tmp_p.next_fight_c_idx].CardId)
			} else {
				log.Error("send_enter_res_to_p own[%d] next_fight_c_idx(%d)", tmp_p.name, tmp_p.next_fight_c_idx, len(tmp_p.resting_cards))
			}
		} else {
			msg_other = &msg_client_message.MatchPlayer{}
			msg_other.Name = proto.String(tmp_p.name)
			msg_other.Lvl = proto.Int32(tmp_p.lvl)
			msg_other.Score = proto.Int32(tmp_p.score)
			msg_other.PlayerIdx = proto.Int32(tmp_p.player_side)
			msg_other.TongIcon = proto.Int32(tmp_p.tongicon)
			msg_other.TongName = proto.String(tmp_p.tongname)
			res_2cli.OtherPlayers = append(res_2cli.OtherPlayers, msg_other)
		}
	}

	res_2cli.Npcs = make([]*msg_client_message.S2CNpcAdd, 0, this.max_tower_npc_id)
	var msg_npc *msg_client_message.S2CNpcAdd
	var tmp_npc *Npc
	for id := int32(1); id <= this.max_tower_npc_id; id++ {
		tmp_npc = this.id2npc[id]
		if nil == tmp_npc {
			continue
		}

		msg_npc = &msg_client_message.S2CNpcAdd{}
		msg_npc.Id = proto.Int32(tmp_npc.Id)
		msg_npc.CfgId = proto.Int32(tmp_npc.cfgid)
		msg_npc.CurHP = proto.Int32(tmp_npc.curhp)
		msg_npc.CurX = proto.Float32(tmp_npc.x)
		msg_npc.CurY = proto.Float32(tmp_npc.y)
		msg_npc.PlayerIdx = proto.Int32(tmp_npc.player_side)
		if nil != tmp_npc.path_points {
			msg_npc.TargetX = proto.Float32(tmp_npc.path_points.fx)
			msg_npc.TargetY = proto.Float32(tmp_npc.path_points.fy)
		}
		res_2cli.Npcs = append(res_2cli.Npcs, msg_npc)
	}

	p.Send(res_2cli)

	log.Info("FightRoom send_enter_res_to_p[%d:%s]", p.Id, p.name)
}

func (this *FightRoom) PlayerIn(pin *PlayerLoginoutReady) bool {
	this.room_end_lock.RLock()
	defer this.room_end_lock.RUnlock()
	if ROOM_STATE_END == this.room_state {
		return false
	}

	this.loginout_chan <- pin

	return true
}

func (this *FightRoom) PlayerOut(pout *PlayerLoginoutReady) bool {
	this.room_end_lock.RLock()
	defer this.room_end_lock.RUnlock()
	if ROOM_STATE_END == this.room_state {
		return false
	}

	this.loginout_chan <- pout
	return true
}

func (this *FightRoom) on_player_in(p *Player) {
	if nil == p {
		log.Error("FightRoom on_player_in p nil")
		return
	}

	b_not_ready := false
	for idx, tmp_p := range this.players {
		if tmp_p == p {
			this.players_state[idx] = PLAYER_STATE_ENTERED_ROOM
		}

		if !this.players_ready[idx] {
			b_not_ready = true
		}
	}

	log.Trace("Room[%d] state[%d] on_player_in[%d] !!!", this.room_id, this.room_state, p.Id)

	switch this.room_state {
	case ROOM_STATE_CREATE:
		{
			this.first_conn_time = int32(time.Now().Unix())

			this.room_state = ROOM_STATE_FIRST_CONN
			return
		}
	case ROOM_STATE_FIRST_CONN:
		{
			log.Info("ROOM_STATE_FIRST_CONN**************************** cur state %v", this.players_state)

			if !b_not_ready {
				this.start_fight()
			}
			return
		}
	case ROOM_STATE_START:
		{
			this.send_enter_res_to_p(p)
			return
		}
	}

	return
}

func (this *FightRoom) on_player_out(p *Player) {
	if nil == p {
		log.Error("FightRoom on_player_out p nil")
		return
	}

	for idx, tmp_p := range this.players {
		if p == tmp_p {
			this.players_state[idx] = PLAYER_STATE_NOT_ENTER_ROOM
			this.players_ready[idx] = false
		}
	}

	return
}

func (this *FightRoom) on_player_ready(p *Player) {
	if nil == p {
		log.Error("FightRoom on_player_ready p nil !")
		return
	}

	for idx, tmp_p := range this.players {
		if p == tmp_p {
			this.players_ready[idx] = true
		}
	}

	res_2cli := &msg_client_message.S2CMultiNpcAdd{}
	res_2cli.Npcs = make([]*msg_client_message.S2CNpcAdd, 0, len(this.id2npc))
	var msg_npc *msg_client_message.S2CNpcAdd
	for _, tmp_npc := range this.id2npc {
		if nil == tmp_npc || tmp_npc.Id <= this.max_tower_npc_id {
			continue
		}

		msg_npc = &msg_client_message.S2CNpcAdd{}
		msg_npc.Id = proto.Int32(tmp_npc.Id)
		msg_npc.CfgId = proto.Int32(tmp_npc.cfgid)
		msg_npc.CurHP = proto.Int32(tmp_npc.curhp)
		msg_npc.CurX = proto.Float32(tmp_npc.x)
		msg_npc.CurY = proto.Float32(tmp_npc.y)
		msg_npc.PlayerIdx = proto.Int32(tmp_npc.player_side)
		if nil != tmp_npc.path_points {
			msg_npc.TargetX = proto.Float32(tmp_npc.path_points.fx)
			msg_npc.TargetY = proto.Float32(tmp_npc.path_points.fy)
		}
		res_2cli.Npcs = append(res_2cli.Npcs, msg_npc)
	}

	p.Send(res_2cli)

	return
}

func (this *FightRoom) on_npc_be_damage(npc *Npc) {
	if nil == npc {
		log.Error("FightRoom on_npc_be_damage npc nil !")
		return
	}

	if global_config.RoomCfg.KingNpcCardCfgId == npc.cfgid {
		tmp_king := this.id2npc[npc.Id]
		if nil != tmp_king {
			tmp_king.load_end_nsec = 0
		}
	}
}

func (this *FightRoom) on_npc_dead(npc *Npc) {
	//log.Info("on_npc_dead === %d  %d", global_config.RoomCfg.KingNpcCardCfgId, npc.cfgid)
	var tmp_npc *Npc
	if global_config.RoomCfg.KingNpcCardCfgId == npc.cardid {
		if PLAYER_SIDE_BTM == npc.player_side {
			this.top_score++
		} else {
			this.btm_score++
		}

		log.Info("p1_king_npc dead about %v", npc.dead_about_npcs)
		for _, tmp_npc_id := range npc.dead_about_npcs {
			tmp_npc = this.id2npc[tmp_npc_id]
			if nil != tmp_npc {
				log.Info("p1_king_npc dead about [%d] [%d]", tmp_npc.Id, tmp_npc.curhp)
				tmp_npc.curhp = 0
			}
		}
	}

	if global_config.RoomCfg.PrinecessCardCfgId == npc.cardid {
		if PLAYER_SIDE_BTM == npc.player_side {
			this.top_score++
		} else {
			this.btm_score++
		}

		for _, tmp_npc_id := range npc.dead_about_npcs {
			tmp_npc = this.id2npc[tmp_npc_id]
			if nil != tmp_npc {
				tmp_npc.load_end_nsec = 0
			}
		}
	}

	if this.top_score >= this.end_fight_score || this.btm_score >= this.end_fight_score {
		this.end_fight()
	}
}

func (this *FightRoom) start_fight() {
	this.room_state = ROOM_STATE_START
	this.start_time = int32(time.Now().Unix())
	for idx, tmp_p := range this.players {
		if PLAYER_STATE_ENTERED_ROOM == this.players_state[idx] {
			this.send_enter_res_to_p(tmp_p)
		}
	}

	log.Trace("Room[%d] state[%d] start_fight ", this.room_id, this.room_state)

	return
}

func (this *FightRoom) end_fight() {
	this.room_state = ROOM_STATE_END
	res_2cli := &msg_client_message.S2CFightEnd{}
	this.SendToAll(res_2cli)
}

func (this *FightRoom) time_over() {
	this.room_state = ROOM_STATE_END
	log.Trace("Room[%d] time over !", this.room_id)
	res_2cli := &msg_client_message.S2CFightEnd{}
	this.SendToAll(res_2cli)
}

func (this *FightRoom) _realse() {
	for idx := 0; idx < len(this.players); idx++ {
		this.players[idx] = nil
	}
	close(this.use_card_chan)
	close(this.loginout_chan)
	close(this.close_chan)
}

func (this *FightRoom) on_room_end() {
	log.Trace("FightRoom[%d] on_room_end [rid:%d] !!", this.room_id, this.result_id)
	res_2m := &msg_server_message.R2MFightResult{}
	res_2m.ResultId = proto.Int32(this.result_id)
	res_2m.P1Towers = proto.Int32(int32(this.btm_score))
	res_2m.P2Towers = proto.Int32(int32(this.top_score))
	res_2m.MatchType = proto.Int32(this.room_type)
	if this.btm_score == this.top_score {
		res_2m.Result = proto.Int32(FIGHT_RESULT_EQUAL)
	} else if this.btm_score > this.top_score {
		res_2m.Result = proto.Int32(FIGHT_RESULT_P1_WIN)
	} else {
		res_2m.Result = proto.Int32(FIGHT_RESULT_P2_WIN)
	}
	match_conn.Send(res_2m)
	fight_room_mgr.remove_room(this.room_id)
	for _, tmp_p := range this.players {
		player_mgr.RemoveFromIdMap(tmp_p.Id)
	}

	this._realse()
}

func (this *FightRoom) _player_point_check() {
	if ROOM_STATE_START != this.room_state {
		return
	}

	for _, tmp_p := range this.players {
		if tmp_p.point >= global_config.RoomCfg.MaxPoint {
			tmp_p.last_point_chg_nsec = 0
		} else {
			if 0 == tmp_p.last_point_chg_nsec {
				tmp_p.last_point_chg_nsec = time.Now().UnixNano()
			} else {
				if time.Now().UnixNano()-tmp_p.last_point_chg_nsec > global_config.RoomCfg.PointUpNSec {
					tmp_p.last_point_chg_nsec += global_config.RoomCfg.PointUpNSec
					tmp_p.point += global_config.RoomCfg.PointUpVal
					res := &msg_client_message.S2CPointChg{}
					res.Point = proto.Int32(tmp_p.point)
					tmp_p.Send(res)

					//log.Info("圣水变化 当前纳秒%d 上次纳秒%d 差值%d 配置%d", time.Now().UnixNano(), this.p1.last_point_chg_nsec, time.Now().UnixNano()-this.p1.last_point_chg_nsec, global_config.RoomCfg.PointUpNSec)
				}
			}
		}
	}
}

func (this *FightRoom) _skill_effect_check() {
	overidxs := make(map[int32]bool)
	for idx, eff := range this.id2skilleffet {
		if nil == eff {
			continue
		}

		//log.Info("技能[%d]效果[%d]检查====================1", eff.skill_id, eff.effectinfo.EffectType)
		if eff.DoEffect(this) {
			overidxs[idx] = true
		}
	}

	for idx, _ := range overidxs {
		delete(this.id2skilleffet, idx)
	}
}

func (this *FightRoom) _npcs_sort() {
	// 排序npc

	var pre_npc, tmp_npc *Npc
	for i := int32(0); i < 3600; i++ {
		bswap := false
		for idx := uint16(1); idx < this.btm_npc_num; idx++ {
			pre_npc = this.btm_npcs[idx-1]
			if nil == pre_npc {
				log.Error("_npc_move_check btm npcs have nil !")
				continue
			}
			tmp_npc = this.btm_npcs[idx]
			if nil == tmp_npc {
				log.Error("_npc_move_check btm npcs have nil !")
				continue
			}

			if tmp_npc.y > pre_npc.y {
				this.btm_npcs[idx-1] = tmp_npc
				this.btm_npcs[idx] = pre_npc
				bswap = true
			}
		}
		if !bswap {
			break
		}
	}

	for i := int32(0); i < 3600; i++ {
		bswap := false
		for idx := uint16(1); idx < this.top_npc_num; idx++ {
			pre_npc = this.top_npcs[idx-1]
			if nil == pre_npc {
				log.Error("_npc_move_check top npcs have nil !")
				continue
			}
			tmp_npc = this.top_npcs[idx]
			if nil == tmp_npc {
				log.Error("_npc_move_check top npcs have nil !")
				continue
			}

			if tmp_npc.y < pre_npc.y {
				this.top_npcs[idx-1] = tmp_npc
				this.top_npcs[idx] = pre_npc
				bswap = true
			}
		}
		if !bswap {
			break
		}
	}
}

func (this *FightRoom) _npc_check() {

	remove_npcs := make(map[int32]*Npc)
	remove_buffs := make(map[int32]int32)

	cur_nsec := time.Now().UnixNano()

	this.cur_npc_info = &msg_client_message.S2CNpcSync{}
	this.cur_npc_info.NpcMoves = make([]*msg_client_message.NpcMoveInfo, 0, len(this.id2npc))

	var tmp_npc *Npc
	for idx := uint16(0); idx < this.btm_npc_num; idx++ {
		tmp_npc = this.btm_npcs[idx]
		if nil == tmp_npc {
			continue
		}

		if tmp_npc.curhp <= 0 {
			remove_npcs[tmp_npc.Id] = tmp_npc
		}

		if cur_nsec < tmp_npc.load_end_nsec {
			continue
		}

		tmp_npc.isattacking = false
		tmp_npc._buff_check(this, remove_buffs)
		tmp_npc._ground_ai_check(this)
	}

	for idx := uint16(0); idx < this.top_npc_num; idx++ {
		tmp_npc = this.top_npcs[idx]
		if nil == tmp_npc {
			continue
		}

		if tmp_npc.curhp <= 0 {
			remove_npcs[tmp_npc.Id] = tmp_npc
		}

		if cur_nsec < tmp_npc.load_end_nsec {
			continue
		}

		tmp_npc._buff_check(this, remove_buffs)
		tmp_npc._ground_ai_check(this)
	}

	/*
		for npcid, tmp_npc := range this.id2npc {
			if nil == tmp_npc {
				continue
			}

			if tmp_npc.curhp <= 0 {
				remove_npcs[npcid] = tmp_npc
			}

			if cur_nsec < tmp_npc.load_end_nsec {
				continue
			}

			tmp_npc._ground_ai_check(this)
			tmp_npc._buff_check(this, remove_buffs)
		}
	*/

	if len(remove_npcs) > 0 {
		res_2cli := &msg_client_message.S2CNpcRemove{}
		res_2cli.NpcIds = make([]int32, 0, len(remove_npcs))
		for id, tmp_npc := range remove_npcs {
			this.on_npc_dead(tmp_npc)
			tmp_npc._buff_death_check(this)
			this._remove_npc(tmp_npc) //delete(this.id2npc, id)
			res_2cli.NpcIds = append(res_2cli.NpcIds, id)
		}

		this.SendToAll(res_2cli)
	}

	if len(remove_buffs) > 0 {
		res_2cli := &msg_client_message.S2CMultiNpcBuffRemove{}
		res_2cli.Buffs = make([]*msg_client_message.S2CRemoveBuff, 0, len(remove_buffs))
		var tmp_rm *msg_client_message.S2CRemoveBuff
		for buffid, npcid := range remove_buffs {
			tmp_rm = &msg_client_message.S2CRemoveBuff{}
			tmp_rm.BuffId = proto.Int32(buffid)
			tmp_rm.NpcId = proto.Int32(npcid)
			res_2cli.Buffs = append(res_2cli.Buffs, tmp_rm)
		}
	}
}

func (this *FightRoom) _npc_move_check() {
	//log.Info("FightRoom _npc_move_check")
	this.cur_npc_info = &msg_client_message.S2CNpcSync{}
	this.cur_npc_info.NpcMoves = make([]*msg_client_message.NpcMoveInfo, 0, len(this.id2npc))

	var tmp_npc *Npc
	for idx := uint16(0); idx < this.btm_npc_num; idx++ {
		tmp_npc = this.btm_npcs[idx]
		if nil == tmp_npc {
			continue
		}

		tmp_npc._do_ground_move(this)
	}

	for idx := uint16(0); idx < this.top_npc_num; idx++ {
		tmp_npc = this.top_npcs[idx]
		if nil == tmp_npc {
			continue
		}

		tmp_npc._do_ground_move(this)
	}
	/*
		for _, tmp_npc = range this.id2npc {
			if nil == tmp_npc {
				continue
			}

			tmp_npc._do_ground_move(this)
		}
	*/

	if len(this.cur_npc_info.NpcMoves) > 0 {
		this.SendToAll(this.cur_npc_info)
	}
}

func (this *FightRoom) _npc_buff_check() {
	remove_buffs := make(map[int32]int32)
	for _, tmp_npc := range this.id2npc {
		if nil == tmp_npc {
			continue
		}

		tmp_npc._buff_check(this, remove_buffs)
	}

	if len(remove_buffs) > 0 {
		res_2cli := &msg_client_message.S2CMultiNpcBuffRemove{}
		res_2cli.Buffs = make([]*msg_client_message.S2CRemoveBuff, 0, len(remove_buffs))
		var tmp_rm *msg_client_message.S2CRemoveBuff
		for buffid, npcid := range remove_buffs {
			tmp_rm = &msg_client_message.S2CRemoveBuff{}
			tmp_rm.BuffId = proto.Int32(buffid)
			tmp_rm.NpcId = proto.Int32(npcid)
			res_2cli.Buffs = append(res_2cli.Buffs, tmp_rm)
		}
	}
}

func (this *FightRoom) _room_ai_check() {
	cur_unix := int32(time.Now().Unix())
	if cur_unix-this.last_ai_check_unix < 2 {
		return
	}

	this.last_ai_check_unix = cur_unix

	if ROOM_STATE_START != this.room_state {
		return
	}

	tmp_p := this.players[1]
	if tmp_p.Id >= 0 || nil == cfg_map_mgr.mapid2mapdata[this.map_id] || cfg_map_mgr.mapid2mapdata[this.map_id].P2AIPoints_Len < 1 {
		return
	}

	if this.ai_wait_sec > 0 {
		this.ai_wait_sec--
		return
	}

	var card_cfg *XmlPlayerCard
	var tmp_pos *XmlXYPos
	for idx, val := range tmp_p.fighting_cards {
		card_cfg = cfg_player_cards.Map[val.CardId]
		if nil == card_cfg {
			continue
		}

		if tmp_p.point >= card_cfg.LoadCost {
			tmp_pos = this.map_data.get_random_p2ai_pos()
			this.on_player_carduse(&PlayerCardUse{idx: int32(idx), p: tmp_p, x: tmp_pos.X, y: tmp_pos.Y})
		}
	}
}

func (this *FightRoom) _time_over_check() bool {
	this.time_over_frame++
	if this.time_over_frame < ROOM_TIME_OVER_CHECK_FRAME {
		return false
	}

	this.time_over_frame = 0
	now_t := int32(time.Now().Unix())
	switch this.room_state {
	case ROOM_STATE_CREATE:
		{
			if now_t-this.create_time > global_config.RoomCfg.CreateOverSecond {
				this.time_over()
				return true
			}
		}
	case ROOM_STATE_FIRST_CONN:
		{
			if now_t-this.first_conn_time > global_config.RoomCfg.FirstConnWaitSecond {
				this.start_fight()
				return false
			}
		}
	case ROOM_STATE_START:
		{
			if now_t-this.start_time > global_config.RoomCfg.FightOverSecond {
				this.end_fight()
				return false
			}
		}
	default:
		{
			this.time_over()
			log.Error("_time_over_check wrong state %d", this.room_state)
			return true
		}
	}

	return false
}

func (this *FightRoom) _room_end_check() bool {
	if ROOM_STATE_END == this.room_state {
		return true
	}

	return false
}

func (this *FightRoom) _room_state_switch() {

}

func (this *FightRoom) Start() {
	log.Trace("FightRoom[%d] start !!", this.room_id)
	go this.run()
}

func (this *FightRoom) run() {
	defer func() {
		if err := recover(); err != nil {
			log.Stack(err)
		}

		this.on_room_end()
		log.Trace("Room[%d] run stop ", this.room_id)

		time.Sleep(2 * time.Second)
	}()

	this.ticker = timer.NewTickTimer(50)
	this.ticker.Start()
	defer this.ticker.Stop()

	for {
		select {
		case _, ok := <-this.ticker.Chan:
			{
				if !ok {
					log.Trace("Room[%d] ticker_chan return", this.room_id)
					return
				}

				begin := time.Now()
				if this._room_end_check() {
					log.Trace("Room[%d] state[%d] _room_end_check return", this.room_id, this.room_state)
					return
				}
				this._time_over_check()
				this._room_ai_check()
				this._player_point_check()
				for _, tmp_p := range this.players {
					this._check_card_use(tmp_p)
				}
				this._skill_effect_check()
				this._npcs_sort()
				this._npc_check()
				this._npcs_sort()
				this._npc_move_check()

				//this._npc_move_check()
				//this._npc_remove_check()

				time_cost := time.Now().Sub(begin).Seconds()
				if time_cost > 1 {
					log.Trace("房间[%d]耗时 %v", this.room_id, time_cost)
					if time_cost > 30 {
						log.Error("房间[%d]耗时 %v", this.room_id, time_cost)
					}
				}
			}
		case loginout, ok := <-this.loginout_chan:
			{
				if !ok {
					log.Trace("Room[%d] loginout_chan return", this.room_id)
					return
				}

				if PLAYER_LOGIN_OUT_READY_IN == loginout.inout {
					this.on_player_in(loginout.p)
				} else if PLAYER_LOGIN_OUT_READY_OUT == loginout.inout {
					this.on_player_out(loginout.p)
				} else if PLAYER_LOGIN_OUT_READY_READY == loginout.inout {
					this.on_player_ready(loginout.p)
				}
			}
		case c_u, ok := <-this.use_card_chan:
			{
				if !ok {
					log.Trace("Room[%d] use_card_chan return", this.room_id)
					return
				}

				this.on_player_carduse(c_u)
			}
		case _, _ = <-this.close_chan:
			{
				log.Trace("Room[%d] use_card_chan return", this.room_id)
				return
			}
		}
	}
}
