package main

import (
	"encoding/json"
	"io/ioutil"
	"libs/log"
)

type JsonPos struct {
	X float32
	Y float32
}

type RoomConfig struct {
	CreateOverSecond    int32
	CreateOverNSec      int64
	FirstConnWaitSecond int32
	FightOverSecond     int32
	KingNpcCardCfgId    int32
	PrinecessCardCfgId  int32
	P1KingPos           *JsonPos
	P1PrincessLPos      *JsonPos
	P1PrincessRPos      *JsonPos
	P2KingPos           *JsonPos
	P2PrincessLPos      *JsonPos
	P2PrincessRPos      *JsonPos
	MaxPoint            int32 // 最大点数
	PointUpMSec         int64 // 点数涨的间隔毫秒
	PointUpNSec         int64 // 点数涨的间隔纳秒
	PointUpVal          int32 // 每次点数涨的值
}

type GlobalConfig struct {
	PlayerInitCards  []int32
	RoomCfg          *RoomConfig
	CellLen          int32
	MirrorCardCfgIds []int32
	FowardMSec       int32 // 冲锋需要连续运动毫秒数
	FowardNSec       int64 // 冲锋需要连续运动纳秒数
	FowardBuffCfgId  int32 // 冲锋加的buffId
	CardLoadNSec     int64 // 卡片加载需要的纳秒
}

var global_config GlobalConfig

func global_config_load() bool {
	data, err := ioutil.ReadFile("../game_data/global.json")
	if nil != err {
		log.Error("global_config_load failed to readfile err(%s)!", err.Error())
		return false
	}

	err = json.Unmarshal(data, &global_config)
	if nil != err {
		log.Error("global_config_load json unmarshal failed err(%s)!", err.Error())
		return false
	}

	global_config.RoomCfg.PointUpNSec = global_config.RoomCfg.PointUpMSec * 1000000
	global_config.FowardNSec = int64(global_config.FowardMSec) * 1000000
	global_config.RoomCfg.CreateOverNSec = int64(global_config.RoomCfg.CreateOverSecond) * 1000000000

	return true
}
