package main

import (
	"libs/log"
	"public_message/gen_go/client_message"
	"time"

	"3p/code.google.com.protobuf/proto"
)

const (
	SKILL_EFFECT_TYPE_NORMAL_DAMAGE    = 1  // 普通伤害
	SKILL_EFFECT_TYPE_BUILDING_DAMAGE  = 2  // 对塔伤害
	SKILL_EFFECT_TYPE_ADD_BUFF         = 3  // 加buff
	SKILL_EFFECT_TYPE_CALL_ARMY        = 5  // 召唤
	SKILL_EFFECT_TYPE_PUSH             = 6  // 击退
	SKILL_EFFECT_TYPE_JUMP             = 9  // 跳跃
	SKILL_EFFECT_TYPE_SELF_BOMB        = 10 // 自爆 这个纯粹减少自己所有HP
	SKILL_EFFECT_TYPE_COPY_ARMY        = 13 // 复制
	SKILL_EFFECT_TYPE_MULTI_SEC_DAMAGE = 14 // 多段伤害
	SKILL_EFFECT_TYPE_GET_POINT        = 15 // 获得圣水
	SKILL_EFFECT_TYPE_SUB_SKILL        = 16 // 子技能
	SKILL_EFFECT_TYPE_MIRROR           = 17 // 镜像

	SKILL_LAST_NOR       = 1 // 普通
	SKILL_LAST_MY_PER_T  = 2 // 自身持续定时间 间隔生效
	SKILL_LAST_NOR_COUNT = 3 // 普通持续 生效次数
	SKILL_LAST_NOR_PER_T = 4 // 普通持续 间隔生效
	SKILL_LAST_SELF      = 5 // 被动

	SKILL_TARGET_ENEMY  = 1 // 敌人
	SKILL_TARGET_FRIEND = 2 // 友军
	SKILL_TARGET_SELF   = 3 // 对自己放

	SKILL_RANGE_SINGLE        = 1 // 单个目标
	SKILL_RANGE_SELF_CIRCLE   = 2 // 自身圆形范围
	SKILL_RANGE_TARGET_CIRCLE = 3 // 目标圆形范围
	SKILL_RANGE_PUSH_FORWARD  = 4 // 推进

	NPC_HP_CHOOSE_RAND = 0 // 随机选择
	NPC_HP_CHOOSE_OVER = 1 // 选择血多的
	NPC_HP_CHOOSE_LESS = 2 // 选择血少的

	MAX_NPC_CHOOSE_NUM = 999

	VAL_IDX_SKILL = 1000000
	VAL_IDX_INDEX = 100
)

type SkillEffect struct {
	idx          int32            // 唯一id
	active_nsec  int64            // 延迟到的纳秒
	last_do_nsec int64            // 上一次生效时间
	cur_do_count int32            // 当前生效次数
	cast_npc_id  int32            // 释放NPC 如果不存在，就使用下面的X Y坐标
	cast_x       float32          // 释放者x
	cast_y       float32          // 释放者Y
	player_side  int32            // 所属的玩家Idx
	player_idx   int32            // 所属的玩家side
	tgt_npc_id   int32            // 目标NPC 如果不存在，就使用下面的X Y坐标
	tgt_x        float32          // 目标X
	tgt_y        float32          // 目标Y
	card_id      int32            // 卡片Id
	skill_id     int32            // 技能Id
	skill_lvl    int32            // 技能等级
	skill_cfg    *XmlSkill        // 技能配置
	effectinfo   *EffectModeParam // 效果信息
	dmg          int32            // 基础伤害
	dmg_adjust   int32            // 伤害调整
	effect_npcs  map[int32]int32  // 生效过的npc
}

func NewSkillEffect(caster *Npc, tgt_npc_id int32, tgt_x, tgt_y float32, skillid, skilllvl int32, skill_cfg *XmlSkill, effectinfo *EffectModeParam) *SkillEffect {
	if nil == skill_cfg || nil == effectinfo || nil == caster {
		log.Error("NewSkillEffect failed !", nil == skill_cfg, nil == effectinfo)
		return nil
	}
	ret_effect := &SkillEffect{}
	ret_effect.skill_id = skillid
	ret_effect.skill_lvl = skilllvl
	ret_effect.skill_cfg = skill_cfg
	ret_effect.effectinfo = effectinfo
	ret_effect.tgt_npc_id = tgt_npc_id
	ret_effect.cast_npc_id = caster.Id
	ret_effect.cast_x = caster.x
	ret_effect.cast_y = caster.y
	ret_effect.player_side = caster.player_side
	ret_effect.player_idx = caster.player_idx
	ret_effect.tgt_x = tgt_x
	ret_effect.tgt_y = tgt_y
	ret_effect.card_id = caster.cardid
	if 2 == caster.isforward {
		log.Trace("释放者在冲锋 ！！ 设置伤害加成 %d", caster.forwarddmgadd)
		ret_effect.dmg_adjust = caster.forwarddmgadd
	}

	//log.Info("NewSkillEffect !!!", caster.Id, caster.player_side, tgt_npc_id, tgt_x, tgt_y, skillid, skilllvl, skill_cfg, effectinfo, ret_effect.dmg)

	return ret_effect
}

func NewSkillEffectDirect(casterid, player_side, card_id int32, cast_x, cast_y float32, tgt_npc_id int32, tgt_x, tgt_y float32, skillid, skilllvl int32, skill_cfg *XmlSkill, effectinfo *EffectModeParam) *SkillEffect {
	if nil == skill_cfg || nil == effectinfo {
		log.Error("NewSkillEffect failed !", nil == skill_cfg, nil == effectinfo)
		return nil
	}
	ret_effect := &SkillEffect{}
	ret_effect.skill_id = skillid
	ret_effect.skill_lvl = skilllvl
	ret_effect.skill_cfg = skill_cfg
	ret_effect.effectinfo = effectinfo
	ret_effect.tgt_npc_id = tgt_npc_id
	ret_effect.cast_npc_id = casterid
	ret_effect.cast_x = cast_x
	ret_effect.cast_y = cast_y
	ret_effect.player_side = player_side
	ret_effect.tgt_x = tgt_x
	ret_effect.tgt_y = tgt_y
	ret_effect.card_id = card_id

	//log.Info("NewSkillEffect !!!", caster.Id, caster.player_idx, tgt_npc_id, tgt_x, tgt_y, skillid, skilllvl, skill_cfg, effectinfo, ret_effect.dmg)

	return ret_effect
}

func (this *SkillEffect) DoEffect(room *FightRoom) (bover bool) {
	cur_nsec := time.Now().UnixNano()
	if cur_nsec < this.active_nsec {
		//log.Trace("技能[%d]效果[%d] 时间还没到 还差%d毫秒", this.skill_id, this.effectinfo.EffectType, (this.active_nsec-cur_nsec)/1000000)
		return
	} else if 0 >= this.active_nsec {
		this.active_nsec = cur_nsec
	}

	cur_left_nsec := int64(0)
	switch this.skill_cfg.EffectLParam.LastType {
	case SKILL_LAST_NOR:
		{
			log.Trace("技能[%d]效果[%d] 为普通攻击效果 ！！", this.skill_id, this.effectinfo.EffectType)
			bover = true
		}
	case SKILL_LAST_NOR_COUNT:
		{
			if len(this.skill_cfg.EffectLParam.Params) < 2 {
				log.Error("技能[%d]效果[%d]SKILL_LAST_NOR_COUNT持续信息参数不够 ！", this.skill_id, this.effectinfo.EffectType)
				return true
			}

			if this.last_do_nsec > 0 && cur_nsec-this.last_do_nsec < int64(this.skill_cfg.EffectLParam.Params[0]*1000000) {
				return
			} else {
				this.last_do_nsec = cur_nsec
			}

			this.cur_do_count++
			if this.cur_do_count >= this.skill_cfg.EffectLParam.Params[1] {
				bover = true
			}

			log.Info("技能[%d]效果[%d] 为持续次数效果 cur_do_count[%d  %d] ！！", this.skill_id, this.effectinfo.EffectType, this.cur_do_count, this.skill_cfg.EffectLParam.Params[1])
		}
	case SKILL_LAST_MY_PER_T:
		fallthrough
	case SKILL_LAST_NOR_PER_T:
		{
			if len(this.skill_cfg.EffectLParam.Params) < 2 {
				log.Info("技能[%d]效果[%d]SKILL_LAST_NOR_COUNT持续信息参数不够 ！", this.skill_id, this.effectinfo.EffectType)
				return true
			}
			if this.last_do_nsec > 0 && cur_nsec-this.last_do_nsec < int64(this.skill_cfg.EffectLParam.Params[0]*1000000) {
				return
			} else {
				this.last_do_nsec = cur_nsec
			}

			cur_left_nsec = int64(this.skill_cfg.EffectLParam.Params[1])*1000000 - (cur_nsec - this.active_nsec)
			if cur_left_nsec <= 0 {
				bover = true
			}

			log.Info("技能[%d]效果[%d] 为持续时间效果 cur_left_nsec[%d] ！！ bover[%v]", this.skill_id, this.effectinfo.EffectType, cur_left_nsec, bover)
		}
	case SKILL_LAST_SELF:
		{
			bover = true
		}
	default:
		{
			log.Error("技能[%d]效果[%d] 持续类型错误 !", this.skill_id, this.effectinfo.EffectType)
			return true
		}
	}

	npcs := make(map[int32]*Npc)
	room.skill_target_count = 0
	npc_hp_choose := int32(NPC_HP_CHOOSE_RAND)
	max_npc_num := int32(MAX_NPC_CHOOSE_NUM)
	switch this.skill_cfg.EffectRParam.RangeType {
	case SKILL_RANGE_SINGLE:
		{
			//log.Trace("选取目标 范围类型 单体")
			if SKILL_TARGET_ENEMY == this.skill_cfg.TargetType {
				tmp_npc := room.id2npc[this.tgt_npc_id]
				if nil == tmp_npc {
					log.Trace("普通技能效果对敌人 目标缺失")
					return true
				}
				npcs[tmp_npc.Id] = tmp_npc
				room.skill_target_cache[0] = tmp_npc
				room.skill_target_count++
			} else if SKILL_TARGET_SELF == this.skill_cfg.TargetType {
				tmp_npc := room.id2npc[this.cast_npc_id]
				if nil == tmp_npc {
					log.Trace("普通技能效果对自己 目标[%d]缺失", this.cast_npc_id)
					return true
				}
				npcs[tmp_npc.Id] = tmp_npc
				room.skill_target_cache[0] = tmp_npc
				room.skill_target_count++
			} else if SKILL_TARGET_FRIEND == this.skill_cfg.TargetType {
				tmp_npc := room.id2npc[this.cast_npc_id]
				if nil == tmp_npc {
					log.Trace("普通技能效果对友军的单体技能 目标[%d]缺失", this.cast_npc_id)
					return true
				}
				npcs[tmp_npc.Id] = tmp_npc
				room.skill_target_cache[0] = tmp_npc
				room.skill_target_count++
			}
		}
	case SKILL_RANGE_SELF_CIRCLE:
		{
			if len(this.skill_cfg.EffectRParam.Params) < 4 {
				log.Error("Do Skill[%d] SKILL_RANGE_SELF_CIRCLE less param[%d]", this.skill_id, len(this.skill_cfg.EffectRParam.Params))
				return
			}

			max_npc_num = this.skill_cfg.EffectRParam.Params[2]
			npc_hp_choose = this.skill_cfg.EffectRParam.Params[3]
			//log.Trace("选取目标 范围类型 自身园")
			self_x := this.cast_x
			self_y := this.cast_y
			self_npc := room.id2npc[this.cast_npc_id]
			if nil != self_npc {
				log.Trace("技能效果 自己圆 自己[%d]", this.cast_npc_id)
				self_x = self_npc.x
				self_y = self_npc.y
			}

			if SKILL_TARGET_ENEMY == this.skill_cfg.TargetType {
				npcs = room.GetInCircleEnemy(self_x, self_y, float32(this.skill_cfg.EffectRParam.Params[0]), this.skill_cfg.EffectRParam.Params[1], this.player_side)
			} else if SKILL_TARGET_SELF == this.skill_cfg.TargetType {
				if nil != self_npc {
					npcs[self_npc.Id] = self_npc
				}
			} else if SKILL_TARGET_FRIEND == this.skill_cfg.TargetType {
				npcs = room.GetInCircleFriend(self_y, self_y, float32(this.skill_cfg.EffectRParam.Params[0]), this.skill_cfg.EffectRParam.Params[1], this.player_side)
			}
		}
	case SKILL_RANGE_TARGET_CIRCLE:
		{
			if len(this.skill_cfg.EffectRParam.Params) < 4 {
				log.Error("Do Skill[%d] SKILL_RANGE_TARGET_CIRCLE less param[%d]!", this.skill_id, len(this.skill_cfg.EffectRParam.Params))
				return
			}

			max_npc_num = this.skill_cfg.EffectRParam.Params[2]
			npc_hp_choose = this.skill_cfg.EffectRParam.Params[3]
			//log.Trace("选取目标 范围类型 目标[%d]圆形", this.tgt_npc_id)
			var tgt_x, tgt_y float32
			if this.tgt_npc_id > 0 {
				tgt_npc := room.id2npc[this.tgt_npc_id]
				if nil == tgt_npc {
					tgt_x = this.tgt_x
					tgt_y = this.tgt_y
				} else {
					tgt_x = tgt_npc.x
					tgt_y = tgt_npc.y
				}
			} else {
				tgt_x = this.tgt_x
				tgt_y = this.tgt_y
			}
			if SKILL_TARGET_ENEMY == this.skill_cfg.TargetType {
				npcs = room.GetInCircleEnemy(tgt_x, tgt_y, float32(this.skill_cfg.EffectRParam.Params[0]), this.skill_cfg.EffectRParam.Params[1], this.player_side)
			} else if SKILL_TARGET_SELF == this.skill_cfg.TargetType {
				log.Error("目标范围内的自己，这种组合不应该存在")
				return true
			} else if SKILL_TARGET_FRIEND == this.skill_cfg.TargetType {
				npcs = room.GetInCircleFriend(tgt_x, tgt_y, float32(this.skill_cfg.EffectRParam.Params[0]), this.skill_cfg.EffectRParam.Params[1], this.player_side)
			}
		}
	case SKILL_RANGE_PUSH_FORWARD:
		{
			if len(this.skill_cfg.EffectRParam.Params) < 6 {
				log.Error("Do skill[%d] Effect range SKILL_RANGE_PUSH_FORWARD less param[%d]", this.skill_id, len(this.skill_cfg.EffectRParam.Params))
				return
			}

			roll_speed := this.skill_cfg.EffectRParam.Params[2]

			max_npc_num = this.skill_cfg.EffectRParam.Params[4]
			npc_hp_choose = this.skill_cfg.EffectRParam.Params[5]

			if SKILL_TARGET_SELF == this.skill_cfg.TargetType || SKILL_TARGET_FRIEND == this.skill_cfg.TargetType {
				log.Error("Do skill[%d] Effect range SKILL_RANGE_PUSH_FORWARD target_self !", this.skill_id)
				return
			}

			past_sec := float32(float64(cur_nsec-this.active_nsec) / 1000000000)
			if past_sec <= 0 {
				return
			}

			if nil == this.effect_npcs {
				this.effect_npcs = make(map[int32]int32)
			}

			area_y := this.tgt_y
			if PLAYER_SIDE_BTM == this.player_side {
				area_y = this.tgt_y + past_sec*float32(roll_speed)
			} else {
				area_y = this.tgt_y - past_sec*float32(roll_speed)
			}

			inleft := this.tgt_x - float32(this.skill_cfg.EffectRParam.Params[0])/2
			intop := area_y - float32(this.skill_cfg.EffectRParam.Params[1])/2

			log.Info("滚木效果, 已经过去%f 宽度[%f, %f] 长度[%f, %f, %f] ", past_sec, this.tgt_x, float32(this.skill_cfg.EffectRParam.Params[0])/2, this.tgt_y, float32(this.skill_cfg.EffectRParam.Params[1])/2)
			for npcid, tmp_npc := range room.id2npc {
				if nil == tmp_npc || NPC_TYPE_MAGIC == tmp_npc.npctype {
					continue
				}

				if tmp_npc.isfly != this.skill_cfg.EffectRParam.Params[3] {
					log.Info("滚木选取Npc 飞行不匹配 %d %d", tmp_npc.isfly, this.skill_cfg.EffectRParam.Params[3])
					continue
				}

				if this.player_side == tmp_npc.player_side {
					log.Info("滚木选取Npc player_side不匹配 %d %d", this.player_side, tmp_npc.player_side)
					continue
				}

				if 0 != this.effect_npcs[npcid] {
					continue
				}

				if !if_area_hit(inleft, intop, float32(this.skill_cfg.EffectRParam.Params[0]), float32(this.skill_cfg.EffectRParam.Params[1]),
					tmp_npc.x-tmp_npc.hitradius/2, tmp_npc.y+tmp_npc.hitradius/2, tmp_npc.hitradius, tmp_npc.hitradius) {
					log.Info("滚木选取Npc[%d,%f,%f] 未碰到 [%f,%f,%f,%f]!", tmp_npc.Id, tmp_npc.x, tmp_npc.y, inleft, intop, float32(this.skill_cfg.EffectRParam.Params[0]), float32(this.skill_cfg.EffectRParam.Params[1]))
					continue
				}

				log.Info("滚木选取Npc[%d,%f,%f] 成功", tmp_npc.Id, tmp_npc.x, tmp_npc.y)
				this.effect_npcs[npcid] = 1
				npcs[npcid] = tmp_npc
				if room.skill_target_count >= room.skill_target_max {
					room.skill_target_max = 2 * room.skill_target_max
					tmp_targets := make([]*Npc, room.skill_target_max)
					for idx := int32(0); idx < int32(len(room.skill_target_cache)); idx++ {
						tmp_targets[idx] = room.skill_target_cache[idx]
					}
					room.skill_target_cache = tmp_targets
				}
				room.skill_target_cache[room.skill_target_count] = tmp_npc
				room.skill_target_count++
			}
		}
	}

	if room.skill_target_count < 1 && this.effectinfo.EffectType != SKILL_EFFECT_TYPE_CALL_ARMY { //if len(npcs) < 1 {
		log.Trace("检查技能[%d]效果[%d] effectInfo(%v) 没有目标)", this.skill_id, this.effectinfo.EffectType, this.effectinfo.Params)
		return
	}

	var tmp_npc *Npc

	if max_npc_num < room.skill_target_count { // || NPC_HP_CHOOSE_RAND == npc_hp_choose
		var min_val, min_idx int32
		room.skill_target_count = max_npc_num
		if NPC_HP_CHOOSE_LESS == npc_hp_choose {
			for count := int32(0); count < max_npc_num; count++ {
				for idx := count; idx < room.skill_target_count; idx++ {
					tmp_npc = room.skill_target_cache[idx]
					if tmp_npc.curhp < min_val {
						min_idx = idx
						min_val = tmp_npc.curhp
					}
				}
				if min_idx > -1 && min_idx != count {
					tmp_npc = room.skill_target_cache[count]
					room.skill_target_cache[count] = room.skill_target_cache[min_idx]
					room.skill_target_cache[min_idx] = tmp_npc
				}
			}
		} else if NPC_HP_CHOOSE_OVER == npc_hp_choose {
			for count := int32(0); count < max_npc_num; count++ {
				min_val = int32(999999)
				min_idx = int32(-1)
				for idx := count; idx < room.skill_target_count; idx++ {
					tmp_npc = room.skill_target_cache[idx]
					if tmp_npc.curhp < min_val {
						min_idx = idx
						min_val = tmp_npc.curhp
					}
				}
				if min_idx > -1 && min_idx != count {
					tmp_npc = room.skill_target_cache[count]
					room.skill_target_cache[count] = room.skill_target_cache[min_idx]
					room.skill_target_cache[min_idx] = tmp_npc
				}
			}
		}
	}

	log.Info("检查技能[%d]效果[%d] effectInfo(%v) 有%d个目标NPC(%v)", this.skill_id, this.effectinfo.EffectType, this.effectinfo.Params, room.skill_target_count, room.skill_target_cache)
	switch this.effectinfo.EffectType {
	case SKILL_EFFECT_TYPE_NORMAL_DAMAGE:
		{
			if len(this.effectinfo.Params) < 1 {
				log.Error("SkillEffect DoEffect 对军队的攻击 less param count !")
				return true
			}

			idx := int64(this.skill_id)*VAL_IDX_SKILL + int64(this.effectinfo.Params[0])*VAL_IDX_INDEX + int64(this.skill_lvl)
			dmg := cfg_skillbuff_val_mgr.Idx2Values[idx] * (10000 + this.dmg_adjust) / 10000
			//log.Info("对军队伤害%d %d 加成%d", idx, dmg, this.dmg_adjust)
			res_2cli := &msg_client_message.S2CMultiNpcHpChg{}
			res_2cli.HpChgs = make([]*msg_client_message.S2CNpcHpChg, 0, int32(len(npcs)))
			var tmp_hpchg *msg_client_message.S2CNpcHpChg
			for idx := int32(0); idx < room.skill_target_count; idx++ { //for _, tmp_npc := range npcs {
				tmp_npc = room.skill_target_cache[idx]
				if nil == tmp_npc || NPC_TYPE_BUILDING == tmp_npc.npctype {
					continue
				}

				tmp_npc.curhp = tmp_npc.curhp - dmg
				room.on_npc_be_damage(tmp_npc)
				tmp_hpchg = &msg_client_message.S2CNpcHpChg{}
				tmp_hpchg.CurHP = proto.Int32(tmp_npc.curhp)
				tmp_hpchg.NpcId = proto.Int32(tmp_npc.Id)
				res_2cli.HpChgs = append(res_2cli.HpChgs, tmp_hpchg)
			}

			if len(res_2cli.GetHpChgs()) > 0 {
				room.SendToAll(res_2cli)
			}

			caster := room.id2npc[this.cast_npc_id]
			if nil != caster {
				caster.cur_tgt_atk_count++
			}
		}
	case SKILL_EFFECT_TYPE_BUILDING_DAMAGE:
		{
			if len(this.effectinfo.Params) < 1 {
				log.Error("SkillEffect DoEffect SKILL_EFFECT_BUILDING_DAMAGE less param count !")
				return true
			}

			idx := int64(this.skill_id)*VAL_IDX_SKILL + int64(this.effectinfo.Params[0])*VAL_IDX_INDEX + int64(this.skill_lvl)
			dmg := cfg_skillbuff_val_mgr.Idx2Values[idx] * (10000 + this.dmg_adjust) / 10000
			//log.Info("对建筑伤害%d %d 加成%d", idx, dmg, this.dmg_adjust)
			res_2cli := &msg_client_message.S2CMultiNpcHpChg{}
			res_2cli.HpChgs = make([]*msg_client_message.S2CNpcHpChg, 0, int32(len(npcs)))
			var tmp_hpchg *msg_client_message.S2CNpcHpChg
			for idx := int32(0); idx < room.skill_target_count; idx++ { //for _, tmp_npc := range npcs {
				tmp_npc = room.skill_target_cache[idx]
				if nil == tmp_npc || NPC_TYPE_ARMY == tmp_npc.npctype {
					continue
				}

				tmp_npc.curhp = tmp_npc.curhp - dmg
				room.on_npc_be_damage(tmp_npc)
				//log.Info("建筑Npc 掉血 当前血量%d", tmp_npc.curhp)
				tmp_hpchg = &msg_client_message.S2CNpcHpChg{}
				tmp_hpchg.CurHP = proto.Int32(tmp_npc.curhp)
				tmp_hpchg.NpcId = proto.Int32(tmp_npc.Id)
				res_2cli.HpChgs = append(res_2cli.HpChgs, tmp_hpchg)
			}

			if len(res_2cli.GetHpChgs()) > 0 {
				room.SendToAll(res_2cli)
			}

			caster := room.id2npc[this.cast_npc_id]
			if nil != caster {
				caster.cur_tgt_atk_count++
			}
		}
	case SKILL_EFFECT_TYPE_ADD_BUFF:
		{
			if len(this.effectinfo.Params) < 3 {
				log.Error("SkillEffect DoEffect SKILL_EFFECT_ADD_BUFF less param count !")
				return true
			}

			//log.Info("[%d]====================技能效果加buff[%d]", this.cast_npc_id, this.effectinfo.Params[0])

			last_nsec := int64(this.effectinfo.Params[1]+this.effectinfo.Params[2]*this.skill_lvl) * 1000000

			for idx := int32(0); idx < room.skill_target_count; idx++ { //for _, tmp_npc := range npcs {
				tmp_npc = room.skill_target_cache[idx]
				if nil == tmp_npc {
					continue
				}

				tmp_npc.AddBuff(room, this.effectinfo.Params[0], last_nsec)
			}
		}
	case SKILL_EFFECT_TYPE_CALL_ARMY:
		{
			if len(this.effectinfo.Params) < 3 {
				log.Error("SkillEffect DoEffect SKILL_EFFECT_TYPE_CALL_ARMY !")
				return true
			}

			call_lvl := this.skill_lvl + this.effectinfo.Params[2]
			if call_lvl < 1 {
				call_lvl = 1
			}

			call_id := this.effectinfo.Params[0]
			npc_id := call_id*100 + call_lvl
			call_count := this.effectinfo.Params[1]
			if call_count <= 0 {
				log.Error("SkillEffect DoEffect SKILL_EFFECT_TYPE_CALL_ARMY card_count(%d) <=0", call_count)
				return true
			}

			card_cfg := cfg_player_cards.Map[call_id]
			if nil == card_cfg {
				log.Error("SkillEffect DoEffect SKILL_EFFECT_TYPE_CALL_ARMY can not find card(%d)", call_id)
				return true
			}

			npc_cfg := cfg_npcs.Map[npc_id]
			if nil == npc_cfg {
				log.Error("SkillEffect DoEffect SKILL_EFFECT_TYPE_CALL_ARMY %d no config", npc_id)
				return true
			}

			self_npc := room.id2npc[this.cast_npc_id]
			if nil == self_npc {
				log.Error("SkillEffect DoEffect SKILL_EFFECT_TYPE_CALL_ARMY self_npc nil !")
				return true
			}

			if SKILL_RANGE_TARGET_CIRCLE == this.skill_cfg.EffectRParam.RangeType {
				room.call_npc(npc_cfg, this.tgt_x, this.tgt_y, call_count, card_cfg.Type, this.player_side, this.player_idx, call_lvl)
			} else {
				if PLAYER_SIDE_BTM == self_npc.player_side {
					room.call_npc(npc_cfg, self_npc.x+1, self_npc.y+self_npc.buidradius/2+card_cfg.Placesize/2+1, call_count, card_cfg.Type, this.player_side, this.player_idx, call_lvl)
				} else {
					room.call_npc(npc_cfg, self_npc.x+1, self_npc.y-self_npc.buidradius/2-card_cfg.Placesize/2-1, call_count, card_cfg.Type, this.player_side, this.player_idx, call_lvl)
				}
			}
		}
	case SKILL_EFFECT_TYPE_PUSH: // 滚木击退
		{
			if len(this.effectinfo.Params) < 1 {
				log.Error("SkillEffect 击退效果参数少于1个 !")
				return true
			}

			back_dis := float32(this.effectinfo.Params[0])
			if PLAYER_SIDE_TOP == this.player_side {
				back_dis = -back_dis
			}
			log.Info("击退效果 距离:%f", back_dis)

			effected_npcs := make(map[int32]*Npc)
			for idx := int32(0); idx < room.skill_target_count; idx++ { //for _, tmp_npc := range npcs {
				tmp_npc = room.skill_target_cache[idx]
				if nil == tmp_npc || tmp_npc.Id == this.cast_npc_id || NPC_TYPE_BUILDING == tmp_npc.npctype {
					log.Info("击退判断1不满足!!!!!")
					continue
				}

				new_y := tmp_npc.y + back_dis
				pushed_npcs := make(map[int32]*Npc)
				if !room._push_npc(tmp_npc, tmp_npc.x, new_y, pushed_npcs, false) {
					log.Info("推人失败!!!!!")
					continue
				} else {
					log.Info("推人成功!!!!!")
					tmp_npc.AddBuff(room, 30000001, 500000000)
					tmp_npc.y = new_y
					tmp_npc.path_points = nil
					effected_npcs[tmp_npc.Id] = tmp_npc
					for _, tmp_p_npc := range pushed_npcs {
						effected_npcs[tmp_p_npc.Id] = tmp_p_npc
					}
				}
			}

			res_push := &msg_client_message.S2CMultiNpcRelocate{}
			res_push.NpcMoves = make([]*msg_client_message.S2CNpcRelocate, 0, len(effected_npcs))
			for _, tmp_npc := range effected_npcs {
				tmp_re := &msg_client_message.S2CNpcRelocate{}
				tmp_re.Id = proto.Int32(tmp_npc.Id)
				tmp_re.Type = proto.Int32(NPC_RELOCATE_PUSH)
				tmp_re.CurX = proto.Float32(tmp_npc.x)
				tmp_re.CurY = proto.Float32(tmp_npc.y)
				if nil != tmp_npc.cur_target {
					tmp_re.TargetX = proto.Float32(tmp_npc.cur_target.x)
					tmp_re.TargetY = proto.Float32(tmp_npc.cur_target.y)
				} else if nil != tmp_npc.path_points {
					tmp_re.TargetX = proto.Float32(tmp_npc.path_points.fx)
					tmp_re.TargetY = proto.Float32(tmp_npc.path_points.fy)
				} else {
					tmp_re.TargetX = proto.Float32(tmp_npc.x)
					tmp_re.TargetY = proto.Float32(tmp_npc.y)
				}
				res_push.NpcMoves = append(res_push.NpcMoves, tmp_re)
			}

			room.SendToAll(res_push)
		}
	case SKILL_EFFECT_TYPE_JUMP:
		{
			log.Info("跳跃效果")
			for idx := int32(0); idx < room.skill_target_count; idx++ { //for _, tmp_npc := range npcs {
				tmp_npc = room.skill_target_cache[idx]
				if nil == tmp_npc || NPC_TYPE_BUILDING == tmp_npc.npctype {
					continue
				}

				tmp_npc.isjump = 1
			}
		}
	case SKILL_EFFECT_TYPE_SELF_BOMB:
		{
			log.Info("自爆效果")
			for idx := int32(0); idx < room.skill_target_count; idx++ { //for _, tmp_npc := range npcs {
				tmp_npc = room.skill_target_cache[idx]
				if nil == tmp_npc {
					continue
				}

				tmp_npc.curhp = -1
			}
		}
	case SKILL_EFFECT_TYPE_MIRROR:
		{
			log.Error("释放技能中不应该有镜像效果！")
		}
	case SKILL_EFFECT_TYPE_COPY_ARMY:
		{
			cp_npcs := make([]*Npc, 0, len(npcs))
			var cp_npc *Npc
			for idx := int32(0); idx < room.skill_target_count; idx++ { //for _, tmp_npc := range npcs {
				tmp_npc = room.skill_target_cache[idx]
				if nil == tmp_npc {
					continue
				}

				cp_npc = NewNpc(room.get_next_npc_id(), cfg_npcs.Map[tmp_npc.cfgid], -1, -1, tmp_npc.npctype, tmp_npc.player_side, tmp_npc.player_idx, tmp_npc.npc_lvl)
				if nil == cp_npc {
					log.Trace("SkillEffect cp npc[%d] failed !", tmp_npc.Id)
					continue
				}
				cp_npcs = append(cp_npcs, cp_npc)
			}
			res_2cli := &msg_client_message.S2CMultiNpcRelocate{}
			res_2cli.NpcMoves = make([]*msg_client_message.S2CNpcRelocate, 0, len(npcs))
			room.reloadnpcs(cp_npcs, this.tgt_x, this.tgt_y, NPC_RELOCATE_COPY, res_2cli)
			room.SendToAll(res_2cli)
		}
	case SKILL_EFFECT_TYPE_MULTI_SEC_DAMAGE:
		{
			param_len := int32(len(this.effectinfo.Params))
			if param_len < 3 {
				log.Error("Skill[%d] SKILL_EFFECT_TYPE_MULTI_SEC_DAMAGE param error !", this.skill_id)
				return
			}

			var val_idx int64
			caster := room.id2npc[this.cast_npc_id]
			if nil != caster {
				val_idx = int64(this.skill_id)*VAL_IDX_SKILL + int64(this.effectinfo.Params[0])*VAL_IDX_INDEX + int64(this.skill_lvl)
				dmg := cfg_skillbuff_val_mgr.Idx2Values[val_idx]
				val_idx = int64(this.skill_id)*VAL_IDX_SKILL + int64(this.effectinfo.Params[1])*VAL_IDX_INDEX + int64(this.skill_lvl)
				dmg = dmg + caster.cur_tgt_atk_count*cfg_skillbuff_val_mgr.Idx2Values[val_idx]
				val_idx = int64(this.skill_id)*VAL_IDX_SKILL + int64(this.effectinfo.Params[1])*VAL_IDX_INDEX + int64(this.skill_lvl)
				if dmg > cfg_skillbuff_val_mgr.Idx2Values[val_idx] {
					dmg = cfg_skillbuff_val_mgr.Idx2Values[val_idx]
				}

				res_2cli := &msg_client_message.S2CMultiNpcHpChg{}
				res_2cli.HpChgs = make([]*msg_client_message.S2CNpcHpChg, 0, int32(len(npcs)))
				var tmp_hpchg *msg_client_message.S2CNpcHpChg
				for idx := int32(0); idx < room.skill_target_count; idx++ { //for _, tmp_npc := range npcs {
					tmp_npc = room.skill_target_cache[idx]
					if nil == tmp_npc {
						continue
					}

					tmp_npc.curhp = tmp_npc.curhp - dmg
					room.on_npc_be_damage(tmp_npc)
					tmp_hpchg = &msg_client_message.S2CNpcHpChg{}
					tmp_hpchg.CurHP = proto.Int32(tmp_npc.curhp)
					tmp_hpchg.NpcId = proto.Int32(tmp_npc.Id)
					res_2cli.HpChgs = append(res_2cli.HpChgs, tmp_hpchg)
				}

				if len(res_2cli.GetHpChgs()) > 0 {
					room.SendToAll(res_2cli)
				}

				caster.cur_tgt_atk_count++
			}
		}
	case SKILL_EFFECT_TYPE_GET_POINT:
		{
			if len(this.effectinfo.Params) < 1 {
				log.Error("npc[%d] skill[%d] get point effect param error !", this.cast_npc_id, this.skill_id)
				return
			}

			res_2cli := &msg_client_message.S2CPointChg{}
			p := room.players[this.player_idx]
			if nil != p {
				p.point += this.effectinfo.Params[0]
				if room.players_ready[this.player_idx] {
					p.Send(res_2cli)
				}
			}
		}
	}

	return
}
