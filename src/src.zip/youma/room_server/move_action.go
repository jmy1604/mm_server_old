package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
)

const (
	MOVE_ACTION_TYPE_TO_XY_SCOPE    = 1 // 移动到坐标范围
	MOVE_ACTION_TYPE_DIRECTION      = 2 // 固定方向移动
	MOVE_ACTION_TYPE_UP_ROAD_MOVE   = 3 // 向上靠边移动
	MOVE_ACTION_TYPE_DOWN_ROAD_MOVE = 4 // 向下靠边移动
	MOVE_ACTION_TYPE_UP_DIRECTION   = 5 // 向上移动
	MOVE_ACTION_TYPE_DOWN_DIRECTION = 6 // 向下移动
	MOVE_ACTION_TYPE_TO_TARGET      = 7 // 向目标点移动
)

type XmlMoveAction struct {
	Idx           int32   `xml:"idx,attr"`
	ActionType    int32   `xml:"type,attr"`
	Ybase         float32 `xml:"ybase,attr"`
	Xbase         float32 `xml:"xbase,attr"`
	Centerx       float32 `xml:"centerx,attr"`
	ForbidenAreas []int32 `xml:""`
}

type XmlMoveActions struct {
	MoveActions []XmlMoveAction `xml:"action"`
}

type CfgMoveActionMgr struct {
	idx2action      map[int32]*XmlMoveAction
	idx2p1defaction map[int32]*XmlDefMoveAction
	idx2p2defaction map[int32]*XmlDefMoveAction
}

var cfg_move_act_mgr CfgMoveActionMgr

func (this *CfgMoveActionMgr) Init() bool {
	this.LoadMoveActions()

	return true
}

func (this *CfgMoveActionMgr) LoadMoveActions() bool {
	this.idx2action = make(map[int32]*XmlMoveAction)
	content, err := ioutil.ReadFile("../game_data/moveAction.xml")

	if nil != err {
		log.Error("CfgMoveActionMgr LoadMoveActions failed err(%s)", err.Error())
		return false
	}

	xmlactions := &XmlMoveActions{}
	err = xml.Unmarshal(content, xmlactions)
	if nil != err {
		log.Error("CfgMoveActionMgr LoadMoveActions Unmarshal failed err(%s)", err.Error())
		return false
	}

	for _, val := range xmlactions.MoveActions {
		tmp_action := &XmlMoveAction{}
		tmp_action.Idx = val.Idx
		tmp_action.ActionType = val.ActionType
		tmp_action.Xbase = val.Xbase * float32(global_config.CellLen)
		tmp_action.Ybase = val.Ybase * float32(global_config.CellLen)
		tmp_action.Centerx = val.Centerx * float32(global_config.CellLen)

		this.idx2action[val.Idx] = tmp_action
	}

	return true
}

func (this *CfgMoveActionMgr) GetMovetargetByAction(in_x, in_y float32, actionidx int32) (berr bool, tgt_x, tgt_y, p_tgt_x, p_tgt_y float32) {
	action_info := this.idx2action[actionidx]
	if nil == action_info {
		log.Error("CfgMoveActionMgr can not find action[%d]", actionidx)
		berr = true
		return
	}

	switch action_info.ActionType {
	case MOVE_ACTION_TYPE_TO_XY_SCOPE:
		{
			tgt_x = action_info.Xbase
			tgt_y = action_info.Ybase
			p_tgt_y = tgt_y
			p_tgt_x = tgt_x
			if (in_x > MAP_LEFT_BRIGE_LEFT && in_x < MAP_LEFT_BRIGE_RIGHT) || (in_x > MAP_RIGHT_BRIGE_LEFT && in_x < MAP_RIGHT_BRIGE_RIGHT) {
				p_tgt_x = in_x
			}
		}
	case MOVE_ACTION_TYPE_DIRECTION:
		{
			log.Error("CfgMoveActionMgr MOVE_ACTION_TYPE_DIRECTION !!!")
			berr = true
		}
	case MOVE_ACTION_TYPE_UP_ROAD_MOVE:
		{
			//log.Info("靠边移动3 %v", action_info)
			dis_y := action_info.Ybase - in_y
			if dis_y < 0 {
				dis_y = -dis_y
			}

			if dis_y > 3 { // 如果没有到Y基准线
				tgt_x = action_info.Xbase
				tgt_y = action_info.Ybase
				p_tgt_y = tgt_y
				p_tgt_x = tgt_x
				if (in_x > MAP_LEFT_BRIGE_LEFT && in_x < MAP_LEFT_BRIGE_RIGHT) || (in_x > MAP_RIGHT_BRIGE_LEFT && in_x < MAP_RIGHT_BRIGE_RIGHT) {
					p_tgt_x = in_x
				}

				//log.Info("靠边移动3 %v 如果没有到Y基准线", action_info, action_info.Ybase, in_x, in_y, p_tgt_x, p_tgt_y)
			} else { // 如果已经到Y基准线
				tgt_x = action_info.Centerx
				tgt_y = action_info.Ybase
				p_tgt_y = in_y
				p_tgt_x = tgt_x
			}
		}
	case MOVE_ACTION_TYPE_DOWN_ROAD_MOVE:
		{
			//log.Info("靠边移动4 %v", action_info)
			dis_y := action_info.Ybase - in_y
			if dis_y < 0 {
				dis_y = -dis_y
			}

			if dis_y > 3 { // 如果没有到Y基准线

				tgt_x = action_info.Xbase
				tgt_y = action_info.Ybase
				p_tgt_y = tgt_y
				p_tgt_x = tgt_x
				if (in_x > MAP_LEFT_BRIGE_LEFT && in_x < MAP_LEFT_BRIGE_RIGHT) || (in_x > MAP_RIGHT_BRIGE_LEFT && in_x < MAP_RIGHT_BRIGE_RIGHT) {
					p_tgt_x = in_x
				}
			} else { // 如果已经到Y基准线
				tgt_x = action_info.Centerx
				tgt_y = action_info.Ybase
				p_tgt_y = in_y
				p_tgt_x = tgt_x
			}

		}
	case MOVE_ACTION_TYPE_UP_DIRECTION:
		{
			log.Error("CfgMoveActionMgr MOVE_ACTION_TYPE_DIRECTION !!!")
			berr = true
		}
	case MOVE_ACTION_TYPE_DOWN_DIRECTION:
		{
			log.Error("CfgMoveActionMgr MOVE_ACTION_TYPE_DIRECTION !!!")
			berr = true
		}
	case MOVE_ACTION_TYPE_TO_TARGET: // 不应该有这种情况
		{
			log.Error("CfgMoveActionMgr MOVE_ACTION_TYPE_TO_TARGET !!!")
			berr = true
		}
	}

	return
}
