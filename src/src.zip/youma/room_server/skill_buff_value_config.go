package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
)

type XmlSkillBuffValue struct {
	SkillId    int32   `xml:"SkillID,attr"`
	Index      int32   `xml:"Index,attr"`
	SkillLevel int32   `xml:"SkillLevel,attr"`
	Value      float32 `xml:"Value,attr"`
}

type XmlSkillBuffValueConfig struct {
	SkillValues []XmlSkillBuffValue `xml:"item"`
}

type SkillBuffValueConfigMgr struct {
	Idx2Values map[int64]int32
}

var cfg_skillbuff_val_mgr SkillBuffValueConfigMgr

func (this *SkillBuffValueConfigMgr) Init() bool {
	if !this.Load() {
		return false
	}

	return true
}

func (this *SkillBuffValueConfigMgr) Load() bool {
	content, err := ioutil.ReadFile("../game_data/SkillValueConfig.xml")
	if nil != err {
		log.Error("SkillBuffValueConfigMgr Load read file err(%s)", err.Error())
		return false
	}

	skillvalues := &XmlSkillBuffValueConfig{}
	err = xml.Unmarshal(content, skillvalues)
	if nil != err {
		log.Error("SkillBuffValueConfigMgr Load unmashal failed(%s)", err.Error())
		return false
	}

	this.Idx2Values = make(map[int64]int32)
	for _, val := range skillvalues.SkillValues {
		idx := int64(val.SkillId)*VAL_IDX_SKILL + int64(val.Index)*VAL_IDX_INDEX + int64(val.SkillLevel)
		this.Idx2Values[idx] = int32(val.Value)

		//log.Info("skillid %d index %d, skilllevel %d idx%d  value %d", val.SkillId, val.Index, val.SkillLevel, val.Index, val.Value)
	}

	log.Info("=====after load %v", this.Idx2Values[20620110101])

	return true
}
