package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"libs/log"
	"os"
	"public_message/gen_go/server_message"
	"runtime"
	"time"
)

type ServerConfig struct {
	ServerId          int32
	InnerVersion      string
	ServerName        string
	LogConfigDir      string // 日志配置文件路径
	MatchServerIP     string // 连接匹配服务器
	ListenClientInIP  string // 监听客户端的地址
	ListenClientOutIP string // 监听客户端的外部地址
	MaxClientConns    int32  // 最大客户端连接数目
	RecvMaxMSec       int64  // 接收超时毫秒数
	SendMaxMSec       int64  // 发送超时毫秒数
}

var config ServerConfig
var shutingdown bool

func g_init() bool {
	if !global_config_load() {
		return false
	} else {
		log.Event("global_config_load succeed !", nil)
	}

	if !cfg_map_mgr.Init() {
		return false
	} else {
		log.Event("cfg_map_mgr load succeed !", nil)
	}

	if !cfg_move_act_mgr.Init() {
		return false
	} else {
		log.Event("cfg_move_act_mgr load succeed !", nil)
	}

	if !cfg_loadarea_mgr.Init() {
		return false
	} else {
		log.Event("cfg_loadarea_mgr Init succeed !", nil)
	}

	if !cfg_skillbuff_val_mgr.Init() {
		return false
	} else {
		log.Event("cfg_skill_buff_mgr init succeed !", nil)
	}

	if !cfg_skill_mgr.Init() {
		return false
	} else {
		log.Event("cfg_skill_mgr init succeed !", nil)
	}

	if !cfg_buff_mgr.Init() {
		return false
	} else {
		log.Event("cfg_buff_mgr init succeed !", nil)
	}

	if !cfg_player_cards.Load() {
		return false
	} else {
		log.Event("cfg_player_cards load succeed !", nil)
	}

	if !cfg_npcs.Load() {
		return false
	} else {
		log.Event("cfg_npcs load succeed !", nil)
	}

	if !match_conn.Init() {
		log.Error("match_conn Init ")
		return false
	} else {
		log.Event("match_conn Init succeed !", nil)
	}

	if !fight_room_mgr.Init() {
		log.Error("g_init  error !")
		return false
	} else {
		log.Event("fight_room_mgr init succeed !", nil)
	}

	return true
}

func main() {
	defer func() {
		log.Event("关闭服务器", nil)
		if err := recover(); err != nil {
			log.Stack(err)
		}
		server.Shutdown()

		time.Sleep(time.Second * 5)
	}()

	runtime.GOMAXPROCS(runtime.NumCPU())

	var temp_i int32

	config_file := "../conf/room_server.cfg"
	if len(os.Args) > 1 {
		arg_config_file := flag.String("f", "", "config file path")
		if arg_config_file != nil && *arg_config_file == "" {
			flag.Parse()
			fmt.Printf("配置参数 %s", *arg_config_file)
			config_file = *arg_config_file
		}
	}

	data, err := ioutil.ReadFile(config_file)
	if err != nil {
		fmt.Printf("读取配置文件失败 %v", err)
		return
	}
	err = json.Unmarshal(data, &config)
	if err != nil {
		fmt.Printf("解析配置文件失败 %v", err.Error())
		fmt.Scanln(&temp_i)
		return
	}

	// 加载日志配置
	log.Init("", config.LogConfigDir, true)
	log.Event("配置:服务器Id", config.ServerId)
	log.Event("配置:网络协议版本", int32(msg_server_message.E_VERSION_NUMBER))
	log.Event("配置:服务器名称", config.ServerName)
	log.Event("配置:匹配服务器IP", config.MatchServerIP)
	log.Event("配置:监听客户端IP", config.ListenClientInIP)

	if !g_init() {
		log.Error("g_init failed !")
		return
	} else {
		log.Event("g_init succeed !", nil)
	}

	// 连接MatchServer
	go match_conn.Start()

	if !server.Init() {
		log.Info("server init failed !!")
		return
	}

	server.Start()
}
