package main

import (
	"fmt"
	"libs/log"
	"os"
	"public_message/gen_go/server_message"
	"sync"

	"3p/code.google.com.protobuf/proto"
)

type FightRoomMgr struct {
	id2rooms      map[int32]*FightRoom
	id2rooms_lock *sync.RWMutex

	next_room_id      int32
	next_room_id_lock *sync.Mutex
}

var fight_room_mgr FightRoomMgr

func (this *FightRoomMgr) Init() bool {
	this.id2rooms = make(map[int32]*FightRoom)
	this.id2rooms_lock = &sync.RWMutex{}

	this.next_room_id = 0
	this.next_room_id_lock = &sync.Mutex{}

	this.RegMsgHandler()

	return true
}

func (this *FightRoomMgr) GetNextRoomId() int32 {
	this.next_room_id_lock.Lock()
	defer this.next_room_id_lock.Unlock()

	this.next_room_id++
	if this.next_room_id <= 0 {
		this.next_room_id = 1
	}

	return this.next_room_id
}

func (this *FightRoomMgr) add_room(room *FightRoom) int32 {
	if nil == room {
		log.Error("FightRoomMgr add_room room nil !")
		return -1
	}

	this.id2rooms_lock.Lock()
	defer this.id2rooms_lock.Unlock()

	cur_room := this.id2rooms[room.room_id]
	if nil != cur_room {
		log.Error("FightRoomMgr add_room room nil")
		return -2
	}

	this.id2rooms[room.room_id] = cur_room
	return 0
}

func (this *FightRoomMgr) remove_room(room_id int32) {
	this.id2rooms_lock.Lock()
	defer this.id2rooms_lock.Unlock()

	if nil != this.id2rooms {
		delete(this.id2rooms, room_id)
	}

	return
}

// 消息处理 =====================================================================

func (this *FightRoomMgr) RegMsgHandler() {
	match_conn.SetMessageHandler(msg_server_message.ID_GetRoomReq, M2RGetRoomReqHandler)
}

func M2RGetRoomReqHandler(conn *MatchConnection, msg proto.Message) {
	req := msg.(*msg_server_message.GetRoomReq)
	if nil == conn || nil == req {
		log.Error("M2RGetRoomReqHandler param error !")
		return
	}

	roomid := fight_room_mgr.GetNextRoomId()
	new_room := NewFightRoom(roomid, req)
	if nil == new_room {
		log.Error("M2RGetRoomReqHandler(%d) failed to new room !", req.GetResultId())
		return
	}

	iret := fight_room_mgr.add_room(new_room)
	if iret < 0 {
		log.Error("M2RGetRoomReqHandler(%d) failed to add room (%d) !", iret)
		return
	}

	new_room.on_create()
	//new_room.on_create_test()
	new_room.Start()

	res_2m := &msg_server_message.R2MGetRoomResponse{}
	res_2m.ResultId = proto.Int32(req.GetResultId())
	res_2m.RoomId = proto.Int32(roomid)

	conn.Send(res_2m)
	return
}

func (this *FightRoomMgr) TT_Room() {
	r_cfg := global_config.RoomCfg
	clen := float32(global_config.CellLen)
	/*
		for i := int64(0); i < 10000; i = i + 2 {
			req := &msg_server_message.M2RGetRoomReq{}
			req.ResultId = proto.Int32(1)
			req.Id1 = proto.Int64(i)
			req.Name1 = proto.String("name1")
			req.Score1 = proto.Int32(1)
			req.Token1 = proto.Int32(1)
			req.CardCfgIds1 = []int32{1001, 1002, 1003, 1004, 1005, 1006, 1007}
			req.CardLvls1 = []int32{1, 2, 3, 4, 5, 6, 7}
			req.Id2 = proto.Int64(i + 1)
			req.Name2 = proto.String("name2")
			req.Score2 = proto.Int32(1)
			req.Token2 = proto.Int32(1)
			req.CardCfgIds2 = []int32{1001, 1002, 1003, 1004, 1005, 1006, 1007}
			req.CardLvls2 = []int32{1, 2, 3, 4, 5, 6, 7}
			roomid := this.GetNextRoomId()
			new_room := NewFightRoom(roomid, req)
			if nil == new_room {
				log.Error("M2RGetRoomReqHandler(%d) failed to new room !", req.GetResultId())
				return
			}

			iret := fight_room_mgr.add_room(new_room)
			if iret < 0 {
				log.Error("M2RGetRoomReqHandler(%d) failed to add room (%d) !", iret)
				return
			}

			new_room.on_create()

			clen := float32(global_config.CellLen)
			new_room.LoadNpc(P1_KING_NPC_ID, r_cfg.KingNpcCardCfgId, 1, r_cfg.P1KingPos.X*clen, r_cfg.P1KingPos.Y*clen, PLAYER_SIDE_BTM)
			//new_room.LoadNpc(P2_KING_NPC_ID, r_cfg.KingNpcCardCfgId, 1, r_cfg.P2KingPos.X*clen, r_cfg.P2KingPos.Y*clen, PLAYER_SIDE_TOP)
			new_room.Start()
			new_room.LoadCardByCfgId(1001, 1, 54, 116, PLAYER_SIDE_TOP)
		}
	*/
	req := &msg_server_message.GetRoomReq{}
	req.ResultId = proto.Int32(1)
	req.MatchPlayers = make([]*msg_server_message.MatchPlayer, 0, 2)
	for idx := int32(0); idx < 2; idx++ {
		tmp_mp := &msg_server_message.MatchPlayer{}
		tmp_mp.Id = proto.Int64(int64(900 + idx))
		tmp_mp.Name = proto.String("test")
		tmp_mp.Score = proto.Int32(1)
		tmp_mp.Token = proto.Int32(1)
		tmp_mp.CardCfgIds = []int32{1001, 1002, 1003, 1004, 1005, 1006, 1007}
		tmp_mp.CardLvls = []int32{1, 2, 3, 4, 5, 6, 7}
	}

	roomid := this.GetNextRoomId()
	new_room := NewFightRoom(roomid, req)
	if nil == new_room {
		log.Error("M2RGetRoomReqHandler(%d) failed to new room !", req.GetResultId())
		return
	}

	iret := fight_room_mgr.add_room(new_room)
	if iret < 0 {
		log.Error("M2RGetRoomReqHandler(%d) failed to add room (%d) !", iret)
		return
	}

	//new_room.on_create()
	new_room.LoadNpc(1, 1043, 1, r_cfg.P1KingPos.X*clen, r_cfg.P1KingPos.Y*clen, PLAYER_SIDE_BTM, 0)
	//new_room.LoadNpc(P2_KING_NPC_ID, r_cfg.KingNpcCardCfgId, 1, r_cfg.P2KingPos.X*clen, r_cfg.P2KingPos.Y*clen, PLAYER_SIDE_TOP)
	new_room.Start()
	new_room.LoadCardByCfgId(1034, 1, 54, 116, PLAYER_SIDE_TOP, 1)
	//new_room.LoadCardByCfgId(1001, 1, 24, 112, PLAYER_SIDE_TOP)
	//new_room.LoadCardByCfgId(1001, 1, 24, 24)
	//log.Info("=======================================================")

	// EXTRA float32=16.765, float32=58.881065, float32=2, float32=12, float32=12, int=0, int=0, float32=24, int32=0, int32=9
	//path, bret := &A_PATH_POINT{}, 0

	fmt.Print("==")
	os.Create("fsfs2.excel")
	/*
		path, bret := new_room.PatchFindInRoom(14, 37, 2, 5, 14.000000, 26.000000, 12.0000, 0, 24, 0, -1, 2)
		log.Info("******* bret(%v)", bret)

		for {
			if nil == path {
				break
			}

			out_str := fmt.Sprintf("%f,%f\r\n", path.fx, path.fy)
			outfile.WriteString(out_str)

			path = path.next_point
		}
	*/

	new_room.print_npc_pos()

	return
}
