package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
)

const (
	AREA_TYPE_BTM_ALL_TOWERS = 1 // 下面玩家 对面两个护卫塔都在
	AREA_TYPE_BTM_NO_LEFT    = 2 // 下面玩家 对面左边塔没了
	AREA_TYPE_BTM_NO_RIGHT   = 3 // 下面玩家 对面右边塔没了
	AREA_TYPE_BTM_NO_ALL     = 4 // 下面玩家 对面所有塔都没了

	AREA_TYPE_TOP_ALL_TOWERS = 5 // 上面玩家 对面两个护卫塔都在
	AREA_TYPE_TOP_NO_LEFT    = 6 // 上面玩家 对面左边塔没了
	AREA_TYPE_TOP_NO_RIGHT   = 7 // 上面玩家 对面右边塔没了
	AREA_TYPE_TOP_NO_ALL     = 8 // 上面玩家 对面所有塔都没了
)

type XmlLoadAreas struct {
	LoadAreas []XmlLoadArea `xml:"loadarea"`
}

var cfg_loadarea_mgr CfgLoadAreaMgr

type CfgLoadAreaMgr struct {
	xml_loadarea_cfg *XmlLoadAreas          // 数组结构
	type2loadarea    map[uint8]*XmlLoadArea // 区域类型定义
}

func (this *CfgLoadAreaMgr) Init() bool {
	if !this.Load() {
		return false
	}

	return true
}

func (this *CfgLoadAreaMgr) Load() bool {
	this.xml_loadarea_cfg = &XmlLoadAreas{}

	content, err := ioutil.ReadFile("../game_data/loadareaconfig.xml")

	if nil != err {
		log.Error("CfgLoadAreaMgr load failed err(%s)", err.Error())
		return false
	}

	err = xml.Unmarshal(content, this.xml_loadarea_cfg)
	if nil != err {
		log.Error("CfgLoadAreaMgr load Unmarshal failed err(%s)", err.Error())
		return false
	}

	this.type2loadarea = make(map[uint8]*XmlLoadArea)
	for _, val := range this.xml_loadarea_cfg.LoadAreas {
		tmp_area := &XmlLoadArea{}
		tmp_area.AreaType = val.AreaType
		tmp_area.Areas = make([]XmlArea, len(val.Areas))
		for idx, area := range val.Areas {
			tmp_area.Areas[idx].Camp = area.Camp
			tmp_area.Areas[idx].Idx = area.Idx
			tmp_area.Areas[idx].Left = area.Left * float32(global_config.CellLen)
			tmp_area.Areas[idx].Top = area.Top * float32(global_config.CellLen)
			tmp_area.Areas[idx].Right = area.Right * float32(global_config.CellLen)
			tmp_area.Areas[idx].Bottom = area.Bottom * float32(global_config.CellLen)
		}

		this.type2loadarea[uint8(val.AreaType)] = tmp_area

		log.Info("加载区域配置：%v", *tmp_area)
	}

	return true
}

func (this *CfgLoadAreaMgr) IfInTypeArea(area_type uint8, x, y float32) bool {
	load_area := this.type2loadarea[area_type]
	if nil == load_area {
		log.Error("IfInTypeArea type[%d] nil", area_type)
		return false
	}

	for _, area := range load_area.Areas {
		log.Info("对比区域(%f,%f) (%f,%f)", area.Left, area.Top, area.Right, area.Bottom)
		if x >= area.Left && x <= area.Right && y >= area.Bottom && y <= area.Top {
			return true
		}
	}

	return false
}
