package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
)

const (
	NPC_TYPE_ARMY     = 1 // 军队
	NPC_TYPE_BUILDING = 2 // 建筑
	NPC_TYPE_MAGIC    = 3 // 法术
)

type XmlNpc struct {
	ConfigId    int32   `xml:"ID,attr"`
	Level       int32   `xml:"Level,attr"`
	HP          int32   `xml:"HP,attr"`
	DEF         int32   `xml:"DEF,attr"`
	MSpeed      float32 `xml:"MSpeed,attr"`
	IsFly       int32   `xml:"IsFly,attr"`
	Radius      float32 `xml:"Radius,attr"`
	PlaceSize   float32 `xml:"PlaceSize,attr"`
	SearchRange float32 `xml:"SearchRange,attr"`
}

type XmlNpcs struct {
	Npcs []XmlNpc `xml:"item"`
}

type ConfigNpc struct {
	ConfigId    int32
	Level       int32
	HP          int32
	DEF         int32
	MSpeed      float32
	IsFly       int32
	Radius      float32
	PlaceSize   float32
	SearchRange float32
}

var cfg_npcs ConfigNpcs

type ConfigNpcs struct {
	Map   map[int32]*ConfigNpc // 映射结构
	Array []*ConfigNpc
}

func (this *ConfigNpcs) Load() bool {

	content, err := ioutil.ReadFile("../game_data/NPCConfig.xml")

	if nil != err {
		log.Error("ConfigNpcs load failed err(%s)", err.Error())
		return false
	}

	var xml_npcs XmlNpcs
	err = xml.Unmarshal(content, &xml_npcs)
	if nil != err {
		log.Error("ConfigNpcs load Unmarshal failed err(%s)", err.Error())
		return false
	}

	this.Array = make([]*ConfigNpc, len(xml_npcs.Npcs))
	this.Map = make(map[int32]*ConfigNpc)
	for _, val := range xml_npcs.Npcs {
		tmp_cfg_npc := &ConfigNpc{}
		tmp_cfg_npc.ConfigId = val.ConfigId*100 + val.Level
		tmp_cfg_npc.Level = val.Level
		tmp_cfg_npc.IsFly = val.IsFly
		tmp_cfg_npc.DEF = val.DEF
		tmp_cfg_npc.MSpeed = val.MSpeed
		tmp_cfg_npc.HP = val.HP
		tmp_cfg_npc.Radius = val.Radius
		tmp_cfg_npc.PlaceSize = val.PlaceSize
		tmp_cfg_npc.SearchRange = val.SearchRange

		this.Array = append(this.Array, tmp_cfg_npc)
		this.Map[tmp_cfg_npc.ConfigId] = tmp_cfg_npc
		//log.Info("ConfigNpcs load cfg(%d)  %v", val.ConfigId, val.SearchRange)
	}

	return true
}
