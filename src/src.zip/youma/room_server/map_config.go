package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"math/rand"
	"strconv"
	"strings"
)

const (
	PLAYER_SIDE_BTM = 1 // 下方玩家
	PLAYER_SIDE_TOP = 2 // 玩家2编号

	MAP_CENTER_X           = 36.0 // x 中线
	MAP_REVIER_DOWN_Y      = 60   // 河道下边y
	MAP_REVIER_DOWN_JUMP_Y = 58   // 河道下方跳跃y
	MAP_REVIER_UP_Y        = 68   // 河道上边y
	MAP_REVIER_UP_JUMP_Y   = 70   // 河道上边跳跃点
	MAP_LEFT_BRIGE_LEFT    = 8    // 左边桥左x
	MAP_LEFT_BRIGE_RIGHT   = 20   // 左边桥右x
	MAP_RIGHT_BRIGE_LEFT   = 52   // 右边桥左x
	MAP_RIGHT_BRIGE_RIGHT  = 64   // 右边桥右x
)

type XYPos struct {
	X float32
	Y float32
}

type XmlXYPos struct {
	X float32 `xml:"x,attr"`
	Y float32 `xml:"y,attr"`
}

type XmlP2AiPoint struct {
	Points []XmlXYPos `xml:"xypos"`
}

type XmlArea struct {
	Idx    int32   `xml:"idx,attr"`
	Camp   string  `xml:"camp,attr"`
	Left   float32 `xml:"left,attr"`
	Top    float32 `xml:"top,attr"`
	Right  float32 `xml:"right,attr"`
	Bottom float32 `xml:"bottom,attr"`
}

type XmlNormalArea struct {
	Areas []XmlArea `xml:"area"`
}

type XmlBuildingArea struct {
	Areas []XmlArea `xml:"area"`
}

type XmlFlyArea struct {
	Areas []XmlArea `xml:"area"`
}

type XmlDefMoveAction struct {
	SrcArea int32 `xml:"srcarea,attr"`
	Action  int32 `xml:"action,attr"`
}

type XmlDefMoveActions struct {
	DefActions []XmlDefMoveAction `xml:"defmoveaction"`
}

type XmlLoadArea struct {
	AreaType int32     `xml:"areatype,attr"`
	Areas    []XmlArea `xml:"area"`
}

type XmlPlayerLoadArea struct {
	PlayerIdx int32         `xml:"player_idx,attr"`
	LoadAreas []XmlLoadArea `xml:"loadarea"`
}

type PlayerLoadArea struct {
	PlayerIdx     int32
	type2LoadArea map[uint8]*XmlLoadArea
}

type XmlMapConfig struct {
	Normal           XmlNormalArea       `xml:"normalarea"`
	Building         XmlBuildingArea     `xml:"buildingarea"`
	Fly              XmlFlyArea          `xml:"flyarea"`
	P2AiPoint        XmlP2AiPoint        `xml:"p2aipoint"`
	P1defmoveactions XmlDefMoveActions   `xml:"btmdefmoveactions"`
	P2defmoveactions XmlDefMoveActions   `xml:"topdefmoveactions"`
	PlayerLoadAreas  []XmlPlayerLoadArea `xml:"playerloadarea"`
}

type XmlMapPathItem struct {
	MapId      int32  `xml:"MapId,attr"`
	MapName    string `xml:"MapName,attr"`
	MatchTypes string `xml:"MatchTypes,attr"`
}

type XmlMapPathConfig struct {
	Items []XmlMapPathItem `xml:"item"`
}

// ---------------------------------------------------------------------------

type MapData struct {
	mapcfg          []*XmlArea  // 地面区域
	flymapcfg       []*XmlArea  // 飞行区域
	buildmapcfg     []*XmlArea  // 建筑区域
	P2AIPoints      []*XmlXYPos // 简单Ai的放卡点
	P2AIPoints_Len  int32       // Ai点的长度
	defmoveactions  map[int32](map[int32]*XmlDefMoveAction)
	player2loadarea map[int32]*PlayerLoadArea
}

func (this *MapData) getxy_army_area_idx(x, y float32, isfly int32) int32 {

	if 0 == isfly {
		for _, area := range this.mapcfg {
			if area.Left <= x && x <= area.Right &&
				area.Bottom <= y && y <= area.Top {
				return area.Idx
			}
		}
	} else {
		for _, area := range this.flymapcfg {
			if area.Left <= x && x <= area.Right &&
				area.Bottom <= y && y <= area.Top {
				return area.Idx
			}
		}
	}

	return -1
}

func (this *MapData) getxy_build_area_idx(x, y, halfradius float32, isfly int32) int32 {

	for _, area := range this.buildmapcfg {
		if area.Left+halfradius <= x && x <= area.Right-halfradius &&
			area.Bottom+halfradius <= y && y <= area.Top-halfradius {
			return area.Idx
		}
	}

	return -1
}

func (this *MapData) get_def_move_action(area_idx, player_side int32) int32 {

	defactions := this.defmoveactions[player_side]
	if nil == defactions {
		log.Error("MapData get_def_move_action failed player_side(%d)", player_side)
		return -1
	}

	action_info := defactions[area_idx]
	if nil == action_info {
		log.Error("MapData get_def_move_action failed area_idx[%d]", area_idx)
		return -1
	}

	return action_info.Action
}

func (this *MapData) get_random_p2ai_pos() *XmlXYPos {
	rand_idx := rand.Int31n(this.P2AIPoints_Len)
	return this.P2AIPoints[rand_idx]
}

func (this *MapData) IfInTypeArea(player_idx int32, area_type uint8, x, y float32) bool {
	p_load_area := this.player2loadarea[player_idx]
	if nil == p_load_area {
		return false
	}

	load_area := p_load_area.type2LoadArea[area_type]
	if nil == load_area {
		log.Error("MapData IfInTypeArea type[%d] nil", area_type)
		return false
	}

	for _, area := range load_area.Areas {
		log.Info("对比区域(%f,%f) (%f,%f)", area.Left, area.Top, area.Right, area.Bottom)
		if x >= area.Left && x <= area.Right && y >= area.Bottom && y <= area.Top {
			return true
		}
	}

	return false
}

// ---------------------------------------------------------------------------

var cfg_map_mgr CfgMapManager

type CfgMapManager struct {
	xmlmapcfg *XmlMapConfig // 数组结构

	mapid2mapdata map[int32]*MapData
	type2mapid    map[int32]int32
}

func (this *CfgMapManager) Init() bool {

	if !this.LoadMap() {
		return false
	}

	return true
}

func (this *CfgMapManager) LoadMap() bool {
	xmlconfig := &XmlMapPathConfig{}
	content, err := ioutil.ReadFile("../game_data/mappath.xml")

	if nil != err {
		log.Error("CfgMapManager LoadMap err(%s)", err.Error())
		return false
	}

	err = xml.Unmarshal(content, xmlconfig)
	if nil != err {
		log.Error("CfgMapManager LoadMap Unmarshal failed err(%s)", err.Error())
		return false
	}

	this.type2mapid = make(map[int32]int32)

	var strs_len int32
	var ival int
	this.mapid2mapdata = make(map[int32]*MapData)
	for _, val := range xmlconfig.Items {
		tmp_data := &MapData{}
		if !this.LoadSingleMap(val.MapId, val.MapName, tmp_data) {
			return false
		}
		this.mapid2mapdata[val.MapId] = tmp_data

		type_strs := strings.Split(val.MatchTypes, "|")
		strs_len = int32(len(type_strs))
		for idx := int32(0); idx < strs_len; idx++ {
			ival, err = strconv.Atoi(type_strs[idx])
			if nil != err {
				log.Error("CfgMapManager LoadMap strconv[%s] error[%s] !", type_strs[idx], err.Error())
				return false
			}

			this.type2mapid[int32(ival)] = val.MapId
		}
	}

	log.Info("地图类型到Id的映射 %v", this.type2mapid)

	return true
}

func (this *CfgMapManager) LoadSingleMap(map_id int32, map_name string, map_data *MapData) bool {
	xmlmapcfg := &XmlMapConfig{}
	content, err := ioutil.ReadFile("../game_data/map/" + map_name)

	if nil != err {
		log.Error("CfgMapManager load map[%s] failed err(%s)", map_name, err.Error())
		return false
	}

	err = xml.Unmarshal(content, xmlmapcfg)
	if nil != err {
		log.Error("CfgMapManager load map[%s] Unmarshal failed err(%s)", map_name, err.Error())
		return false
	}

	map_data.mapcfg = make([]*XmlArea, len(xmlmapcfg.Normal.Areas))
	for idx, val := range xmlmapcfg.Normal.Areas {
		tmp_area := &XmlArea{}
		tmp_area.Camp = val.Camp
		tmp_area.Idx = val.Idx
		tmp_area.Left = val.Left * float32(global_config.CellLen)
		tmp_area.Right = val.Right * float32(global_config.CellLen)
		tmp_area.Bottom = val.Bottom * float32(global_config.CellLen)
		tmp_area.Top = val.Top * float32(global_config.CellLen)

		map_data.mapcfg[idx] = tmp_area
	}

	for idx, val := range map_data.mapcfg {
		log.Info("map[%s] normal area[%d] (%f,%f) (%f,%f)", map_name, idx, val.Left, val.Top, val.Right, val.Bottom)
	}

	map_data.buildmapcfg = make([]*XmlArea, len(xmlmapcfg.Building.Areas))
	for idx, val := range xmlmapcfg.Building.Areas {
		tmp_area := &XmlArea{}
		tmp_area.Camp = val.Camp
		tmp_area.Idx = val.Idx
		tmp_area.Left = val.Left * float32(global_config.CellLen)
		tmp_area.Right = val.Right * float32(global_config.CellLen)
		tmp_area.Bottom = val.Bottom * float32(global_config.CellLen)
		tmp_area.Top = val.Top * float32(global_config.CellLen)

		map_data.buildmapcfg[idx] = tmp_area
	}

	for idx, val := range map_data.mapcfg {
		log.Info("map[%s] build area[%d] (%f,%f) (%f,%f)", map_name, idx, val.Left, val.Top, val.Right, val.Bottom)
	}

	map_data.flymapcfg = make([]*XmlArea, len(xmlmapcfg.Fly.Areas))
	for idx, val := range xmlmapcfg.Fly.Areas {
		tmp_area := &XmlArea{}
		tmp_area.Camp = val.Camp
		tmp_area.Idx = val.Idx
		tmp_area.Left = val.Left * float32(global_config.CellLen)
		tmp_area.Right = val.Right * float32(global_config.CellLen)
		tmp_area.Bottom = val.Bottom * float32(global_config.CellLen)
		tmp_area.Top = val.Top * float32(global_config.CellLen)

		map_data.flymapcfg[idx] = tmp_area
	}

	for idx, val := range map_data.flymapcfg {
		log.Info("flyarea[%d] (%f,%f) (%f,%f)", idx, val.Left, val.Top, val.Right, val.Bottom)
	}

	map_data.P2AIPoints = make([]*XmlXYPos, 0, len(xmlmapcfg.P2AiPoint.Points))
	for _, val := range xmlmapcfg.P2AiPoint.Points {
		tmp_pos := &XmlXYPos{}
		tmp_pos.X = val.X * float32(global_config.CellLen)
		tmp_pos.Y = val.Y * float32(global_config.CellLen)
		map_data.P2AIPoints_Len++
		map_data.P2AIPoints = append(map_data.P2AIPoints, tmp_pos)
	}

	if map_data.P2AIPoints_Len < 1 {
		log.Error("CfgMapManager can not find P2AIPoints ")
		return false
	} else {
		for _, val := range map_data.P2AIPoints {
			log.Info("P2AiPoints [x:%f, y:%f]", val.X, val.Y)
		}
	}

	map_data.defmoveactions = make(map[int32](map[int32]*XmlDefMoveAction))
	defactionmap := make(map[int32]*XmlDefMoveAction)
	for _, val := range xmlmapcfg.P1defmoveactions.DefActions {
		tmp_defaction := &XmlDefMoveAction{}
		*tmp_defaction = val
		log.Info("====defactions1 %v", *tmp_defaction)
		defactionmap[val.SrcArea] = tmp_defaction
	}
	map_data.defmoveactions[PLAYER_SIDE_BTM] = defactionmap

	defactionmap = make(map[int32]*XmlDefMoveAction)
	for _, val := range xmlmapcfg.P2defmoveactions.DefActions {
		tmp_defaction := &XmlDefMoveAction{}
		*tmp_defaction = val

		defactionmap[val.SrcArea] = tmp_defaction
	}

	map_data.defmoveactions[PLAYER_SIDE_TOP] = defactionmap

	for idx, actions := range map_data.defmoveactions[PLAYER_SIDE_BTM] {
		log.Info("def1 action[%d] content %v", idx, *actions)
	}

	for idx, actions := range map_data.defmoveactions[PLAYER_SIDE_TOP] {
		log.Info("def2 action[%d] content %v", idx, *actions)
	}

	map_data.player2loadarea = make(map[int32]*PlayerLoadArea)
	for _, xml_p_la := range xmlmapcfg.PlayerLoadAreas {
		tmp_p_la := &PlayerLoadArea{}
		tmp_p_la.PlayerIdx = xml_p_la.PlayerIdx
		tmp_p_la.type2LoadArea = make(map[uint8]*XmlLoadArea)
		for _, xml_la := range xml_p_la.LoadAreas {
			tmp_area := &XmlLoadArea{}
			tmp_area.AreaType = xml_la.AreaType
			tmp_area.Areas = make([]XmlArea, len(xml_la.Areas))
			for idx, area := range xml_la.Areas {
				tmp_area.Areas[idx].Camp = area.Camp
				tmp_area.Areas[idx].Idx = area.Idx
				tmp_area.Areas[idx].Left = area.Left * float32(global_config.CellLen)
				tmp_area.Areas[idx].Top = area.Top * float32(global_config.CellLen)
				tmp_area.Areas[idx].Right = area.Right * float32(global_config.CellLen)
				tmp_area.Areas[idx].Bottom = area.Bottom * float32(global_config.CellLen)
			}

			tmp_p_la.type2LoadArea[uint8(xml_la.AreaType)] = tmp_area

			log.Info("加载区域配置：%v", *tmp_area)
		}

		map_data.player2loadarea[xml_p_la.PlayerIdx] = tmp_p_la
	}

	return true
}

/*
func (this *CfgMapManager) getxy_army_area_idx(map_id int32, x, y float32, isfly int32) int32 {
	map_data := this.mapid2mapdata[map_id]
	if nil == map_data {
		log.Error("CfgMapManager getxy_build_area_idx failed to get map_data %d", map_id)
		return -1
	}

	//log.Info("CfgMapManager getxy_army_area_idx ", map_id, x, y, isfly)
	//log.Info("CfgMapManager getxy_army_area_idx===============%v ", map_id, x, y, isfly)

	if 0 == isfly {
		for _, area := range map_data.mapcfg {
			if area.Left <= x && x <= area.Right &&
				area.Bottom <= y && y <= area.Top {
				return area.Idx
			}
		}
	} else {
		for _, area := range map_data.flymapcfg {
			if area.Left <= x && x <= area.Right &&
				area.Bottom <= y && y <= area.Top {
				return area.Idx
			}
		}
	}

	return -1
}

func (this *CfgMapManager) getxy_build_area_idx(map_id int32, x, y, halfradius float32, isfly int32) int32 {
	map_data := this.mapid2mapdata[map_id]
	if nil == map_data {
		log.Error("CfgMapManager getxy_build_area_idx failed to get map_data %d", map_id)
		return -1
	}

	for _, area := range map_data.buildmapcfg {
		if area.Left+halfradius <= x && x <= area.Right-halfradius &&
			area.Bottom+halfradius <= y && y <= area.Top-halfradius {
			return area.Idx
		}
	}

	return -1
}

func (this *CfgMapManager) get_def_move_action(map_id int32, area_idx, player_side int32) int32 {
	//log.Info("CfgMapManager get_def_move_action area_idx%d player_side%d", area_idx, player_side)
	map_data := this.mapid2mapdata[map_id]
	if nil == map_data {
		log.Error("CfgMapManager get_def_move_action failed to get map_data %d", map_id)
		return -1
	}
	defactions := map_data.defmoveactions[player_side]
	if nil == defactions {
		log.Error("CfgMapManager get_def_move_action failed player_side(%d)", player_side)
		return -1
	}

	action_info := defactions[area_idx]
	if nil == action_info {
		log.Error("CfgMapMananger get_def_move_action failed area_idx[%d]", area_idx)
		return -1
	}

	return action_info.Action
}

func (this *CfgMapManager) get_random_p2ai_pos(map_id int32) *XmlXYPos {
	map_data := this.mapid2mapdata[map_id]
	if nil == map_data {
		log.Error("CfgMapManager get_random_p2ai_pos failed to get map_data %d", map_id)
		return nil
	}

	rand_idx := rand.Int31n(map_data.P2AIPoints_Len)
	return map_data.P2AIPoints[rand_idx]
}

func (this *CfgMapManager) IfInTypeArea(map_id, player_idx int32, area_type uint8, x, y float32) bool {
	map_data := this.mapid2mapdata[map_id]
	if nil == map_data {
		log.Error("CfgMapManager get_random_p2ai_pos failed to get map_data %d", map_id)
		return false
	}

	p_load_area := map_data.player2loadarea[player_idx]
	if nil == p_load_area {
		return false
	}

	load_area := p_load_area.type2LoadArea[area_type]
	if nil == load_area {
		log.Error("CfgMapManager IfInTypeArea type[%d] nil", area_type)
		return false
	}

	for _, area := range load_area.Areas {
		log.Info("对比区域(%f,%f) (%f,%f)", area.Left, area.Top, area.Right, area.Bottom)
		if x >= area.Left && x <= area.Right && y >= area.Bottom && y <= area.Top {
			return true
		}
	}

	return false
}
*/

func if_area_hit(x1, y1, w1, h1, x2, y2, w2, h2 float32) bool {
	//log.Info("if_area_hit ", x1, y1, w1, h1, x2, y2, w2, h2)
	if (x1+w1) <= x2 || (x2+w2) <= x1 || (y1-h1) >= y2 || (y2-h2) >= y1 {
		return false
	}
	return true
}

func if_area_hit_move(x1, y1, w1, h1, x2, y2, w2, h2 float32) bool {
	//log.Info("if_area_hit ", x1, y1, w1, h1, x2, y2, w2, h2)
	if (x1+w1) <= x2 || (x2+w2) <= x1 || (y1-h1) >= y2 || (y2-h2) >= y1 {
		return false
	}
	return true
}

func if_x_y_in_area(x, y float32, area *XmlArea) bool {
	if nil == area {
		log.Error("if_x_y_inarea param error !")
		return false
	}

	if area.Left <= x && x <= area.Right &&
		area.Bottom <= y && y <= area.Top {
		return true
	}

	return false
}
