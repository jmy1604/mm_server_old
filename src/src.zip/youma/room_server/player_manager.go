package main

import (
	"libs/log"
	"libs/socket"
	"math/rand"
	"public_message/gen_go/client_message"
	"public_message/gen_go/server_message"
	"sync"

	"3p/code.google.com.protobuf/proto"
)

const (
	DEF_CARD_LIB_CAPACITY = 10
	DEF_CARD_SLOT_NUM     = 4

	MATCH_TYPE_NORMAL      = 0 // 普通匹配赛
	MATCH_TYPE_TONG_FRIEND = 1 // 帮会友谊赛
	MATCH_TYPE_CAMP_MATCH  = 2 // 阵营战
	MATCH_TYPE_2V2_MATCH   = 3 // 2v2比赛
)

type PlayerCard struct {
	CardId   int32
	Lvl      int32
	bloading bool
}

type PlayerCardLoading struct {
	idx int32
}

type Player struct {
	Id       int32  // 玩家Id
	Idx      int32  // 玩家编号
	name     string // 玩家名称
	lvl      int32  // 玩家等级
	score    int32  // 玩家积分
	tongicon int32  // 帮会图标
	tongname string // 帮会名称

	player_knpc_id    int32         // 国王塔NpcId
	player_side       int32         // 玩家所在方 上方或者下方
	cur_rest_lib_idx  int32         // 预备卡库插入序号
	resting_lib_len   int32         // 预备卡库长度
	resting_lib_cards []*PlayerCard // 预备卡库
	resting_cards     []*PlayerCard // 随机好的预备卡
	fighting_cards    []*PlayerCard // 随机出来的卡片
	rest_card_count   int32         // 未在战斗槽中卡片的数量
	next_fight_c_idx  int32         // 下一张卡片在卡库中的位置

	loading_slots       []*PlayerCardUse // 加载中（卡片有加载时间，这个时候未到战场上）
	loading_cards_count int32            // 当前加载中卡片的数目

	load_area_type uint8 // 当前可以放置类型

	token               int32 // 玩家Token
	fight_score         int32 // 玩家比赛中获得的积分
	point               int32 // 能量点数
	last_point_chg_nsec int64 // 上一次
	last_use_card_cfgid int32 // 上一次使用的卡

	conn      *socket.TcpConn // 玩家连接
	conn_lock *sync.Mutex

	room *FightRoom // 玩家所在房间
}

func NewPlayerFromMsg(room *FightRoom, req *msg_server_message.GetRoomReq) {
	if nil == req || nil == room {
		log.Error("NewPlayerFromMsg req nilor room nil")
		return
	}

	match_type := req.GetMatchType()
	msg_ps := req.GetMatchPlayers()
	tmp_len := int32(len(msg_ps))
	room.players = make([]*Player, 0, tmp_len)
	room.players_state = make([]uint8, tmp_len)
	room.players_ready = make([]bool, tmp_len)

	var tmp_p *Player
	for idx, msg_p := range msg_ps {
		if nil == msg_p {
			log.Error("NewPlayerFromMsg msg_p nil")
			continue
		}

		tmp_p = &Player{}
		tmp_p.Id = int32(msg_p.GetId())
		tmp_p.name = msg_p.GetName()
		tmp_p.score = msg_p.GetScore()
		tmp_p.tongname = msg_p.GetTongName()

		switch idx {
		case 0:
			{
				tmp_p.player_side = PLAYER_SIDE_BTM
				tmp_p.load_area_type = AREA_TYPE_BTM_ALL_TOWERS
			}
		case 1:
			{
				if MATCH_TYPE_2V2_MATCH == match_type {
					tmp_p.player_side = PLAYER_SIDE_BTM
					tmp_p.load_area_type = AREA_TYPE_BTM_ALL_TOWERS
				} else {
					tmp_p.player_side = PLAYER_SIDE_TOP
					tmp_p.load_area_type = AREA_TYPE_TOP_ALL_TOWERS
				}
			}
		case 2:
			{
				tmp_p.player_side = PLAYER_SIDE_TOP
				tmp_p.load_area_type = AREA_TYPE_TOP_ALL_TOWERS
			}
		case 3:
			{
				tmp_p.player_side = PLAYER_SIDE_TOP
				tmp_p.load_area_type = AREA_TYPE_TOP_ALL_TOWERS
			}
		}

		cardcfgids := msg_p.GetCardCfgIds()
		cardlvls := msg_p.GetCardLvls()
		lib_count := int32(len(cardcfgids))
		tmp_p.fighting_cards = make([]*PlayerCard, DEF_CARD_SLOT_NUM)
		if lib_count <= DEF_CARD_SLOT_NUM {
			tmp_p.next_fight_c_idx = -1
			tmp_p.resting_lib_len = 0
			for idx := int32(0); idx < lib_count; idx++ {
				tmp_p.fighting_cards[idx] = &PlayerCard{CardId: cardcfgids[idx], Lvl: cardlvls[idx]}
			}
		} else {
			tmp_p.resting_cards = make([]*PlayerCard, lib_count-DEF_CARD_SLOT_NUM)
			tmp_p.resting_lib_len = lib_count - DEF_CARD_SLOT_NUM - 1
			if tmp_p.resting_lib_len > 0 {
				tmp_p.cur_rest_lib_idx = 0
				tmp_p.resting_lib_cards = make([]*PlayerCard, tmp_p.resting_lib_len)
			} else {
				tmp_p.cur_rest_lib_idx = -1
			}
			var tmp_val int32
			for idx := int32(0); idx < DEF_CARD_SLOT_NUM; idx++ {
				tmp_val = rand.Int31n(lib_count)
				tmp_p.fighting_cards[idx] = &PlayerCard{CardId: cardcfgids[tmp_val], Lvl: cardlvls[tmp_val]}
				lib_count--
				if tmp_val != lib_count {
					cardcfgids[tmp_val] = cardcfgids[lib_count]
					cardlvls[tmp_val] = cardlvls[lib_count]
				}
				if lib_count <= 0 {
					break
				}
			}

			tmp_p.rest_card_count = lib_count
			if tmp_p.rest_card_count > 0 {
				tmp_p.resting_cards = make([]*PlayerCard, tmp_p.rest_card_count)
				for idx := int32(0); idx < tmp_p.rest_card_count; idx++ {
					tmp_p.resting_cards[idx] = &PlayerCard{CardId: cardcfgids[idx], Lvl: cardlvls[idx]}
				}

				tmp_p.next_fight_c_idx = rand.Int31n(tmp_p.rest_card_count)
			}
		}

		log.Info("playr idx[%d] after init fightingcards:%v restingcards:%v nextcard_idx", idx, tmp_p.fighting_cards, tmp_p.resting_cards, tmp_p.next_fight_c_idx)
		tmp_p.fight_score = 0
		tmp_p.conn_lock = &sync.Mutex{}
		tmp_p.room = room
		tmp_p.token = msg_p.GetToken()
		tmp_p.loading_slots = make([]*PlayerCardUse, DEF_CARD_SLOT_NUM)
		tmp_p.loading_cards_count = int32(0)
		room.players = append(room.players, tmp_p)

		player_mgr.Add2IdMap(tmp_p)
	}

	return
}

func (this *Player) SetConn(conn *socket.TcpConn) {
	this.conn_lock.Lock()
	defer this.conn_lock.Unlock()
	if nil != this.conn {
		this.conn.Close(socket.E_DISCONNECT_REASON_OTHER_PLACE_LOGIN)
	}
	this.conn = conn
}

func (this *Player) Send(msg proto.Message) {
	this.conn_lock.Lock()
	defer this.conn_lock.Unlock()
	if nil != this.conn {
		this.conn.Send(msg)
	}
}

// 玩家管理器 ===================================================================

type PlayerManager struct {
	id2players      map[int32]*Player
	id2players_lock *sync.RWMutex
}

var player_mgr PlayerManager

func (this *PlayerManager) Init() bool {
	this.id2players = make(map[int32]*Player)
	this.id2players_lock = &sync.RWMutex{}

	this.RegMsgHandler()

	return true
}

func (this *PlayerManager) GetPlayerById(id int32) *Player {
	this.id2players_lock.Lock()
	defer this.id2players_lock.Unlock()

	return this.id2players[id]
}

func (this *PlayerManager) Add2IdMap(p *Player) {
	if nil == p {
		log.Error("Player_agent_mgr Add2IdMap p nil !")
		return
	}
	this.id2players_lock.Lock()
	defer this.id2players_lock.Unlock()

	if nil != this.id2players[p.Id] {
		log.Error("PlayerManager Add2IdMap already have player(%d)", p.Id)
	}

	this.id2players[p.Id] = p
}

func (this *PlayerManager) RemoveFromIdMap(id int32) {
	this.id2players_lock.Lock()
	defer this.id2players_lock.Unlock()
	if nil != this.id2players[id] {
		delete(this.id2players, id)
	}

	return
}

func (this *PlayerManager) PlayerLogout(p *Player) {
	if nil == p {
		log.Error("PlayerManager PlayerLogout p nil !")
		return
	}

	this.id2players_lock.Lock()
	defer this.id2players_lock.Unlock()

	this.RemoveFromIdMap(p.Id)
}

func (this *PlayerManager) OnTick() {

}

//==============================================================================
func (this *PlayerManager) RegMsgHandler() {
	server.SetMessageHandler(msg_client_message.ID_C2SEnterRoomReq, C2SEnterRoomReqHandler)
	server.SetMessageHandler(msg_client_message.ID_HeartBeat, HeartBeatHandler)
	server.SetMessageHandler(msg_client_message.ID_C2SUseCard, C2SUseCardHandler)
	server.SetMessageHandler(msg_client_message.ID_C2SEnterRoomReady, C2SEnterRoomReadyHanler)
}

func C2SEnterRoomReqHandler(conn *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SEnterRoomReq)
	if nil == conn || nil == req {
		log.Error("C2SEnterRoomReqHandler param error !")
		return
	}

	pid := int32(req.GetId())
	p := player_mgr.GetPlayerById(pid)
	if nil == p {
		log.Error("C2SEnterRoomReqHandler can not find player[%d]", pid)
		return
	}

	cur_room := p.room
	if nil == cur_room {
		log.Error("C2SEnterRoomReqHandler room nil")
		return
	}

	if ROOM_STATE_END == p.room.room_state {
		log.Error("")
	}

	if p.token != req.GetToken() {
		log.Error("C2SEnterRoomReqHandler token error(%d != %d) !!", p.token, req.GetToken())
		return
	}

	conn.T = int64(p.Id)
	p.SetConn(conn)

	if ROOM_STATE_END == p.room.room_state {
		log.Trace("C2SEnterRoomReqHandler room has end !!")
		return
	}

	p.room.loginout_chan <- &PlayerLoginoutReady{p: p, inout: PLAYER_LOGIN_OUT_READY_IN}

	log.Trace("C2SEnterRoomReqHandler %v", *req)
	return
}

func HeartBeatHandler(conn *socket.TcpConn, msg proto.Message) {
	return
}

func C2SUseCardHandler(conn *socket.TcpConn, msg proto.Message) {
	req := msg.(*msg_client_message.C2SUseCard)
	if nil == conn || nil == req {
		log.Error("C2SUseCardHandler param error !")
		return
	}

	if conn.T <= 0 {
		log.Error("C2SUseCardHandler not login !")
		return
	}

	p := player_mgr.GetPlayerById(int32(conn.T))
	if nil == p {
		log.Error("C2SUseCardHandler can not find player[%d] !", conn.T)
		return
	}

	res_2cli := &msg_client_message.S2CUseCardRes{}
	idx := req.GetIdx()
	res_2cli.Idx = proto.Int32(idx)
	if idx < 0 || idx >= DEF_CARD_SLOT_NUM {
		log.Error("C2SUseCardHandler idx[%d] error !", idx)
		conn.Send(res_2cli)
		return
	}

	x := req.GetX()
	y := req.GetY()

	if nil == p.room {
		log.Error("C2SUseCardHandler room nil !")
		return
	}

	card_use := &PlayerCardUse{}
	card_use.idx = idx
	card_use.p = p
	card_use.x = float32(int32(x))
	card_use.y = float32(int32(y))

	if ROOM_STATE_END == p.room.room_state {
		log.Trace("C2SUseCardHandler room has end !!")
		conn.Send(res_2cli)
		return
	}

	p.room.PlayerUseCard(card_use)

	log.Info("玩家[%d:%s] 请求使用卡片", p.Id, p.name, req.GetIdx())

	return
}

func C2SEnterRoomReadyHanler(conn *socket.TcpConn, msg proto.Message) {
	if nil == conn {
		log.Error("C2SUseCardHandler param error !")
		return
	}

	if conn.T <= 0 {
		log.Error("C2SUseCardHandler not login !")
		return
	}

	p := player_mgr.GetPlayerById(int32(conn.T))
	if nil == p {
		log.Error("C2SUseCardHandler get player[%d] failed !", conn.T)
		return
	}

	if nil != p.room {
		/*
			if p.room.p1.Id == p.Id {
				p.room.p1_b_ready = true
			} else if p.room.p2.Id == p.Id {
				p.room.p2_b_ready = true
			} else {
				log.Error("C2SUseCardHandler player[%d] not in room[%d]", p.Id, p.room.roomid)
			}
		*/
		p.room.loginout_chan <- &PlayerLoginoutReady{p: p, inout: PLAYER_LOGIN_OUT_READY_READY}
	} else {
		log.Error("C2SUseCardHandler =================  p room nil !")
	}

	return
}
