package main

import (
	"encoding/xml"
	"io/ioutil"
	"libs/log"
	"strconv"
	"strings"
)

type XmlBuff struct {
	BuffId       int32  `xml:"BuffId,attr"`
	EffectModel1 string `xml:"EffectModel1,attr"`
	EffectModel2 string `xml:"EffectModel2,attr"`
	EffectModel3 string `xml:"EffectModel3,attr"`
	EffectInfos1 *EffectModeParam
	EffectInfos2 *EffectModeParam
	EffectInfos3 *EffectModeParam
}

type XmlBuffConfig struct {
	Buffs []XmlBuff `xml:"item"`
}

type BuffConfigManager struct {
	Array []*XmlBuff
	Map   map[int32]*XmlBuff
}

var cfg_buff_mgr BuffConfigManager

func (this *BuffConfigManager) Init() bool {
	if !this.load() {
		return false
	}
	return true
}

func (this *BuffConfigManager) load() bool {
	content, err := ioutil.ReadFile("../game_data/BuffConfig.xml")
	if nil != err {
		log.Error("BuffConfigManager load ReadFile error(%s) !", err.Error())
		return false
	}

	xmlbuffcfg := &XmlBuffConfig{}
	err = xml.Unmarshal(content, &xmlbuffcfg)
	if nil != err {
		log.Error("BuffConfigManager load Unmarshal failed error(%s) !", err.Error())
		return false
	}

	this.Array = make([]*XmlBuff, 0, len(xmlbuffcfg.Buffs))
	this.Map = make(map[int32]*XmlBuff)
	var tmp_buff *XmlBuff
	int_val := int(0)
	for _, val := range xmlbuffcfg.Buffs {
		tmp_buff = &XmlBuff{}
		*tmp_buff = val

		if "" != tmp_buff.EffectModel1 {
			str_vals := strings.Split(tmp_buff.EffectModel1, "|")
			len_vals := int32(len(str_vals))
			if len_vals > 0 {
				effectinfo := &EffectModeParam{}
				int_val, err = strconv.Atoi(str_vals[0])
				if nil != err {
					log.Error("BuffConfigManager effectmodel1(%s) 配置错误(%s)不能转化出类型", tmp_buff.EffectModel1, err.Error())
					return false
				} else {
					effectinfo.EffectType = int32(int_val)
				}
				if len_vals > 1 {
					effectinfo.Params = make([]int32, len_vals-1)
					for i := int32(1); i < len_vals; i++ {
						int_val, err = strconv.Atoi(str_vals[i])
						if nil != err {
							log.Error("BuffConfigManager effectmodel1(%s) 配置错误(%s)参数错误", tmp_buff.EffectModel1, err.Error())
							return false
						} else {
							effectinfo.Params[i-1] = int32(int_val)
						}
					}
				}
				tmp_buff.EffectInfos1 = effectinfo
			} else {
				log.Error("BuffConfigManager effectmodel1(%s) 配置错误", tmp_buff.EffectModel1)
				return true
			}
		}

		if "" != tmp_buff.EffectModel2 {
			str_vals := strings.Split(tmp_buff.EffectModel2, "|")
			len_vals := int32(len(str_vals))
			if len_vals > 0 {
				effectinfo := &EffectModeParam{}
				int_val, err = strconv.Atoi(str_vals[0])
				if nil != err {
					log.Error("BuffConfigManager effectmodel2(%s) 配置错误(%s)不能转化出类型", tmp_buff.EffectModel2, err.Error())
					return false
				} else {
					effectinfo.EffectType = int32(int_val)
				}
				if len_vals > 1 {
					effectinfo.Params = make([]int32, len_vals-1)
					for i := int32(1); i < len_vals; i++ {
						int_val, err = strconv.Atoi(str_vals[i])
						if nil != err {
							log.Error("BuffConfigManager effectmodel2(%s) 配置错误(%s)参数错误", tmp_buff.EffectModel2, err.Error())
							return false
						} else {
							effectinfo.Params[i-1] = int32(int_val)
						}
					}
				}
				tmp_buff.EffectInfos2 = effectinfo
			} else {
				log.Error("BuffConfigManager effectmodel2(%s) 配置错误", tmp_buff.EffectModel2)
				return false
			}
		}

		if "" != tmp_buff.EffectModel3 {
			str_vals := strings.Split(tmp_buff.EffectModel3, "|")
			len_vals := int32(len(str_vals))
			if len_vals > 0 {
				effectinfo := &EffectModeParam{}
				int_val, err = strconv.Atoi(str_vals[0])
				if nil != err {
					log.Error("BuffConfigManager effectmodel3(%s) 配置错误(%s)不能转化出类型", tmp_buff.EffectModel3, err.Error())
					return false
				} else {
					effectinfo.EffectType = int32(int_val)
				}
				if len_vals > 1 {
					effectinfo.Params = make([]int32, len_vals-1)
					for i := int32(1); i < len_vals; i++ {
						int_val, err = strconv.Atoi(str_vals[i])
						if nil != err {
							log.Error("BuffConfigManager effectmodel3(%s) 配置错误(%s)参数错误", tmp_buff.EffectModel3, err.Error())
							return false
						} else {
							effectinfo.Params[i-1] = int32(int_val)
						}
					}
				}
				tmp_buff.EffectInfos3 = effectinfo
			} else {
				log.Error("BuffConfigManager effectmodel3(%s) 配置错误", tmp_buff.EffectModel3)
				return false
			}
		}
		this.Array = append(this.Array, tmp_buff)
		this.Map[tmp_buff.BuffId] = tmp_buff
	}

	return true
}
