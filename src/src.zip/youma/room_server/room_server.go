package main

import (
	"errors"
	"libs/log"
	"libs/socket"
	"libs/timer"
	"public_message/gen_go/client_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

type RoomServer struct {
	start_time         time.Time
	net                *socket.Node
	quit               bool
	shutdown_lock      *sync.Mutex
	shutdown_completed bool
	ticker             *timer.TickTimer
	initialized        bool
	last_gc_time       int32
}

var server RoomServer

func (this *RoomServer) Init() (ok bool) {
	this.start_time = time.Now()
	this.shutdown_lock = &sync.Mutex{}
	this.net = socket.NewNode(&server, time.Duration(config.RecvMaxMSec), time.Duration(config.SendMaxMSec), 5000, msg_client_message.MessageNames)

	err := this.OnInit()
	if err != nil {
		log.Error("登陆服务器初始化失败")
		return
	}

	this.initialized = true

	ok = true
	return
}

func (this *RoomServer) Start() (err error) {
	log.Event("服务器启动", nil)
	log.Trace("**************************************************")

	go this.Run()

	tmp_err := this.net.Listen(config.ListenClientInIP, config.MaxClientConns)
	if nil != tmp_err {
		log.Error("服务器启动失败 [%s] ！", tmp_err.Error())
		return
	}

	return
}

func (this *RoomServer) Run() {
	defer func() {
		if err := recover(); err != nil {
			log.Stack(err)
		}

		this.shutdown_completed = true
	}()

	this.ticker = timer.NewTickTimer(1000)
	this.ticker.Start()
	defer this.ticker.Stop()

	for {
		select {
		case _, ok := <-this.ticker.Chan:
			{
				if !ok {
					return
				}

				begin := time.Now()
				this.OnTick()
				time_cost := time.Now().Sub(begin).Seconds()
				if time_cost > 1 {
					log.Trace("耗时 %v", time_cost)
					if time_cost > 30 {
						log.Error("耗时 %v", time_cost)
					}
				}
			}
		}
	}
}

func (this *RoomServer) Shutdown() {
	log.Info("========================1")
	if !this.initialized {
		log.Info("========================2")
		match_conn.ShutDown()
		this.quit = true
		return
	}

	log.Info("========================3")
	this.shutdown_lock.Lock()
	defer this.shutdown_lock.Unlock()

	log.Info("========================4")
	if this.quit {
		return
	}
	log.Info("========================5")
	this.quit = true

	log.Trace("关闭游戏主循环")

	begin := time.Now()

	if this.ticker != nil {
		this.ticker.Stop()
	}

	for {
		if this.shutdown_completed {
			break
		}

		time.Sleep(time.Millisecond * 100)
	}

	match_conn.ShutDown()
	this.net.Shutdown()
	log.Trace("关闭游戏主循环耗时 %v 秒", time.Now().Sub(begin).Seconds())
}

func (this *RoomServer) OnInit() (err error) {
	if !player_mgr.Init() {
		return errors.New("player_mgr init failed")
	} else {
		log.Event("player_mgr init succeed !", nil)
	}
	log.Info("RoomServer OnInit !")

	//fight_room_mgr.TT_Room()

	return
}

func (this *RoomServer) OnTick() {
}

func (this *RoomServer) OnAccept(c *socket.TcpConn) {

}

func (this *RoomServer) OnConnect(c *socket.TcpConn) {

}

func (this *RoomServer) OnDisconnect(c *socket.TcpConn, reason socket.E_DISCONNECT_REASON) {
	log.Trace("断开连接[%v]", c.GetAddr())
	if c.T > 0 {
		p := player_mgr.GetPlayerById(int32(c.T))
		c.T = 0
		if nil != p {
			if nil != p.room {
				p.room.on_player_out(p)
			}
			//player_mgr.PlayerLogout(p)
		}
	}
}

type MessageHandler func(conn *socket.TcpConn, m proto.Message)

func (this *RoomServer) set_ih(type_id uint16, h socket.Handler) {
	t := msg_client_message.MessageTypes[type_id]
	if t == nil {
		log.Error("设置消息句柄失败，不存在的消息类型 %v", type_id)
		return
	}

	this.net.SetHandler(type_id, t, h)
}

func (this *RoomServer) SetMessageHandler(type_id uint16, h MessageHandler) {
	if h == nil {
		this.set_ih(type_id, nil)
		return
	}

	this.set_ih(type_id, func(c *socket.TcpConn, m proto.Message) {
		h(c, m)
	})
}

func (this *RoomServer) CloseConnection(c *socket.TcpConn, reason socket.E_DISCONNECT_REASON) {
	if c == nil {
		log.Error("参数为空")
		return
	}

	c.Close(reason)
}

func (this *RoomServer) OnUpdate(c *socket.TcpConn, t timer.TickTime) {
}
