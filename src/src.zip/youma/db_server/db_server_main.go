package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"libs/log"
	"os"
	"public_message/gen_go/server_message"
	"time"
)

type ServerConfig struct {
	ServerId          int32
	InnerVersion      string
	ServerName        string
	ListenMatchIP     string
	MaxMatchConntions int32
	LogConfigDir      string // 日志配置文件路径
	CenterServerIP    string // 连接AssistServer

	MYSQL_NAME    string
	MYSQL_IP      string
	MYSQL_ACCOUNT string
	MYSQL_PWD     string
	DBCST_MIN     int
	DBCST_MAX     int

	MYSQL_COPY_PATH string
}

var config ServerConfig
var shutingdown bool
var dbc DBC

func g_init() bool {
	err := dbc.Preload()
	if nil != err {
		log.Error("连接数据库预加载失败！！")
		return false
	} else {
		log.Event("数据库预加载成功!", nil)
	}

	if !signal_mgr.Init() {
		log.Error("signal mgr failed !")
		return false
	} else {
		log.Event("初始化：signal mgr init succeed ！", nil)
	}

	server = new(DbServer)
	if !server.Init() {
		return false
	}

	return true
}

func main() {
	defer func() {
		log.Event("关闭服务器", nil)
		if err := recover(); err != nil {
			log.Stack(err)
		}
		if nil != server {
			server.Shutdown()
		}
		time.Sleep(time.Second * 5)
	}()

	var temp_i int32

	config_file := "../conf/db_server.cfg"
	if len(os.Args) > 1 {
		arg_config_file := flag.String("f", "", "config file path")
		if arg_config_file != nil && *arg_config_file == "" {
			flag.Parse()
			fmt.Printf("配置参数 %s", *arg_config_file)
			config_file = *arg_config_file
		}
	}

	data, err := ioutil.ReadFile(config_file)
	if err != nil {
		fmt.Printf("读取配置文件失败 %v", err)
		return
	}
	err = json.Unmarshal(data, &config)
	if err != nil {
		fmt.Printf("解析配置文件失败 %v", err.Error())
		fmt.Scanln(&temp_i)
		return
	}

	// 加载日志配置
	log.Init("", config.LogConfigDir, true)
	log.Event("配置:服务器Id", config.ServerId)
	log.Event("配置:服务器监听MatchIP", config.ListenMatchIP)
	log.Event("配置:网络协议版本", int32(msg_server_message.E_VERSION_NUMBER))
	log.Event("配置:服务器名称", config.ServerName)

	log.Event("连接数据库", config.MYSQL_NAME, log.Property{"地址", config.MYSQL_IP})
	err = dbc.Conn(config.MYSQL_NAME, config.MYSQL_IP, config.MYSQL_ACCOUNT, config.MYSQL_PWD, config.MYSQL_COPY_PATH)
	if err != nil {
		log.Error("连接数据库失败 %v", err)
		return
	}

	g_init()

	server.Start()
}
