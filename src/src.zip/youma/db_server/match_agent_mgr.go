package main

import (
	"libs/log"
	"libs/server_conn"
	"public_message/gen_go/server_message"
	"sync"

	"3p/code.google.com.protobuf/proto"
)

type MatchAgent struct {
	Id   int32
	Name string

	conn      *server_conn.ServerConn
	conn_lock *sync.RWMutex
}

func new_matchagent(conn *server_conn.ServerConn, id int32, name string) *MatchAgent {
	if id <= 0 || nil == conn {
		log.Error("new_matchagent id <= 0 !")
		return nil
	}

	ret_mi := &MatchAgent{}
	ret_mi.Id = id
	ret_mi.Name = name
	ret_mi.conn = conn
	ret_mi.conn.T = id
	ret_mi.conn_lock = &sync.RWMutex{}

	return ret_mi
}

func (this *MatchAgent) SetConn(conn *server_conn.ServerConn) {
	if nil == conn {
		log.Error("MatchAgent SetConn in conn nil")
		return
	}

	this.conn_lock.Lock()
	defer this.conn_lock.Unlock()

	this.conn = conn
	return
}

func (this *MatchAgent) Disconnect() {
	this.conn_lock.Lock()
	defer this.conn_lock.Unlock()

	this.conn.Close(server_conn.E_DISCONNECT_REASON_FORCE_CLOSED)
}

type MatchAgentManager struct {
	id2matchagent   map[int32]*MatchAgent
	conn2matchagent map[*server_conn.ServerConn]*MatchAgent
	locker          *sync.RWMutex
	inited          bool
}

var match_agent_mgr MatchAgentManager

func (this *MatchAgentManager) Init() bool {
	this.id2matchagent = make(map[int32]*MatchAgent)
	this.conn2matchagent = make(map[*server_conn.ServerConn]*MatchAgent)
	this.locker = &sync.RWMutex{}

	this.RegMsgHandler()

	this.inited = true
	return true
}

func (this *MatchAgentManager) Has(id int32) (ok bool) {
	if !this.inited {
		return
	}
	this.locker.RLock()
	defer this.locker.RUnlock()
	_, o := this.id2matchagent[id]
	if o {
		ok = true
	}
	return
}

func (this *MatchAgentManager) Get(id int32) (info *MatchAgent) {
	if !this.inited {
		return
	}

	this.locker.RLock()
	defer this.locker.RUnlock()

	in, o := this.id2matchagent[id]
	if !o {
		return
	}

	info = in
	return
}

func (this *MatchAgentManager) Add(conn *server_conn.ServerConn, id int32, name string) (ok bool) {
	if !this.inited {
		return
	}

	this.locker.Lock()
	defer this.locker.Unlock()

	_, o := this.id2matchagent[id]
	if o {
		return
	}

	match_agent := new_matchagent(conn, id, name)
	this.id2matchagent[id] = match_agent
	this.conn2matchagent[conn] = match_agent
	conn.T = id

	ok = true
	return
}

func (this *MatchAgentManager) Remove(id int32) (ok bool) {
	if !this.inited {
		return
	}

	this.locker.Lock()
	defer this.locker.Unlock()

	info, o := this.id2matchagent[id]
	if !o {
		return
	}

	delete(this.id2matchagent, id)

	for k, v := range this.conn2matchagent {
		if info == v {
			delete(this.conn2matchagent, k)
			break
		}
	}
	ok = true
	return
}

func (this *MatchAgentManager) RemoveByConn(conn *server_conn.ServerConn) (ok bool) {
	if !this.inited {
		return
	}

	this.locker.Lock()
	defer this.locker.Unlock()

	info, o := this.conn2matchagent[conn]
	if !o {
		return
	}

	delete(this.conn2matchagent, conn)

	for k, v := range this.id2matchagent {
		if info == v {
			delete(this.id2matchagent, k)
			break
		}
	}

	ok = true
	return
}

//================================================================

func (this *MatchAgentManager) RegMsgHandler() {
	server.SetMessageHandler(msg_server_message.ID_M2DMatchServerRegister, M2DMatchServerRegisterHandler)
	server.SetMessageHandler(msg_server_message.ID_M2DMatchServerUnRegister, M2DMatchServerUnRegisterHandler)
}

func M2DMatchServerRegisterHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.M2DMatchServerRegister)
	if nil == c || nil == req {
		log.Error("M2DMatchServerRegisterHandler param error !")
		return
	}

	serverid := req.GetServerId()
	old_match := match_agent_mgr.Get(serverid)
	if nil != old_match {
		match_agent_mgr.Remove(old_match.Id)
		old_match.Disconnect()
		log.Error("M2DMatchServerRegisterHandler old_match(id:%d) (name:%s) not nil", old_match.Id, old_match.Name)
	}

	match_agent_mgr.Add(c, serverid, req.GetServerName())

	return
}

func M2DMatchServerUnRegisterHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.M2DMatchServerUnRegister)
	if nil == c || nil == req {
		log.Error("M2DMatchServerUnRegisterHandler param error !")
		return
	}

	serverid := req.GetServerId()
	old_match := match_agent_mgr.Get(serverid)
	if nil == old_match {
		return
	}

	match_agent_mgr.Remove(old_match.Id)
	old_match.Disconnect()

	log.Info("M2DMatchServerRegisterHandler serverid(%d)", serverid)
	return
}
