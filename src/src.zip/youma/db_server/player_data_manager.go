package main

import (
	"libs/log"
	"libs/server_conn"
	"public_message/gen_go/server_message"

	"3p/code.google.com.protobuf/proto"
)

const (
	MAX_CARD_TEAM_NUM = 11 // 目前最大10套卡牌
)

type PlayerDataManager struct {
}

var player_data_mgr PlayerDataManager

func (this *PlayerDataManager) Init() bool {
	this.RegMsgHandler()
	return true
}

func player_db_to_msg(playerid int32) (pmsg *msg_server_message.D2MPlayerDataResponse) {
	pdb := dbc.Players.GetRow(playerid)
	if nil == pdb {
		new_row := dbc.Players.AddRow(playerid)
		if nil == new_row {
			log.Error("player_db_to_msg AddRow pid(%d) failed !", playerid)
			return nil
		}

		pmsg = &msg_server_message.D2MPlayerDataResponse{}
		pmsg.PlayerId = proto.Int64(int64(playerid))
		pmsg.State = proto.Int32(1)
		log.Info("player_db_to_msg new player(%d) !", playerid)
		return
	} else {
		pmsg = &msg_server_message.D2MPlayerDataResponse{}
		pmsg.PlayerId = proto.Int64(int64(playerid))
		pmsg.State = proto.Int32(0)

		// 基础信息
		pmsg.BaseInfo = &msg_server_message.PlayerBaseInfo{}
		pmsg.BaseInfo.MatchScore = proto.Int32(pdb.Info.GetMatchScore())
		pmsg.BaseInfo.Coin = proto.Int32(pdb.Info.GetCoin())
		pmsg.BaseInfo.Diamond = proto.Int32(pdb.Info.GetDiamond())
		pmsg.BaseInfo.DayMatchRewardNum = proto.Int32(pdb.Info.GetDayMatchRewardNum())
		pmsg.BaseInfo.LastDayMatchRewardTime = proto.Int32(pdb.Info.GetLayMatchRewardTime())
		pmsg.BaseInfo.CurUseCardTeam = proto.Int32(pdb.Info.GetCurUseCardTeam())

		// 卡片数据
		all_cards := pdb.Cards.GetAll()
		pmsg.Cards = make([]*msg_server_message.PlayerCard, 0, len(all_cards))
		var tmp_card *msg_server_message.PlayerCard
		for _, d_card := range all_cards {
			if d_card.ConfigId <= 0 {
				continue
			}

			tmp_card = &msg_server_message.PlayerCard{}
			tmp_card.CardCfgId = proto.Int32(d_card.ConfigId)
			tmp_card.CardCount = proto.Int32(d_card.CardCount)

			pmsg.Cards = append(pmsg.Cards, tmp_card)
		}

		// 卡组数据
		all_teams := pdb.CardTeams.GetAll()
		pmsg.CardTeams = make([]*msg_server_message.CardTeam, 0, len(all_teams))
		var tmp_card_team *msg_server_message.CardTeam
		for _, d_card_t := range all_teams {
			tmp_card_team = &msg_server_message.CardTeam{}
			tmp_card_team.CardIds = d_card_t.CardCfgIds
			pmsg.CardTeams = append(pmsg.CardTeams, tmp_card_team)
		}

		return
	}
}

func player_msg_to_db_update(pmsg *msg_server_message.M2DPlayerDataUpdate, playerid int32) {
	if nil == pmsg {
		log.Error("player_msg_to_db_update param error !")
		return
	}

	pdb := dbc.Players.GetRow(playerid)
	if nil == pdb {
		log.Error("player_msg_to_db_update not find player(%d) in db !", playerid)
		return
	}

	// 更新玩家基础数据
	base_info := pmsg.GetBaseInfo()
	if nil != base_info {

	}

	// 更新卡片数据
	old_id_map := pdb.Cards.GetAllIIndexMap()
	tmp_card := &dbPlayerCardData{}
	for _, val_card := range pmsg.Cards {
		if nil == val_card {
			continue
		}

		tmp_card.ConfigId = val_card.GetCardCfgId()
		tmp_card.CardCount = val_card.GetCardCount()

		if 1 == old_id_map[tmp_card.ConfigId] {
			pdb.Cards.Set(*tmp_card)
			old_id_map[tmp_card.ConfigId] = 2
		} else {
			pdb.Cards.Add(tmp_card)
		}
	}

	for card_id, val := range old_id_map {
		if 1 == val {
			pdb.Cards.Remove(card_id)
		}
	}

	// 更新卡组数据

	return
}

func (this *PlayerDataManager) RegMsgHandler() {
	server.SetMessageHandler(msg_server_message.ID_M2DGetPlayerData, M2DGetPlayerDataHandler)
}

func M2DGetPlayerDataHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.M2DGetPlayerData)
	if nil == c || nil == req {
		log.Error("M2DGetPlayerDataHandler param error !")
		return
	}

	res := player_db_to_msg(int32(req.GetPlayerId()))
	if nil == res {
		log.Error("M2DGetPlayerDataHandler player_db_to_msg return nil !")
		return
	}

	c.Send(res, true)

	log.Info("M2DGetPlayerDataHandler %v", req)

	return
}

func M2DPlayerDataUpdateHandler(c *server_conn.ServerConn, msg proto.Message) {
	req := msg.(*msg_server_message.M2DPlayerDataUpdate)
	if nil == c || nil == req {
		log.Error("M2DGetPlayerDataHandler param error !")
		return
	}

}
