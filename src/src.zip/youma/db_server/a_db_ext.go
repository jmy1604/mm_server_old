package main

import (
	"3p/code.google.com.protobuf/proto"
)

func (this *DBC) on_preload() (err error) {
	for _, row := range this.Players.m_rows {
		if nil == row {
			continue
		}

	}
	return
}

func (this *dbPlayerCardColumn) GetAllIIndexMap() map[int32]int32 {
	ret_map := make(map[int32]int32)
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for k, _ := range this.m_data {
		ret_map[k] = 1
	}
	return ret_map
}

func (this *dbPlayerCardColumn) GetAllClientMsgCards() map[int32]int32 {
	ret_map := make(map[int32]int32)
	this.m_row.m_lock.UnSafeRLock("dbPlayerCardColumn.GetAllIndex")
	defer this.m_row.m_lock.UnSafeRUnlock()
	for k, _ := range this.m_data {
		ret_map[k] = 1
	}
	return ret_map
}
