package main

import (
	"libs/log"
	"libs/server_conn"
	"libs/timer"
	"public_message/gen_go/server_message"
	"sync"
	"time"

	"3p/code.google.com.protobuf/proto"
)

type DbServer struct {
	start_time         time.Time
	server_node        *server_conn.Node
	quit               bool
	shutdown_lock      *sync.Mutex
	shutdown_completed bool
	ticker             *timer.TickTimer
	initialized        bool
	last_gc_time       int32
}

var server *DbServer

func (this *DbServer) Init() (ok bool) {
	this.start_time = time.Now()
	this.shutdown_lock = &sync.Mutex{}
	this.server_node = server_conn.NewNode(this, 0, 0, 5000, 0, 0, 0, 0, 0)
	this.server_node.SetDesc("", "匹配服务器")

	err := this.OnInit()
	if err != nil {
		log.Error("登陆服务器初始化失败")
		return
	}

	this.initialized = true

	ok = true
	return
}

func (this *DbServer) Start() (err error) {
	log.Event("服务器已启动", nil)
	go this.Run()
	err = this.server_node.Listen(config.ListenMatchIP, config.MaxMatchConntions)
	if err != nil {
		log.Error("启动服务器失败 %v", err)
		return
	}

	return
}

func (this *DbServer) Run() {
	defer func() {
		if err := recover(); err != nil {
			log.Stack(err)
		}

		this.shutdown_completed = true
	}()

	this.ticker = timer.NewTickTimer(1000)
	this.ticker.Start()
	defer this.ticker.Stop()

	for {
		select {
		case _, ok := <-this.ticker.Chan:
			{
				if !ok {
					return
				}

				begin := time.Now()
				this.OnTick()
				time_cost := time.Now().Sub(begin).Seconds()
				if time_cost > 1 {
					log.Trace("耗时 %v", time_cost)
					if time_cost > 30 {
						log.Error("耗时 %v", time_cost)
					}
				}
			}
		}
	}
}

func (this *DbServer) Shutdown() {
	if !this.initialized {
		return
	}

	this.shutdown_lock.Lock()
	defer this.shutdown_lock.Unlock()

	if this.quit {
		return
	}
	this.quit = true

	this.server_node.Shutdown()

	log.Trace("关闭游戏主循环")

	begin := time.Now()

	if this.ticker != nil {
		this.ticker.Stop()
	}

	for {
		if this.shutdown_completed {
			break
		}

		time.Sleep(time.Millisecond * 100)
	}

	log.Trace("关闭游戏主循环耗时 %v 秒", time.Now().Sub(begin).Seconds())

	dbc.Save(false)
}

func (this *DbServer) OnInit() (err error) {
	if !match_agent_mgr.Init() {
		log.Error("match_agent_mgr init failed !")
		return
	} else {
		log.Event("match_agent_mgr init succeed !", nil)
	}

	if !player_data_mgr.Init() {
		log.Error("player_data_mgr init failed !")
		return
	} else {
		log.Event("player_data_mgr init succeed !", nil)
	}

	return
}

func (this *DbServer) OnTick() {
}

func (this *DbServer) OnAccept(c *server_conn.ServerConn) {

}

func (this *DbServer) OnConnect(c *server_conn.ServerConn) {

}

func (this *DbServer) OnDisconnect(c *server_conn.ServerConn, reason server_conn.E_DISCONNECT_REASON) {
	log.Trace("MatchServer[%d]断开连接[%v]", c.T, c.GetAddr())
	if c.T > 0 {
		match_agent_mgr.Remove(c.T)
	}
}

type MessageHandler func(conn *server_conn.ServerConn, m proto.Message)

func (this *DbServer) set_ih(type_id uint16, h server_conn.Handler) {
	t := msg_server_message.MessageTypes[type_id]
	if t == nil {
		log.Error("设置消息句柄失败，不存在的消息类型 %v", type_id)
		return
	}

	this.server_node.SetHandler(type_id, t, h)
}

func (this *DbServer) SetMessageHandler(type_id uint16, h MessageHandler) {
	if h == nil {
		this.set_ih(type_id, nil)
		return
	}

	this.set_ih(type_id, func(c *server_conn.ServerConn, m proto.Message) {
		h(c, m)
	})
}

func (this *DbServer) CloseConnection(c *server_conn.ServerConn, reason server_conn.E_DISCONNECT_REASON) {
	if c == nil {
		log.Error("DbServer CloseConnection 参数为空")
		return
	}

	c.Close(reason)
}

func (this *DbServer) OnUpdate(c *server_conn.ServerConn, t timer.TickTime) {
}
