package main

import (
	"fmt"
	"io"
	"runtime"
	"time"
	//"io"
	//"log"
	"net"
)

func recv_loop(conn *net.Conn) {
	if nil == conn {
		return
	}

	recvbuf := make([]byte, 5)

	fmt.Println("start recv_loop")

	for {
		fmt.Println("start recv_loop1")
		n, err := (*conn).Read(recvbuf)
		fmt.Println("start recv_loop2")
		if nil != err {
			fmt.Println("conn read failed", err.Error())
		} else {
			fmt.Println("conn read succeeded", n)
			for _, info := range recvbuf {
				fmt.Println(info)
			}
		}
	}
}

func main() {
	runtime.GOMAXPROCS(runtime.NumCPU())

	conn, err := net.Dial("tcp", "127.0.0.1:2000")
	if nil != err {
		fmt.Println("net Dial failed !", err.Error())
		return
	}

	go recv_loop(&conn)

	time.Sleep(100)

	test_str := "djalkdjajll"
	n, err := io.WriteString(conn, test_str)
	if nil != err {
		fmt.Println("Io writestring failed", err.Error())
	} else {
		fmt.Println("Io writestring succeeded", n)
	}

	for {
		//time.Sleep(1)
	}
}
